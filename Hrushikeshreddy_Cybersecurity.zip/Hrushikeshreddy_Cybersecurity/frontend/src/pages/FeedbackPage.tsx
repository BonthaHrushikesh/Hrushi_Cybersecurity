import {
  CheckCircle2,
  MessageSquareText,
  ThumbsDown,
  ThumbsUp,
} from "lucide-react";
import { feedbackApi } from "../api";
import {
  LoadingSkeleton,
  ErrorState,
  PageHeader,
  Panel,
  StatusBadge,
} from "../components/ui";
import { useApiResource } from "../hooks/useApiResource";
import type { Feedback } from "../types";
import { formatDate } from "../utils/format";

const demoFeedback: Feedback[] = [
  {
    id: 1,
    context_type: "investigation",
    incident_id: "DEMO-INV-10293",
    context: "DEMO-INV-10293",
    created_at: new Date().toISOString(),
    helpful: 1,
    comment: "Evidence and priority were useful for triage.",
    review_status: "pending",
  },
];
export function FeedbackPage() {
  const query = useApiResource(["feedback"], feedbackApi.list, demoFeedback);
  if (!query.data) return query.isLoading ? <LoadingSkeleton rows={5} /> : <ErrorState message="Analyst feedback is unavailable." onRetry={() => query.refetch()} />;
  const rows = query.data;
  const useful = rows.filter((x) => x.helpful).length;
  return (
    <div>
      <PageHeader
        eyebrow="Human oversight"
        title="Analyst Feedback"
        description="Review analyst assessments that support governed model and recommendation improvement."
      />
      <div className="mb-5 grid gap-4 sm:grid-cols-3">
        <Panel title="Total Feedback" eyebrow="Records">
          <strong className="text-3xl">{rows.length}</strong>
        </Panel>
        <Panel title="Marked Useful" eyebrow="Analyst signal">
          <strong className="text-3xl text-emerald-400">{useful}</strong>
        </Panel>
        <Panel title="Pending Review" eyebrow="Governance">
          <strong className="text-3xl text-amber-400">
            {rows.filter((x) => x.review_status === "pending").length}
          </strong>
        </Panel>
      </div>
      {query.isLoading ? (
        <LoadingSkeleton rows={5} />
      ) : (
        <Panel title="Feedback Registry" eyebrow="Review queue">
          <div className="space-y-3">
            {rows.map((row) => (
              <article
                key={`${row.context_type}:${row.id}`}
                className="rounded-lg border border-white/[.07] p-4"
              >
                <div className="flex flex-wrap items-center gap-2">
                  {row.helpful ? (
                    <ThumbsUp size={16} className="text-emerald-400" />
                  ) : (
                    <ThumbsDown size={16} className="text-red-400" />
                  )}
                  <strong className="text-xs">
                    {row.context_type === "investigation"
                      ? row.incident_id
                      : row.context_type === "ai_analyst" ? "AI Analyst" : "RAG Search"}
                  </strong>
                  <StatusBadge status={row.review_status} />
                  <span className="ml-auto text-xs text-zinc-600">
                    {formatDate(row.created_at)}
                  </span>
                </div>
                {row.context_type !== "investigation" && (
                  <p className="mt-3 break-words text-xs text-zinc-500">
                    Query: {row.context}
                  </p>
                )}
                <p className="mt-3 text-sm text-zinc-400">
                  {row.comment || "No analyst note supplied."}
                </p>
                {(row.corrected_attack_type || row.corrected_severity) && (
                  <p className="mt-2 text-xs text-gold">
                    Correction:{" "}
                    {row.corrected_attack_type || "attack unchanged"} ·{" "}
                    {row.corrected_severity || "severity unchanged"}
                  </p>
                )}
              </article>
            ))}
            {rows.length === 0 && (
              <div className="flex min-h-48 flex-col items-center justify-center text-zinc-600">
                <MessageSquareText />
                <p className="mt-2 text-sm">No feedback submitted yet.</p>
              </div>
            )}
          </div>
        </Panel>
      )}
      <div className="mt-5 flex gap-3 rounded-lg border border-emerald-400/15 bg-emerald-400/[.035] p-4 text-xs leading-5 text-zinc-500">
        <CheckCircle2 size={17} className="shrink-0 text-emerald-400" />
        Corrections remain pending until reviewed. They are not automatically
        promoted into training data.
      </div>
    </div>
  );
}
