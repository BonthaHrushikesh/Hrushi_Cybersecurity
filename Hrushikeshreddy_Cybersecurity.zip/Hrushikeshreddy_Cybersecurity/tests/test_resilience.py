import pytest

from src.services.provider_resilience import CircuitOpenError, ProviderCircuit


def test_circuit_skips_provider_and_recovers_after_cooldown(monkeypatch):
    clock = [10.0]
    monkeypatch.setattr("src.services.provider_resilience.monotonic", lambda: clock[0])
    circuit = ProviderCircuit(2, 60)
    calls = []

    def fail():
        calls.append(1)
        raise TimeoutError("private provider error")

    for _ in range(2):
        with pytest.raises(TimeoutError):
            circuit.call(fail)
    with pytest.raises(CircuitOpenError):
        circuit.call(fail)
    assert len(calls) == 2
    clock[0] += 61
    assert circuit.call(lambda: "recovered") == "recovered"
    assert circuit.call(lambda: "available") == "available"


def test_empty_generated_analysis_is_rejected(investigation):
    from src.api.schemas import Analysis
    from src.services.recommendations import validate_grounding

    analysis = Analysis.model_validate(investigation["analysis"])
    analysis.immediate_investigation = []
    with pytest.raises(ValueError, match="omits evidence"):
        validate_grounding(analysis, {})
