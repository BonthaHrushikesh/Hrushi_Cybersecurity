import type { InvestigationResult, WorkflowStep } from '../types'

export function workflowDetail(result: InvestigationResult, step: WorkflowStep): string | undefined {
  if (step.detail) return step.detail
  if (step.agent === 'Quality Judge Agent') {
    if (!result.judge) return 'LLM judging was not requested for this investigation (judge=false). No quality scores were generated.'
    return result.judge.limitation || (result.judge.status === 'completed'
      ? `Evidence-aware LLM judging completed using ${result.judge.provider}.`
      : `LLM judge status: ${result.judge.status}. No quality scores were generated.`)
  }
  if (step.agent === 'Response Recommendation Agent') {
    if (result.analysis_provider === 'local_fallback') return result.analysis.evidence_limitations.find(item => item.includes('local evidence-based playbook'))
      || 'Live response generation failed; local evidence-based recommendations were retained.'
    if (result.analysis_provider === 'local_evidence_playbook') return 'Recommendations were generated from the local evidence playbook; live LLM generation was not used.'
    return `Analysis provider: ${result.analysis_provider}.`
  }
  return undefined
}
