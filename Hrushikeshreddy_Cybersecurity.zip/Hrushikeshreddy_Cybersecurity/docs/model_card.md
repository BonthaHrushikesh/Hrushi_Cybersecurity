# Model Card

## Intended Use

Defensive network-flow analyst triage. Outputs are hypotheses, not attack
attribution, legal evidence, or permission for automatic containment.

## Dataset And Models

Active version: cicids-aa6f46dbeb. Primary TrafficLabelling CSVs, 20,273 prepared
flows, nine categories, 77 raw and three derived features. Flow/incident IDs,
IPs, timestamps, and labels are excluded from numeric inputs. Destination port
remains an observed service feature with environment-memorization risk.

Random Forest: 100 trees, balanced weights, seed 42, maximum depth 24, minimum
leaf size two. Extra Trees is the validation comparison. Separate binary
Random Forest predicts intrusion likelihood. Benign-only Isolation Forest
provides anomaly unusualness. Saved training imputation accompanies inference.
Exact TreeSHAP explains local output; global impurity importance is separate.

## Measured Results

Validation macro F1: Random Forest 0.9851274; Extra Trees 0.9674945.
Refit history/training: 16,218; final test: 4,055.
Test accuracy 0.9921085, macro F1 0.9743258, binary accuracy 0.9930949,
binary ROC AUC 0.9961082, anomaly ROC AUC 0.7627583.
Heartbleed test support two; Infiltration seven. See evaluation_report.md.

## Limitations And Governance

Sampled class priors, uncalibrated probabilities, related-session leakage,
source-clock uncertainty, rare support, partial-input imputation, and network
distribution shift prevent production generalization claims. Metadata permits
time/host-disjoint experiments, but none was performed. SHAP is attribution,
not causation; anomalous does not mean malicious.

Labels/original subtypes and genuine metadata are preserved. UTC is user-declared,
not source-verified. No measurements or incidents are synthesized to improve scores.
The 467-row portable demo has separate artifacts and different metrics.

Versioning includes prepared-data and training/holdout fingerprints. Joblib
artifacts must be trusted local artifacts, never accepted as uploads. Feedback
requires review; candidate training protects the fixed holdout; promotion is
manual. LLM narrative is separately validated and may fall back. Current live
Claude/DeepEval quality remains unverified because authentication returned 401.
