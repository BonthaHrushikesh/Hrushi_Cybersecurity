"""Build the named capstone PDF deliverables from repository-owned sources."""

from __future__ import annotations

import argparse
import html
import re
import shutil
import subprocess
import sys
from pathlib import Path

from markdown_it import MarkdownIt


ROOT = Path(__file__).resolve().parents[1]
MARKDOWN = MarkdownIt("commonmark", {"html": True}).enable("table")

REPORTS = (
    (ROOT / "docs/design.md", ROOT / "design/Design_Document.html", "Design Document", "Architecture, retrieval, agents, evaluation, and trade-offs"),
    (ROOT / "docs/api.md", ROOT / "docs/API_Documentation.html", "API Documentation", "FastAPI contracts, examples, guardrails, and response models"),
    (ROOT / "docs/dataset_details.md", ROOT / "docs/Dataset_Details.html", "Dataset Details", "CIC-IDS2017 source, fields, preparation, purpose, and limitations"),
    (ROOT / "docs/evaluation_report.md", ROOT / "docs/Evaluation_Report.html", "Evaluation Report", "Measured ML, retrieval, quality, API, and interface verification"),
)


REPORT_CSS = """
  :root{--ink:#20252b;--muted:#69737e;--line:#d8dde2;--gold:#b78615;--paper:#fff;--soft:#f4f6f7}
  *{box-sizing:border-box}html,body{margin:0;color:var(--ink);background:#e8ebee;font-family:Inter,"Segoe UI",Arial,sans-serif;font-size:10pt;line-height:1.48;print-color-adjust:exact;-webkit-print-color-adjust:exact}
  @page{size:A4 portrait;margin:16mm 15mm 17mm}@page cover{size:A4 portrait;margin:0}.cover{page:cover;width:210mm;height:297mm;margin:0;background:#0c0f12;color:#f1f3f5;padding:28mm 23mm;page-break-after:always;position:relative}.cover:before{content:"";position:absolute;left:23mm;top:20mm;width:35mm;height:3px;background:#d7aa34}.cover .kind{color:#f0cf73;font-size:9pt;letter-spacing:2px;font-weight:800;margin-top:20mm}.cover h1{color:#f1f3f5;font-size:34pt;line-height:1.08;margin:9mm 0 7mm;max-width:150mm}.cover .subtitle{color:#aeb7c1;font-size:14pt;max-width:145mm}.cover .meta{position:absolute;bottom:24mm;left:23mm;right:23mm;border-top:1px solid #39414a;padding-top:5mm;display:flex;justify-content:space-between;color:#9ca6b1;font-size:8pt}.document{max-width:180mm;min-width:0;margin:0 auto;background:var(--paper);overflow-wrap:anywhere}.document>h1:first-child{display:none}h1,h2,h3,h4{letter-spacing:0;line-height:1.2;page-break-after:avoid;color:#15191e}h1{font-size:24pt}h2{font-size:17pt;border-bottom:1px solid var(--line);padding-bottom:2mm;margin:9mm 0 4mm;color:#1e252c}h2:before{content:"";display:inline-block;width:4mm;height:4mm;background:var(--gold);margin-right:3mm}h3{font-size:12pt;margin:6mm 0 2mm}p{margin:0 0 3mm}a{color:#7b5b0d;text-decoration:none}ul,ol{margin:2mm 0 4mm;padding-left:6mm}li{margin:1.2mm 0}table{border-collapse:collapse;table-layout:fixed;width:100%;font-size:8.5pt;margin:3mm 0 6mm;page-break-inside:auto}tr{page-break-inside:avoid}th{background:#20262c;color:#fff;text-align:left;padding:2.2mm;border:1px solid #313941;overflow-wrap:anywhere}td{padding:2mm;border:1px solid var(--line);vertical-align:top;overflow-wrap:anywhere;word-break:break-word}tr:nth-child(even) td{background:var(--soft)}code{font-family:"SFMono-Regular",Consolas,monospace;color:#6d500c;background:#f5f1e7;padding:.2mm .8mm;border-radius:2px;white-space:normal;overflow-wrap:anywhere}pre{background:#15191e;color:#e8edf1;padding:4mm;border-radius:4px;white-space:pre-wrap;word-break:break-word;font-size:8pt;page-break-inside:avoid}pre code{background:none;color:inherit;padding:0}blockquote{margin:4mm 0;padding:3mm 4mm;border-left:3px solid var(--gold);background:#f7f3e9;color:#4f5861}img{max-width:100%;height:auto;border:1px solid var(--line);border-radius:4px;margin:3mm 0 5mm}.doc-footer{position:fixed;bottom:-11mm;left:0;right:0;border-top:1px solid #d8dde2;padding-top:2mm;color:#7a838d;font-size:7pt;display:flex;justify-content:space-between}
"""

SLIDE_CSS = """
  :root{--ink:#17262b;--muted:#5c6b70;--line:#dce4e7;--teal:#087f8c;--green:#18856c;--orange:#b75920}
  *{box-sizing:border-box}html,body{margin:0;background:#e9eef0;color:var(--ink);font-family:Arial,"Segoe UI",sans-serif;print-color-adjust:exact;-webkit-print-color-adjust:exact;letter-spacing:0}
  @page{size:13.333333in 7.5in;margin:0}.slide{width:13.333333in;height:7.5in;padding:40px 64px 30px;background:#fff;display:flex;flex-direction:column;page-break-after:always;overflow:hidden;border-top:6px solid var(--teal)}.slide:last-child{page-break-after:auto}
  .head{display:flex;align-items:flex-start;justify-content:space-between;gap:26px;border-bottom:1px solid var(--line);padding-bottom:22px}.kicker{font-size:12px;font-weight:700;color:var(--teal);margin-bottom:9px}.slide h1{font-size:36px;line-height:1.14;margin:0;font-weight:700;max-width:950px;overflow-wrap:anywhere}.slide[data-slide="1"] h1{font-size:40px}.brand{font-size:12px;line-height:1.6;color:var(--muted);text-align:right;flex-shrink:0;max-width:150px}
  .body{display:grid;grid-template-columns:.92fr 1.38fr;gap:40px;padding:27px 0 20px;flex:1;min-height:0;align-items:center}.content ul{padding-left:22px;margin:0}.content li{font-size:22px;line-height:1.38;margin-bottom:21px}.content li:last-child{margin-bottom:0}.content strong{color:var(--teal)}.visual{min-width:0;overflow-wrap:anywhere}.caption{font-size:14px;line-height:1.4;color:var(--muted);margin:14px 0 0}
  .media-window{height:365px;overflow:hidden;border:1px solid var(--line);background:#090909}.media-window img{width:100%;height:auto;display:block}.media-window.result{height:365px}.visual h2{font-size:20px;line-height:1.2;margin:0 0 14px}.visual h3{font-size:15px;margin:0 0 8px;color:var(--teal)}
  .question-row{padding:18px 0;border-bottom:1px solid var(--line);display:grid;grid-template-columns:1.05fr 1fr;gap:24px;font-size:19px;line-height:1.4}.question-row strong{font-weight:700}.question-row span{color:var(--muted)}
  .data-lead{display:flex;gap:30px;border-bottom:1px solid var(--line);padding-bottom:20px;margin-bottom:18px}.data-lead strong{font-size:38px;display:block;color:var(--teal)}.data-lead span{font-size:15px;color:var(--muted)}.data-table{width:100%;border-collapse:collapse;font-size:20px;line-height:1.3}.data-table td{border-bottom:1px solid var(--line);padding:12px 0}.data-table td:last-child{text-align:right;font-weight:700;padding-left:14px}.category-line{font-size:15px;line-height:1.55;color:var(--muted);margin-top:18px}
  .lane{margin-bottom:24px}.flow-row{display:grid;grid-template-columns:repeat(3,1fr);gap:15px}.flow-row.four{grid-template-columns:repeat(4,1fr)}.node{border-top:3px solid var(--teal);border-bottom:1px solid var(--line);padding:13px 5px 16px;position:relative;font-size:19px;line-height:1.3;font-weight:700}.node small{font-size:14px;display:block;color:var(--muted);font-weight:400;margin-top:7px}.node:not(:last-child):after{content:">";position:absolute;right:-13px;top:18px;color:var(--teal);font-size:18px}.stack{font-size:16px;line-height:1.65;color:var(--muted)}
  .retrieval-pair{display:grid;grid-template-columns:1fr 1fr;gap:28px;border-bottom:1px solid var(--line);padding:17px 0}.retrieval-pair strong{font-size:24px;display:block}.retrieval-pair span{font-size:16px;line-height:1.5;color:var(--muted);display:block;margin-top:8px}.retrieval-stage{padding:17px 0;border-bottom:1px solid var(--line);font-size:21px;font-weight:700;color:var(--teal)}.retrieval-stage small{display:block;font-size:15px;line-height:1.4;font-weight:400;color:var(--muted);margin-top:6px}
  .answer-row{display:grid;grid-template-columns:135px 1fr;gap:18px;padding:17px 0;border-bottom:1px solid var(--line);font-size:23px;line-height:1.3}.answer-row strong{color:var(--teal)}.answer-row small{font-size:16px;display:block;color:var(--muted);margin-top:5px}.priority-line{font-size:15px;line-height:1.5;margin-top:20px;color:var(--muted)}
  .agent-row{display:grid;grid-template-columns:28px 150px 1fr;gap:10px;padding:10px 0;border-bottom:1px solid var(--line);align-items:baseline;font-size:17px;line-height:1.3}.agent-row .order{color:var(--teal);font-size:14px;font-weight:700}.agent-row small{font-size:15px;color:var(--muted)}.metric-table{width:100%;border-collapse:collapse;font-size:18px;line-height:1.3}.metric-table td{padding:12px 0;border-bottom:1px solid var(--line)}.metric-table td:last-child{text-align:right;color:var(--teal);font-size:25px;font-weight:700;padding-left:14px}.scope{font-size:14px;color:var(--muted);line-height:1.5;margin-top:15px}.delivery{padding:20px 0;border-bottom:1px solid var(--line)}.delivery strong{display:block;font-size:20px;margin-bottom:10px;color:var(--green)}.delivery.pending strong{color:var(--orange)}.delivery p{font-size:18px;line-height:1.5;margin:0;color:var(--muted)}
  .footer{display:flex;justify-content:space-between;gap:18px;align-items:center;border-top:1px solid var(--line);padding-top:13px;color:var(--muted);font-size:12px;min-height:30px}.footer strong{color:var(--ink);font-weight:700}
  @media screen and (max-width:900px){.slide{width:100%;height:auto;min-height:720px;padding:28px 24px}.head{gap:12px}.slide h1,.slide[data-slide="1"] h1{font-size:30px}.brand{display:none}.body{grid-template-columns:1fr;gap:24px;padding-top:24px}.content li{font-size:20px;margin-bottom:14px}.media-window,.media-window.result{height:300px}.flow-row.four{grid-template-columns:repeat(2,1fr)}.flow-row.four .node:nth-child(2):after{content:none}.node{font-size:17px}.question-row{font-size:17px;gap:14px}.data-lead{gap:24px}.data-lead strong{font-size:32px}.answer-row{grid-template-columns:110px 1fr;font-size:20px}.agent-row{grid-template-columns:22px 125px 1fr;font-size:16px}.agent-row small{font-size:14px}.metric-table{font-size:16px}.metric-table td:last-child{font-size:22px}.footer{margin-top:20px;font-size:11px}}
"""


def report_document(source: Path, title: str, subtitle: str) -> str:
    text = source.read_text(encoding="utf-8")
    if source.name == "api.md":
        examples = ROOT / "docs/API_Examples.md"
        if examples.exists():
            text += "\n\n" + examples.read_text(encoding="utf-8")
    rendered = MARKDOWN.render(text)
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><title>{html.escape(title)}</title><style>{REPORT_CSS}</style></head><body>
<section class="cover"><div class="kind">CAPSTONE DELIVERABLE</div><h1>{html.escape(title)}</h1><p class="subtitle">{html.escape(subtitle)}</p><div class="meta"><span>Hrushikeshreddy | Cybersecurity Incident Response</span><span>11 October 2026</span></div></section>
<main class="document">{rendered}<div class="doc-footer"><span>AI-Powered Cybersecurity Incident Response Assistant</span><span>{html.escape(title)}</span></div></main></body></html>"""


def presentation_sections(source: Path) -> list[dict]:
    raw = source.read_text(encoding="utf-8")
    matches = re.findall(r"^## Slide (\d+): ([^\n]+)\n(.*?)(?=^## Slide \d+:|^## Likely Panel Questions|\Z)", raw, re.M | re.S)
    slides = []
    for number, heading, section in matches:
        duration = re.search(r" \((\d+) Seconds\)$", heading)
        content = re.search(r"Content:\s*(.*?)(?=\nVisual:|\nSpeaker notes|\Z)", section, re.S)
        caption = re.search(r"Visual:\s*([^\n]+)", section)
        notes = re.search(r"Speaker notes:\s*(.*?)(?=\nDemo sequence:|\nBackup:|\Z)", section, re.S)
        demo = re.search(r"Demo sequence:\s*(.*?)(?=\nBackup:|\Z)", section, re.S)
        if not all([duration, content, caption, notes]):
            raise ValueError(f"Slide {number} is missing content, timing, visual caption, or speaker notes")
        slides.append({"number": int(number), "title": heading[:duration.start()], "seconds": int(duration.group(1)),
                       "content": content.group(1).strip(), "caption": caption.group(1).strip(),
                       "notes": notes.group(1).strip(), "demo": demo.group(1).strip() if demo else ""})
    if [slide["number"] for slide in slides] != list(range(1, 11)) or sum(slide["seconds"] for slide in slides) != 600:
        raise ValueError("The capstone presentation must have ten ordered slides totaling 600 seconds")
    return slides


def slide_visual(number: int) -> str:
    visuals = {
        1: '<div class="media-window"><img src="../artifacts/figures/dashboard-desktop.png" alt="Actual dashboard showing historical traffic counts"></div>',
        2: '<div class="question-row"><strong>Has this happened before?</strong><span>Similar historical incidents</span></div><div class="question-row"><strong>What does the traffic suggest?</strong><span>Prediction and feature explanation</span></div><div class="question-row"><strong>What should I investigate first?</strong><span>Priority and defensive next steps</span></div>',
        3: '<div class="data-lead"><div><strong>9</strong><span>categories, including benign</span></div><div><strong>80</strong><span>77 raw + 3 derived inputs</span></div></div><table class="data-table"><tr><td>Prepared sample</td><td>20,273 flows</td></tr><tr><td>Training + historical index</td><td>16,218 flows</td></tr><tr><td>Untouched final test</td><td>4,055 flows</td></tr></table><p class="category-line">BENIGN / Brute Force / DoS / DDoS / Bot / PortScan / Web Attack / Infiltration / Heartbleed</p>',
        4: '<div class="lane"><h3>OFFLINE: PREPARE THE EVIDENCE</h3><div class="flow-row"><div class="node">CIC dataset<small>Observed labeled flows</small></div><div class="node">Clean + split<small>Validate, sample, deduplicate</small></div><div class="node">Models + index<small>Flow documents, LSA, FAISS, BM25</small></div></div></div><div class="lane"><h3>ONLINE: INVESTIGATE A FLOW</h3><div class="flow-row four"><div class="node">React<small>Analyst input</small></div><div class="node">FastAPI<small>Validated request</small></div><div class="node">Agents<small>Evidence + inference</small></div><div class="node">Result<small>Explain and prioritize</small></div></div></div><div class="stack">Python / React / FAISS + BM25 / SQLite<br>Response: local playbook or optional hosted LLM</div>',
        5: '<div class="retrieval-pair"><div><strong>Keyword search</strong><span>BM25 matches terms such as SSH and service ports.</span></div><div><strong>Semantic search</strong><span>LSA + FAISS compares related flow descriptions.</span></div></div><div class="retrieval-stage">Combine and rank<small>Weighted or reciprocal-rank fusion; optional flow reranking</small></div><div class="retrieval-stage">Filter and select evidence<small>Attack, IPs, protocol, ports, time; avoid repetitive matches</small></div><div class="retrieval-stage">Answer with citations<small>Use retrieved incident IDs and disclose evidence gaps</small></div>',
        6: '<div class="answer-row"><strong>What?</strong><div>Attack prediction<small>Multiclass and binary Random Forest models</small></div></div><div class="answer-row"><strong>How urgent?</strong><div>Risk and priority<small>Anomaly signal plus a transparent five-signal policy</small></div></div><div class="answer-row"><strong>Why?</strong><div>Feature explanation<small>Exact local TreeSHAP contributions</small></div></div><p class="priority-line">P4: score &lt;30 / P3: 30 to &lt;60 / P2: 60 to &lt;80 / P1: 80-100<br>P1 is highest priority. Policy score is not attack probability.</p>',
        7: '<div class="agent-row"><span class="order">01</span><strong>Detection</strong><small>Predict the attack category</small></div><div class="agent-row"><span class="order">02</span><strong>Anomaly</strong><small>Compare with benign traffic</small></div><div class="agent-row"><span class="order">03</span><strong>Retrieval</strong><small>Find comparable incidents</small></div><div class="agent-row"><span class="order">04</span><strong>Risk</strong><small>Apply the priority policy</small></div><div class="agent-row"><span class="order">05</span><strong>Explainability</strong><small>Show feature contributions</small></div><div class="agent-row"><span class="order">06</span><strong>Response</strong><small>Local playbook / optional LLM</small></div><div class="agent-row"><span class="order">07</span><strong>Quality judge</strong><small>Optional; valid provider required</small></div>',
        8: '<table class="metric-table"><tr><td>Attack-model accuracy</td><td>99.21%</td></tr><tr><td>Macro F1</td><td>0.9743</td></tr><tr><td>Unassisted hybrid Precision@5</td><td>62.86%</td></tr><tr><td>Model-assisted hybrid Precision@5</td><td>95.24%</td></tr><tr><td>Backend / React tests passed</td><td>173 / 20</td></tr><tr><td>Offline structural cases passed</td><td>9 / 9</td></tr></table><p class="scope">Classification: 4,055 sampled test flows. Retrieval: 42 queries, K=5.<br>Category agreement is a retrieval proxy, not LLM faithfulness.</p>',
        9: '<div class="media-window result"><img src="../artifacts/figures/investigation-result-desktop.png" alt="Actual local investigation result with prediction and triage output"></div>',
        10: '<div class="delivery"><strong>Delivered and tested locally</strong><p>API + React / Models + retrieval / Explanations + local response / Reviewed feedback / Source + PDFs + sample data</p></div><div class="delivery pending"><strong>Deferred or still to validate</strong><p>Hosted generation and quality checks / Independent-network testing / React acceptance / GitHub upload and access</p></div><p class="scope">The analyst validates evidence and authorizes response actions.</p>',
    }
    return visuals[number]


def presentation_document(source: Path) -> str:
    slides = []
    elapsed = 0
    for slide in presentation_sections(source):
        elapsed += slide["seconds"]
        number = slide["number"]
        content = MARKDOWN.render(slide["content"])
        time_label = f'{slide["seconds"] // 60}:{slide["seconds"] % 60:02d}'
        slides.append(f"""<section class="slide" data-slide="{number}"><header class="head"><div><div class="kicker">CYBERSECURITY CAPSTONE / {number:02d}</div><h1>{html.escape(slide["title"])}</h1></div><div class="brand">Hrushikeshreddy<br>{time_label} on this slide</div></header><div class="body"><div class="content">{content}</div><div class="visual">{slide_visual(number)}<p class="caption">{html.escape(slide["caption"])}</p></div></div><footer class="footer"><span><strong>Incident Response Assistant</strong> / Evidence-based analyst support</span><span>{number} / 10</span></footer></section>""")
    preview_script = """<script>
      const requested = Number(new URLSearchParams(window.location.search).get("page"));
      if (requested > 0) {
        document.querySelectorAll(".slide").forEach((slide, index) => {
          slide.style.display = index === requested - 1 ? "flex" : "none";
        });
      }
    </script>"""
    return f"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><title>Project Presentation</title><style>{SLIDE_CSS}</style></head><body>{''.join(slides)}{preview_script}</body></html>"


def speaker_notes(source: Path) -> str:
    sections = ["# Speaker Notes: Ten-Minute Presentation",
                "Participant: Hrushikeshreddy. These notes explain the short slides in plain language. Practise the timings; keep the live demo local-only. Benchmark results describe the full sampled run, not the portable demo."]
    start = 0
    for slide in presentation_sections(source):
        end = start + slide["seconds"]
        window = f"{start // 60}:{start % 60:02d} to {end // 60}:{end % 60:02d}"
        sections.extend([f'## Slide {slide["number"]}: {slide["title"]}', f'Planned time: {slide["seconds"]} seconds. Presentation window: {window}.',
                         slide["notes"]])
        if slide["demo"]:
            sections.extend(["### Demo Sequence", slide["demo"]])
        start = end
    raw = source.read_text(encoding="utf-8")
    questions = raw.split("## Likely Panel Questions", 1)
    if len(questions) == 2:
        sections.append("## Panel Questions And Delivery Tips\n" + questions[1].strip())
    return "\n\n".join(sections) + "\n"


def find_chrome(explicit: str | None) -> Path:
    candidates = [
        explicit,
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        shutil.which("google-chrome"),
        shutil.which("chromium"),
        shutil.which("chromium-browser"),
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return Path(candidate)
    raise FileNotFoundError("Chrome/Chromium was not found. Pass --chrome /path/to/browser.")


def browser_run(chrome: Path, *args: str) -> None:
    completed = subprocess.run(
        [str(chrome), "--headless=new", "--disable-gpu", "--allow-file-access-from-files", *args],
        cwd=ROOT,
        text=True,
        capture_output=True,
        timeout=120,
        check=False,
    )
    if completed.returncode:
        raise RuntimeError(completed.stderr or completed.stdout or "Browser rendering failed")


def build_html() -> list[Path]:
    outputs: list[Path] = []
    for source, destination, title, subtitle in REPORTS:
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(report_document(source, title, subtitle), encoding="utf-8")
        outputs.append(destination)
    presentation = ROOT / "presentation/Project_Presentation.html"
    presentation.parent.mkdir(parents=True, exist_ok=True)
    presentation.write_text(presentation_document(ROOT / "docs/presentation.md"), encoding="utf-8")
    outputs.append(presentation)
    notes_source = ROOT / "presentation/Speaker_Notes.md"
    notes_source.write_text(speaker_notes(ROOT / "docs/presentation.md"), encoding="utf-8")
    notes_html = notes_source.with_suffix(".html")
    notes_html.write_text(report_document(notes_source, "Speaker Notes", "Plain-language explanations, timed demo, and panel questions"), encoding="utf-8")
    outputs.append(notes_html)
    return outputs


def render_outputs(chrome: Path, reports: list[Path]) -> None:
    architecture_html = ROOT / "architecture/Architecture_Diagram.html"
    architecture_pdf = architecture_html.with_suffix(".pdf")
    architecture_png = architecture_html.with_suffix(".png")
    browser_run(chrome, "--no-pdf-header-footer", f"--print-to-pdf={architecture_pdf}", architecture_html.as_uri())
    browser_run(chrome, "--hide-scrollbars", "--window-size=1123,794", f"--screenshot={architecture_png}", architecture_html.as_uri())
    for source in reports:
        browser_run(chrome, "--no-pdf-header-footer", f"--print-to-pdf={source.with_suffix('.pdf')}", source.as_uri())


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--html-only", action="store_true", help="Build HTML sources without rendering PDFs")
    parser.add_argument("--chrome", help="Chrome/Chromium executable path")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    reports = build_html()
    if not args.html_only:
        render_outputs(find_chrome(args.chrome), reports)
    print("Built submission artifacts:")
    for path in [ROOT / "architecture/Architecture_Diagram.html", *reports]:
        print(f"- {path.relative_to(ROOT)}")
        if not args.html_only:
            print(f"- {path.with_suffix('.pdf').relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
