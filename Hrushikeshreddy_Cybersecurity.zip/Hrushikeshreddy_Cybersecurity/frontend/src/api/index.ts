import { apiClient } from './client'
import type { RAGResult, SystemStatus, NetworkFlow } from '../types'
import type { Feedback, FeedbackRequest, GlobalExplanation, HistoricalIncident, IncidentListParams, IncidentListResponse, InvestigationRequest, InvestigationResult, Metrics, ModelInfo, SearchRequest, SearchResult, SystemHealth } from '../types'

export const healthApi = {
  status: async () => (await apiClient.get<SystemStatus>('/api/v1/system/status')).data,
  get: async () => (await apiClient.get<SystemHealth>('/health')).data,
  model: async () => (await apiClient.get<ModelInfo>('/api/v1/model/info')).data,
}
export const dashboardApi = {
  metrics: async () => (await apiClient.get<Metrics>('/api/v1/metrics')).data,
  incidents: async () => (await apiClient.get<IncidentListResponse>('/api/v1/incidents')).data,
  incidentPage: async (params: IncidentListParams) => (await apiClient.get<IncidentListResponse>('/api/v1/incidents', { params })).data,
}
export const investigationApi = {
  parseCSV: async (csv_text: string) => (await apiClient.post<NetworkFlow>('/api/v1/flows/parse', { csv_text })).data,
  report: async (id: string) => (await apiClient.get<Blob>(`/api/v1/incidents/${encodeURIComponent(id)}/report`, { responseType: 'blob' })).data,
  investigate: async (payload: InvestigationRequest) => (await apiClient.post<InvestigationResult>('/api/v1/investigate', payload, { timeout: 300_000 })).data,
  get: async (id: string) => (await apiClient.get<InvestigationResult | HistoricalIncident>(`/api/v1/incidents/${encodeURIComponent(id)}`)).data,
  samples: async () => (await apiClient.get<HistoricalIncident[]>('/api/v1/samples')).data,
}
export const searchApi = { search: async (payload: SearchRequest) => (await apiClient.post<SearchResult>('/api/v1/search', payload)).data }
export const ragApi = { answer: async (payload: SearchRequest & { use_llm?: boolean }) => (await apiClient.post<RAGResult>('/api/v1/rag/answer', payload)).data }
export const explainApi = { global: async () => (await apiClient.get<GlobalExplanation>('/api/v1/explain/global')).data }
export const feedbackApi = {
  list: async () => (await apiClient.get<Feedback[]>('/api/v1/feedback')).data,
  submit: async (payload: FeedbackRequest) => (await apiClient.post<{feedback_id: number; incident_id?: string | null; interaction_type?: 'ai_analyst' | 'rag_search' | null; status: string}>('/api/v1/feedback', payload)).data,
}
