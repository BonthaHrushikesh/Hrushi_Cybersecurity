import {
  Activity,
  BrainCircuit,
  Check,
  FileSearch,
  Gauge,
  GitBranch,
  Lightbulb,
  Radar,
  RefreshCw,
  Scale,
  ShieldCheck,
} from "lucide-react";
import { Link } from "react-router-dom";
import { dashboardApi, investigationApi } from "../api";
import { PageHeader, Panel, StatusBadge, LoadingSkeleton, ErrorState, EmptyState } from "../components/ui";
import { demoInvestigation, demoMetrics } from "../demo/data";
import { useApiResource } from "../hooks/useApiResource";
import type { InvestigationResult } from "../types";
import { formatDate, formatNumber, titleCase } from "../utils/format";
import { asRecord } from "../utils/records";
import { workflowDetail } from "../utils/workflow";

const agents = [
  {
    name: "Detection Agent",
    icon: Radar,
    tool: "Supervised classifier",
    input: "Validated flow",
    output: "Attack probabilities",
  },
  {
    name: "Anomaly Agent",
    icon: Activity,
    tool: "Isolation Forest",
    input: "Traffic features",
    output: "Anomaly percentile",
  },
  {
    name: "Retrieval Agent",
    icon: FileSearch,
    tool: "LSA + BM25 + filters",
    input: "Flow document",
    output: "Historical evidence",
  },
  {
    name: "Risk Assessment Agent",
    icon: Gauge,
    tool: "Weighted triage policy",
    input: "Prediction + anomaly",
    output: "Risk and priority",
  },
  {
    name: "Explainability Agent",
    icon: Lightbulb,
    tool: "TreeSHAP",
    input: "Prediction context",
    output: "Feature contributions",
  },
  {
    name: "Response Recommendation Agent",
    icon: ShieldCheck,
    tool: "Grounded playbook / LLM",
    input: "Bounded evidence",
    output: "Response actions",
  },
  {
    name: "Quality Judge Agent",
    icon: Scale,
    tool: "Evidence-aware judge",
    input: "Analysis + evidence",
    output: "Quality dimensions",
  },
];

export function AgentWorkflowPage() {
  const metrics = useApiResource(["metrics"], dashboardApi.metrics, demoMetrics);
  const trace = useApiResource(
    ["latest-workflow"],
    async () => {
      const list = await dashboardApi.incidents();
      if (!list.items[0]) throw new Error("No investigations");
      const result = await investigationApi.get(list.items[0].incident_id);
      if (!("workflow" in result)) throw new Error("No workflow trace");
      return result as InvestigationResult;
    },
    demoInvestigation,
  );
  if (!trace.data) return trace.isLoading ? <LoadingSkeleton rows={7} /> : trace.error?.message === 'No investigations' ? <EmptyState title="No Workflow Yet" description="No investigations have been recorded." /> : <ErrorState message="Workflow trace is unavailable." onRetry={() => trace.refetch()} />;
  const result = trace.data;
  const connection = asRecord(metrics.data?.evaluation.provider_connection);
  return (
    <div>
      <PageHeader
        eyebrow="Investigation orchestration"
        title="Multi-Agent Workflow"
        description="A deterministic state workflow coordinates detection, retrieval, risk assessment, explainability, response guidance, and quality validation."
        action={
          <div className="flex items-center gap-2">
          <button className="icon-btn" title="Refresh workflow trace" aria-label="Refresh workflow trace" disabled={trace.isFetching} onClick={() => trace.refetch()}><RefreshCw size={16} /></button>
          <Link to="/investigate?judge=true" className="btn-primary">
            <GitBranch size={15} />
            Run workflow
          </Link>
          </div>
        }
      />
      <div className="grid gap-4 sm:grid-cols-3">
        <Panel title="Latest Trace" eyebrow="Incident">
          <strong className="font-mono text-lg">{result.incident_id}</strong>
          <p className="mt-2 text-xs text-zinc-500">{formatDate(result.created_at)}</p>
        </Panel>
        <Panel title="Total Latency" eyebrow="End to end">
          <strong className="text-3xl">
            {formatNumber(result.latency_ms, 0)}{" "}
            <span className="text-sm text-zinc-500">ms</span>
          </strong>
        </Panel>
        <Panel title="Completed Steps" eyebrow="Contract status">
          <strong className="text-3xl text-emerald-400">
            {result.workflow.filter((x) => x.status === "completed").length}/
            {agents.length}
          </strong>
        </Panel>
      </div>
      {connection.status === 'failed' && <div role="alert" className="mt-5 border-l-2 border-amber-400 bg-amber-400/[.04] px-4 py-3 text-sm text-amber-200"><strong>Last provider connection check failed{typeof connection.http_status === 'number' ? ` (HTTP ${connection.http_status})` : ''}.</strong><p className="mt-1 text-xs leading-5">Live generation and judging require a working provider credential. This saved workflow trace is not rerun when configuration changes.</p><Link to="/settings" className="mt-2 inline-flex items-center gap-2 text-xs text-gold"><ShieldCheck size={14} />Provider settings</Link></div>}
      <Panel
        title="Execution Graph"
        eyebrow="Typed state transitions"
        className="mt-5"
      >
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {agents.map((agent, index) => {
            const step = result.workflow.find(
              (item) => item.agent === agent.name,
            );
            const Icon = agent.icon;
            return (
              <article
                key={agent.name}
                className="relative rounded-lg border border-white/[.07] bg-black/20 p-4 lg:min-h-52"
              >
                {index < agents.length - 1 && (
                  <span className="absolute -right-3 top-1/2 z-10 hidden h-px w-3 bg-gold/40 lg:block" />
                )}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-gold/25 bg-gold/[.05]">
                    <Icon size={17} className="text-gold" />
                  </div>
                  {step ? (
                    <StatusBadge status={step.status.replaceAll('_', ' ')} />
                  ) : (
                    <StatusBadge status="not run" />
                  )}
                </div>
                <strong className="mt-4 block text-sm leading-5">
                  {agent.name}
                </strong>
                <p className="mt-2 text-xs leading-5 text-zinc-500">
                  {agent.tool}
                </p>
                {step && workflowDetail(result, step) && <p className="mt-3 text-xs leading-5 text-amber-200/80">{workflowDetail(result, step)}</p>}
                <div className="mt-4 border-t border-white/[.06] pt-3 text-[10px] uppercase tracking-wider text-zinc-600">
                  {step ? `${step.latency_ms.toFixed(1)} ms` : "Awaiting trace"}
                </div>
              </article>
            );
          })}
        </div>
      </Panel>
      <div className="mt-5 grid gap-5 xl:grid-cols-2">
        <Panel title="Agent Contracts" eyebrow="Inputs and outputs">
          <div className="space-y-3">
            {agents.map((agent, index) => (
              <div
                key={agent.name}
                className="grid grid-cols-[28px_1fr] gap-3 rounded-lg border border-white/[.06] p-3"
              >
                <span className="flex h-7 w-7 items-center justify-center rounded-full border border-gold/25 text-xs text-gold">
                  {index + 1}
                </span>
                <div>
                  <strong className="text-sm">{agent.name}</strong>
                  <p className="mt-1 text-xs text-zinc-500">
                    {agent.input} → {agent.output}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Latest Execution Trace" eyebrow="Tool audit">
          <div className="space-y-3">
            {result.workflow.map((step) => (
              <div
                key={step.agent}
                className="flex items-start gap-3 border-b border-white/[.06] pb-3"
              >
                {step.status === 'completed' ? <Check size={15} className="mt-0.5 shrink-0 text-emerald-400" /> : <Scale size={15} className="mt-0.5 shrink-0 text-zinc-500" />}
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap justify-between gap-3">
                    <strong className="text-sm">{step.agent}</strong>
                    <span className="font-mono text-xs text-zinc-500">
                      {step.latency_ms.toFixed(1)} ms
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-zinc-600">
                    {step.tools.map(titleCase).join(", ")}
                  </p>
                  {workflowDetail(result, step) && <p className="mt-2 text-xs leading-5 text-zinc-400">{workflowDetail(result, step)}</p>}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 flex gap-2 rounded-lg border border-blue-400/15 bg-blue-400/[.04] p-3 text-xs leading-5 text-blue-200">
            <BrainCircuit size={16} className="shrink-0" />
            Agents operate on explicit state contracts. They do not autonomously
            execute containment actions.
          </div>
        </Panel>
      </div>
    </div>
  );
}
