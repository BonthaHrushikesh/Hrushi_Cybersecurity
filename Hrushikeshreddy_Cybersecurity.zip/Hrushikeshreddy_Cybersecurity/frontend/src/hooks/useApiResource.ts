import { useQuery, type UseQueryOptions } from '@tanstack/react-query'
import { DEMO_MODE } from '../api/client'
import { useSettings } from '../store/settings'

export function useApiResource<T>(key: string[], queryFn: () => Promise<T>, fallback: T, options?: Partial<UseQueryOptions<T>>) {
  const settings = useSettings()
  const operational = ['metrics', 'evaluation-metrics', 'analytics-metrics', 'incident-list', 'feedback', 'latest-workflow'].includes(key[0])
  const query = useQuery<T>({ queryKey: key, queryFn, retry: 1, staleTime: 15_000, refetchInterval: operational && settings.autoRefresh ? 30_000 : false, ...options })
  return { ...query, data: query.data ?? (DEMO_MODE && query.isError ? fallback : undefined), isDemo: DEMO_MODE && query.isError }
}
