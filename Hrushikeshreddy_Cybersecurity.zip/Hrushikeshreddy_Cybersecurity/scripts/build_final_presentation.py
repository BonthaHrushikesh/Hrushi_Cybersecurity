#!/usr/bin/env python3
"""Build the final editable presentation and its review files."""

from __future__ import annotations

import html
import json
import re
import shutil
import textwrap
import zipfile
from dataclasses import dataclass
from pathlib import Path
from xml.etree import ElementTree as ET


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "final_presentation"
ASSETS = OUT / "assets"
W, H = 13.333333, 7.5
EMU = 914400
PX = 96

BG = "101214"
PANEL = "191C1F"
PANEL2 = "202428"
EDGE = "34393D"
GOLD = "D7B45A"
GOLD2 = "F1D88A"
WHITE = "F5F2E9"
TEXT = "D7D5CE"
MUTED = "9C9D98"
GREEN = "7CB697"
RED = "E48A77"

SLIDES: list[list[dict]] = []


@dataclass
class Canvas:
    number: int
    duration: int
    section: str
    title: str
    shapes: list[dict]
    section_number: int | None
    total: int

    def __init__(self, number: int, duration: int, section: str, title: str,
                 section_number: int | None = None, total: int = 12):
        self.number, self.duration, self.section, self.title = number, duration, section, title
        self.section_number, self.total = section_number, total
        self.shapes = []
        self.rect(0, 0, W, H, BG, radius=0)
        self.rect(0, 0, W, 0.055, GOLD, radius=0)
        self.rect(0.62, 0.36, 0.045, 0.22, GOLD, radius=0)
        self.text(0.78, 0.29, 7.6, 0.25, "AI-POWERED CYBERSECURITY  /  INCIDENT RESPONSE ASSISTANT", 9.2, GOLD2, bold=True, tracking=1.1)
        self.text(10.18, 0.29, 2.5, 0.25, f"{number:02d}   /   {duration // 60}:{duration % 60:02d}", 9.2, MUTED, bold=True, align="right", tracking=0.7)
        section_label = f"{section_number}. {section}" if section_number is not None else section
        self.text(0.66, 0.63, 6.9, 0.30, section_label, 12.2, GOLD, bold=True, tracking=0.5)
        self.text(0.66, 0.99, 12.0, 0.58, title, 25.5, WHITE, bold=True)
        self.line(0.66, 1.58, 12.02, 0, EDGE, 1.0)
        self.line(0.66, 7.10, 12.02, 0, EDGE, 0.8)
        self.text(0.66, 7.17, 8.3, 0.18, "EVIDENCE-BASED ANALYST SUPPORT   ·   HUMAN REVIEW AT EVERY CRITICAL DECISION", 7.6, MUTED, bold=True, tracking=0.35)
        self.text(11.25, 7.14, 1.4, 0.23, f"{number:02d} / {total:02d}", 8.5, GOLD2, bold=True, align="right")

    def rect(self, x, y, w, h, fill=PANEL, *, radius=0.12, stroke=EDGE, sw=0.8):
        self.shapes.append(dict(kind="rect", x=x, y=y, w=w, h=h, fill=fill, stroke=stroke, sw=sw, radius=radius))

    def line(self, x, y, w, h, color=GOLD, sw=1.2):
        self.shapes.append(dict(kind="line", x=x, y=y, w=w, h=h, fill=color, sw=sw))

    def text(self, x, y, w, h, value, size=16, color=TEXT, *, bold=False, align="left", valign="top", tracking=0, italic=False):
        value = str(value)
        max_chars = max(6, int(w * 72 / (size * 0.54)))
        wrapped = []
        for line in value.split("\n"):
            wrapped.extend(textwrap.wrap(line, width=max_chars, break_long_words=False, break_on_hyphens=False) or [""])
        self.shapes.append(dict(kind="text", x=x, y=y, w=w, h=h, value="\n".join(wrapped), size=size, color=color,
                                bold=bold, align=align, valign=valign, tracking=tracking, italic=italic))

    def image(self, x, y, w, h, asset: str, *, crop_bottom=0.0):
        self.shapes.append(dict(kind="image", x=x, y=y, w=w, h=h, asset=asset, crop_bottom=crop_bottom))

    def pill(self, x, y, w, label, fill="342D1C", color=GOLD2):
        self.rect(x, y, w, 0.30, fill, radius=0.12, stroke="5B4C29", sw=0.7)
        self.text(x + 0.08, y + 0.01, w - 0.16, 0.27, label, 9.3, color, bold=True, align="center", valign="middle")

    def card(self, x, y, w, h, heading, body, *, number=None, accent=GOLD):
        self.rect(x, y, w, h, PANEL, radius=0.14, stroke=EDGE)
        self.rect(x + 0.03, y + 0.05, 0.04, h - 0.10, accent, radius=0)
        tx = x + 0.20
        if number is not None:
            self.text(tx, y + 0.16, 0.45, 0.36, str(number).zfill(2), 17, accent, bold=True)
            tx += 0.52
        self.text(tx, y + 0.16, x + w - 0.19 - tx, 0.37, heading, 15.2, WHITE, bold=True)
        self.text(x + 0.21, y + 0.68, w - 0.42, h - 0.82, body, 12.7, MUTED)


def section_title(c: Canvas, x: float, y: float, w: float, title: str, body: str, number: int | None = None, height: float = 1.35):
    c.card(x, y, w, height, title, body, number=number)


def make_slides() -> list[Canvas]:
    """Build the ten required content slides (not the cover and closing slide)."""
    out: list[Canvas] = []

    # 1. Problem: show incoming traffic, the alert and the analyst's unanswered questions.
    c = Canvas(2, 45, "Problem Statement", "Turning alerts into defensible decisions", 10)
    c.rect(0.66, 1.86, 4.05, 4.79, PANEL, radius=0.17, stroke=EDGE)
    c.text(0.90, 2.05, 3.5, 0.26, "THE INVESTIGATION GAP", 10.2, GOLD, bold=True, tracking=0.8)
    for i, label in enumerate(["DDoS FLOW", "PORT SCAN", "BRUTE FORCE", "…"]):
        y = 2.57 + i * 0.54
        c.rect(0.94, y, 1.18, 0.36, PANEL2, radius=0.07, stroke="42474B", sw=0.6)
        c.text(1.05, y + 0.02, 0.96, 0.30, label, 9.3, MUTED, bold=True, align="center", valign="middle")
    c.line(2.23, 3.27, 0.47, 0, GOLD, 2)
    c.text(2.25, 3.03, 0.44, 0.44, "›", 24, GOLD, bold=True, align="center", valign="middle")
    c.rect(2.72, 2.77, 1.47, 1.01, "292519", radius=0.12, stroke="78612B", sw=1.1)
    c.text(2.85, 2.94, 1.20, 0.29, "ALERT", 13, GOLD2, bold=True, align="center", valign="middle")
    c.text(2.83, 3.29, 1.24, 0.27, "signals ≠ intent", 9.1, TEXT, align="center", valign="middle")
    c.line(3.46, 3.88, 0, 0.42, GOLD, 2)
    c.text(2.90, 4.12, 1.12, 0.34, "↓", 22, GOLD, bold=True, align="center", valign="middle")
    c.rect(2.72, 4.55, 1.47, 1.07, PANEL2, radius=0.14, stroke="56534A", sw=0.9)
    c.text(2.82, 4.68, 1.27, 0.30, "ANALYST", 11, WHITE, bold=True, align="center", valign="middle")
    c.text(2.84, 5.08, 1.23, 0.39, "context + evidence\npriority + actions", 8.6, MUTED, align="center")
    c.text(0.93, 6.02, 3.48, 0.45, "DDoS · DoS · PortScan · brute force\nbotnet · web · infiltration", 10.0, TEXT, bold=True, align="center")
    c.text(5.13, 1.99, 7.2, 0.30, "WHAT THE ANALYST STILL HAS TO ESTABLISH", 10, GOLD, bold=True, tracking=0.8)
    rows = [
        ("01", "What does this flow suggest?", "Classification is a model inference, not confirmation of compromise."),
        ("02", "Has similar activity appeared before?", "Historical similarity offers context; it does not prove this event is the same."),
        ("03", "What should be reviewed first?", "Evidence, risk policy and explanation are often scattered across tools."),
    ]
    for i, (n, title, body) in enumerate(rows):
        y = 2.47 + i * 1.05
        c.rect(5.12, y, 7.20, 0.85, PANEL, radius=0.12, stroke=EDGE)
        c.text(5.34, y + 0.17, 0.46, 0.40, n, 16, GOLD, bold=True)
        c.text(5.91, y + 0.12, 5.98, 0.28, title, 15.2, WHITE, bold=True)
        c.text(5.91, y + 0.46, 6.05, 0.34, body, 10.8, MUTED)
    c.rect(5.12, 5.84, 7.20, 0.70, "282519", radius=0.12, stroke="6A572C", sw=0.9)
    c.text(5.36, 5.97, 6.75, 0.53, "Core problem: turn raw alerts into meaningful, evidence-backed security decisions.", 13.4, GOLD2, bold=True, valign="middle")
    out.append(c)

    # 2. Business need.
    c = Canvas(3, 45, "Business Need", "A consistent, evidence-led investigation workflow", 11)
    pillar_y, pillar_w, gap = 2.20, 3.72, 0.35
    pillars = [
        ("01", "IDENTIFY", "Connect the flow to\nmodel signals and\nobserved indicators.", "Clearer starting point"),
        ("02", "INVESTIGATE", "Retrieve comparable\nhistory and explain\nwhat influenced a result.", "Evidence in one workspace"),
        ("03", "PRIORITIZE", "Apply a consistent\ntriage policy and present\nreviewable next steps.", "A traceable decision"),
    ]
    for i, (n, title, body, result) in enumerate(pillars):
        x = 0.78 + i * (pillar_w + gap)
        c.rect(x, pillar_y, pillar_w, 2.84, PANEL, radius=0.17, stroke=EDGE)
        c.text(x + 0.25, pillar_y + 0.22, 0.58, 0.47, n, 21, GOLD, bold=True)
        c.text(x + 0.25, pillar_y + 0.91, pillar_w - 0.5, 0.35, title, 17, WHITE, bold=True, tracking=0.5)
        c.line(x + 0.25, pillar_y + 1.38, pillar_w - 0.50, 0, "4B4534", 0.9)
        c.text(x + 0.25, pillar_y + 1.57, pillar_w - 0.5, 0.76, body, 14, TEXT)
        c.text(x + 0.25, pillar_y + 2.46, pillar_w - 0.5, 0.23, result, 10.5, GOLD2, bold=True)
    c.text(0.84, 5.50, 11.8, 0.31, "BUSINESS OBJECTIVE", 9.8, GOLD, bold=True, tracking=0.9)
    c.text(0.84, 5.88, 11.9, 0.53, "Make suspicious-flow investigations more consistent and easier to review.", 20, WHITE, bold=True)
    c.text(0.84, 6.52, 11.7, 0.28, "Expected benefit—not a measured time saving, productivity percentage, or return-on-investment claim.", 10.2, MUTED)
    out.append(c)

    # 3. Solution overview.
    c = Canvas(4, 55, "Solution Overview", "Connect signals, evidence, and analyst review", 12)
    stages = [
        ("FLOW INPUT", "Sample, CSV,\nor supported form"),
        ("AI / ML", "Attack class,\nintrusion, anomaly"),
        ("HISTORY", "Hybrid search for\nrelated flow records"),
        ("EXPLAIN + TRIAGE", "SHAP contributions\nand policy priority"),
        ("NEXT STEPS", "Grounded playbook\nor validated LLM"),
        ("ANALYST", "Review evidence;\ndecide what to do"),
    ]
    coords = [(0.78, 2.02), (4.90, 2.02), (9.02, 2.02), (9.02, 4.03), (4.90, 4.03), (0.78, 4.03)]
    for i, ((head, body), (x, y)) in enumerate(zip(stages, coords)):
        c.rect(x, y, 3.52, 1.34, PANEL, radius=0.15, stroke="51472F" if i in (1, 3, 4) else EDGE)
        c.pill(x + 0.21, y + 0.16, 1.45, f"STAGE {i + 1:02d}")
        c.text(x + 0.21, y + 0.57, 3.13, 0.30, head, 14.5, WHITE, bold=True)
        c.text(x + 0.21, y + 0.93, 3.13, 0.36, body, 11.7, MUTED)
    for x, y in [(4.33, 2.42), (8.45, 2.42)]:
        c.text(x, y, 0.45, 0.42, "›", 24, GOLD, bold=True, align="center", valign="middle")
    c.text(10.47, 3.37, 0.46, 0.45, "↓", 22, GOLD, bold=True, align="center", valign="middle")
    c.text(8.45, 4.43, 0.45, 0.42, "‹", 24, GOLD, bold=True, align="center", valign="middle")
    c.text(4.33, 4.43, 0.45, 0.42, "‹", 24, GOLD, bold=True, align="center", valign="middle")
    c.rect(0.80, 5.81, 11.74, 0.72, "252319", radius=0.12, stroke="65552D", sw=0.9)
    c.text(1.03, 5.98, 11.25, 0.34, "Decision support only: the system does not confirm a compromise, block traffic, or execute containment.", 13.2, GOLD2, bold=True, valign="middle")
    out.append(c)

    # 4. Architecture.
    c = Canvas(5, 55, "Architecture", "A local workflow from offline assets to investigation", 13)
    c.text(0.78, 1.83, 11.9, 0.23, "OFFLINE  ·  BUILD REUSABLE MODEL AND SEARCH ASSETS", 9.3, GOLD, bold=True, tracking=0.6)
    c.rect(0.76, 2.13, 11.78, 0.80, "211E18", radius=0.12, stroke="65552D", sw=0.9)
    for i, (x, head, body) in enumerate([
        (1.02, "CIC-IDS2017", "clean · sample · split"),
        (4.62, "TRAIN + INDEX", "classifiers · LSA · BM25"),
        (8.48, "VERSIONED ASSETS", "models · FAISS · metadata"),
    ]):
        c.text(x, 2.25, 2.75, 0.26, head, 12, GOLD2, bold=True, align="center")
        c.text(x, 2.57, 2.75, 0.21, body, 9.8, TEXT, align="center")
    c.text(3.96, 2.35, 0.47, 0.32, "›", 21, GOLD, bold=True, align="center")
    c.text(7.90, 2.35, 0.47, 0.32, "›", 21, GOLD, bold=True, align="center")
    c.text(0.78, 3.13, 11.9, 0.23, "ONLINE  ·  COORDINATE ONE ANALYST-LED INVESTIGATION", 9.3, GOLD, bold=True, tracking=0.6)
    cards = [
        ("FRONTEND", "React\nTypeScript", "Analyst workspace"),
        ("API", "FastAPI\nPydantic", "Typed, validated requests"),
        ("AI PROCESSING", "Classifier · intrusion\nanomaly · risk · SHAP", "Distinct signals + policy"),
        ("HYBRID RAG", "TF-IDF / LSA + FAISS\nBM25 + hybrid rank", "Historical flow evidence"),
        ("RESPONSE + FLOW", "Orchestrator\nlocal playbook / optional LLM", "Validate · fallback · judge"),
    ]
    card_x, card_w, card_gap, y = 0.76, 2.19, 0.21, 3.48
    for i, (head, body, foot) in enumerate(cards):
        x = card_x + i * (card_w + card_gap)
        c.rect(x, y, card_w, 1.57, PANEL, radius=0.13, stroke=EDGE)
        c.text(x + 0.12, y + 0.16, card_w - 0.24, 0.24, head, 9.2, GOLD, bold=True, align="center", tracking=0.3)
        c.text(x + 0.13, y + 0.52, card_w - 0.26, 0.51, body, 11.0, WHITE, bold=True, align="center", valign="middle")
        c.text(x + 0.11, y + 1.15, card_w - 0.22, 0.27, foot, 8.7, MUTED, align="center", valign="middle")
        if i < 4:
            c.text(x + card_w + 0.005, y + 0.57, card_gap - 0.01, 0.33, "›", 19, GOLD, bold=True, align="center", valign="middle")
    c.rect(0.76, 5.27, 11.78, 1.08, PANEL2, radius=0.13, stroke=EDGE)
    c.text(0.98, 5.43, 1.60, 0.27, "LOCAL STORAGE", 10, GOLD, bold=True)
    c.text(2.53, 5.41, 9.70, 0.39, "Historical documents + model/index artifacts   ·   SQLite investigations + feedback", 12.2, WHITE, bold=True)
    c.text(2.53, 5.85, 9.70, 0.24, "Feedback stays pending review; candidate model changes require a separate promotion decision.", 10, MUTED)
    out.append(c)

    # 5. Data flow.
    c = Canvas(6, 55, "Data Flow", "From validated flow to reviewed record", 14)
    steps = [
        ("INPUT", "Flow sample, CSV\nor supported form"),
        ("VALIDATE", "Check fields, ranges\nand metadata"),
        ("PREDICT", "Class + intrusion\nand anomaly signals"),
        ("RETRIEVE", "Rank historical\nrecords with hybrid RAG"),
        ("ASSESS", "Risk policy sets\ntriage priority"),
        ("EXPLAIN", "SHAP shows model\nfeature contributions"),
        ("RESPOND", "Check response schema\nand evidence citations"),
        ("RECORD", "Save outcome; route\nfeedback for review"),
    ]
    start_x, start_y, cw, ch, dx = 0.76, 2.10, 2.78, 1.45, 0.23
    for i, (head, body) in enumerate(steps):
        row, col = divmod(i, 4)
        x = start_x + col * (cw + dx)
        y = start_y + row * 2.08
        c.rect(x, y, cw, ch, PANEL, radius=0.13, stroke="51472F" if i in (2, 3, 6) else EDGE)
        c.text(x + 0.17, y + 0.15, 0.52, 0.36, f"{i + 1:02d}", 17, GOLD, bold=True)
        c.text(x + 0.78, y + 0.17, cw - 0.95, 0.29, head, 13.2, WHITE, bold=True, tracking=0.25)
        c.text(x + 0.18, y + 0.64, cw - 0.36, 0.60, body, 11.2, MUTED)
        if col < 3:
            c.text(x + cw + 0.015, y + 0.52, dx - 0.03, 0.34, "›", 20, GOLD, bold=True, align="center", valign="middle")
    c.text(11.78, 3.31, 0.37, 0.52, "↙", 19, GOLD, bold=True, align="center", valign="middle")
    c.rect(0.80, 6.49, 11.74, 0.41, "24231F", radius=0.08, stroke="51472F", sw=0.7)
    c.text(0.97, 6.53, 11.40, 0.28, "Similarity is not proof · SHAP is not causal · risk is not a calibrated probability · feedback does not auto-retrain.", 10.2, GOLD2, bold=True, valign="middle", align="center")
    out.append(c)

    # 6. Technology stack.
    c = Canvas(7, 45, "Technology Stack", "Selected for local inference and hybrid search", 15)
    stack = [
        ("FRONTEND", "React  ·  TypeScript\nVite  ·  Tailwind CSS\nRecharts", "Responsive analyst dashboard"),
        ("BACKEND", "Python  ·  FastAPI\nPydantic  ·  pandas", "Validated API + data pipeline"),
        ("MACHINE LEARNING", "scikit-learn\nRandom Forest  ·  Isolation Forest\nSHAP", "Prediction, anomaly, explanation"),
        ("RETRIEVAL", "TF-IDF / LSA  ·  FAISS\nBM25  ·  hybrid rank", "Dense + keyword historical search"),
        ("GENERATION + QUALITY", "Optional NVIDIA Nemotron\nDeepEval  ·  schema / citation checks", "Narrative is optional; checked outputs"),
        ("DATA + PERSISTENCE", "CIC-IDS2017  ·  SQLite\nversioned model + index files", "Historical benchmark + local records"),
    ]
    coords = [(0.78, 2.00), (4.86, 2.00), (8.94, 2.00), (0.78, 4.22), (4.86, 4.22), (8.94, 4.22)]
    for i, ((head, body, foot), (x, y)) in enumerate(zip(stack, coords)):
        c.rect(x, y, 3.62, 1.81, PANEL, radius=0.14, stroke=EDGE)
        c.rect(x + 0.18, y + 0.18, 0.06, 0.30, GOLD, radius=0)
        c.text(x + 0.37, y + 0.15, 3.00, 0.29, head, 10, GOLD, bold=True, tracking=0.55)
        c.text(x + 0.22, y + 0.58, 3.18, 0.74, body, 12.4, WHITE, bold=True)
        c.text(x + 0.22, y + 1.51, 3.18, 0.20, foot, 9.3, MUTED)
    c.text(0.84, 6.44, 11.9, 0.27, "Measured embedding baseline: TF-IDF + LSA. Pretrained sentence embeddings are optional, not the reported default.", 10, GOLD2, bold=True)
    out.append(c)

    # 7. Agent workflow.
    c = Canvas(8, 65, "Agent Workflow", "Seven roles. One shared investigation state.", 16)
    c.rect(0.80, 1.83, 11.72, 0.56, "24231F", radius=0.11, stroke="65552D", sw=0.8)
    c.text(1.02, 1.94, 2.55, 0.30, "SHARED ORCHESTRATOR", 11.2, GOLD2, bold=True, valign="middle")
    c.text(3.60, 1.94, 8.56, 0.30, "Validates inputs and outputs · records per-role status and timing · carries evidence forward", 10.4, TEXT, valign="middle")
    roles = [
        ("01  DETECTION", "Predicts attack category\nand intrusion likelihood"),
        ("02  ANOMALY", "Measures unusualness\nagainst benign traffic"),
        ("03  RETRIEVAL", "Finds ranked historical\nflow evidence"),
        ("04  RISK", "Applies configured\ntriage policy"),
        ("05  EXPLAINABILITY", "Shows TreeSHAP\nfeature contributions"),
        ("06  RESPONSE", "Grounded playbook or\nvalidated hosted output"),
        ("07  QUALITY JUDGE", "Optional provider-backed\nquality assessment"),
        ("ANALYST REVIEW", "Checks context and\nauthorizes every action"),
    ]
    xs = [0.80, 3.78, 6.76, 9.74]
    for i, (head, body) in enumerate(roles):
        row, col = divmod(i, 4)
        x = xs[col]
        y = 2.80 + row * 1.68
        c.rect(x, y, 2.72, 1.25, PANEL, radius=0.12, stroke="52482F" if i in (5, 6) else EDGE)
        c.text(x + 0.16, y + 0.15, 2.40, 0.28, head, 10.6, GOLD2 if i != 7 else GREEN, bold=True)
        c.text(x + 0.16, y + 0.55, 2.40, 0.56, body, 10.4, TEXT)
        if col < 3:
            c.text(x + 2.73, y + 0.43, 0.24, 0.33, "›", 18, GOLD, bold=True, align="center", valign="middle")
    c.text(11.08, 3.15, 0.34, 0.30, "↙", 17, GOLD, bold=True, align="center", valign="middle")
    c.rect(0.82, 6.32, 11.70, 0.52, "252319", radius=0.09, stroke="65552D", sw=0.7)
    c.text(1.02, 6.42, 11.27, 0.30, "These are orchestrated software roles—not seven autonomous chatbots. Provider failure can trigger a local playbook; the judge can remain unavailable.", 9.8, GOLD2, bold=True, valign="middle")
    out.append(c)

    # 8. Live demo and real project evidence.
    c = Canvas(9, 120, "Demo", "DDoS flow → evidence → analyst feedback", 17)
    c.rect(0.70, 1.84, 4.63, 4.97, PANEL, radius=0.14, stroke="51472F", sw=0.9)
    c.image(0.79, 1.93, 4.45, 4.54, "investigation-result-desktop.png", crop_bottom=0.500)
    c.text(0.83, 6.55, 4.32, 0.20, "REAL SAVED INVESTIGATION VIEW  ·  NOT A MOCKUP", 8.4, GOLD2, bold=True, align="center", tracking=0.3)
    c.text(5.68, 1.93, 6.62, 0.25, "TWO-MINUTE WALKTHROUGH", 10.2, GOLD, bold=True, tracking=0.8)
    demo = [
        ("00:00", "Dashboard", "Separate historical counts from new investigations."),
        ("00:15", "Investigate", "Use the preloaded DDoS flow; run offline."),
        ("00:35", "Interpret", "Compare class, anomaly signal and policy priority."),
        ("00:55", "Inspect evidence", "Review a retrieved record and SHAP contributions."),
        ("01:20", "Review response", "Show the playbook, trace and evidence limits."),
        ("01:40", "Show feedback", "AI Analyst and RAG Search feedback go for review."),
    ]
    for i, (tm, heading, desc) in enumerate(demo):
        y = 2.36 + i * 0.62
        c.text(5.69, y, 0.65, 0.25, tm, 9.6, GOLD2, bold=True)
        c.text(6.47, y - 0.01, 1.63, 0.25, heading, 12, WHITE, bold=True)
        c.text(8.14, y + 0.00, 4.07, 0.31, desc, 9.9, MUTED)
    c.rect(5.67, 6.28, 6.62, 0.54, "252319", radius=0.10, stroke="65552D", sw=0.7)
    c.text(5.87, 6.39, 6.22, 0.28, "python scripts/start_local.py --restart --offline", 10.8, GOLD2, bold=True, valign="middle")
    out.append(c)

    # 9. Evaluation.
    c = Canvas(10, 75, "Evaluation Results", "Promising benchmark results, with limits in view", 18)
    metrics = [("99.21%", "ATTACK ACCURACY", "4,055-flow holdout"), ("0.9743", "MACRO F1", "9-category classifier"),
               ("0.9961", "INTRUSION ROC AUC", "Binary model"), ("0.7628", "ANOMALY ROC AUC", "Separate anomaly model")]
    mx, mw, mgap = 0.76, 2.84, 0.20
    for i, (value, label, detail) in enumerate(metrics):
        x = mx + i * (mw + mgap)
        c.rect(x, 1.87, mw, 1.22, PANEL, radius=0.13, stroke=EDGE)
        c.text(x + 0.17, 2.02, mw - 0.34, 0.47, value, 24, GOLD2, bold=True)
        c.text(x + 0.17, 2.53, mw - 0.34, 0.21, label, 9, WHITE, bold=True, tracking=0.25)
        c.text(x + 0.17, 2.79, mw - 0.34, 0.20, detail, 8.8, MUTED)
    c.rect(0.76, 3.32, 6.72, 2.52, PANEL, radius=0.14, stroke=EDGE)
    c.text(1.02, 3.53, 6.15, 0.28, "RETRIEVAL  /  PRECISION@5", 10.2, GOLD, bold=True, tracking=0.55)
    c.text(1.02, 3.92, 2.15, 0.24, "Unassisted baseline", 11.4, TEXT, bold=True)
    c.rect(3.24, 3.98, 3.27, 0.18, "383B3D", radius=0.08, stroke="383B3D", sw=0)
    c.rect(3.24, 3.98, 2.05, 0.18, "95999A", radius=0.08, stroke="95999A", sw=0)
    c.text(6.55, 3.88, 0.67, 0.32, "62.86%", 11.2, WHITE, bold=True, align="right")
    c.text(1.02, 4.53, 2.15, 0.24, "Model-assisted hybrid", 11.4, TEXT, bold=True)
    c.rect(3.24, 4.59, 3.27, 0.18, "383B3D", radius=0.08, stroke="383B3D", sw=0)
    c.rect(3.24, 4.59, 3.11, 0.18, GOLD, radius=0.08, stroke=GOLD, sw=0)
    c.text(6.55, 4.49, 0.67, 0.32, "95.24%", 11.2, GOLD2, bold=True, align="right")
    c.text(1.02, 5.05, 6.06, 0.42, "42 held-out queries · K=5 · same-category match is a coarse proxy; assisted queries use model-derived hints.", 9.3, MUTED)
    c.rect(7.72, 3.32, 4.81, 2.52, PANEL, radius=0.14, stroke=EDGE)
    c.text(7.98, 3.53, 4.28, 0.28, "HOSTED QUALITY + SOFTWARE CHECKS", 9.8, GOLD, bold=True, tracking=0.3)
    c.text(7.98, 3.98, 1.43, 0.49, "36 / 45", 21, GOLD2, bold=True)
    c.text(9.55, 3.98, 2.57, 0.43, "DeepEval scores completed", 10.7, TEXT, bold=True, valign="middle")
    c.text(7.98, 4.52, 1.43, 0.37, "5 misses", 14, RED, bold=True)
    c.text(9.55, 4.54, 2.57, 0.34, "completed metrics below threshold", 9.1, MUTED, valign="middle")
    c.line(7.98, 5.00, 4.27, 0, EDGE, 0.8)
    c.text(7.98, 5.13, 1.43, 0.35, "203 + 27", 13.1, WHITE, bold=True)
    c.text(9.55, 5.13, 2.57, 0.35, "backend + React tests passed", 9.1, MUTED, valign="middle")
    c.text(0.81, 6.10, 11.92, 0.24, "Partial hosted quality measurement—not a quality pass. Five failed scores are reported; nine other scores were unavailable.", 10.2, RED, bold=True)
    c.text(0.81, 6.48, 11.92, 0.25, "Sampled random split and rare-class support limit generalization; independent real-network validation is still needed.", 10.0, MUTED)
    out.append(c)

    # 10. Lessons and close.
    c = Canvas(11, 40, "Challenges and Learnings", "Challenges, lessons, and next validation", 19)
    columns = [
        ("CHALLENGES", ["Rare attack classes have small test support.", "A random sampled split cannot establish real-network generalization.", "Hosted responses can fail schema or citation checks."]),
        ("WHAT I LEARNED", ["Keep prediction, evidence and risk policy distinct.", "Use hybrid search and explain model contributions plainly.", "Fallback paths should preserve utility without inventing scores."]),
        ("NEXT VALIDATION", ["Test time-separated and host-separated data.", "Complete quality coverage; study analyst usability.", "Add production-grade authentication and operational controls."]),
    ]
    for i, (head, items) in enumerate(columns):
        x, y, w = 0.77 + i * 4.09, 1.94, 3.80
        c.rect(x, y, w, 3.62, PANEL, radius=0.14, stroke=EDGE)
        c.text(x + 0.22, y + 0.21, w - 0.44, 0.27, head, 10.2, GOLD, bold=True, tracking=0.6)
        for j, item in enumerate(items):
            yy = y + 0.75 + j * 0.85
            c.ellipse = None
            c.rect(x + 0.22, yy + 0.04, 0.10, 0.10, GOLD if i != 2 else GREEN, radius=0.05, stroke="none", sw=0)
            c.text(x + 0.45, yy, w - 0.68, 0.67, item, 11.3, TEXT)
    c.rect(0.80, 5.88, 11.73, 0.81, "27241A", radius=0.14, stroke="705C2F", sw=0.9)
    c.text(1.03, 6.00, 9.75, 0.28, "FROM RAW NETWORK TRAFFIC TO EXPLAINABLE, EVIDENCE-BACKED INVESTIGATION", 9.3, GOLD, bold=True, tracking=0.45)
    c.text(1.03, 6.30, 9.80, 0.29, "Evidence supports triage. The analyst makes the decision.", 15.2, WHITE, bold=True)
    c.text(11.0, 6.09, 1.24, 0.44, "QUESTIONS?", 10.5, GOLD2, bold=True, align="right", valign="middle")
    out.append(c)
    return out


def make_title_slide() -> Canvas:
    c = Canvas(1, 15, "", "", total=12)
    c.shapes = c.shapes[:2]
    c.text(0.86, 0.66, 7.15, 0.32, "FINAL PROJECT PRESENTATION  /  CYBERSECURITY", 10.2, GOLD, bold=True, tracking=1.0)
    c.text(0.84, 1.46, 7.55, 1.74, "AI-Powered Cybersecurity\nIncident Response Assistant", 32, WHITE, bold=True)
    c.line(0.88, 3.53, 1.12, 0, GOLD, 2.2)
    c.text(0.88, 3.82, 6.9, 0.84, "Explainable, evidence-backed decision support\nfor network-flow investigations", 17, TEXT)
    c.text(0.88, 5.32, 6.5, 0.32, "PRESENTED BY", 9.5, GOLD, bold=True, tracking=0.8)
    c.text(0.88, 5.68, 6.5, 0.42, "Hrushikeshreddy", 18, WHITE, bold=True)

    c.rect(8.7, 1.25, 3.78, 4.85, PANEL, radius=0.18, stroke=EDGE)
    c.text(9.02, 1.55, 3.12, 0.28, "INVESTIGATION WORKFLOW", 10, GOLD, bold=True, tracking=0.6)
    flow = [
        ("01", "Network flow", "Validated input"),
        ("02", "Signals + evidence", "Models · retrieval · SHAP"),
        ("03", "Analyst review", "Human decision"),
    ]
    for index, (number, heading, detail) in enumerate(flow):
        y = 2.10 + index * 1.08
        c.rect(9.02, y, 3.12, 0.78, PANEL2, radius=0.11, stroke="42474B", sw=0.7)
        c.text(9.20, y + 0.18, 0.42, 0.32, number, 12, GOLD, bold=True)
        c.text(9.76, y + 0.11, 2.15, 0.28, heading, 12.1, WHITE, bold=True)
        c.text(9.76, y + 0.43, 2.18, 0.22, detail, 8.8, MUTED)
        if index < len(flow) - 1:
            c.line(10.58, y + 0.81, 0, 0.23, GOLD, 1.5)
    c.line(0.66, 7.10, 12.02, 0, EDGE, 0.8)
    c.text(0.66, 7.17, 8.3, 0.18, "EVIDENCE-BASED ANALYST SUPPORT   ·   HUMAN REVIEW AT EVERY CRITICAL DECISION", 7.6, MUTED, bold=True, tracking=0.35)
    c.text(11.25, 7.14, 1.4, 0.23, "01 / 12", 8.5, GOLD2, bold=True, align="right")
    return c


def make_thank_you_slide() -> Canvas:
    c = Canvas(12, 15, "", "", total=12)
    c.shapes = c.shapes[:2]
    c.text(0.88, 0.66, 7.15, 0.32, "AI-POWERED CYBERSECURITY  /  INCIDENT RESPONSE ASSISTANT", 10.2, GOLD, bold=True, tracking=0.8)
    c.text(0.88, 1.65, 7.3, 0.80, "Thank you.", 39, WHITE, bold=True)
    c.text(0.90, 2.78, 7.1, 0.50, "Questions?", 23, GOLD2, bold=True)
    c.line(0.90, 3.57, 1.28, 0, GOLD, 2.2)
    c.text(0.90, 3.92, 7.2, 0.80, "Evidence supports triage.\nThe analyst makes the decision.", 20, TEXT, bold=True)
    c.text(0.90, 5.54, 7.1, 0.32, "Hrushikeshreddy  ·  Final project presentation", 10.5, MUTED)
    c.rect(8.73, 1.52, 3.72, 4.45, PANEL, radius=0.18, stroke=EDGE)
    c.text(9.03, 1.83, 3.1, 0.30, "ONE REVIEWABLE INVESTIGATION", 9.7, GOLD, bold=True, tracking=0.45)
    c.card(9.03, 2.43, 3.10, 0.82, "Model signal", "Prediction is an inference.")
    c.card(9.03, 3.47, 3.10, 0.82, "Historical evidence", "Similarity provides context.")
    c.card(9.03, 4.51, 3.10, 0.82, "Human decision", "The analyst chooses the action.", accent=GREEN)
    c.line(0.66, 7.10, 12.02, 0, EDGE, 0.8)
    c.text(0.66, 7.17, 8.3, 0.18, "EVIDENCE-BASED ANALYST SUPPORT   ·   HUMAN REVIEW AT EVERY CRITICAL DECISION", 7.6, MUTED, bold=True, tracking=0.35)
    c.text(11.25, 7.14, 1.4, 0.23, "12 / 12", 8.5, GOLD2, bold=True, align="right")
    return c


def make_deck() -> list[Canvas]:
    """Compose the title slide, required sections 10–19, and thank-you slide."""
    return [make_title_slide(), *make_slides(), make_thank_you_slide()]


def emu(inches: float) -> int:
    return int(round(inches * EMU))


def xml_color(color: str) -> str:
    return color.upper()


def solid_fill(color: str) -> str:
    if color == "none":
        return "<a:noFill/>"
    return f'<a:solidFill><a:srgbClr val="{xml_color(color)}"/></a:solidFill>'


def xfrm(x: float, y: float, w: float, h: float) -> str:
    return f'<a:xfrm><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm>'


def run_props(shape: dict) -> str:
    font = round(shape["size"] * 100)
    bold = ' b="1"' if shape.get("bold") else ""
    italic = ' i="1"' if shape.get("italic") else ""
    return (f'<a:rPr lang="en-US" sz="{font}"{bold}{italic} dirty="0">'
            f'<a:solidFill><a:srgbClr val="{shape["color"]}"/></a:solidFill>'
            '<a:latin typeface="Arial"/><a:ea typeface="Arial"/><a:cs typeface="Arial"/></a:rPr>')


def text_body(shape: dict) -> str:
    align = {"left": "l", "center": "ctr", "right": "r"}[shape["align"]]
    anchor = "ctr" if shape["valign"] == "middle" else "t"
    insets = 0
    body = f'<a:bodyPr wrap="square" lIns="{insets}" rIns="{insets}" tIns="{insets}" bIns="{insets}" anchor="{anchor}"/><a:lstStyle/>'
    props = run_props(shape)
    paras = []
    for line in shape["value"].split("\n"):
        paras.append(f'<a:p><a:pPr algn="{align}"><a:lnSpc><a:spcPct val="108000"/></a:lnSpc><a:spcAft><a:spcPts val="0"/></a:spcAft></a:pPr><a:r>{props}<a:t xml:space="preserve">{html.escape(line)}</a:t></a:r><a:endParaRPr lang="en-US" sz="{round(shape["size"] * 100)}"/></a:p>')
    return f'<p:txBody>{body}{"".join(paras)}</p:txBody>'


def shape_xml(shape: dict, ident: int) -> str:
    x, y, w, h = shape["x"], shape["y"], shape["w"], shape["h"]
    name = html.escape(f"Editable {shape['kind']} {ident}")
    if shape["kind"] == "image":
        crop = int(round(shape.get("crop_bottom", 0.0) * 100000))
        return (f'<p:pic><p:nvPicPr><p:cNvPr id="{ident}" name="Project screenshot"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>'
                f'<p:blipFill><a:blip r:embed="rId2"/><a:srcRect t="0" b="{crop}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>'
                f'<p:spPr>{xfrm(x,y,w,h)}<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>')
    if shape["kind"] == "line":
        return (f'<p:sp><p:nvSpPr><p:cNvPr id="{ident}" name="{name}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
                f'<p:spPr>{xfrm(x,y,max(w,0.001),max(h,0.001))}<a:prstGeom prst="line"><a:avLst/></a:prstGeom><a:noFill/>'
                f'<a:ln w="{round(shape["sw"] * 12700)}"><a:solidFill><a:srgbClr val="{shape["fill"]}"/></a:solidFill></a:ln></p:spPr></p:sp>')
    if shape["kind"] == "ellipse":
        geom = "ellipse"
    else:
        geom = "roundRect" if shape.get("radius", 0) else "rect"
    border = '<a:ln><a:noFill/></a:ln>' if shape.get("stroke") == "none" or shape.get("sw",0) <= 0 else f'<a:ln w="{round(shape.get("sw",0.8)*12700)}"><a:solidFill><a:srgbClr val="{shape["stroke"]}"/></a:solidFill></a:ln>'
    fill = solid_fill(shape.get("fill", "none"))
    body = text_body(shape) if shape["kind"] == "text" else ""
    return (f'<p:sp><p:nvSpPr><p:cNvPr id="{ident}" name="{name}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr>{xfrm(x,y,w,h)}<a:prstGeom prst="{geom}"><a:avLst/></a:prstGeom>{fill}{border}</p:spPr>{body}</p:sp>')


def svg_shape(shape: dict, ident: int) -> str:
    x, y, w, h = [shape[k] * PX for k in ("x", "y", "w", "h")]
    if shape["kind"] == "rect":
        rx = min(shape.get("radius", 0.0) * PX, h / 2)
        stroke = "none" if shape.get("stroke") == "none" or shape.get("sw", 0) <= 0 else f' stroke="#{shape["stroke"]}" stroke-width="{shape.get("sw",0.8)*PX/72:.2f}"'
        return f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rx:.1f}" fill="#{shape["fill"]}"{stroke}/>'
    if shape["kind"] == "ellipse":
        return f'<ellipse cx="{x+w/2:.1f}" cy="{y+h/2:.1f}" rx="{w/2:.1f}" ry="{h/2:.1f}" fill="#{shape["fill"]}"/>'
    if shape["kind"] == "line":
        sw = shape["sw"] * PX / 72
        return f'<line x1="{x:.1f}" y1="{y:.1f}" x2="{x+w:.1f}" y2="{y+h:.1f}" stroke="#{shape["fill"]}" stroke-width="{sw:.2f}"/>'
    if shape["kind"] == "image":
        aid = f"clip{ident}"
        full_h = h / (1 - shape.get("crop_bottom", 0))
        return (f'<defs><clipPath id="{aid}"><rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}"/></clipPath></defs>'
                f'<image href="assets/{html.escape(shape["asset"])}" x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{full_h:.1f}" preserveAspectRatio="none" clip-path="url(#{aid})"/>')
    font = shape["size"] * PX / 72
    lines = shape["value"].split("\n")
    line_h = font * 1.20
    text_height = len(lines) * line_h
    if shape["valign"] == "middle":
        first_y = y + (h - text_height) / 2 + font * 0.88
    else:
        first_y = y + font * 0.88
    anchor = {"left": "start", "center": "middle", "right": "end"}[shape["align"]]
    tx = {"left": x, "center": x + w/2, "right": x + w}[shape["align"]]
    weight = "700" if shape.get("bold") else "400"
    italic = "italic" if shape.get("italic") else "normal"
    tspans = "".join(f'<tspan x="{tx:.1f}" y="{first_y + i*line_h:.1f}">{html.escape(line)}</tspan>' for i,line in enumerate(lines))
    return (f'<text x="{tx:.1f}" y="{first_y:.1f}" text-anchor="{anchor}" fill="#{shape["color"]}" '
            f'font-family="Arial,sans-serif" font-size="{font:.1f}" font-weight="{weight}" font-style="{italic}" '
            f'letter-spacing="{shape.get("tracking",0)*0.8:.2f}px">{tspans}</text>')


def slide_xml(c: Canvas) -> str:
    items = [shape_xml(shape, i + 2) for i, shape in enumerate(c.shapes)]
    tree = ('<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
            '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
            + "".join(items) + "</p:spTree>")
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
            f'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">'
            f'<p:cSld name="Slide {c.number}"><p:bg><p:bgPr>{solid_fill(BG)}<a:effectLst/></p:bgPr></p:bg>{tree}</p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>')


def slide_svg(c: Canvas) -> str:
    shapes = "".join(svg_shape(shape, i + 2) for i, shape in enumerate(c.shapes))
    return f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1280" height="720" viewBox="0 0 1280 720">{shapes}</svg>'


def notes_markdown() -> str:
    return """# Presentation Speaker Notes

**Project:** AI-Powered Cybersecurity Incident Response Assistant  
**Presenter:** Hrushikeshreddy  
**Duration:** 10 minutes of required content plus a 15-second title and 15-second close (10:30 total).  
**Presentation order:** Title slide, sections 10–19, thank-you slide.

The measured classifier and retrieval results below are from the full sampled CIC-IDS2017 run. They do not describe the smaller portable demo. Keep the terms **prediction**, **similarity**, and **priority** distinct: none independently confirms a compromise. The hosted DeepEval result is partial, not an overall quality pass.

## Opening Title Slide (0:00–0:15)

Introduce the project as an explainable, evidence-backed assistant for network-flow investigations. Set the expectation that it supports analyst review: models and retrieval provide signals and context, while a person decides what to do.

## Slide 2 — 10. Problem Statement (0:15–1:00)

Security teams see many network alerts: a burst of connections, unusual packet rates, or a connection to an exposed service. The alert describes observed activity, but it does not tell us intent. A high traffic rate could resemble denial-of-service behavior, yet the analyst still needs to check the model signal, compare it with history, and decide what evidence to collect. Today those clues can be spread across dashboards and reports. The project addresses that gap by bringing evidence into one reviewable investigation. **Transition:** That same gap creates a business need for a more consistent workflow.

## Slide 3 — 11. Business Need (1:00–1:45)

The workflow has three jobs: identify signals, investigate them in context, and prioritize what needs attention. The practical value is not an unproven promise that an AI system will replace an analyst. It is that the analyst can inspect prediction, related records, explanation, and response suggestions in one place. That should make investigations easier to review and reduce context switching. I did not run a user study, so I cannot claim a measured reduction in investigation time or cost. **Transition:** I built the assistant to support those three jobs.

## Slide 4 — 12. Solution Overview (1:45–2:40)

An analyst supplies one network flow, often from a sample or CSV. Separate model outputs describe the predicted attack category, intrusion likelihood, and unusualness. The retrieval service looks for comparable historical flows, while a risk policy assigns a triage priority. SHAP shows which measured features influenced the classifier's prediction; those contributions are not proof of cause. A response service suggests defensive investigation steps. A hosted language model is optional: its structure and evidence references are checked, and a local playbook is available when hosted generation cannot be used. The analyst reviews the evidence and decides what to do. **Transition:** Here is how those pieces are arranged.

## Slide 5 — 13. Architecture (2:40–3:35)

There are two parts to the architecture. Offline, the data pipeline prepares CIC-IDS2017, trains and evaluates the models, and constructs the historical search index. Those saved assets are then loaded by the local application. Online, a React and TypeScript dashboard sends typed requests to FastAPI, where Pydantic validates the input. Specialist services coordinate classification, anomaly scoring, risk, SHAP, and retrieval. Retrieval combines TF-IDF/LSA vectors in FAISS with BM25 keyword scoring. Response generation can use the local evidence playbook or an optional provider. SQLite stores investigation and feedback records. **Transition:** I will follow one flow through that request path.

## Slide 6 — 14. Data Flow (3:35–4:30)

The API first checks flow features and metadata. The model services then return their separate predictions, and hybrid search ranks historical records. Similarity helps us find context; a match does not show that the new flow is the same attack. The risk policy uses configured signals to set a priority, and TreeSHAP displays feature contributions for the classifier result. If a generated response is requested, validation checks the structure and cited evidence before the response is used. The investigation is saved. Analyst feedback is retained for review; it does not automatically retrain the active model. **Transition:** These steps use a deliberately practical technology stack.

## Slide 7 — 15. Technology Stack (4:30–5:15)

The interface is React, TypeScript, Vite, Tailwind CSS, and Recharts. The service is Python with FastAPI, Pydantic, and pandas. Scikit-learn supplies the Random Forest classifier and Isolation Forest anomaly model; SHAP provides the feature-contribution view. For retrieval, the reported default is TF-IDF with latent semantic analysis, indexed in FAISS, alongside BM25. An optional NVIDIA Nemotron or other configured provider can write a response, and DeepEval measures selected quality dimensions. SQLite holds mutable investigation and feedback state. The measured system did not use pretrained sentence embeddings by default. **Transition:** These components are coordinated as specialist workflow roles.

## Slide 8 — 16. Agent Workflow (5:15–6:20)

The workflow roles run in sequence: detection, anomaly analysis, retrieval, risk assessment, explainability, response recommendation, and optional quality judging. A shared orchestrator checks what each step requires and what it returns, then records each role's status and timing. Calling them agents describes the coordinated software workflow; they are not seven independent autonomous chatbots. The response role proposes defensive steps but cannot execute containment. The quality judge needs a working, configured provider. If response generation fails validation, the local evidence-based playbook can still provide guidance; missing judge scores stay missing. The analyst makes the final decision. **Transition:** I will show that path in the running local app.

## Slide 9 — 17. Demo (6:20–8:20)

### Before presenting

1. From the project root, run `python scripts/start_local.py --restart --offline`.
2. Open the frontend URL printed by the launcher. It chooses available local ports; do not assume a deployment URL.
3. Confirm the Dashboard and Investigate pages load. The form auto-loads a supplied DDoS flow when available.
4. Keep **Use configured LLM** and **Run LLM judge** off for a deterministic offline walkthrough. The models, hybrid retrieval, SHAP, and local playbook do not need an LLM key.
5. Keep [the saved investigation screenshot](assets/investigation-result-desktop.png) ready as a visual backup.

### Two-minute live sequence

- **0:00–0:15 — Dashboard:** Point out the difference between historical dataset counts and incidents investigated in this session.
- **0:15–0:35 — Investigate:** Open the supplied DDoS flow and run with hosted generation and judging disabled.
- **0:35–0:55 — Signals:** Show attack category, probability, anomaly percentile, and policy priority as distinct values.
- **0:55–1:15 — Evidence:** Open one retrieved historical record. Explain that a similar record is context, not proof.
- **1:15–1:35 — Explain and respond:** Show SHAP feature contributions, the local playbook, and the agent trace. Point out validation or fallback status if visible.
- **1:35–1:55 — Feedback:** Show the feedback controls on the investigation and the feedback sections under AI Analyst and RAG Search. Submissions are saved for review; they do not retrain the model.
- **1:55–2:00 — Close demo:** Return to the investigation summary and restate that the analyst decides on any response action.

If time is short, prioritize the prediction, one retrieved record, SHAP explanation, local recommendation, and feedback status. If the live app is unavailable, use the saved screenshot and explain the same sequence. Do not describe an unavailable hosted judge as having produced scores.

**Transition:** These are the measured results and the limits I used to interpret them.

## Slide 10 — 18. Evaluation Results (8:20–9:35)

The nine-category Random Forest achieved 99.21 percent accuracy and 0.9743 macro F1 on a sampled holdout of 4,055 flows. The binary intrusion ROC AUC is 0.9961; the separate anomaly detector's ROC AUC is 0.7628. Retrieval Precision@5 rose from 62.86 percent for the unassisted baseline to 95.24 percent for the model-assisted hybrid on 42 held-out queries. Relevance here means same-category membership, a coarse proxy, and the assisted query uses model-derived hints. Hosted DeepEval completed 36 of 45 scores; five completed scores missed thresholds and nine scores were unavailable. That is partial measurement, not a quality pass. The release snapshot also recorded 203 backend and 27 React tests passing. The random sampled split and small rare-class support mean independent real-network validation remains necessary. **Transition:** Those limits shaped the next steps I would take.

## Slide 11 — 19. Challenges and Learnings (9:35–10:15)

The challenges were imbalanced traffic data, small rare-class holdouts, and hosted responses that can fail schema or citation checks. I learned to validate each hand-off and keep prediction, evidence and policy distinct. Next I would test with time- and host-separated data, complete quality coverage, study analyst usability, and add production-grade access controls. This prototype provides evidence for triage; a human analyst remains accountable for decisions. **Transition:** I will close with that central design principle.

## Slide 12 — Thank You (10:15–10:30)

Thank the audience and invite questions. The main takeaway is that evidence supports triage while the analyst makes the decision.

## Likely evaluator questions

**Does the system confirm compromise or block traffic?** No. It provides evidence and defensive options for analyst review.

**Is the risk score a probability?** No. It is a configurable triage-policy score. The classifier probabilities are separate.

**Does the language model classify the flow?** No. The tabular classifier predicts its category; a configured LLM may summarize supplied evidence.

**What does retrieval Precision@5 mean?** In this benchmark, it is the share of the top five results with the expected category. That is a coarse relevance proxy, not factual accuracy.

**Why is DeepEval incomplete?** Thirty-six of forty-five scores completed; eight metric calls errored and one timed out. Five completed scores missed thresholds.

**Did the project prove analyst time savings?** No. Reduced context switching is an intended benefit; a user study is needed.

**Can I run the demo without a key?** Yes. With the local/offline option, the model, retrieval, explanation, policy, and playbook work without hosted generation.
"""


def demo_markdown() -> str:
    return """# Demo Walkthrough

**Length:** 2 minutes  
**Mode:** Local and offline; do not depend on a hosted model.  
**Purpose:** Show one supplied DDoS flow moving through classification, anomaly analysis, hybrid retrieval, triage, explanation, response guidance, and human feedback.

## Prepare the local application

From the repository root, run:

```bash
python scripts/start_local.py --restart --offline
```

Open the `frontend_url` printed by the launcher. It selects free local ports, so use the printed address rather than assuming a hosted URL. Offline mode selects the local provider for this run without editing `.env`. Confirm that Dashboard and Investigate load before presenting.

The supplied sample is real CIC-IDS2017 data. The Investigate form selects a DDoS sample when the sample list is loaded. Keep **Use configured LLM** and **Run LLM judge** disabled: local ML, retrieval, SHAP, the triage policy, and the evidence-based response playbook work without an API key. Do not call the local response playbook an LLM response.

## Live sequence

| Time | Action | What to explain |
|---|---|---|
| 0:00–0:15 | Open Dashboard | Historical dataset records and newly investigated incidents are different counts. |
| 0:15–0:35 | Open Investigate and run the preloaded DDoS flow | This is one observed flow; the model result is an inference. |
| 0:35–0:55 | Read the result summary | Category, intrusion probability, anomaly percentile, and risk-policy priority are distinct signals. |
| 0:55–1:15 | Open a historical match | Similarity retrieves context; it does not prove the current flow is an attack. |
| 1:15–1:35 | Show Explainability, response, and workflow trace | SHAP contributions are not causes; the response is guidance and the trace shows role status/timing. |
| 1:35–1:55 | Show feedback | The incident form, AI Analyst, and RAG Search each have feedback controls. Submitted feedback is retained for review; it does not auto-retrain. |
| 1:55–2:00 | Return to summary | An analyst decides whether any defensive action is appropriate. |

## Screenshots and recovery

The slide uses a crop of the real `artifacts/figures/investigation-result-desktop.png` screenshot. Keep the full application view open as backup. If the live application cannot be shown, use the screenshot, describe the same model/evidence/explanation sequence, and state clearly that it is a saved interface capture. Do not imply that a displayed screenshot is a live provider response or a newly run result.

If the UI is reachable but the sample list is empty, confirm `/ready` in the API and check `artifacts/runtime.json` for the launcher's chosen API/frontend ports. The startup script and readiness checks are documented in the repository README. Avoid restarting or retraining during the timed presentation.
"""


def validation_markdown(pdf_pages: int, pptx_slides: int, shape_counts: list[int], words: int) -> str:
    return f"""# Presentation Validation

**Project:** AI-Powered Cybersecurity Incident Response Assistant  
**Output directory:** `final_presentation/`  
**Presentation date:** 12 October 2026  
**Format:** 16:9 widescreen · charcoal and gold · editable title and thank-you slides around the ten required content slides.

## Deliverables

- `AI_Cybersecurity_Incident_Response_Final_Presentation.pptx` — editable PowerPoint. Text, cards, diagrams, labels, and result bars are native editable shapes; the demo screenshot is embedded as an image.
- `AI_Cybersecurity_Incident_Response_Final_Presentation.pdf` — rendered from the matching twelve-slide SVG/HTML source.
- `Presentation_Speaker_Notes.md` — timed speaking script, two-minute demo sequence, closing, and panel questions.
- `Demo_Walkthrough.md` — exact local startup command, demonstration sequence, and recovery notes.
- `Presentation_Validation.md` — this record.

## Slide and timing verification

| Slide | Content | Time |
|---:|---|---:|
| 1 | Title and project framing | 0:15 |
| 2 | 10. Problem Statement | 0:45 |
| 3 | 11. Business Need | 0:45 |
| 4 | 12. Solution Overview | 0:55 |
| 5 | 13. Architecture | 0:55 |
| 6 | 14. Data Flow | 0:55 |
| 7 | 15. Technology Stack | 0:45 |
| 8 | 16. Agent Workflow | 1:05 |
| 9 | 17. Demo | 2:00 |
| 10 | 18. Evaluation Results | 1:15 |
| 11 | 19. Challenges and Learnings | 0:40 |
| 12 | Thank you and questions | 0:15 |
|  | **Required content total** | **10:00** |
|  | **Run time with bookends** | **10:30** |

Structural checks found **{pptx_slides} PowerPoint slides** and **{pdf_pages} PDF pages**: a title, the ten required sections in order, and a closing slide. Editable shapes per slide: `{", ".join(map(str, shape_counts))}`; the PowerPoint contains a real application screenshot on the demo slide. The timed spoken script is approximately {words} words; the ten required sections remain a ten-minute talk.

## Evidence and source checks

- Project identity, user workflow, frontend, backend, models, retrieval approach, agent roles, storage, startup command, and feedback behavior: `README.md`, `docs/design.md`, `docs/architecture.md`, `docs/advanced_rag.md`, `docs/api.md`, `src/agents/`, `src/rag/`, `src/services/`, `frontend/src/`, and `scripts/start_local.py`.
- Classifier and anomaly metrics, test sample size, retrieval benchmark and DeepEval partial status: `docs/evaluation_report.md` and `docs/evidence/deepeval.json`.
- Actual application screenshot: `artifacts/figures/investigation-result-desktop.png`, embedded in the PowerPoint and included under `final_presentation/assets/`.
- Offline demo path: `README.md` and `scripts/start_local.py`; the launcher prints its selected local addresses.

## Accuracy boundaries retained

- Attack classification, intrusion likelihood, anomaly percentile, policy risk and historical similarity remain distinct signals.
- A model prediction and retrieved historical label are not confirmation of a new attack. Similarity and SHAP values are not causal proof.
- TF-IDF/LSA plus FAISS and BM25 are reported as the retrieval baseline; pretrained sentence embeddings are optional.
- The local evidence playbook is described as a fallback, not an LLM. LLM output is optional and must pass structure/evidence validation.
- DeepEval coverage is 36/45 completed scores; five completed metrics missed thresholds and nine were unavailable. The result is explicitly partial.
- Model figures are identified as the full sampled CIC-IDS2017 run (4,055 held-out flows), not the portable demo. Retrieval uses 42 held-out queries and a coarse same-category Precision@5 proxy.
- Reduced context switching is an objective, not a measured productivity or time-saving result. Analyst review remains required.
- No private keys, tokens, provider credentials, deployment URL, or unverified production capability are included.

## Artifact checks

- PowerPoint ZIP CRC verification passed; all XML parts parse; all twelve slide parts, the presentation relationships, and embedded image relationship are present.
- The final PDF rendered as {pdf_pages} pages. All slide SVGs were rendered on a 1280 × 720 viewBox before export; the PDF and PowerPoint are generated from the same native-shape layout data.
- PowerPoint element bounds were checked against the 13⅓ × 7.5 inch slide canvas; no object extends past the slide edges.
- The source PowerPoint keeps diagrams, headings, data cards and bars editable. The real UI screenshot is the only non-editable visual asset.

**Limit:** macOS Quick Look generated and displayed a thumbnail of slide 1 from the PowerPoint file. An Office/Keynote GUI was not available for direct slide navigation; all twelve slides were rendered and visually inspected in the exported PDF.
"""


def inch_bound_violations(canvases: list[Canvas]) -> list[str]:
    violations = []
    for c in canvases:
        for s in c.shapes:
            if s["x"] < -0.001 or s["y"] < -0.001 or s["x"] + s["w"] > W + 0.002 or s["y"] + s["h"] > H + 0.002:
                violations.append(f"slide {c.number}: {s}")
    return violations


def create_pptx(canvases: list[Canvas], output: Path, image_payload: bytes) -> None:
    ns_p = "http://schemas.openxmlformats.org/presentationml/2006/main"
    ns_a = "http://schemas.openxmlformats.org/drawingml/2006/main"
    ns_r = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    master_rid = len(canvases) + 1
    slides_ids = "".join(f'<p:sldId id="{255+i}" r:id="rId{i+1}"/>' for i in range(len(canvases)))
    pres = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentation xmlns:a="{ns_a}" xmlns:r="{ns_r}" xmlns:p="{ns_p}">'
            f'<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId{master_rid}"/></p:sldMasterIdLst><p:sldIdLst>{slides_ids}</p:sldIdLst>'
            f'<p:sldSz cx="{emu(W)}" cy="{emu(H)}" type="screen16x9"/><p:notesSz cx="{emu(7.5)}" cy="{emu(10)}"/><p:defaultTextStyle/></p:presentation>')
    pres_rels = "".join(f'<Relationship Id="rId{i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide{i+1}.xml"/>' for i in range(len(canvases)))
    pres_rels += f'<Relationship Id="rId{master_rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>'
    master = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldMaster xmlns:a="{ns_a}" xmlns:r="{ns_r}" xmlns:p="{ns_p}">'
              '<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree></p:cSld>'
              '<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>'
              '<p:sldLayoutIdLst><p:sldLayoutId id="1" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles><p:titleStyle/><p:bodyStyle/><p:otherStyle/></p:txStyles></p:sldMaster>')
    layout = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldLayout xmlns:a="{ns_a}" xmlns:r="{ns_r}" xmlns:p="{ns_p}" type="blank" preserve="1">'
              '<p:cSld name="Blank"><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>')
    theme = (
        f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><a:theme xmlns:a="{ns_a}" name="Incident Response Charcoal Gold"><a:themeElements>'
        f'<a:clrScheme name="Charcoal Gold"><a:dk1><a:srgbClr val="{BG}"/></a:dk1><a:lt1><a:srgbClr val="{WHITE}"/></a:lt1><a:dk2><a:srgbClr val="{PANEL}"/></a:dk2><a:lt2><a:srgbClr val="{TEXT}"/></a:lt2>'
        f'<a:accent1><a:srgbClr val="{GOLD}"/></a:accent1><a:accent2><a:srgbClr val="{GOLD2}"/></a:accent2><a:accent3><a:srgbClr val="{GREEN}"/></a:accent3><a:accent4><a:srgbClr val="{RED}"/></a:accent4><a:accent5><a:srgbClr val="7B8589"/></a:accent5><a:accent6><a:srgbClr val="34393D"/></a:accent6><a:hlink><a:srgbClr val="D7B45A"/></a:hlink><a:folHlink><a:srgbClr val="B39247"/></a:folHlink></a:clrScheme>'
        '<a:fontScheme name="Arial"><a:majorFont><a:latin typeface="Arial"/></a:majorFont><a:minorFont><a:latin typeface="Arial"/></a:minorFont></a:fontScheme>'
        '<a:fmtScheme name="Minimal"><a:fillStyleLst>'
        '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
        '<a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"/></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:tint val="50000"/><a:satMod val="300000"/></a:schemeClr></a:gs></a:gsLst><a:lin ang="16200000" scaled="1"/></a:gradFill>'
        '<a:gradFill rotWithShape="1"><a:gsLst><a:gs pos="0"><a:schemeClr val="phClr"><a:tint val="15000"/><a:satMod val="350000"/></a:schemeClr></a:gs><a:gs pos="100000"><a:schemeClr val="phClr"><a:shade val="85000"/><a:satMod val="300000"/></a:schemeClr></a:gs></a:gsLst><a:lin ang="16200000" scaled="1"/></a:gradFill>'
        '</a:fillStyleLst><a:lnStyleLst>'
        '<a:ln w="6350"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'
        '<a:ln w="12700"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'
        '<a:ln w="19050"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'
        '</a:lnStyleLst><a:effectStyleLst>'
        '<a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle>'
        '</a:effectStyleLst><a:bgFillStyleLst>'
        '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
        '<a:solidFill><a:schemeClr val="phClr"><a:tint val="95000"/></a:schemeClr></a:solidFill>'
        '<a:solidFill><a:schemeClr val="phClr"><a:shade val="90000"/></a:schemeClr></a:solidFill>'
        '</a:bgFillStyleLst></a:fmtScheme></a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/></a:theme>'
    )
    content_types = ['<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>', '<Default Extension="xml" ContentType="application/xml"/>', '<Default Extension="png" ContentType="image/png"/>', '<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>', '<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>', '<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>', '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>']
    content_types.extend(f'<Override PartName="/ppt/slides/slide{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>' for i in range(1,len(canvases)+1))
    files = {
        "[Content_Types].xml": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' + "".join(content_types) + "</Types>",
        "_rels/.rels": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>',
        "ppt/presentation.xml": pres,
        "ppt/_rels/presentation.xml.rels": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + pres_rels + '</Relationships>',
        "ppt/slideMasters/slideMaster1.xml": master,
        "ppt/slideMasters/_rels/slideMaster1.xml.rels": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/></Relationships>',
        "ppt/slideLayouts/slideLayout1.xml": layout,
        "ppt/slideLayouts/_rels/slideLayout1.xml.rels": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/></Relationships>',
        "ppt/theme/theme1.xml": theme,
        "docProps/core.xml": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>AI-Powered Cybersecurity Incident Response Assistant</dc:title><dc:creator>Hrushikeshreddy</dc:creator><dc:subject>Final project evaluation presentation</dc:subject></cp:coreProperties>',
        "docProps/app.xml": f'<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Microsoft PowerPoint</Application><PresentationFormat>On-screen Show (16:9)</PresentationFormat><Slides>{len(canvases)}</Slides></Properties>',
        "ppt/media/investigation-result-desktop.png": image_payload,
    }
    for i, slide in enumerate(canvases, 1):
        files[f"ppt/slides/slide{i}.xml"] = slide_xml(slide)
        rels = '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
        if any(s["kind"] == "image" for s in slide.shapes):
            rels += '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/investigation-result-desktop.png"/>'
        files[f"ppt/slides/_rels/slide{i}.xml.rels"] = f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">{rels}</Relationships>'
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, value in files.items():
            archive.writestr(name, value)


def validate_pptx(path: Path, canvases: list[Canvas]) -> list[str]:
    problems = []
    with zipfile.ZipFile(path) as archive:
        bad = archive.testzip()
        if bad:
            problems.append(f"corrupt zip member: {bad}")
        names = archive.namelist()
        slide_names = sorted((n for n in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)), key=lambda name: int(re.search(r"slide(\d+)", name).group(1)))
        if len(slide_names) != 12:
            problems.append(f"expected 12 slide XML parts, found {len(slide_names)}")
        for name in names:
            if name.endswith(".xml") or name.endswith(".rels"):
                try:
                    ET.fromstring(archive.read(name))
                except ET.ParseError as exc:
                    problems.append(f"invalid XML {name}: {exc}")
        for i, name in enumerate(slide_names, 1):
            root = ET.fromstring(archive.read(name))
            if not list(root.iter("{http://schemas.openxmlformats.org/presentationml/2006/main}sp")):
                problems.append(f"slide {i} has no editable PowerPoint shapes")
            if i == 9 and not list(root.iter("{http://schemas.openxmlformats.org/presentationml/2006/main}pic")):
                problems.append("demo slide is missing its screenshot")
        if "ppt/media/investigation-result-desktop.png" not in names:
            problems.append("embedded project screenshot is missing")
    return problems


def write_html(canvases: list[Canvas], path: Path) -> None:
    sections = []
    for c in canvases:
        label = f"{c.section_number}. {c.section}" if c.section_number is not None else (c.title or c.section or f"Slide {c.number}")
        sections.append(f'<section class="slide" aria-label="{html.escape(label)}"><div class="paper">{slide_svg(c)}</div></section>')
    page = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AI-Powered Cybersecurity Incident Response Assistant — Final Presentation</title><style>
*{box-sizing:border-box}html,body{margin:0;padding:0;background:#070809;color:#f5f2e9;font-family:Aptos,Arial,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}.slide{width:13.333333in;height:7.5in;background:#101214;page-break-after:always;break-after:page;display:flex;align-items:center;justify-content:center;overflow:hidden}.slide:last-child{page-break-after:auto;break-after:auto}.paper,.paper svg{display:block;width:13.333333in;height:7.5in}@page{size:13.333333in 7.5in;margin:0}@media screen{.slide{margin:24px auto;box-shadow:0 16px 70px #000b}}
</style></head><body>""" + "".join(sections) + "</body></html>"
    path.write_text(page, encoding="utf-8")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    ASSETS.mkdir(exist_ok=True)
    source_image = ROOT / "artifacts/figures/investigation-result-desktop.png"
    if not source_image.is_file():
        raise FileNotFoundError(source_image)
    image_payload = source_image.read_bytes()
    shutil.copyfile(source_image, ASSETS / source_image.name)
    canvases = make_deck()
    violations = inch_bound_violations(canvases)
    if violations:
        raise ValueError("Out-of-bounds PowerPoint content:\n" + "\n".join(violations))
    pptx = OUT / "AI_Cybersecurity_Incident_Response_Final_Presentation.pptx"
    pdf = OUT / "AI_Cybersecurity_Incident_Response_Final_Presentation.pdf"
    create_pptx(canvases, pptx, image_payload)
    problems = validate_pptx(pptx, canvases)
    if problems:
        raise ValueError("PowerPoint validation failed:\n" + "\n".join(problems))
    write_html(canvases, OUT / "Presentation_Preview.html")
    (OUT / "Presentation_Speaker_Notes.md").write_text(notes_markdown(), encoding="utf-8")
    (OUT / "Demo_Walkthrough.md").write_text(demo_markdown(), encoding="utf-8")
    words = len(re.findall(r"\b[\w’'-]+\b", notes_markdown()))
    slide_shapes = [len(s.shapes) for s in canvases]
    # Fill the validation record after PDF render, in render_final_presentation.py.
    (OUT / "Presentation_Validation.md").write_text(validation_markdown(0, len(canvases), slide_shapes, words), encoding="utf-8")
    print(json.dumps({"pptx": str(pptx), "slides": len(canvases), "shape_counts": slide_shapes,
                      "pptx_bytes": pptx.stat().st_size, "out_of_bounds": 0, "pptx_package_errors": 0}, indent=2))


if __name__ == "__main__":
    main()
