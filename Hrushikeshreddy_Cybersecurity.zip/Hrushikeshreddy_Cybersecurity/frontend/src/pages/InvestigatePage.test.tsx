import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { demoHistorical, demoInvestigation } from '../demo/data'
import { InvestigatePage } from './InvestigatePage'

const mocks = vi.hoisted(() => ({ investigate: vi.fn() }))
vi.mock('../api', () => ({ investigationApi: { investigate: mocks.investigate, samples: vi.fn() } }))
vi.mock('../hooks/useApiResource', () => ({ useApiResource: () => ({ data: [demoHistorical] }) }))
vi.mock('../components/investigation/AnalysisStageLoader', () => ({ AnalysisStageLoader: () => <div>Pending fixture</div> }))

function renderPage() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false }, mutations: { retry: false } } })
  render(<QueryClientProvider client={client}><MemoryRouter initialEntries={['/investigate']}><Routes>
    <Route path="/investigate" element={<InvestigatePage />} />
    <Route path="/incidents/:id" element={<p>Saved incident fixture</p>} />
  </Routes></MemoryRouter></QueryClientProvider>)
  return client
}

describe('investigation recovery', () => {
  beforeEach(() => mocks.investigate.mockReset())
  afterEach(() => { cleanup(); vi.restoreAllMocks() })

  it('preserves edited flows and explicit provider choices after an API error', async () => {
    let reject!: (reason: Error) => void
    mocks.investigate.mockImplementation(() => new Promise((_, fail) => { reject = fail }))
    renderPage()
    fireEvent.change(screen.getByLabelText('Destination port'), { target: { value: '443' } })
    fireEvent.change(screen.getByLabelText('Investigation objective'), { target: { value: 'Investigate my custom TLS flow' } })
    fireEvent.click(screen.getByLabelText('Use configured LLM'))
    fireEvent.click(screen.getByLabelText('Run LLM judge'))
    fireEvent.click(screen.getByRole('button', { name: 'Run investigation' }))
    await screen.findByText('Pending fixture')
    reject(new Error('The incident-analysis API is unavailable.'))
    await screen.findByRole('alert')
    expect(screen.getByRole('alert')).toHaveTextContent('The incident-analysis API is unavailable.')
    expect(screen.getByLabelText('Destination port')).toHaveValue(443)
    expect(screen.getByLabelText('Investigation objective')).toHaveValue('Investigate my custom TLS flow')
    expect(screen.getByLabelText('Use configured LLM')).not.toBeChecked()
    expect(screen.getByLabelText('Run LLM judge')).not.toBeChecked()

    mocks.investigate.mockResolvedValue(demoInvestigation)
    fireEvent.click(screen.getByRole('button', { name: 'Run investigation' }))
    await screen.findByText('Saved incident fixture')
    expect(mocks.investigate.mock.calls[1][0]).toEqual(mocks.investigate.mock.calls[0][0])
  })

  it('opens a successfully saved incident when browser storage is unavailable', async () => {
    vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => { throw new Error('Storage blocked') })
    mocks.investigate.mockResolvedValue(demoInvestigation)
    const client = renderPage()
    fireEvent.click(screen.getByRole('button', { name: 'Run investigation' }))
    await screen.findByText('Saved incident fixture')
    await waitFor(() => expect(client.getQueryData(['incident', demoInvestigation.incident_id])).toEqual(demoInvestigation))
  })
})
