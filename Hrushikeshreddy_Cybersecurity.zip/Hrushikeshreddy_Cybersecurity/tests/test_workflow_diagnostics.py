from dataclasses import replace

import pytest

from src.agents.orchestrator import Orchestrator
from src.api.schemas import Analysis, InvestigationRequest, JudgeDimensions, JudgeOutput, JudgeScore
from src.services.provider_resilience import CircuitOpenError, provider_failure_reason
from src.services.recommendations import RecommendationService, local_analysis
from src.services.reporting import markdown_report
from src.agents.quality_judge import DIMENSIONS, JudgeService


class FixtureHTTPError(RuntimeError):
    def __init__(self, status):
        super().__init__("private-provider-detail")
        self.status_code = status


@pytest.mark.parametrize("error,expected", [
    (FixtureHTTPError(401), "credential (HTTP 401)"),
    (FixtureHTTPError(403), "access"),
    (FixtureHTTPError(429), "quota limit"),
    (FixtureHTTPError(404), "not found"),
    (CircuitOpenError("private-provider-detail"), "cooldown"),
    (TimeoutError("private-provider-detail"), "timeout"),
    (ValueError("private-provider-detail"), "validation"),
    (RuntimeError("private-provider-detail"), "could not be completed"),
])
def test_provider_failure_categories_do_not_expose_private_messages(error, expected):
    reason = provider_failure_reason(error)
    assert expected in reason
    assert "private-provider-detail" not in reason


def workflow(client, monkeypatch):
    services = client.app.state.services
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-only-key")
    config = replace(services.config, llm_provider="anthropic")
    return Orchestrator(services.models, services.retrieval, services.risk,
                        RecommendationService(config), JudgeService(config), services.repository, persist=False)


@pytest.mark.parametrize("judge_enabled", [False, True])
def test_failed_live_generation_keeps_recommendations_and_explains_judge_status(client, sample, monkeypatch, judge_enabled):
    runner = workflow(client, monkeypatch)
    calls = []

    def fail(*args, **kwargs):
        calls.append(1)
        raise FixtureHTTPError(401)

    monkeypatch.setattr("src.services.recommendations.generate_structured", fail)
    monkeypatch.setattr("src.agents.quality_judge.generate_structured", fail)
    result = runner.investigate(InvestigationRequest(flow={"features": sample["features"]}, use_llm=True, judge=judge_enabled))
    assert result.analysis_provider == "local_fallback"
    assert result.analysis.immediate_investigation
    response, judge = result.workflow[-2:]
    assert response.status == "degraded" and "HTTP 401" in response.detail
    assert judge.status == ("unavailable" if judge_enabled else "not_requested")
    assert ("HTTP 401" if judge_enabled else "judge=false") in judge.detail
    assert len(calls) == (2 if judge_enabled else 1)
    if judge_enabled:
        assert result.judge.dimensions == {}
    report = markdown_report(result.model_dump(mode="json"))
    assert "HTTP 401" in report
    assert "private-provider-detail" not in report and "test-only-key" not in report


def test_missing_credentials_do_not_attempt_remote_generation(client, sample, monkeypatch):
    runner = workflow(client, monkeypatch)
    monkeypatch.delenv("ANTHROPIC_API_KEY")

    def unexpected(*args, **kwargs):
        pytest.fail("A provider request was attempted without credentials")

    monkeypatch.setattr("src.services.recommendations.generate_structured", unexpected)
    monkeypatch.setattr("src.agents.quality_judge.generate_structured", unexpected)
    result = runner.investigate(InvestigationRequest(flow={"features": sample["features"]}, judge=True))
    assert "API key is missing" in result.workflow[-2].detail
    assert result.workflow[-1].status == "not_configured"


def test_mocked_success_contract_completes_response_and_all_judge_dimensions(client, sample, monkeypatch):
    runner = workflow(client, monkeypatch)

    def generate(config, instructions, payload, schema, **kwargs):
        if schema is Analysis:
            return local_analysis(payload["evidence_data"])
        return JudgeOutput(dimensions=JudgeDimensions(**{
            name: JudgeScore(score=4, reason="Synthetic provider contract fixture, not live quality evidence.") for name in DIMENSIONS}))

    monkeypatch.setattr("src.services.recommendations.generate_structured", generate)
    monkeypatch.setattr("src.agents.quality_judge.generate_structured", generate)
    result = runner.investigate(InvestigationRequest(flow={"features": sample["features"]}, judge=True))
    assert all(step.status == "completed" for step in result.workflow)
    assert result.analysis_provider == "anthropic"
    assert set(result.judge.dimensions) == DIMENSIONS
    assert "anthropic" in result.workflow[-2].detail and "anthropic" in result.workflow[-1].detail
