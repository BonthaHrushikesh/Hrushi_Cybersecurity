import json

from src.api.schemas import InvestigationRequest

QUESTIONS = {
    "Brute Force": "Does this traffic resemble historical authentication brute force activity? What evidence should be investigated?",
    "DDoS": "Which similar historical denial of service incidents exist and which signals drive priority?",
    "PortScan": "Does this flow resemble reconnaissance and which service logs should be correlated?",
    "Web Attack": "What similar historical web incidents exist and what application evidence should be collected?",
    "BENIGN": "Does this flow resemble normal traffic and what uncertainty remains?",
    "Bot": "What historical bot activity resembles this flow and which endpoint evidence should be collected?",
    "DoS": "How should this suspected denial of service flow be prioritized?",
    "Infiltration": "Does this traffic resemble historical infiltration and what host evidence would confirm an intrusion?",
    "Heartbleed": "What similar historical Heartbleed flows exist and which service or packet evidence should be investigated?",
}


def build_cases(services, use_llm: bool = False, judge: bool = False) -> list[dict]:
    import pandas as pd

    frame = pd.read_csv(services.config.processed / "test.csv")
    columns = services.models.bundle["raw_features"]
    cases = []
    for category, group in frame.groupby("attack_category"):
        complete = group.dropna(subset=["destination_port", "flow_duration", "flow_packets_s", "flow_bytes_s"])
        if complete.empty:
            raise ValueError(f"No complete held-out flow is available for evaluation category {category}")
        row = complete.iloc[0]
        features = {name: float(row[name]) for name in columns if pd.notna(row[name])}
        metadata = {name: row[name] for name in ["flow_id", "source_ip", "destination_ip", "source_port", "protocol", "timestamp"] if name in row and pd.notna(row[name])}
        if "flow_id" in metadata:
            metadata["flow_id"] = str(metadata["flow_id"])
        if "source_port" in metadata:
            metadata["source_port"] = int(metadata["source_port"])
        request = InvestigationRequest(flow={"features": features, "metadata": metadata}, query=QUESTIONS[category], use_llm=use_llm, judge=judge)
        result = services.orchestrator.investigate(request)
        # Expected output describes evaluation truth, independent from the model prediction.
        expected = f"The supplied labeled evaluation flow belongs to {category}. Distinguish model inference from confirmation; recommend defensive log correlation and analyst-approved containment."
        context = [json.dumps({"observed_features": features, "prediction": result.prediction.model_dump(), "risk": result.risk.model_dump(),
                               "anomaly": result.anomaly.model_dump(), "explanation": result.explanation.model_dump()})]
        context += [json.dumps({"incident_id": x.incident_id, "document": x.document}) for x in result.retrieval.results]
        cases.append({"input": request.query, "actual_output": result.analysis.model_dump_json(), "expected_output": expected,
                      "retrieval_context": context, "context": context, "metadata": {"category": category, "analysis_provider": result.analysis_provider,
                                                                                "judge": result.judge.model_dump() if result.judge else None}})
    return cases
