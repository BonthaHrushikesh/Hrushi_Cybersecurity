from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import logging
from time import perf_counter
from typing import Any
from uuid import uuid4

from src.rag.document_builder import ALIASES, flow_document
from src.api.schemas import InvestigationRequest, InvestigationResult, SearchRequest, WorkflowStep
from src.services.recommendations import evidence_payload

logger = logging.getLogger(__name__)


@dataclass
class InvestigationState:
    request: InvestigationRequest
    values: dict[str, Any] = field(default_factory=dict)
    trace: list[WorkflowStep] = field(default_factory=list)


class Agent:
    name = "Agent"
    requires: set[str] = set()
    provides: set[str] = set()
    tools: list[str] = []

    def run(self, state: InvestigationState) -> dict:
        raise NotImplementedError


class DetectionAgent(Agent):
    name, provides, tools = "Detection Agent", {"prediction"}, ["supervised_classifier"]

    def __init__(self, models):
        self.models = models

    def run(self, state):
        return {"prediction": self.models.classify(state.request.flow)}


class AnomalyAgent(Agent):
    name, provides, tools = "Anomaly Agent", {"anomaly"}, ["isolation_forest"]

    def __init__(self, models):
        self.models = models

    def run(self, state):
        return {"anomaly": self.models.anomaly(state.request.flow)}


class RetrievalAgent(Agent):
    name, requires, provides, tools = "Retrieval Agent", {"prediction"}, {"retrieval"}, ["semantic_vectors", "bm25", "model_hypothesis", "metadata_filter"]

    def __init__(self, retrieval):
        self.retrieval = retrieval

    def run(self, state):
        request = state.request
        category = state.values["prediction"].predicted_attack_type
        hypothesis = f"Model hypothesis: {category}. {ALIASES.get(category, category)}."
        query = " ".join([request.query, hypothesis, flow_document(request.flow.features, request.flow.metadata.model_dump())])
        query = query[:1000]
        search = SearchRequest(query=query, top_k=request.top_k, alpha=request.alpha, filters=request.filters,
                               mode=request.mode, fusion=request.fusion, expand_query=request.expand_query, diversify=request.diversify)
        return {"retrieval": self.retrieval.search(search, flow_features=request.flow.features if request.mode == "hybrid" else None)}


class RiskAgent(Agent):
    name, requires, provides, tools = "Risk Assessment Agent", {"prediction", "anomaly", "retrieval"}, {"risk"}, ["weighted_triage_policy"]

    def __init__(self, risk):
        self.risk = risk

    def run(self, state):
        risk = self.risk.score(state.request.flow, state.values["prediction"], state.values["anomaly"])
        history = state.values["retrieval"].results
        if history:
            agreement = sum(x.attack_type == state.values["prediction"].predicted_attack_type for x in history)
            risk.explanation += f" Historical category agreement: {agreement}/{len(history)} retrieved records; this informs review but is not counted as independent attack proof."
        else:
            risk.explanation += " No matching historical evidence is available for corroboration."
        return {"risk": risk}


class ExplainabilityAgent(Agent):
    name, requires, provides, tools = "Explainability Agent", {"prediction"}, {"explanation"}, ["tree_shap"]

    def __init__(self, models):
        self.models = models

    def run(self, state):
        return {"explanation": self.models.explain(state.request.flow, state.values["prediction"])}


class ResponseAgent(Agent):
    name = "Response Recommendation Agent"
    requires, provides, tools = {"prediction", "anomaly", "risk", "retrieval", "explanation"}, {"analysis", "analysis_provider", "evidence"}, ["grounded_response_provider", "citation_validation"]

    def __init__(self, recommendations):
        self.recommendations = recommendations

    def run(self, state):
        v = state.values
        evidence = evidence_payload(state.request.flow, v["prediction"], v["anomaly"], v["risk"], v["retrieval"], v["explanation"])
        analysis, provider = self.recommendations.generate(evidence, state.request.query, state.request.use_llm)
        return {"analysis": analysis, "analysis_provider": provider, "evidence": evidence}


class JudgeAgent(Agent):
    name, requires, provides, tools = "Quality Judge Agent", {"analysis", "evidence"}, {"judge"}, ["evidence_aware_llm_judge"]

    def __init__(self, judge):
        self.judge = judge

    def run(self, state):
        return {"judge": self.judge.evaluate(state.values["analysis"], state.values["evidence"]) if state.request.judge else None}


class Orchestrator:
    def __init__(self, models, retrieval, risk, recommendations, judge, repository, persist: bool = True):
        self.repository = repository
        self.persist = persist
        self.agents = [DetectionAgent(models), AnomalyAgent(models), RetrievalAgent(retrieval),
                       RiskAgent(risk), ExplainabilityAgent(models), ResponseAgent(recommendations), JudgeAgent(judge)]

    def investigate(self, request: InvestigationRequest) -> InvestigationResult:
        started = perf_counter()
        state = InvestigationState(request)
        incident_id = "INV-" + uuid4().hex[:16]
        for agent in self.agents:
            if not agent.requires <= state.values.keys():
                raise RuntimeError(f"Unsatisfied workflow dependencies for {agent.name}")
            begin = perf_counter()
            try:
                output = agent.run(state)
                if set(output) != agent.provides:
                    raise RuntimeError(f"Invalid output contract for {agent.name}")
                state.values.update(output)
            except Exception as error:
                logger.error(json.dumps({"event": "agent_failed", "incident_id": incident_id, "agent": agent.name, "error_type": type(error).__name__}))
                raise
            status = "completed"
            detail = None
            if "judge" in output:
                status = output["judge"].status if output["judge"] is not None else "not_requested"
                detail = (output["judge"].limitation or f"Evidence-aware LLM judging completed using {output['judge'].provider}.") if output["judge"] else "LLM judging was not requested for this investigation (judge=false). No quality scores were generated."
            elif output.get("analysis_provider") == "local_fallback" or "fallback" in getattr(output.get("retrieval"), "strategy", ""):
                status = "degraded"
                if output.get("analysis_provider") == "local_fallback":
                    detail = next((item for item in reversed(output["analysis"].evidence_limitations)
                                   if "local evidence-based playbook" in item), "Live response generation failed; local evidence-based recommendations were retained.")
                else:
                    detail = " ".join(output["retrieval"].limitations)
            elif "analysis_provider" in output:
                detail = ("Recommendations were generated from the local evidence playbook; live LLM generation was not used."
                          if output["analysis_provider"] == "local_evidence_playbook"
                          else f"Response generated using {output['analysis_provider']} and validated against supplied evidence.")
            state.trace.append(WorkflowStep(agent=agent.name, status=status,
                                            latency_ms=round((perf_counter() - begin) * 1000, 3), tools=agent.tools, detail=detail))
        v = state.values
        result = InvestigationResult(incident_id=incident_id, created_at=datetime.now(timezone.utc).isoformat(),
                                     prediction=v["prediction"], anomaly=v["anomaly"], risk=v["risk"], explanation=v["explanation"],
                                     retrieval=v["retrieval"], analysis=v["analysis"], analysis_provider=v["analysis_provider"], judge=v["judge"],
                                     workflow=state.trace, latency_ms=round((perf_counter() - started) * 1000, 3))
        if self.persist:
            self.repository.save(request.model_dump(mode="json"), result)
        logger.info(json.dumps({"event": "investigation_completed", "incident_id": incident_id, "model_version": result.prediction.model_version,
                                "retrieval_latency_ms": result.retrieval.latency_ms, "model_inference_latency_ms": state.trace[0].latency_ms,
                                "total_latency_ms": result.latency_ms, "retrieved_document_count": len(result.retrieval.results)}))
        return result
