import axios, { AxiosError } from 'axios'

export const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL ?? 'http://127.0.0.1:8000').replace(/\/$/, '')
export const DEMO_MODE = import.meta.env.VITE_DEMO_MODE === 'true'

export const apiClient = axios.create({ baseURL: API_BASE_URL, timeout: 100_000, headers: { 'Content-Type': 'application/json' } })

export class ApiError extends Error {
  constructor(message: string, public readonly status?: number) { super(message); this.name = 'ApiError' }
}

apiClient.interceptors.response.use(response => response, (error: AxiosError<{ detail?: unknown }>) => {
  if (!error.response) throw new ApiError('Unable to reach the incident-analysis API.')
  const detail = error.response.data?.detail
  const message = Array.isArray(detail)
    ? detail.map(item => typeof item === 'object' && item && 'msg' in item ? String(item.msg) : 'Invalid input').join(' ')
    : typeof detail === 'string' ? detail : 'The incident-analysis API returned an error.'
  throw new ApiError(message, error.response.status)
})
