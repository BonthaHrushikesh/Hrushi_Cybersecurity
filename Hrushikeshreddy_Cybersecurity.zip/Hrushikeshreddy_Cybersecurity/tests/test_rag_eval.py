import json

from src.api.schemas import Analysis
from src.services.recommendations import validate_grounding
from evaluation.deepeval_runner import build_structural_metric
from evaluation.retrieval_metrics import aggregate_metrics, ranking_metrics
import pytest


def test_retrieval_metrics_have_known_values():
    result = ranking_metrics([False, True, True], relevant_total=4, k=3)
    assert result == {"precision_at_k": 2/3, "recall_at_k": 0.5, "hit_rate_at_k": 1., "mrr": 0.5}


def test_retrieval_metrics_are_aggregated_per_metric():
    rows = [
        {"precision_at_k": 1.0, "recall_at_k": 0.2, "hit_rate_at_k": 1.0, "mrr": 1.0},
        {"precision_at_k": 0.0, "recall_at_k": 0.0, "hit_rate_at_k": 0.0, "mrr": 0.0},
    ]
    assert aggregate_metrics(rows) == {"precision_at_k": 0.5, "recall_at_k": 0.1, "hit_rate_at_k": 0.5, "mrr": 0.5}


def test_deepeval_local_metric_rejects_fabricated_citations(investigation):
    from deepeval.test_case import LLMTestCase
    analysis = investigation["analysis"]
    context = [json.dumps({"incident_id": x["incident_id"]}) for x in investigation["retrieval"]["results"]]
    metric = build_structural_metric()
    case = LLMTestCase(input="Investigate flow", actual_output=json.dumps(analysis), retrieval_context=context)
    assert metric.measure(case) == 1
    broken = {**analysis, "historical_incident_ids": ["CIC-invented"]}
    bad_case = LLMTestCase(input="Investigate flow", actual_output=json.dumps(broken), retrieval_context=context)
    assert metric.measure(bad_case) == 0
    with pytest.raises(ValueError):
        validate_grounding(Analysis.model_validate(broken), {"historical_incidents": [{"incident_id": x["incident_id"]} for x in investigation["retrieval"]["results"]]})
