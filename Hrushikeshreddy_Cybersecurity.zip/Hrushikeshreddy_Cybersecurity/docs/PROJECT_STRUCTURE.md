# Project Structure

The implementation follows the supplied source layout. Files were moved, not
copied into a second implementation. Existing trained models/data were preserved.

```text
Hrushikeshreddy_Cybersecurity/
  architecture/Architecture_Diagram.pdf
  design/Design_Document.pdf
  src/
    main.py                     # Canonical Uvicorn entry point
    api/application.py          # Routes, lifespan, services, error handling
    api/schemas.py              # Strict request/response contracts
    agents/orchestrator.py      # Shared-state specialist workflow
    agents/quality_judge.py     # Optional seven-dimension hosted judge
    rag/                        # Flow documents, ranking, prompts
    services/                   # ML, retrieval, response, persistence, reports
    utils/                      # Config, features, guardrails
  app/                          # Small legacy entry/artifact compatibility only
  ml/                           # Preparation, selection, training, holdout
  evaluation/                   # Retrieval and DeepEval runners/cases
  scripts/                      # Startup, demo, review, packaging, documentation
  frontend/                     # React source, package.json, lockfile, tests
  data/sample_data/              # Real portable CIC-IDS2017 sample
  docs/                         # API, dataset, evaluation PDFs and audit evidence
  tests/                        # Python unit/integration/regression tests
  presentation/Project_Presentation.pdf
  requirements.txt
  requirements-dev.txt          # Optional Playwright verification
  requirements-embeddings.txt   # Optional neural embeddings
  README.md
  .gitignore
```

Start with `uvicorn src.main:app`. `uvicorn app.main:app` remains supported.
The saved full-dataset embedding object references `app.services.embeddings`;
its compatibility module exposes the canonical class so the trusted artifact
still loads without forced retraining or index replacement. These modules
contain no business logic and are not unused duplicate code.

Configuration resolves the repository root independently of the working directory.
Tests import canonical modules; training/evaluation scripts use the same code as
the API. Public dependencies and source are packaged; secrets, databases, raw
exports, caches, node_modules, dist, and virtual environments are not.
