export const formatNumber = (value: number, maximumFractionDigits = 1) => new Intl.NumberFormat('en-US', { maximumFractionDigits }).format(value)
export const formatPercent = (value: number) => `${(value * 100).toFixed(1)}%`
export const formatDate = (value?: string | null) => value ? new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value)) : 'Not provided'
export const titleCase = (value: string) => value.replaceAll('_', ' ').replace(/\b\w/g, letter => letter.toUpperCase())
