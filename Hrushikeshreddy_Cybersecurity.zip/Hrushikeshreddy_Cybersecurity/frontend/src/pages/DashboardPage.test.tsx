import { cleanup, fireEvent, render, screen, within } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { demoMetrics } from '../demo/data'
import { useApiResource } from '../hooks/useApiResource'
import { DashboardPage } from './DashboardPage'
import type { Metrics } from '../types'

vi.mock('../hooks/useApiResource', () => ({ useApiResource: vi.fn() }))
vi.mock('../components/charts', () => ({ ActivityChart: () => null, AttackDistributionChart: () => null, PriorityChart: () => null }))

const metrics: Metrics = {
  ...demoMetrics, total_analyzed: 0, malicious: 0, benign: 0, priority_distribution: {}, attack_distribution: {}, recent_incidents: [],
  historical_summary: {
    total_records: 16218, malicious: 14626, benign: 1592,
    attack_distribution: { BENIGN: 1592, DDoS: 14626 }, severity_distribution: { LOW: 1592, CRITICAL: 14626 },
    timestamp_missing: 0, activity: [{ time: '2017-07-03', incidents: 16218 }],
    recent_records: [{ incident_id: 'CIC-dashboard-fixture', timestamp: null, attack_type: 'DDoS',
                       risk_score: 90, severity: 'CRITICAL', risk_source: 'historical_label_prior' }],
  },
}

describe('dashboard data scopes', () => {
  afterEach(cleanup)

  beforeEach(() => {
    vi.mocked(useApiResource, { partial: true }).mockReturnValue({ data: metrics, isLoading: false, isFetching: false, refetch: vi.fn() })
  })

  it('shows indexed historical records when the investigation database is empty', () => {
    render(<MemoryRouter><DashboardPage /></MemoryRouter>)
    expect(screen.getByRole('tab', { name: 'Historical traffic' })).toBeEnabled()
    expect(screen.getByRole('tab', { name: 'Historical traffic' })).toHaveAttribute('aria-selected', 'true')
    expect(screen.getByText('16,218')).toBeInTheDocument()
    expect(screen.getByText('14,626')).toBeInTheDocument()
    expect(screen.getByText('1,592')).toBeInTheDocument()
    expect(screen.getByText('Historical label')).toBeInTheDocument()
    expect(screen.queryByText('Analysis recorded')).not.toBeInTheDocument()
    expect(screen.getByText('Not provided')).toBeInTheDocument()
  })

  it('keeps zero operational counters separate from historical labels', () => {
    render(<MemoryRouter><DashboardPage /></MemoryRouter>)
    fireEvent.click(screen.getByRole('tab', { name: 'Investigations' }))
    expect(screen.getByRole('tab', { name: 'Investigations' })).toHaveAttribute('aria-selected', 'true')
    const maliciousCard = screen.getByText('Malicious').closest('article')!
    expect(within(maliciousCard).getByText('0')).toBeInTheDocument()
    expect(screen.queryByText('14,626')).not.toBeInTheDocument()
    expect(screen.getByText('NO INCIDENTS FOUND')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('tab', { name: 'Historical traffic' }))
    expect(screen.getByText('14,626')).toBeInTheDocument()
  })

  it('keeps historical traffic selectable with an explicit retry state when the summary is missing', () => {
    const refetch = vi.fn()
    vi.mocked(useApiResource, { partial: true }).mockReturnValue({
      data: { ...metrics, historical_summary: undefined }, isLoading: false, isFetching: false, refetch,
    })
    render(<MemoryRouter><DashboardPage /></MemoryRouter>)
    const historical = screen.getByRole('tab', { name: 'Historical traffic' })
    expect(historical).toBeEnabled()
    expect(screen.getByText('Historical traffic summary is unavailable.')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Retry' }))
    expect(refetch).toHaveBeenCalledOnce()
    fireEvent.click(screen.getByRole('tab', { name: 'Investigations' }))
    expect(screen.getByText('NO INCIDENTS FOUND')).toBeInTheDocument()
    fireEvent.click(historical)
    expect(historical).toHaveAttribute('aria-selected', 'true')
    expect(screen.getByText('Historical traffic summary is unavailable.')).toBeInTheDocument()
    expect(screen.queryByText('NO INCIDENTS FOUND')).not.toBeInTheDocument()
  })
})
