import { useMemo, useSyncExternalStore } from 'react'

export interface UiSettings { resultCount: number; hybridAlpha: number; autoRefresh: boolean }
const defaults: UiSettings = { resultCount: 8, hybridAlpha: .65, autoRefresh: true }
const key = 'soc-settings'
function rawSettings() {
  try { return localStorage.getItem(key) || '{}' } catch { return '{}' }
}
function parseSettings(raw: string): UiSettings {
  try {
    const value = JSON.parse(raw)
    return { resultCount: Number.isInteger(value?.resultCount) && value.resultCount >= 3 && value.resultCount <= 30 ? value.resultCount : defaults.resultCount,
      hybridAlpha: typeof value?.hybridAlpha === 'number' && Number.isFinite(value.hybridAlpha) && value.hybridAlpha >= 0 && value.hybridAlpha <= 1 ? value.hybridAlpha : defaults.hybridAlpha,
      autoRefresh: typeof value?.autoRefresh === 'boolean' ? value.autoRefresh : defaults.autoRefresh }
  } catch { return defaults }
}
export const getSettings = () => parseSettings(rawSettings())
export const saveSettings = (settings: UiSettings) => {
  try {
    localStorage.setItem(key, JSON.stringify(settings))
    window.dispatchEvent(new Event('soc-settings-changed'))
    return true
  } catch { return false }
}
function subscribe(callback: () => void) {
  window.addEventListener('storage', callback)
  window.addEventListener('soc-settings-changed', callback)
  return () => { window.removeEventListener('storage', callback); window.removeEventListener('soc-settings-changed', callback) }
}
export function useSettings() {
  const raw = useSyncExternalStore(subscribe, rawSettings, () => '{}')
  return useMemo(() => parseSettings(raw), [raw])
}
