# Design

## Current Analyst Workflow

Complete sampled/imported measurements reach the model unchanged except for
explicit analyst edits. CSV parsing is validated; absent features stay missing.
Readiness, operational data quality, effective preferences, and service failures
are visible. Saved records export Markdown reports with model version, fixed
risk, citations, SHAP, provider status, and limitations.

Advanced RAG combines expansion, reciprocal-rank fusion, observed feature
reranking, and MMR selection. Answers use bounded structured evidence and
validated citations. The evaluation page compares keyword, weighted hybrid,
and advanced retrieval on the same held-out queries. See advanced_rag.md,
guardrails.md, and operations.md for executable details.

## Problem Statement

SOC analysts must correlate network-flow alerts, historical incidents, model signals, and response guidance under time pressure. Traditional dashboards expose records but leave similarity search, attack classification, prioritization, and explanation as disconnected manual tasks. The system must turn one observed flow into a traceable investigation without treating model output or generated text as forensic proof.

## Business Objectives

- Reduce time spent finding relevant historical network-flow incidents.
- Produce consistent attack classification, anomaly, severity, and priority evidence.
- Explain which observed features influenced the classifier.
- Provide defensive next steps grounded in measured signals and cited incidents.
- Capture reviewed analyst corrections without allowing automatic production promotion.

## Architecture Design

<img src="../architecture/Architecture_Diagram.png" alt="End-to-end system architecture" style="width:100%;max-width:1100px">

The application separates an offline data and artifact pipeline from online investigation. CIC-IDS2017 flows are cleaned, sampled, split, and used to produce classifier, anomaly, document, embedding, vector-index, and evaluation artifacts. At runtime, FastAPI validates requests and coordinates specialist agents for detection, anomaly scoring, retrieval, risk, explainability, response, and optional judging. The React SOC workspace consumes the typed API. SQLite stores investigations and feedback; model and retrieval artifacts remain versioned files.

## Technology Selection

| Technology | Selection and justification |
|---|---|
| Python 3.12, FastAPI, Pydantic | Typed local microservice, generated OpenAPI, strict validation, and straightforward ML integration |
| React + TypeScript | Production-style routed SOC workspace with typed services, responsive investigation views, and reusable visualizations |
| Random Forest / Extra Trees | Strong nonlinear tabular baselines with probabilities, feature importance, and exact TreeSHAP support |
| Isolation Forest | Unsupervised deviation scoring fitted only to benign training traffic |
| TF-IDF + LSA | Reproducible offline semantic baseline that requires no external model download |
| Sentence Transformers | Optional pretrained embedding path for comparative semantic retrieval |
| FAISS IndexFlatIP | Exact cosine retrieval over normalized dense vectors with inspectable scores |
| BM25 | Independent keyword retrieval for ports, attack terminology, and protocol language |
| NVIDIA NIM Chat Completions / OpenAI Responses / Claude Messages | Structured narrative and judge providers with schema validation and local fallback |
| SQLite | Portable local persistence for investigation and feedback records |

## Scope And Choices

The product supports defensive SOC investigations of individual network-flow records. A microservice, local persistent stores, and a routed React/TypeScript workspace keep the system reproducible on a development machine. Ordinary model training, retrieval indexing, and offline evaluation use scripts that import the same application modules. There are no disconnected notebooks.

The primary source is eight metadata-rich TrafficLabelling CSVs, with nine categories and 77 raw + three derived inputs. Original flow IDs, IPs, ports, protocols, raw times, and labels are preserved. MachineLearningCVE is a numeric cross-check, not a duplicate training corpus. Missing metadata stays null. Incident IDs are stable numeric-feature signatures, separate from original flow IDs.

## Data Contracts

| Field family | Role | Treatment |
|---|---|---|
| Attack Type / Label | Training target | Normalize to attack category; preserve original label; exclude from ML input |
| Flow ID / source and destination IP / source port / protocol / timestamp | Retrieval metadata | Optional, validated; excluded from predictive feature vector |
| Destination Port | Metadata and observed numeric feature | Validated 0-65535; risk of service/environment memorization documented |
| Flow duration, lengths, rates, flags, timing statistics | Numeric ML features | Nonfinite and negative sentinel values become missing; training median imputation |
| duration_seconds | Derived feature | Flow Duration / 1,000,000 |
| forward_bytes_per_packet | Derived feature | Forward bytes / max(forward packets, 1) |
| packet_rate_asymmetry | Derived feature | (forward rate - backward rate) / max(sum rates, 1) |
| Incident ID | Evidence reference | Stable feature signature; never a predictive feature |

CSV preparation is chunked. Uniform random priority sampling retains the lowest random priorities per original class, with seed 42 and up to 2,000 records per class. This gives reproducible class coverage without loading the raw source into the API. The scan parses 3,119,345 rows, excludes 288,602 unlabeled rows, and retains 20,273. Final training/history has 16,218 records; test has 4,055. Sampling changes prevalence; model probabilities must not be interpreted as calibrated operational attack rates.

Deduplication and conflict exclusion occur before splitting, using exact numeric feature signatures. The scope is the retained sample, not a claimed full-file duplicate audit. Near-duplicate session leakage remains possible. Genuine metadata permits temporal/host-disjoint experiments, but none has been performed. Naive source times use user-declared UTC, not independently verified; raw strings remain available.

## ML Architecture

Random Forest and Extra Trees use balanced class weights for attack-family model selection. Training/validation/test fractions are approximately 64%/16%/20%. Selection uses validation macro F1, because every class should contribute to model comparison. The selected classifier is refit on training+validation and evaluated on final test data. A separate balanced binary Random Forest is trained on the same training-only partition to estimate malicious-versus-benign intrusion risk. Saved reports include class precision/recall/F1/support, weighted and macro averages, accuracy, a labeled confusion matrix, binary intrusion metrics and ROC AUC, and comparison metrics.

The preprocessing pipeline is persisted with the classifier. Derived values are calculated before imputation; no labels, IDs, addresses, or times are accepted as numeric input. Negative CICFlowMeter window sentinels are treated as missing; API input permits the documented `-1` window sentinel only. Required basic fields prevent empty-flow inference. Missing features and out-of-training-range values accompany every prediction.

Malicious probability comes from the dedicated binary intrusion classifier. Classification confidence is the winning multiclass category's ensemble probability. They describe different things: a flow can be strongly malicious while the attack classifier is uncertain between several attack families. Neither output is calibrated to operational network prevalence in this version.

Isolation Forest uses benign training rows, median imputation, and RobustScaler. Its raw anomaly value is `-score_samples`. Normalized anomaly risk is the empirical percentile against saved benign training scores. The anomaly flag begins at the 95th percentile. This percentile is not a malicious probability; novelty and benign workload changes can trigger it.

## Retrieval Architecture

### Chunking Strategy

One historical flow is one document/chunk. This preserves the link between observed
measurements, original labels, metadata, and incident IDs; unrelated flows are not
combined. There is no cross-flow overlap. Training/validation rows alone form the
corpus; test rows never become indexed evidence. The RAG answer context has an
18,000-character structured-evidence budget, with records omitted rather than
silently combining or fabricating observations. This flow-aware strategy suits
structured event records better than arbitrary prose token windows.

Historical documents describe service port, observed timing/rates/packet statistics, coarse traffic descriptions, known historical category, and original label. They contain meaningful feature descriptions, rather than embedded CSV strings. Identifying hosts are kept separately and omitted from LLM documents.

Two embedding providers share `EmbeddingService`: offline LSA (TF-IDF + TruncatedSVD + normalization) and configurable sentence-transformers. LSA is a practical latent-semantic baseline, not a substitute claim for pretrained sentence understanding. FAISS `IndexFlatIP` stores normalized dense vectors and yields cosine scores. BM25 independently scores keyword tokens.

During a full investigation, the predicted attack category and its defensive vocabulary are appended as a soft query hint. This is not a strict category filter: competing historical categories can still rank. Evaluation reports both the unassisted text baseline and this integrated strategy per attack class so classifier reinforcement risk remains visible.

For eligible candidates:

`hybrid = alpha * clipped_cosine + (1 - alpha) * positive_BM25 / max_positive_BM25`

If every keyword score is zero, normalized keyword scores are zero. The default alpha is 0.65. The caller can choose pure semantic or keyword ranking. Explicit filters compose with AND, apply before eligible-score normalization, and never match null metadata. The response exposes raw BM25, normalized BM25, cosine, hybrid score, metadata, features, and evidence IDs. Ranking is the reranking stage; no opaque LLM reranker is introduced.

Historical `risk_score`/severity are clearly labeled `historical_label_prior`. They support historical filters and must not be mistaken for calculated investigation risk.

## Risk Scoring

Five normalized signals determine score:

| Component | Default Weight | Meaning |
|---|---:|---|
| malicious_probability | 0.40 | Dedicated binary intrusion-classifier probability |
| anomaly_percentile | 0.15 | Empirical benign-reference anomaly percentile |
| malicious_confidence | 0.05 | Winning class confidence if nonbenign; zero for BENIGN |
| attack_prior | 0.25 | Documented category triage prior |
| traffic_indicators | 0.15 | Log-scaled packet/byte rates and optional SYN/RST counts |

`risk_score = round(100 * sum(weight * signal), 2)`

Traffic score combines 0.5 packet-rate activity, 0.3 byte-rate activity, and 0.2 optional SYN/RST activity. Each input is capped to [0,1]. Packet-rate scaling saturates at 100,000 packets/s and byte-rate scaling at 100,000,000 bytes/s. Absent SYN/RST features contribute zero and are never fabricated. Category priors range from 0 for benign to 0.95 for Heartbleed; only trained classes are predicted.

Severity intervals are `[0,30)` LOW/P4, `[30,60)` MEDIUM/P3, `[60,80)` HIGH/P2, and `[80,100]` CRITICAL/P1. Weights must be nonnegative and sum to one. The score is a transparent triage policy. Related confidence terms are correlated, so this is not claimed to be a statistically independent probability estimator. Historical evidence is surfaced for analyst corroboration; it is not added as proof that a new attack occurred.

## Explainability

`shap.TreeExplainer` computes actual TreeSHAP values for the selected forest after saved imputation. Responses include the class baseline, all feature contributions, observed values where available, reconstructed probability, and interpretation. Additivity is tested: baseline + contributions equals predicted class probability. The UI sorts by absolute contribution and shows the top 12 with direction colors. Correlation is not causation.

Global feature importance uses ensemble mean decrease in impurity, explicitly labeled separately from SHAP. Per-category median features describe historical attack associations; these are not causal effects. Global importance can favor high-cardinality features and needs external validation.

## Agent Workflow

The state contains a validated request, outputs from completed agents, and a trace. Each node declares dependencies and output keys. Detection, anomaly, retrieval, risk, explainability, response, and quality-judge roles expose specific tools. Contract violations and nonrecoverable model failures stop the workflow. Narrative-provider failure uses a declared fallback; failed LLM scores are never replaced by fake judge ratings.

Model inference and risk calculation remain outside the LLM. Recommendations reference observed features, model inference, and validated historical IDs. The local provider selects category-specific defensive playbooks; NVIDIA NIM Chat Completions, OpenAI Responses, and Claude Messages providers enforce typed structured outputs. The final API keeps calculated quantities separate from generated narrative.

## Guardrails And Grounding

Pydantic rejects unknown object fields, feature names, invalid IPs, ports, protocols, naive timestamps, inconsistent ports, numeric strings/bools, NaN/infinity, negative unrecognized values, and values outside an explicit maximum. Search length, filter types, date ranges, and top K are bounded. Obvious prompt override/offensive requests are rejected; regex screening is a first-line guard, not a complete semantic security classifier.

User queries and retrieved documents are supplied as JSON data beneath a defensive system instruction, which explicitly treats them as untrusted data. Structured output parsing and citation-membership validation reject unknown historical IDs and unsupported CVE references. Explicit narrative triage-score claims are checked against the calculated score with rounding tolerance. The LLM does not execute code, access a shell, or remediate a host. No arbitrary URL/tool execution is exposed. All containment language requires analyst validation.

LLM evidence omits host identifiers and API logs omit request bodies, keys, and prompts. Input error responses contain location/message/type without echoing potentially nonfinite or sensitive input. API keys are read from the environment; `.env` and raw datasets are ignored by Git and Docker.

Citation membership and schema validation cannot establish that every free-text statement is supported. The optional judge checks factual claims against source evidence, and DeepEval supplements these checks. Analysts retain responsibility for reviewing narrative.

## Feedback And Persistence

SQLite stores each full request/result snapshot and indexes category, priority, time, and risk. Feedback references a persisted investigation and includes helpfulness, label/severity corrections, comment, and time. Parameterized SQL and foreign keys protect contracts. A correction remains pending until approved/rejected by the review CLI.

Only approved corrected labels are exported for training. Candidate retraining combines reviewed rows, applies duplicate/conflict protection, and writes artifacts to a separate directory. It evaluates on the active held-out benchmark, excluding matching feature signatures from candidate training even when feedback gives a row a different incident ID. A comparison report records active/candidate versions and measured metrics on the same benchmark. Automatic promotion is absent; independent external validation is still needed before deployment.

## Evaluation And Operations

Non-LLM retrieval evaluation uses label-free held-out flow descriptions with category-based relevance. It reports Precision@K, Recall@K, Hit Rate@K, and MRR. Category membership is a coarse relevance proxy; recall denominators include every same-category corpus document.

DeepEval produces schema-valid nine-category test cases from real pipeline outputs. Offline custom metrics check supported citations and required sections only. Configured built-in metrics evaluate answer relevancy, faithfulness, contextual precision/recall, and hallucination quality. The LLM judge separately emits 1-5 scores and reasons for seven dimensions; the hallucination-risk dimension is oriented so higher is safer.

Structured logs include request IDs, investigation IDs, model versions, model/retrieval/total latency, result counts, status codes, and error types. Model versions use the prepared dataset SHA-256 prefix; training metadata captures date, source, features, selected algorithm, splits, metrics, and artifact path.

The Docker image builds a fresh small-demo model/index. Local deployment binds to loopback. Authentication, tenant isolation, audit retention policies, worker queues, and production rate limits belong to an authenticated deployment stage rather than being claimed in this local prototype.

## Challenges And Trade-offs

| Challenge | Decision | Trade-off |
|---|---|---|
| Large imbalanced multi-file source | Stream and retain a seeded per-original-label sample | Fast local iteration, but sampled prevalence is not operational prevalence |
| Source times lack timezone and some metadata is malformed | Preserve raw times, declare UTC provenance, keep invalid values null | Genuine filtering without claiming independently verified clock context |
| Local execution must work without paid services | Default to LSA embeddings and deterministic response playbooks | Fully reproducible, but weaker language understanding than pretrained/hosted models |
| High benchmark model scores | Report leakage risks and require external time/host validation | Results remain defensible, but are not deployment guarantees |
| Multiple AI/ML signals can be mistaken for certainty | Keep prediction, anomaly, risk policy, retrieval, and narrative separate | More fields for analysts to interpret, with clearer provenance |
| Analyst feedback can contain label errors | Require review, candidate evaluation, and manual promotion | Slower learning loop, but avoids silent model contamination |

## Submission Choice And Current Evidence

Participant: Hrushikeshreddy. React is the only frontend by explicit participant request. Guidelines prescribe Streamlit; organizer acceptance is pending. Docker/cloud/CI are optional. NVIDIA authentication, recommendations, seven-dimensional judging, and cited RAG have live smoke evidence. Hosted DeepEval measured 36/45 scores across nine cases; five completed scores missed their thresholds, nine metric calls were unavailable, and two generations used local fallback. Offline structural checks remain separate from prose quality scores.
