from dataclasses import dataclass
import hashlib
import os
import math
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[2]
load_dotenv(ROOT / ".env", override=False)


def resolve_path(value: str) -> Path:
    path = Path(value).expanduser()
    return path if path.is_absolute() else ROOT / path


@dataclass(frozen=True)
class Settings:
    dataset_path: Path = resolve_path(os.getenv("DATASET_PATH", "data/raw/cicids2017_cleaned.csv"))
    artifacts: Path = resolve_path(os.getenv("ARTIFACT_DIR", "artifacts"))
    processed: Path = resolve_path(os.getenv("PROCESSED_DIR", "data/processed"))
    embedding_provider: str = os.getenv("EMBEDDING_PROVIDER", "lsa")
    embedding_model: str = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    hybrid_alpha: float = float(os.getenv("HYBRID_ALPHA", "0.65"))
    llm_provider: str = os.getenv("LLM_PROVIDER", "local")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    judge_model: str = os.getenv("JUDGE_MODEL", "gpt-4o-mini")
    anthropic_model: str = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-6")
    anthropic_judge_model: str = os.getenv("CLAUDE_JUDGE_MODEL", os.getenv("CLAUDE_MODEL", "claude-sonnet-4-6"))
    llm_timeout_seconds: float = float(os.getenv("LLM_TIMEOUT_SECONDS", "20"))
    llm_failure_threshold: int = int(os.getenv("LLM_FAILURE_THRESHOLD", "3"))
    llm_cooldown_seconds: float = float(os.getenv("LLM_COOLDOWN_SECONDS", "60"))
    max_request_bytes: int = int(os.getenv("MAX_REQUEST_BYTES", "65536"))
    risk_weights: tuple[float, ...] = tuple(float(x) for x in os.getenv("RISK_WEIGHTS", "0.40,0.15,0.05,0.25,0.15").split(","))

    def __post_init__(self) -> None:
        if not 1 <= self.llm_timeout_seconds <= 120 or not 1 <= self.llm_failure_threshold <= 20 or not 1 <= self.llm_cooldown_seconds <= 3600:
            raise ValueError("Invalid LLM timeout or circuit breaker configuration")
        if not 1024 <= self.max_request_bytes <= 1048576:
            raise ValueError("MAX_REQUEST_BYTES must be between 1024 and 1048576")
        if not 0 <= self.hybrid_alpha <= 1:
            raise ValueError("HYBRID_ALPHA must be between 0 and 1")
        if len(self.risk_weights) != 5 or any(not math.isfinite(x) or x < 0 for x in self.risk_weights) or abs(sum(self.risk_weights) - 1) > 1e-6:
            raise ValueError("RISK_WEIGHTS must contain five nonnegative weights summing to 1")
        if self.embedding_provider not in {"lsa", "sentence_transformers"}:
            raise ValueError("Unsupported EMBEDDING_PROVIDER")
        if self.llm_provider not in {"local", "openai", "anthropic"}:
            raise ValueError("Unsupported LLM_PROVIDER")

    @property
    def generation_model(self) -> str:
        return {"openai": self.openai_model, "anthropic": self.anthropic_model,
                "local": "local_evidence_playbook"}[self.llm_provider]

    @property
    def evaluation_model(self) -> str:
        return {"openai": self.judge_model, "anthropic": self.anthropic_judge_model,
                "local": "none"}[self.llm_provider]

    @property
    def api_key_env(self) -> str | None:
        return {"openai": "OPENAI_API_KEY", "anthropic": "ANTHROPIC_API_KEY"}.get(self.llm_provider)

    @property
    def credentials_configured(self) -> bool:
        return bool(self.api_key_env and os.getenv(self.api_key_env, "").strip())

    @property
    def credential_fingerprint(self) -> str | None:
        key = os.getenv(self.api_key_env or "", "")
        return hashlib.sha256(key.encode()).hexdigest() if key else None


settings = Settings()
