from contextlib import contextmanager
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
from src.api.schemas import FeedbackRequest, InvestigationResult


class Repository:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS investigations (
                    incident_id TEXT PRIMARY KEY, created_at TEXT NOT NULL,
                    request_json TEXT NOT NULL, result_json TEXT NOT NULL,
                    attack_type TEXT NOT NULL, priority TEXT NOT NULL, risk_score REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    incident_id TEXT NOT NULL REFERENCES investigations(incident_id),
                    created_at TEXT NOT NULL, helpful INTEGER NOT NULL,
                    corrected_attack_type TEXT, corrected_severity TEXT, comment TEXT NOT NULL,
                    review_status TEXT NOT NULL DEFAULT 'pending'
                );
            """)

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA journal_mode=WAL")
        try:
            yield db
            db.commit()
        finally:
            db.close()

    def save(self, request: dict, result: InvestigationResult):
        with self.connection() as db:
            db.execute("INSERT INTO investigations VALUES (?, ?, ?, ?, ?, ?, ?)",
                       (result.incident_id, result.created_at, json.dumps(request), result.model_dump_json(),
                        result.prediction.predicted_attack_type, result.risk.priority, result.risk.risk_score))

    def get(self, incident_id: str) -> dict | None:
        with self.connection() as db:
            row = db.execute("SELECT result_json FROM investigations WHERE incident_id=?", (incident_id,)).fetchone()
        return json.loads(row["result_json"]) if row else None

    def list_investigations(self, limit: int = 200) -> dict:
        with self.connection() as db:
            total = db.execute("SELECT COUNT(*) FROM investigations").fetchone()[0]
            rows = db.execute("""SELECT incident_id, created_at, attack_type, priority, risk_score
                                 FROM investigations ORDER BY created_at DESC LIMIT ?""", (limit,)).fetchall()
        return {"items": [dict(row) for row in rows], "total": total}

    def feedback(self, request: FeedbackRequest) -> int:
        if self.get(request.incident_id) is None:
            raise KeyError(request.incident_id)
        with self.connection() as db:
            cursor = db.execute("INSERT INTO feedback (incident_id, created_at, helpful, corrected_attack_type, corrected_severity, comment) VALUES (?, ?, ?, ?, ?, ?)",
                                (request.incident_id, datetime.now(timezone.utc).isoformat(), request.helpful,
                                 request.corrected_attack_type, request.corrected_severity, request.comment))
            return int(cursor.lastrowid)

    def list_feedback(self) -> list[dict]:
        with self.connection() as db:
            rows = db.execute("SELECT * FROM feedback ORDER BY id DESC LIMIT 200").fetchall()
        return [dict(row) for row in rows]

    def review_feedback(self, feedback_id: int, status: str):
        if status not in {"approved", "rejected"}:
            raise ValueError("Review status must be approved or rejected")
        with self.connection() as db:
            cursor = db.execute("UPDATE feedback SET review_status=? WHERE id=?", (status, feedback_id))
            if cursor.rowcount != 1:
                raise KeyError(feedback_id)

    def reviewed_rows(self) -> list[dict]:
        with self.connection() as db:
            rows = db.execute("""SELECT f.*, i.request_json, i.result_json FROM feedback f
                                 JOIN investigations i ON i.incident_id=f.incident_id
                                 WHERE f.review_status='approved' AND f.corrected_attack_type IS NOT NULL ORDER BY f.id""").fetchall()
        return [dict(x) for x in rows]

    def metrics(self) -> dict:
        with self.connection() as db:
            total = db.execute("SELECT COUNT(*) FROM investigations").fetchone()[0]
            attacks = dict(db.execute("SELECT attack_type, COUNT(*) FROM investigations GROUP BY attack_type").fetchall())
            priorities = dict(db.execute("SELECT priority, COUNT(*) FROM investigations GROUP BY priority").fetchall())
            recent = [dict(x) for x in db.execute("SELECT incident_id, created_at, attack_type, priority, risk_score FROM investigations ORDER BY created_at DESC LIMIT 20")]
            feedback = db.execute("SELECT COUNT(*) FROM feedback").fetchone()[0]
            quality = dict(db.execute("""SELECT
                COALESCE(AVG(risk_score), 0) AS mean_risk_score,
                COALESCE(AVG(json_extract(result_json, '$.latency_ms')), 0) AS mean_latency_ms,
                COALESCE(SUM(json_array_length(json_extract(result_json, '$.prediction.missing_features')) > 0), 0) AS incomplete_flows,
                COALESCE(SUM(json_array_length(json_extract(result_json, '$.prediction.out_of_range_features')) > 0), 0) AS out_of_range_flows,
                COALESCE(SUM(json_extract(result_json, '$.analysis_provider') = 'local_fallback'), 0) AS llm_fallbacks
                FROM investigations""").fetchone())
        return {"total_analyzed": total, "benign": attacks.get("BENIGN", 0), "malicious": total - attacks.get("BENIGN", 0),
                "attack_distribution": attacks, "priority_distribution": priorities, "recent_incidents": recent, "feedback_count": feedback,
                "operational_quality": quality}
