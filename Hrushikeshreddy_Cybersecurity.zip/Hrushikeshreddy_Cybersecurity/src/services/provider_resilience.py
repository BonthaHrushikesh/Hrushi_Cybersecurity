from threading import Lock
from time import monotonic


class CircuitOpenError(RuntimeError):
    pass


def provider_failure_reason(error: Exception) -> str:
    """Expose actionable failure categories without provider bodies or credentials."""
    status = getattr(error, "status_code", None)
    if status == 401 or type(error).__name__ == "AuthenticationError":
        return "The provider rejected the configured API credential (HTTP 401)."
    if status == 403:
        return "The provider denied access to the requested model (HTTP 403)."
    if status == 429:
        return "The provider rate or quota limit was reached (HTTP 429)."
    if status == 404:
        return "The configured provider model or endpoint was not found (HTTP 404)."
    if isinstance(error, CircuitOpenError):
        return "Provider requests are temporarily paused after repeated failures; recovery requires the circuit cooldown."
    if isinstance(error, TimeoutError) or type(error).__name__ == "APITimeoutError":
        return "The provider request exceeded the configured timeout."
    if isinstance(error, ValueError):
        return "The generated output failed structured-response or evidence-grounding validation."
    return "The configured provider request could not be completed."


class ProviderCircuit:
    """Allow one recovery probe after consecutive failures and a cooldown."""

    def __init__(self, threshold: int, cooldown: float):
        self.threshold, self.cooldown = threshold, cooldown
        self.failures = 0
        self.opened_at = None
        self.probing = False
        self.lock = Lock()

    def call(self, operation):
        with self.lock:
            if self.opened_at is not None:
                if monotonic() - self.opened_at < self.cooldown or self.probing:
                    raise CircuitOpenError("Provider is temporarily unavailable")
                self.probing = True
        try:
            result = operation()
        except Exception:
            with self.lock:
                self.failures += 1
                if self.failures >= self.threshold:
                    self.opened_at = monotonic()
                self.probing = False
            raise
        with self.lock:
            self.failures = 0
            self.opened_at = None
            self.probing = False
        return result

    def snapshot(self):
        with self.lock:
            remaining = max(0, self.cooldown - (monotonic() - self.opened_at)) if self.opened_at is not None else 0
            return {"state": "open" if remaining else "half_open" if self.opened_at is not None else "closed",
                    "consecutive_failures": self.failures, "retry_after_seconds": round(remaining, 1)}
