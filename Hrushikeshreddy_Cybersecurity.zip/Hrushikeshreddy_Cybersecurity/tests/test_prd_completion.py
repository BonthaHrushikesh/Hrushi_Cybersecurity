from dataclasses import replace
import json
from types import SimpleNamespace

import pandas as pd
import pytest

from src.utils.config import settings
from src.utils.features import CANONICAL_LABELS
from src.api.application import Services
from src.api.schemas import SearchRequest
from evaluation.evaluation_dataset import build_cases
from ml.preprocess import prepare_dataset
from ml.train import train_models
from scripts.build_index import build_index
from scripts.check_prd_readiness import assess
from scripts.verify_live_llm import verify


def fixture_rows():
    # Synthetic unit fixtures verify contracts; they are not benchmark evidence.
    return [{"Flow ID": f"fixture-{category}-{i}", "Src IP": "192.0.2.1", "Dst IP": "198.51.100.2",
             "Src Port": 10000 + i, "Dst Port": 80, "Protocol": 6,
             "Timestamp": f"2017-07-03T12:00:{i:02d}Z", "Flow Duration": 1000 + index * 10000 + i,
             "Flow Packets/s": 10 + index * 100 + i, "Flow Bytes/s": 100 + index * 1000 + i,
             "Total Bwd Packets": i, "Label": category}
            for index, category in enumerate(CANONICAL_LABELS) for i in range(40)]


def test_original_folder_to_nine_class_model_metadata_index_and_evaluation(tmp_path):
    source = tmp_path / "raw"
    source.mkdir()
    rows = fixture_rows()
    pd.DataFrame(rows[:120]).to_csv(source / "first.csv", index=False)
    pd.DataFrame(rows[120:]).to_csv(source / "second.csv", index=False)
    config = replace(settings, processed=tmp_path / "processed", artifacts=tmp_path / "artifacts", llm_provider="local")
    profile = prepare_dataset(source, config.processed, per_class=32)
    assert len(profile["source_files"]) == 2
    assert set(profile["category_counts"]) == set(CANONICAL_LABELS)
    assert profile["metadata_non_null_counts"]["source_ip"] == profile["processed_rows"]
    train_models(config.processed, config.artifacts, trees=6)
    build_index(config)
    services = Services(config)
    assert services.orchestrator is not None
    sample = next(item for item in services.retrieval.incidents if item.attack_type == "Heartbleed")
    search = SearchRequest(query="Historical Heartbleed service traffic", filters={
        "attack_type": "Heartbleed", "source_ip": sample.metadata["source_ip"], "destination_ip": sample.metadata["destination_ip"],
        "source_port": sample.metadata["source_port"], "destination_port": 80, "protocol": "TCP", "timestamp": sample.metadata["timestamp"]})
    assert sample.incident_id in {hit.incident_id for hit in services.retrieval.search(search).results}
    assert sample.metadata["flow_id"].startswith("fixture-")
    services.orchestrator.persist = False
    assert {item["metadata"]["category"] for item in build_cases(services)} == set(CANONICAL_LABELS)
    readiness = assess(config)
    assert readiness["checks"]["historical_metadata"]
    assert readiness["checks"]["all_prd_attack_categories"]
    assert readiness["status"] == "incomplete"


def test_naive_source_time_requires_declared_timezone(tmp_path):
    rows = fixture_rows()[:24]
    for row in rows:
        row["Timestamp"] = "03/07/2017 09:30:00"
    source = tmp_path / "flows.csv"
    pd.DataFrame(rows).to_csv(source, index=False)
    with pytest.raises(ValueError, match="timestamp-timezone"):
        prepare_dataset(source, tmp_path / "processed", timestamp_format="%d/%m/%Y %H:%M:%S")
    prepare_dataset(source, tmp_path / "processed", timestamp_timezone="UTC", timestamp_format="%d/%m/%Y %H:%M:%S")
    output = pd.read_csv(tmp_path / "processed/incidents.csv")
    assert output.timestamp.str.startswith("2017-07-03 09:30:00+00:00").all()


def test_bad_metadata_is_missing_not_invented(tmp_path):
    rows = fixture_rows()[:24]
    rows[0]["Src IP"] = "invalid"
    rows[0]["Src Port"] = 99999
    rows[0]["Protocol"] = 123
    source = tmp_path / "flows.csv"
    pd.DataFrame(rows).to_csv(source, index=False)
    profile = prepare_dataset(source, tmp_path / "processed")
    assert profile["invalid_metadata_values_marked_missing"]["source_ip"] == 1
    assert profile["invalid_metadata_values_marked_missing"]["source_port"] == 1
    assert profile["invalid_metadata_values_marked_missing"]["protocol"] == 1


@pytest.mark.parametrize("provider", ["openai", "anthropic", "local"])
def test_live_verification_blocks_without_key(monkeypatch, provider):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    assert verify(replace(settings, llm_provider=provider))["status"] == "blocked"


@pytest.mark.parametrize("provider", ["openai", "anthropic"])
def test_metric_failure_is_saved_without_private_details(tmp_path, monkeypatch, investigation, provider):
    import src.api.application
    import deepeval.metrics
    import evaluation.evaluation_dataset
    from evaluation.deepeval_runner import run

    monkeypatch.setenv("OPENAI_API_KEY", "test-only-key")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-only-key")
    config = replace(settings, artifacts=tmp_path / "artifacts", llm_provider=provider)
    stub = SimpleNamespace(orchestrator=SimpleNamespace(persist=False), models=SimpleNamespace(bundle={"version": "fixture-model"}))
    monkeypatch.setattr(src.api.application, "Services", lambda config: stub)
    contexts = [json.dumps({"incident_id": item["incident_id"]}) for item in investigation["retrieval"]["results"]]
    case = {"input": "Investigate defensive traffic", "actual_output": json.dumps(investigation["analysis"]),
            "expected_output": "Defensive evidence-backed analysis", "context": contexts, "retrieval_context": contexts,
            "metadata": {"category": "DDoS", "analysis_provider": provider, "judge": {"status": "completed"}}}
    monkeypatch.setattr(evaluation.evaluation_dataset, "build_cases", lambda *args, **kwargs: [case])

    class Metric:
        def __init__(self, **kwargs):
            self.__name__, self.score, self.reason = "Fixture Metric", 1.0, "Mocked quality contract"
        def measure(self, case):
            return self.score
        def is_successful(self):
            return True

    class FailedMetric(Metric):
        def measure(self, case):
            raise RuntimeError("private-provider-detail")

    for name in ["AnswerRelevancyMetric", "ContextualPrecisionMetric", "ContextualRecallMetric", "HallucinationMetric"]:
        monkeypatch.setattr(deepeval.metrics, name, Metric)
    monkeypatch.setattr(deepeval.metrics, "FaithfulnessMetric", FailedMetric)
    result = run(config=config)
    assert result["llm_metrics_status"] == "partial"
    assert "4/5 metric scores" in result["limitation"]
    saved = (config.artifacts / "evaluation/deepeval.json").read_text()
    assert "private-provider-detail" not in saved
    assert "RuntimeError" in saved
