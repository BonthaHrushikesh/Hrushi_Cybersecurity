import argparse
from dataclasses import replace
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.utils.config import settings
from ml.preprocess import prepare_dataset
from ml.train import train_models
from scripts.build_index import build_index
from scripts.check_prd_readiness import assess


def main():
    parser = argparse.ArgumentParser(description="Build a separate candidate from genuine CIC labeled flow files; active artifacts are preserved.")
    parser.add_argument("--input", required=True, type=Path, help="Extracted CSV/Parquet folder or individual file")
    parser.add_argument("--timestamp-timezone", help="Explicit timezone of naive source times")
    parser.add_argument("--defer-timestamps", action="store_true", help="Preserve raw source times without inventing UTC when the source timezone is unconfirmed")
    parser.add_argument("--timestamp-format")
    parser.add_argument("--day-first", action="store_true")
    parser.add_argument("--encoding", default="utf-8-sig")
    parser.add_argument("--per-class", type=int, default=2000)
    parser.add_argument("--trees", type=int, default=100)
    parser.add_argument("--processed", type=Path, default=settings.processed.parent / "prd_candidate/processed")
    parser.add_argument("--artifacts", type=Path, default=settings.artifacts / "prd_candidate")
    args = parser.parse_args()
    if args.processed.resolve() == settings.processed.resolve() or args.artifacts.resolve() == settings.artifacts.resolve():
        parser.error("Candidate paths must differ from active processed/artifact directories")
    if args.input.is_dir() and args.processed.resolve().is_relative_to(args.input.resolve()):
        parser.error("Candidate output must be outside the source folder")
    config = replace(settings, processed=args.processed.resolve(), artifacts=args.artifacts.resolve(), dataset_path=args.input.resolve())
    prepare_dataset(config.dataset_path, config.processed, args.per_class, timestamp_timezone=args.timestamp_timezone,
                    timestamp_format=args.timestamp_format, day_first=args.day_first, encoding=args.encoding,
                    defer_timestamps=args.defer_timestamps)
    train_models(config.processed, config.artifacts, trees=args.trees)
    build_index(config)
    result = assess(config)
    path = config.artifacts / "evaluation/prd_readiness.json"
    path.write_text(json.dumps(result, indent=2))
    print(json.dumps({"candidate_processed": str(config.processed), "candidate_artifacts": str(config.artifacts),
                      "readiness": result, "activation": "Review measured reports, then explicitly change PROCESSED_DIR and ARTIFACT_DIR and restart."}, indent=2))


if __name__ == "__main__":
    main()
