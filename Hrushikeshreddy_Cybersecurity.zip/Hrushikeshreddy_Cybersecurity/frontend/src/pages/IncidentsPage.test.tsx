import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { MemoryRouter } from 'react-router-dom'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { dashboardApi } from '../api'
import type { IncidentSummary } from '../types'
import { IncidentsPage } from './IncidentsPage'

vi.mock('../api', () => ({ dashboardApi: { incidentPage: vi.fn() } }))
afterEach(cleanup)

const records: IncidentSummary[] = Array.from({ length: 205 }, (_, index) => ({
  incident_id: `INV-${String(index).padStart(3, '0')}`,
  created_at: new Date(Date.UTC(2026, 0, 1) + index * 1000).toISOString(),
  attack_type: index === 0 ? 'DDoS' : 'BENIGN', priority: index === 0 ? 'P1' : 'P4', risk_score: index === 0 ? 99 : 1,
}))

beforeEach(() => {
  vi.mocked(dashboardApi.incidentPage).mockReset().mockImplementation(async ({ offset = 0, limit = 8, query = '', sort = 'time' }) => {
    const matched = records.filter(item => `${item.incident_id} ${item.attack_type} ${item.priority}`.toLowerCase().includes(query.toLowerCase()))
      .sort((a, b) => (sort === 'risk' ? b.risk_score - a.risk_score : 0) || Date.parse(b.created_at) - Date.parse(a.created_at))
    return { items: matched.slice(offset, offset + limit), total: matched.length }
  })
})

function renderPage() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  render(<QueryClientProvider client={client}><MemoryRouter><IncidentsPage /></MemoryRouter></QueryClientProvider>)
}

describe('incident explorer queries the entire registry', () => {
  it('can browse to investigations older than the first 200 records', async () => {
    renderPage()
    await screen.findByText('INV-204')
    for (let page = 1; page <= 25; page++) {
      await waitFor(() => expect(screen.getByRole('button', { name: 'Next page' })).toBeEnabled())
      fireEvent.click(screen.getByRole('button', { name: 'Next page' }))
      await waitFor(() => expect(dashboardApi.incidentPage).toHaveBeenLastCalledWith({ limit: 8, offset: page * 8, query: '', sort: 'time' }))
    }
    await screen.findByText('INV-000')
    expect(screen.getByText('26 / 26')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Next page' })).toBeDisabled()
  })

  it('searches and prioritizes old incidents globally and resets the page on filter changes', async () => {
    renderPage()
    await screen.findByText('INV-204')
    fireEvent.click(screen.getByRole('button', { name: 'Next page' }))
    await screen.findByText('INV-196')
    fireEvent.change(screen.getByRole('textbox', { name: 'Search incidents' }), { target: { value: 'INV-000' } })
    await screen.findByText('INV-000')
    expect(dashboardApi.incidentPage).toHaveBeenLastCalledWith({ limit: 8, offset: 0, query: 'INV-000', sort: 'time' })
    expect(screen.getByText('1 records', { selector: 'span' })).toBeInTheDocument()
    fireEvent.change(screen.getByRole('textbox', { name: 'Search incidents' }), { target: { value: '' } })
    await screen.findByText('INV-204')
    fireEvent.change(screen.getByRole('combobox', { name: 'Sort incidents' }), { target: { value: 'risk' } })
    await screen.findByText('INV-000')
    expect(dashboardApi.incidentPage).toHaveBeenLastCalledWith({ limit: 8, offset: 0, query: '', sort: 'risk' })
  })
})
