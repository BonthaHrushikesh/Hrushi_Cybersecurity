from pathlib import Path
import argparse
from dataclasses import replace
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.utils.config import ROOT, settings, resolve_path
from ml.preprocess import prepare_dataset
from ml.train import train_models
from scripts.build_index import build_index

def seed_demo(source: Path, processed: Path, artifacts: Path, overwrite: bool = False):
    targets = [processed / "incidents.csv", artifacts / "models/bundle.joblib"]
    if not overwrite and any(path.exists() for path in targets):
        raise ValueError("Demo output already contains data or models. Choose fresh directories or explicitly use --overwrite.")
    if source.resolve().is_relative_to(processed.resolve()) or source.resolve().is_relative_to(artifacts.resolve()):
        raise ValueError("Demo input must be outside the output directories")
    config = replace(settings, processed=processed, artifacts=artifacts, llm_provider="local", embedding_provider="lsa")
    prepare_dataset(source, processed, per_class=200)
    train_models(processed, artifacts, trees=60)
    return build_index(config)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Build a real nine-category demo in isolated directories; never implicitly overwrite active artifacts.")
    parser.add_argument("--input", type=Path, default=ROOT / "data/sample_data/cicids2017_labelled_sample.csv")
    parser.add_argument("--processed", type=Path, default=ROOT / "data/demo/processed")
    parser.add_argument("--artifacts", type=Path, default=ROOT / "artifacts/demo")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    seed_demo(resolve_path(str(args.input)), resolve_path(str(args.processed)), resolve_path(str(args.artifacts)), args.overwrite)
