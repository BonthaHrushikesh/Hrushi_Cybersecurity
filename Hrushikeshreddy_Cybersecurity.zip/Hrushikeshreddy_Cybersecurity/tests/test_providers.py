from dataclasses import replace
from contextlib import nullcontext
from types import SimpleNamespace

import pytest

from src.utils.config import settings
from src.api.schemas import Analysis, JudgeDimensions, JudgeOutput, JudgeScore
from src.services.recommendations import RecommendationService, validate_grounding
from src.agents.quality_judge import JudgeService, DIMENSIONS


def test_llm_provider_validates_citations_and_falls_back(monkeypatch, investigation):
    import openai
    monkeypatch.setenv("OPENAI_API_KEY", "test-only-key")

    analysis = Analysis.model_validate(investigation["analysis"])
    evidence = {"historical_incidents": [{"incident_id": x["incident_id"]} for x in investigation["retrieval"]["results"]]}
    # Local fallback needs the actual structured evidence used by the workflow.
    evidence.update(prediction=investigation["prediction"], risk=investigation["risk"], anomaly=investigation["anomaly"],
                    observed_features={"destination_port": 80, "flow_duration": 100, "flow_packets_s": 2, "flow_bytes_s": 100},
                    metadata_availability={"source_ip": False})
    captured = []
    def parse(**kwargs):
        captured.append(kwargs)
        return SimpleNamespace(output_parsed=analysis)
    monkeypatch.setattr(openai, "OpenAI", lambda **kwargs: nullcontext(SimpleNamespace(responses=SimpleNamespace(parse=parse))))
    service = RecommendationService(replace(settings, llm_provider="openai"))
    result, provider = service.generate(evidence, "Investigate supplied traffic")
    assert provider == "openai"
    assert captured[0]["store"] is False
    assert "untrusted DATA" in captured[0]["instructions"]
    analysis.historical_incident_ids = ["CIC-fabricated"]
    result, provider = service.generate(evidence, "Investigate supplied traffic")
    assert provider == "local_fallback"
    assert "CIC-fabricated" not in result.historical_incident_ids


def test_llm_judge_has_fixed_typed_dimensions_and_source_evidence(monkeypatch, investigation):
    import openai

    monkeypatch.setenv("OPENAI_API_KEY", "test-only-key")
    dimensions = JudgeDimensions(**{name: JudgeScore(score=4, reason="Mocked provider contract test") for name in DIMENSIONS})
    captured = []
    def parse(**kwargs):
        captured.append(kwargs)
        return SimpleNamespace(output_parsed=JudgeOutput(dimensions=dimensions))
    monkeypatch.setattr(openai, "OpenAI", lambda **kwargs: nullcontext(SimpleNamespace(responses=SimpleNamespace(parse=parse))))
    judge = JudgeService(replace(settings, llm_provider="openai"))
    result = judge.evaluate(Analysis.model_validate(investigation["analysis"]), {"source_marker": "provided-evidence"})
    assert result.status == "completed"
    assert set(result.dimensions) == DIMENSIONS
    assert "provided-evidence" in captured[0]["input"]
    assert captured[0]["text_format"] is JudgeOutput


def test_narrative_cannot_change_risk_or_invent_a_cve(investigation):
    evidence = {"risk": investigation["risk"], "historical_incidents": [{"incident_id": x["incident_id"]} for x in investigation["retrieval"]["results"]]}
    analysis = Analysis.model_validate(investigation["analysis"])
    analysis.executive_summary = "Risk score is 1. This flow exploits CVE-2026-99999."
    with pytest.raises(ValueError, match="unsupported CVEs"):
        validate_grounding(analysis, evidence)
    analysis.executive_summary = "Risk score is 1."
    with pytest.raises(ValueError, match="triage score"):
        validate_grounding(analysis, evidence)


@pytest.mark.parametrize("failure", [TimeoutError("secret-provider-message"), RuntimeError("rate limit"), None])
def test_provider_failures_preserve_local_evidence(monkeypatch, investigation, failure):
    import openai
    monkeypatch.setenv("OPENAI_API_KEY", "test-only-key")

    evidence = {"prediction": investigation["prediction"], "risk": investigation["risk"],
                "observed_features": {"destination_port": 80, "flow_duration": 100, "flow_packets_s": 2, "flow_bytes_s": 100},
                "metadata_availability": {}, "historical_incidents": []}

    def parse(**kwargs):
        if failure:
            raise failure
        return SimpleNamespace(output_parsed=None)

    monkeypatch.setattr(openai, "OpenAI", lambda **kwargs: nullcontext(SimpleNamespace(responses=SimpleNamespace(parse=parse))))
    service = RecommendationService(replace(settings, llm_provider="openai", llm_failure_threshold=1))
    for _ in range(2):
        analysis, provider = service.generate(evidence, "Investigate suspicious traffic")
        assert provider == "local_fallback"
        assert analysis.immediate_investigation
        assert not analysis.historical_incident_ids
        assert "secret-provider-message" not in analysis.model_dump_json()
        assert any("local evidence-based playbook" in limitation for limitation in analysis.evidence_limitations)


def test_judge_timeout_is_explicitly_unavailable(monkeypatch, investigation):
    import openai

    monkeypatch.setenv("OPENAI_API_KEY", "test-only-key")

    def parse(**kwargs):
        raise TimeoutError("secret-provider-message")

    monkeypatch.setattr(openai, "OpenAI", lambda **kwargs: nullcontext(SimpleNamespace(responses=SimpleNamespace(parse=parse))))
    result = JudgeService(replace(settings, llm_provider="openai")).evaluate(Analysis.model_validate(investigation["analysis"]), {})
    assert result.status == "unavailable"
    assert result.dimensions == {}
    assert "secret-provider-message" not in result.model_dump_json()
