# Speaker Notes: Ten-Minute Presentation

Participant: Hrushikeshreddy. These notes explain the short slides in plain language. Practise the timings; keep the live demo local-only. Benchmark results describe the full sampled run, not the portable demo.

## Slide 1: AI-Powered Cybersecurity Incident Response Assistant

Planned time: 40 seconds. Presentation window: 0:00 to 0:40.

Hello, I am Hrushikeshreddy. My project is an AI-powered cybersecurity incident response assistant. Security teams receive many network alerts, but each alert needs investigation before anyone can decide what it means. My project brings the main investigation tasks into one application: identify a possible attack, find similar past incidents, explain the evidence, and suggest defensive next steps. The important boundary is that this is an analyst assistant. It does not independently confirm a compromise or block traffic. The analyst remains responsible for the final decision.

## Slide 2: Why This Project Is Needed

Planned time: 45 seconds. Presentation window: 0:40 to 1:25.

An analyst usually needs to answer three questions. First, has similar activity happened before? Second, what traffic characteristics suggest a particular attack? Third, which alerts should be investigated first? Without an integrated tool, the analyst switches between records, models, dashboards, and response guidance. This project connects those steps. It returns comparable incidents, a predicted category, a priority score, explanations, and investigation actions in one record. Faster investigation is the business objective; I have not claimed a measured reduction in analyst time because that would require a separate user study.

## Slide 3: The Dataset And Preparation

Planned time: 60 seconds. Presentation window: 1:25 to 2:25.

I used the metadata-rich TrafficLabelling CSVs from CIC-IDS2017. A network flow is a summary of a connection: addresses, ports, duration, packet counts, byte rates, timing, and flags. The scan parsed about 3.12 million rows and excluded unlabeled records. For reproducible local training, I retained 20,273 flows using seeded sampling, cleaned invalid measurements, and removed exact duplicates within that sample. There are 77 raw numeric features and three derived features, giving 80 model inputs. The nine categories include benign traffic, brute force, denial of service, bot activity, port scanning, web attacks, infiltration, and Heartbleed. Final training and historical retrieval use 16,218 rows; the untouched test set has 4,055. Source times use user-declared UTC, not an independently verified timezone.

## Slide 4: How The System Works

Planned time: 55 seconds. Presentation window: 2:25 to 3:20.

The architecture has two parts. Offline, preprocessing creates clean flow records. Training builds the attack, intrusion, and anomaly models. Each historical flow becomes one document, which is indexed for retrieval. Online, the analyst uses the React interface, and FastAPI validates the request. The workflow then calls the relevant model, retrieval, risk, explanation, and response services. Python handles the backend; FAISS stores the vector index; BM25 handles keyword matching; SQLite stores investigations and feedback. The code follows the src API, agents, RAG, services, and utilities structure. Hosted Claude or OpenAI can provide structured narrative, but the current demo uses the local provider.

## Slide 5: Finding Similar Historical Incidents

Planned time: 60 seconds. Presentation window: 3:20 to 4:20.

RAG means retrieving relevant evidence before producing an answer. Here, each historical flow has a readable document and a stable incident ID. Keyword search uses BM25, which helps with exact terms such as SSH or port numbers. The active semantic baseline uses TF-IDF and LSA vectors in FAISS; it is not a pretrained language model. Hybrid search combines the rankings. The advanced path also expands attack vocabulary, compares observed flow features, and avoids repetitive evidence. Metadata filters are combined with AND, and missing metadata never silently matches. The answer cites supplied incident IDs and states evidence gaps. Similarity tells us that past traffic is related; it does not prove that a new flow is malicious.

## Slide 6: Prediction, Priority, And Explanation

Planned time: 60 seconds. Presentation window: 4:20 to 5:20.

The models answer different questions. The multiclass Random Forest predicts the attack category. A separate binary Random Forest estimates malicious-versus-benign confidence. Isolation Forest compares the flow with benign training traffic to identify unusualness. These signals remain separate because unusual traffic is not automatically an attack. A transparent five-signal policy produces a score from zero to one hundred and maps it to priority P1 through P4. P1 is the highest investigation priority. TreeSHAP explains which observed or imputed features pushed the classifier toward or away from its prediction. These are model explanations, not proof of causation, and the risk score is a policy score rather than a calibrated probability.

## Slide 7: Agents And Safety Checks

Planned time: 50 seconds. Presentation window: 5:20 to 6:10.

The workflow contains detection, anomaly, retrieval, risk, explainability, response, and an optional quality judge. These are specialist tool-using roles with shared state and defined dependencies, not seven independent chatbots. Each step records its status and timing. Input validation rejects invalid ports, IPs, feature names, nonfinite values, and unsupported queries. Generated outputs must follow the schema and cite only supplied historical IDs. If a requested provider fails, the application returns an explicitly labeled local playbook. It never invents a judge score. The optional judge evaluates analysis against evidence once a valid provider is available. No agent executes containment actions.

## Slide 8: Results And Honest Limitations

Planned time: 60 seconds. Presentation window: 6:10 to 7:10.

The attack classifier achieved 99.21 percent accuracy and a macro F1 of 0.9743 on 4,055 held-out flows. Macro F1 considers every category, which matters when classes have different sizes. For retrieval, Precision at five means the proportion of the top five results in the expected category. Across 42 queries, the unassisted baseline achieved 62.86 percent and the model-assisted hybrid path 95.24 percent. The assisted path adds predicted-category vocabulary, so it can also reinforce model mistakes. The backend and React test suites passed, and nine offline DeepEval structural checks passed. These checks verify sections and citation membership, not prose faithfulness. Rare-class test support is tiny, the split is random, and hosted generation, judge, and quality metrics remain deferred.

## Slide 9: Live Demonstration

Planned time: 120 seconds. Presentation window: 7:10 to 9:10.

I will show one complete investigation using an actual dataset sample. I will keep hosted generation and judging switched off so the demonstration is reproducible and does not depend on the deferred key. First, the dashboard distinguishes historical records from investigations that analysts have actually run. Next, I will submit the DDoS sample and read the returned category, anomaly signal, risk, and priority. I will open one historical match, point out its evidence ID, and connect one feature explanation to an investigation action. Finally, I will submit analyst feedback. It stays pending review and does not silently retrain the model.

### Demo Sequence

1. 0-15 seconds: Open Dashboard. Show historical counts, not live sensor statistics.
2. 15-35 seconds: Open Investigate, choose DDoS, disable hosted generation and judge, then run.
3. 35-55 seconds: Read the returned category, confidence, risk, and priority; do not assume a fixed value.
4. 55-75 seconds: Open a historical match and identify the cited record and real metadata.
5. 75-95 seconds: Show TreeSHAP and defensive response; distinguish inference from confirmation.
6. 95-110 seconds: Submit feedback and show pending review.
7. 110-120 seconds: Show the agent trace or API documentation.

## Slide 10: What I Delivered And What Comes Next

Planned time: 50 seconds. Presentation window: 9:10 to 10:00.

The deliverable is an executable local microservice with a React analyst workspace, trained models, historical retrieval, explainability, defensive playbooks, and reviewed feedback. The submission includes source code, a real portable sample, named PDFs, API examples, and measured evaluation reports. The extracted ZIP was also tested separately. The next steps are to connect a valid provider, collect real generation and judge evidence, and run hosted DeepEval quality metrics. Independent time or host-based testing and realistic calibration are also needed before deployment. React is a deliberate choice that needs organizer acceptance because the guidelines specify Streamlit, and repository upload/access remain submission steps. My main learning is that useful AI assistance requires traceable evidence and honest uncertainty, not just confident text.

## Panel Questions And Delivery Tips
| Question | Simple answer |
|---|---|
| What is a network flow? | A summary of a connection, such as its hosts, ports, packets, bytes, duration, and timing. |
| What makes this RAG? | The assistant retrieves actual historical flow records and uses their IDs and observations as evidence before forming an answer. |
| Why combine keyword and semantic search? | Exact terms and related descriptions provide different retrieval signals. |
| Which embedding model is active? | TF-IDF plus 96-dimensional LSA. MiniLM is optional and was not the measured default. |
| Does the LLM classify the attack? | No. The trained tabular model predicts the category; optional LLMs explain supplied evidence. |
| Why use separate intrusion and anomaly models? | Intrusion confidence and unusualness are different signals; neither is automatic confirmation. |
| Is a 90 risk score a 90% attack probability? | No. It is a weighted triage-policy score. |
| What does SHAP explain? | How features influenced the classifier's output, not the real-world cause of the attack. |
| Are the agents autonomous? | They are specialist workflow roles; they do not execute remediation. |
| How does feedback improve the project? | Reviewed corrections can train a separate candidate, which must be evaluated before manual promotion. |
| Why are the scores high? | The benchmark is discriminative, but random sampled splits and related sessions can overstate real-network performance. |
| Are the DeepEval checks live quality scores? | No. The nine offline checks are structural; hosted quality measurements remain deferred. |
| Can this run without a key? | Yes, for ML, retrieval, risk, explanations, feedback, and clearly labeled local recommendations. |
| Why React instead of Streamlit? | React was the participant's requested frontend; organizer acceptance remains pending. |

Delivery tips: Explain one idea at a time. Define RAG, SHAP, and Precision@5 when
first used. Read the actual demo output rather than memorizing a risk value.
Present benchmark results with their limits. Do not claim live Claude or judge
quality until those calls have genuinely succeeded.
