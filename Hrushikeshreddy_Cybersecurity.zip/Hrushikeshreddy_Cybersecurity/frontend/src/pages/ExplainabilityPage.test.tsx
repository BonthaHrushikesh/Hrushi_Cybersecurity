import { cleanup, render, screen, within } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { demoModel } from '../demo/data'
import { useApiResource } from '../hooks/useApiResource'
import { ExplainabilityPage } from './ExplainabilityPage'
import type { GlobalExplanation } from '../types'

vi.mock('../hooks/useApiResource', () => ({ useApiResource: vi.fn() }))
vi.mock('../components/charts', () => ({ ShapChart: () => null }))

function show(patterns: GlobalExplanation['attack_patterns'], limitations: string[] = []) {
  const mock = vi.mocked(useApiResource, { partial: true })
  mock.mockReset()
  mock.mockReturnValueOnce({ data: { global_importance: [{ feature: 'flow_packets_s', importance: .5 }],
    importance_method: 'ensemble_mean_impurity_decrease', attack_patterns: patterns, limitations, note: 'Not causal evidence.' },
    isLoading: false, refetch: vi.fn() })
  mock.mockReturnValueOnce({ data: demoModel, isLoading: false, refetch: vi.fn() })
  render(<ExplainabilityPage />)
}

describe('optional attack-pattern evidence', () => {
  afterEach(cleanup)

  it('keeps model importance visible and explains missing pattern reports', () => {
    show({}, ['Historical attack-pattern profiles are unavailable.'])
    expect(screen.getByText('Global Feature Importance')).toBeInTheDocument()
    expect(screen.getByRole('status')).toHaveTextContent('Historical attack-pattern profiles are unavailable.')
    expect(screen.getByText('Attack-pattern profiles are unavailable.')).toBeInTheDocument()
  })

  it('preserves real zero values without replacing missing measurements with zero', () => {
    show({ DDoS: { flow_packets_s: 0, flow_bytes_s: null, destination_port: 80 } })
    const row = screen.getByText('DDoS').closest('tr')!
    expect(within(row).getByText('0')).toBeInTheDocument()
    expect(within(row).getAllByText('Not provided')).toHaveLength(2)
    expect(within(row).getByText('80')).toBeInTheDocument()
  })
})
