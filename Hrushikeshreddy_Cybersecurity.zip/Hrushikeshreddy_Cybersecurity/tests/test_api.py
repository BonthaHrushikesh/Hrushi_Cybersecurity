import pytest


def test_api_starts_and_documents_contracts(client):
    assert client.get("/health").json()["status"] == "ok"
    assert client.get("/docs").status_code == 200
    schema = client.get("/openapi.json").json()
    for route in ["classify", "risk", "anomaly", "search", "investigate", "explain", "recommend", "feedback"]:
        assert f"/api/v1/{route}" in schema["paths"]


def test_investigation_is_grounded_and_has_completed_workflow(client, investigation):
    result = investigation
    assert len(result["workflow"]) == 7
    assert all(x["status"] == "completed" for x in result["workflow"][:-1])
    assert result["workflow"][-1]["status"] == "not_configured"
    assert result["judge"]["status"] == "not_configured"
    assert result["prediction"]["predicted_attack_type"] == "DDoS"
    assert 0 <= result["risk"]["risk_score"] <= 100
    assert result["analysis_provider"] == "local_evidence_playbook"
    retrieved = {x["incident_id"] for x in result["retrieval"]["results"]}
    assert set(result["analysis"]["historical_incident_ids"]) <= retrieved
    assert any(x["attack_type"] == result["prediction"]["predicted_attack_type"] for x in result["retrieval"]["results"])
    assert client.get("/api/v1/incidents/" + result["incident_id"]).json()["incident_id"] == result["incident_id"]
    incident_list = client.get("/api/v1/incidents").json()
    assert incident_list["total"] >= 1
    assert any(x["incident_id"] == result["incident_id"] for x in incident_list["items"])


def test_feedback_is_persistent_and_unknown_incident_is_rejected(client, investigation):
    response = client.post("/api/v1/feedback", json={"incident_id": investigation["incident_id"], "helpful": False, "corrected_attack_type": "DoS", "corrected_severity": "HIGH", "comment": "Validated correction"})
    assert response.status_code == 201
    assert response.json()["status"] == "pending_review"
    assert any(x["id"] == response.json()["feedback_id"] for x in client.get("/api/v1/feedback").json())
    assert client.post("/api/v1/feedback", json={"incident_id": "missing", "helpful": True}).status_code == 404


def test_empty_history_is_explicit(client, sample):
    response = client.post("/api/v1/investigate", json={"flow": {"features": sample["features"]}, "filters": {"source_ip": "192.0.2.1"}, "use_llm": False})
    assert response.status_code == 200
    result = response.json()
    assert result["retrieval"]["results"] == []
    assert any("Insufficient evidence" in x for x in result["analysis"]["evidence_limitations"])


@pytest.mark.parametrize("endpoint", ["classify", "risk", "anomaly", "explain"])
def test_individual_analysis_endpoints(client, sample, endpoint):
    response = client.post("/api/v1/" + endpoint, json={"features": sample["features"]})
    assert response.status_code == 200
    assert response.headers["X-Request-ID"]
