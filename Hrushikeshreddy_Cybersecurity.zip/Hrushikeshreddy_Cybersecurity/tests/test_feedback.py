from src.services.repository import Repository
from src.api.schemas import FeedbackRequest, InvestigationResult


def test_only_reviewed_corrections_are_exportable(tmp_path, investigation):
    repository = Repository(tmp_path / "feedback.sqlite")
    result = InvestigationResult.model_validate(investigation)
    repository.save({"flow": {"features": {"destination_port": 80}}}, result)
    pending = repository.feedback(FeedbackRequest(incident_id=result.incident_id, helpful=False, corrected_attack_type="DoS"))
    assert repository.reviewed_rows() == []
    repository.review_feedback(pending, "approved")
    rows = repository.reviewed_rows()
    assert len(rows) == 1
    assert rows[0]["corrected_attack_type"] == "DoS"
    assert "result_json" in rows[0] and "request_json" in rows[0]
    repository.review_feedback(pending, "rejected")
    assert repository.reviewed_rows() == []


def test_recent_investigations_are_ordered_by_time_not_risk(tmp_path, investigation):
    repository = Repository(tmp_path / "recent.sqlite")
    result = InvestigationResult.model_validate(investigation)
    older = result.model_copy(update={"incident_id": "INV-old", "created_at": "2026-10-10T12:00:00+00:00"})
    newer = result.model_copy(update={"incident_id": "INV-new", "created_at": "2026-10-11T12:00:00+00:00",
                                      "risk": result.risk.model_copy(update={"risk_score": 1, "priority": "P4", "severity": "LOW"})})
    repository.save({}, older)
    repository.save({}, newer)
    assert [row["incident_id"] for row in repository.metrics()["recent_incidents"]] == ["INV-new", "INV-old"]
