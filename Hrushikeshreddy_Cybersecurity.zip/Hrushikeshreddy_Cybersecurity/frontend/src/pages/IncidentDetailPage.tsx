import { ArrowLeft, Download } from "lucide-react";
import { useState } from 'react';
import { Link, useParams } from "react-router-dom";
import { investigationApi } from "../api";
import { FeedbackForm } from "../components/feedback/FeedbackForm";
import { InvestigationResultView } from "../components/investigation/InvestigationResultView";
import {
  AttackBadge,
  ErrorState,
  LoadingSkeleton,
  PageHeader,
  Panel,
  SeverityBadge,
} from "../components/ui";
import { demoHistorical, demoInvestigation } from "../demo/data";
import { useApiResource } from "../hooks/useApiResource";
import type { HistoricalIncident, InvestigationResult } from "../types";
import { formatDate, formatNumber } from "../utils/format";

const isInvestigation = (
  value: InvestigationResult | HistoricalIncident,
): value is InvestigationResult => "prediction" in value;
export function IncidentDetailPage() {
  const [exportError, setExportError] = useState('');
  const [exportPending, setExportPending] = useState(false);
  const { id = "" } = useParams();
  let cached: InvestigationResult | undefined;
  try {
    const value = sessionStorage.getItem(`investigation:${id}`);
    if (value) cached = JSON.parse(value) as InvestigationResult;
  } catch { /* Browser storage is optional; the incident is loaded from the API. */ }
  const fallback = id.startsWith("DEMO-HIST")
    ? demoHistorical
    : cached ?? demoInvestigation;
  const query = useApiResource(
    ["incident", id],
    () => investigationApi.get(id),
    fallback,
  );
  const data = query.data;
  const exportReport = async () => {
    setExportPending(true);
    setExportError('');
    try {
      const blob = await investigationApi.report(id);
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url; anchor.download = `${id}.md`;
      document.body.appendChild(anchor); anchor.click(); anchor.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch { setExportError('The investigation report could not be downloaded.'); }
    finally { setExportPending(false); }
  };
  return (
    <div>
      <Link
        to="/incidents"
        className="mb-4 inline-flex items-center gap-2 text-xs text-zinc-500 hover:text-gold"
      >
        <ArrowLeft size={14} />
        Back to incidents
      </Link>
      <PageHeader
        eyebrow="Incident record"
        title={id || "Incident Detail"}
        description="Classification, retrieved evidence, risk rationale, and analyst response context."
        action={data && isInvestigation(data) && !query.isDemo ? <button className="btn-primary" disabled={exportPending} onClick={exportReport}><Download size={15} />{exportPending ? 'Exporting...' : 'Export report'}</button> : undefined}
      />
      {exportError && <p role="alert" className="mb-4 text-sm text-red-300">{exportError}</p>}
      {query.isLoading ? (
        <LoadingSkeleton rows={8} />
      ) : !data ? (
        <ErrorState
          message="This incident could not be found."
          onRetry={() => query.refetch()}
        />
      ) : isInvestigation(data) ? (
        <>
          <InvestigationResultView result={data} />
          <Panel
            title="Analyst Feedback"
            eyebrow="Continuous improvement"
            className="mt-5"
          >
            <FeedbackForm incidentId={data.incident_id} />
          </Panel>
        </>
      ) : (
        <HistoricalView incident={data} />
      )}
    </div>
  );
}
function HistoricalView({ incident }: { incident: HistoricalIncident }) {
  return (
    <div className="grid gap-5 xl:grid-cols-[1.2fr_.8fr]">
      <Panel title="Historical Evidence" eyebrow="Retrieved record">
        <div className="flex flex-wrap gap-2">
          <AttackBadge attack={incident.attack_type} />
          <SeverityBadge severity={incident.severity} />
        </div>
        <p className="mt-5 text-sm leading-6 text-zinc-300">
          {incident.document}
        </p>
        <p className="mt-4 text-xs text-zinc-500">
          Historical dataset labels provide retrieval context; they do not
          independently validate a current incident.
        </p>
      </Panel>
      <Panel title="Record Metadata" eyebrow={incident.risk_source}>
        <dl className="space-y-3 text-sm">
          <div className="flex justify-between">
            <dt className="text-zinc-500">Risk score</dt>
            <dd>{formatNumber(incident.risk_score, 0)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-zinc-500">Source</dt>
            <dd className="font-mono text-xs">
              {incident.metadata.source_ip || "Unknown"}
            </dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-zinc-500">Destination</dt>
            <dd className="font-mono text-xs">
              {incident.metadata.destination_ip || "Unknown"}
            </dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-zinc-500">Timestamp</dt>
            <dd>{formatDate(incident.metadata.timestamp)}</dd>
          </div>
        </dl>
      </Panel>
      <Panel
        title="Flow Features"
        eyebrow="Observed values"
        className="xl:col-span-2"
      >
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {Object.entries(incident.features).map(([key, value]) => (
            <div key={key} className="rounded-lg border border-white/[.06] p-3">
              <p className="truncate text-[10px] uppercase text-zinc-600">
                {key.replaceAll("_", " ")}
              </p>
              <strong className="mt-1 block font-mono text-sm">
                {formatNumber(value)}
              </strong>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}
