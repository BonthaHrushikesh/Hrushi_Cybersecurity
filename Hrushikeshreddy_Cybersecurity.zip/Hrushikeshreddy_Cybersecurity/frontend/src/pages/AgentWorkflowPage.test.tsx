import { cleanup, fireEvent, render, screen, within } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { demoInvestigation, demoMetrics } from '../demo/data'
import { useApiResource } from '../hooks/useApiResource'
import type { InvestigationResult } from '../types'
import { AgentWorkflowPage } from './AgentWorkflowPage'

vi.mock('../hooks/useApiResource', () => ({ useApiResource: vi.fn() }))
afterEach(cleanup)

const failed: InvestigationResult = {
  ...demoInvestigation, analysis_provider: 'local_fallback',
  analysis: { ...demoInvestigation.analysis, evidence_limitations: ['Synthetic fixture: a local evidence-based playbook was used.'] },
  workflow: [
    ...demoInvestigation.workflow.filter(step => step.agent !== 'Response Recommendation Agent'),
    { agent: 'Response Recommendation Agent', status: 'degraded', latency_ms: 100, tools: ['grounded_response_provider'] },
    { agent: 'Quality Judge Agent', status: 'not_requested', latency_ms: 0, tools: ['evidence_aware_llm_judge'] },
  ],
}

function renderTrace(result: InvestigationResult) {
  const refetch = vi.fn()
  vi.mocked(useApiResource, { partial: true }).mockReset()
    .mockReturnValueOnce({ data: { ...demoMetrics, evaluation: { provider_connection: { status: 'failed', http_status: 401 } } }, isLoading: false })
    .mockReturnValue({ data: result, isLoading: false, isFetching: false, refetch })
  render(<MemoryRouter><AgentWorkflowPage /></MemoryRouter>)
  return refetch
}

describe('workflow failure reporting', () => {
  it('explains older fallback and disabled-judge traces and offers an explicitly judged workflow', () => {
    const refetch = renderTrace(failed)
    const graph = screen.getByRole('heading', { name: 'Execution Graph' }).closest('section')!
    expect(within(graph).getByText('DEGRADED')).toBeInTheDocument()
    expect(within(graph).getByText('Synthetic fixture: a local evidence-based playbook was used.')).toBeInTheDocument()
    expect(within(graph).getByText('NOT REQUESTED')).toBeInTheDocument()
    expect(within(graph).getByText(/judge=false/)).toBeInTheDocument()
    expect(screen.getByRole('alert')).toHaveTextContent('HTTP 401')
    expect(screen.getByRole('link', { name: 'Run workflow' })).toHaveAttribute('href', '/investigate?judge=true')
    fireEvent.click(screen.getByRole('button', { name: 'Refresh workflow trace' }))
    expect(refetch).toHaveBeenCalledOnce()
  })

  it('prefers the request-specific diagnostic over a generic legacy fallback explanation', () => {
    const detail = 'Synthetic request-specific authentication failure (HTTP 401).'
    renderTrace({ ...failed, workflow: failed.workflow.map(step => step.agent === 'Response Recommendation Agent' ? { ...step, detail } : step) })
    const graph = screen.getByRole('heading', { name: 'Execution Graph' }).closest('section')!
    expect(within(graph).getByText(detail)).toBeInTheDocument()
    expect(within(graph).queryByText('Synthetic fixture: a local evidence-based playbook was used.')).not.toBeInTheDocument()
  })
})
