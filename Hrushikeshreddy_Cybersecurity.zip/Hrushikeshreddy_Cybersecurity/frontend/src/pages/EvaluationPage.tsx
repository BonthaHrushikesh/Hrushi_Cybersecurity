import { Beaker, CheckCircle2, Crosshair, FileCheck2, RefreshCw, SearchCheck, ShieldQuestion, XCircle } from 'lucide-react'
import { dashboardApi } from '../api'
import { MetricCard, PageHeader, Panel, StatusBadge, ErrorState, LoadingSkeleton } from '../components/ui'
import { demoMetrics } from '../demo/data'
import { useApiResource } from '../hooks/useApiResource'
import { asNumber, asRecord, asString, asStringArray } from '../utils/records'
import { formatDate, formatPercent, titleCase } from '../utils/format'

const qualityMetrics = ['Answer Relevancy', 'Faithfulness', 'Contextual Precision', 'Contextual Recall', 'Hallucination']
const measuredPercent = (value: unknown) => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1 ? formatPercent(value) : 'Not measured'
const measuredCount = (value: unknown) => typeof value === 'number' && Number.isInteger(value) && value >= 0 ? String(value) : 'Not run'
const readinessLabels: Record<string, string> = {
  live_generation_evidence: 'Live Generation Evidence', live_judge_evidence: 'Live Judge Evidence',
  deepeval_quality_measured: 'DeepEval Quality Measured',
}

const demoEvaluation = {
  classification: { test_metrics: { accuracy: 0.9968, 'macro avg': { 'f1-score': 0.9968 } }, malicious_roc_auc: 0.999 },
  retrieval: {
    status: 'demo', query_count: 35, k: 5,
    metrics: { precision_at_k: 0.9771, hit_rate_at_k: 1, mrr: 1, recall_at_k: 0.0031 },
    baseline_metrics: { precision_at_k: 0.8229, hit_rate_at_k: 0.8571, mrr: 0.8357, recall_at_k: 0.0026 },
    per_class: {},
  },
  deepeval: { framework: 'DeepEval', case_count: 7, llm_metrics_status: 'not_configured', offline_structural_checks: [{ category: 'DDoS', score: 1, reason: 'Citation IDs supported and required sections present.' }], limitation: 'LLM quality metrics require a configured judge provider.' },
}

export function EvaluationPage() {
  const query = useApiResource(['evaluation-metrics'], dashboardApi.metrics, { ...demoMetrics, evaluation: demoEvaluation })
  if (!query.data) return query.isLoading ? <LoadingSkeleton rows={8} /> : <ErrorState message="Evaluation reports are unavailable." onRetry={() => query.refetch()} />
  const evaluation = query.data.evaluation
  const advanced = asRecord(evaluation.advanced_retrieval)
  const advancedMetrics = asRecord(advanced.metrics)
  const readiness = asRecord(evaluation.prd_readiness)
  const classification = asRecord(evaluation.classification)
  const test = asRecord(classification.test_metrics)
  const macro = asRecord(test['macro avg'])
  const retrieval = asRecord(evaluation.retrieval)
  const retrievalMetrics = asRecord(retrieval.metrics)
  const baselineMetrics = asRecord(retrieval.baseline_metrics)
  const perClass = asRecord(retrieval.per_class)
  const liveQuality = asRecord(evaluation.deepeval)
  const offlineQuality = asRecord(evaluation.offline_quality)
  const deep = Object.keys(liveQuality).length && !['stale', 'unavailable', 'unverified'].includes(asString(liveQuality.status, '')) ? liveQuality : offlineQuality
  const connection = asRecord(evaluation.provider_connection)
  const connectionFailed = connection.status === 'failed'
  const blockers = asStringArray(readiness.blockers)
  const llmMetrics = Array.isArray(deep.llm_metrics) ? deep.llm_metrics.map(asRecord) : []
  const providers = asRecord(deep.analysis_providers)
  const judges = asRecord(deep.judge_results)
  const structuralChecks = offlineQuality.offline_structural_checks ?? deep.offline_structural_checks
  const checks = Array.isArray(structuralChecks) ? structuralChecks.map(asRecord) : []
  const confusion = Array.isArray(classification.confusion_matrix) ? classification.confusion_matrix.filter(Array.isArray) as number[][] : []
  const classes = Array.isArray(classification.classes) ? classification.classes.filter((item): item is string => typeof item === 'string') : []

  return <div>
    <PageHeader eyebrow="Quality assurance" title="AI Evaluation Center" description="Classification benchmarks, retrieval comparisons, and analysis quality." action={<button className="icon-btn" title="Refresh evaluation reports" aria-label="Refresh evaluation reports" disabled={query.isFetching} onClick={() => query.refetch()}><RefreshCw size={17} className={query.isFetching ? 'animate-spin' : ''} /></button>} />
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <MetricCard icon={Crosshair} title="Test accuracy" value={measuredPercent(test.accuracy)} context="Untouched holdout" selected />
      <MetricCard icon={CheckCircle2} title="Macro F1" value={measuredPercent(macro['f1-score'])} context="Balanced across classes" />
      <MetricCard icon={SearchCheck} title="RAG Precision@5" value={measuredPercent(retrievalMetrics.precision_at_k)} context={typeof retrieval.query_count === 'number' ? `${retrieval.query_count} held-out queries` : 'Retrieval report not available'} />
      <MetricCard icon={FileCheck2} title="RAG MRR" value={measuredPercent(retrievalMetrics.mrr)} context="Classifier-assisted retrieval" />
    </div>

    <div className="mt-5 grid gap-5 xl:grid-cols-2">
      {Object.entries(evaluation).filter(([, value]) => ['stale', 'unverified', 'unavailable'].includes(asString(asRecord(value).status, ''))).map(([name, value]) => <div role="status" key={name} className="border-l-2 border-amber-400 px-4 py-3 text-sm text-amber-200 xl:col-span-2">{titleCase(name)}: {asString(asRecord(value).limitation, 'Report unavailable.')}</div>)}
      {Boolean(readiness.status) && <Panel title="PRD Demonstration Status" eyebrow={asString(readiness.status)} className="xl:col-span-2"><div className="grid gap-3 sm:grid-cols-2">{Object.entries(asRecord(readiness.checks)).map(([name, value]) => <div key={name} className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[.07] pb-3 text-sm"><span className="text-zinc-400">{readinessLabels[name] || titleCase(name)}</span><StatusBadge status={value === true ? 'passed' : connectionFailed && name in readinessLabels ? 'blocked' : 'pending'} /></div>)}</div>{blockers.length > 0 && <ul className="mt-4 space-y-2 text-xs leading-5 text-amber-200/80">{blockers.map(reason => <li key={reason}>{reason}</li>)}</ul>}<p className="mt-4 text-xs text-zinc-500">{asString(readiness.scope)}</p></Panel>}
      {Boolean(connection.status) && <Panel title="Provider Connection" eyebrow="Last authentication check" className="xl:col-span-2"><div className="flex flex-wrap items-center justify-between gap-3"><strong className="text-sm capitalize">{asString(connection.provider)}</strong><StatusBadge status={connectionFailed ? 'authentication failed' : asString(connection.status)} /></div><dl className="mt-4 grid gap-4 text-sm sm:grid-cols-3">{[['Generation model', connection.generation_model], ['Judge model', connection.judge_model], ['Checked', connection.created_at ? formatDate(asString(connection.created_at)) : 'Not recorded']].map(([label, value]) => <div key={String(label)} className="min-w-0"><dt className="text-xs text-zinc-500">{String(label)}</dt><dd className="mt-1 break-words text-zinc-300">{asString(value)}</dd></div>)}</dl>{connectionFailed && <p className="mt-4 text-sm text-red-300">{connection.http_status === 401 ? `${connection.provider === 'anthropic' ? 'Claude' : 'The provider'} rejected the configured API credential (HTTP 401). Live generation, judging, and DeepEval quality scoring cannot run with this credential.` : `Provider connection failed${typeof connection.http_status === 'number' ? ` (HTTP ${connection.http_status})` : ''}. Live evaluation is blocked until connectivity is restored.`}</p>}</Panel>}
      {Object.keys(advancedMetrics).length > 0 && <Panel title="Retrieval Strategy Comparison" eyebrow={`${asNumber(advanced.queries_per_strategy)} held-out queries per strategy`} className="xl:col-span-2"><div className="table-wrap"><table className="data-table"><thead><tr><th>Strategy</th><th>Precision@5</th><th>Recall@5</th><th>Hit Rate</th><th>MRR</th></tr></thead><tbody>{Object.entries(advancedMetrics).map(([name, value]) => { const row = asRecord(value); return <tr key={name}><td>{titleCase(name)}</td>{['precision_at_k', 'recall_at_k', 'hit_rate_at_k', 'mrr'].map(metric => <td key={metric}>{formatPercent(asNumber(row[metric]))}</td>)}</tr> })}</tbody></table></div><p className="mt-3 text-xs text-zinc-500">Model-assisted category relevance on sampled flows; this comparison does not measure LLM answer quality.</p></Panel>}
      <Panel title="Retrieval Evaluation" eyebrow={`${measuredCount(retrieval.query_count)}${typeof retrieval.query_count === 'number' ? ' queries' : ''} · K=${asNumber(retrieval.k, 5)}`}>
        {Object.keys(retrievalMetrics).length ? <div className="grid grid-cols-2 gap-3">{Object.entries(retrievalMetrics).map(([key, value]) => <div key={key} className="border-b border-white/[.06] py-3"><p className="text-[10px] uppercase tracking-wider text-zinc-500">{titleCase(key)}</p><strong className="mt-2 block text-2xl text-gold">{measuredPercent(value)}</strong></div>)}</div> : <p className="text-sm text-zinc-400">Retrieval evaluation has not been run for the active dataset.</p>}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-white/[.06] pt-3 text-xs"><span className="text-zinc-500">Unassisted semantic + BM25 Precision@5</span><strong>{measuredPercent(baselineMetrics.precision_at_k)}</strong></div>
        {Boolean(retrieval.strategy || retrieval.relevance_definition || retrieval.limitation) && <p className="mt-4 text-xs leading-5 text-zinc-500">{asString(retrieval.strategy, asString(retrieval.relevance_definition, asString(retrieval.limitation)))}</p>}
      </Panel>

      <Panel title="DeepEval & LLM Judge" eyebrow={asString(deep.framework, 'DeepEval')}>
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[.07] pb-4"><div><p className="text-xs text-zinc-500">Evaluation cases</p><strong className="mt-1 block text-2xl">{measuredCount(deep.case_count)}</strong></div><StatusBadge status={deep.llm_metrics_status === 'not_run_offline' ? 'offline only' : asString(deep.llm_metrics_status, 'not run').replaceAll('_', ' ')} /></div>
        {checks.length > 0 && <><h3 className="mt-4 text-sm font-semibold">Offline Structural Checks</h3><p className="mt-1 text-xs text-zinc-500">Section completeness and citation membership only, not LLM answer quality.</p><div className="mt-3 space-y-2">{checks.map((check, index) => <div key={`${check.category}-${index}`} className="flex items-start gap-3 border-b border-white/[.06] py-3">{check.score === 1 ? <CheckCircle2 size={15} className="mt-0.5 shrink-0 text-emerald-400" /> : <XCircle size={15} className="mt-0.5 shrink-0 text-red-400" />}<div className="min-w-0"><strong className="text-xs">{asString(check.category)}</strong><p className="mt-1 text-xs leading-5 text-zinc-500">{asString(check.reason)}</p></div><span className="ml-auto shrink-0 text-xs text-gold">{measuredPercent(check.score)}</span></div>)}</div></>}
        <p className="mt-4 text-xs leading-5 text-amber-200/80">{asString(deep.limitation, 'Live LLM quality evaluation has not been run for the active dataset.')}</p>
      </Panel>

      <Panel title="Live Quality Metrics" eyebrow="DeepEval LLM assessment" className="xl:col-span-2">
        {llmMetrics.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>Traffic category</th>{qualityMetrics.map(name => <th key={name}>{name}</th>)}</tr></thead><tbody>{llmMetrics.map((row, index) => { const metrics = Array.isArray(row.metrics) ? row.metrics.map(asRecord) : []; return <tr key={`${row.category}-${index}`}><td>{asString(row.category)}</td>{qualityMetrics.map(name => { const metric = metrics.find(value => value.metric === name); return <td key={name}><strong title={metric ? asString(metric.reason, asString(metric.error_type, '')) : ''}>{metric?.status === 'completed' ? measuredPercent(metric.score) : 'Not measured'}</strong>{typeof metric?.passed === 'boolean' && <span className={`mt-1 block text-[10px] ${metric.passed ? 'text-emerald-400' : 'text-red-400'}`}>{metric.passed ? 'Threshold passed' : 'Threshold failed'}</span>}</td> })}</tr> })}</tbody></table></div> : <p className="text-sm text-zinc-400">{connectionFailed ? 'Live quality scores are unavailable because the provider authentication check failed.' : 'No live LLM quality scores have been measured.'}</p>}
        <p className="mt-3 text-xs text-zinc-500">Hallucination scores are better when lower; other quality scores are better when higher. Completed measurement does not imply threshold success.</p>
      </Panel>
      {Object.keys(providers).length > 0 && <Panel title="Generation & Judge Evidence" eyebrow="Per-category provider results" className="xl:col-span-2"><div className="table-wrap"><table className="data-table"><thead><tr><th>Traffic category</th><th>Analysis provider</th><th>Judge status</th><th>Judge provider</th></tr></thead><tbody>{Object.entries(providers).map(([category, provider]) => { const judge = asRecord(judges[category]); return <tr key={category}><td>{category}</td><td>{asString(provider)}</td><td><StatusBadge status={asString(judge.status, 'not run').replaceAll('_', ' ')} /></td><td>{asString(judge.provider, 'None')}</td></tr> })}</tbody></table></div>{Object.entries(judges).filter(([, value]) => asRecord(value).status === 'completed').map(([category, value]) => <details key={category} className="mt-3 border-t border-white/10 pt-3"><summary className="cursor-pointer text-sm text-zinc-300">{category} judge assessment</summary><dl className="mt-3 space-y-3">{Object.entries(asRecord(asRecord(value).dimensions)).map(([name, dimension]) => { const score = asRecord(dimension); return <div key={name}><dt className="text-xs font-semibold">{titleCase(name)}: {asNumber(score.score)}/5</dt><dd className="mt-1 text-xs leading-5 text-zinc-500">{asString(score.reason)}</dd></div> })}</dl></details>)}</Panel>}

      <Panel title="Retrieval By Attack Type" eyebrow="Integrated investigation strategy" className="xl:col-span-2">
        <div className="table-wrap"><table className="data-table"><thead><tr><th>Attack type</th><th>Precision@5</th><th>Hit rate@5</th><th>MRR</th></tr></thead><tbody>{Object.entries(perClass).map(([label, value]) => { const row = asRecord(value); return <tr key={label}><td className="font-medium text-zinc-100">{label}</td><td className="font-semibold text-gold">{formatPercent(asNumber(row.precision_at_k))}</td><td>{formatPercent(asNumber(row.hit_rate_at_k))}</td><td>{formatPercent(asNumber(row.mrr))}</td></tr> })}</tbody></table></div>
      </Panel>

      <Panel title="Confusion Matrix" eyebrow="Held-out predictions" className="xl:col-span-2">{confusion.length ? <ConfusionMatrix matrix={confusion} labels={classes} /> : <p className="text-sm text-zinc-500">Confusion-matrix data is unavailable in the current fallback.</p>}</Panel>
      <Panel title="Evaluation Boundaries" eyebrow="Responsible reporting" className="xl:col-span-2"><div className="grid gap-4 md:grid-cols-3"><Boundary icon={Beaker} title="Benchmark context" text="CIC-IDS2017 performance does not guarantee production performance under drift or different prevalence." /><Boundary icon={SearchCheck} title="Retrieval relevance" text="Category agreement is a coarse evaluation proxy and classifier hints can reinforce prediction errors." /><Boundary icon={ShieldQuestion} title="Judge status" text="Unavailable judge metrics stay explicitly unconfigured; the interface never substitutes invented scores." /></div></Panel>
    </div>
  </div>
}

function ConfusionMatrix({ matrix, labels }: { matrix: number[][]; labels: string[] }) {
  const max = Math.max(...matrix.flat(), 1)
  return <div className="overflow-x-auto"><div className="min-w-[680px]"><div className="mb-2 grid gap-1" style={{ gridTemplateColumns: `130px repeat(${matrix.length}, minmax(56px,1fr))` }}><span />{labels.map(label => <span key={label} className="truncate px-1 text-center text-[10px] text-zinc-500">{label}</span>)}</div>{matrix.map((row, i) => <div key={i} className="mb-1 grid gap-1" style={{ gridTemplateColumns: `130px repeat(${matrix.length}, minmax(56px,1fr))` }}><span className="flex items-center text-xs text-zinc-400">{labels[i] || `Class ${i + 1}`}</span>{row.map((value, j) => <div key={j} className="flex h-12 items-center justify-center rounded border border-white/[.05] font-mono text-xs" style={{ background: `rgba(212,175,55,${0.04 + 0.68 * value / max})`, color: value / max > 0.5 ? '#050505' : '#d4d4d8' }}>{value}</div>)}</div>)}</div></div>
}

function Boundary({ icon: Icon, title, text }: { icon: typeof Beaker; title: string; text: string }) {
  return <div className="rounded-lg border border-white/[.06] p-4"><Icon size={18} className="text-gold" /><strong className="mt-3 block text-sm">{title}</strong><p className="mt-2 text-xs leading-5 text-zinc-500">{text}</p></div>
}
