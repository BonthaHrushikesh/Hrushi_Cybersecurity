import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd

from src.utils.config import settings
from src.utils.features import flow_signatures
from ml.train import train_models


def merge_reviewed_feedback(baseline: pd.DataFrame, reviewed: pd.DataFrame, numeric_features: list[str]) -> pd.DataFrame:
    """Replace matching baseline signatures with reviewed labels; reviewed corrections win."""
    if reviewed.empty:
        return baseline.copy()
    required = {"attack_category", "incident_id"}
    if missing := required - set(reviewed.columns):
        raise ValueError(f"Reviewed feedback is missing required columns: {sorted(missing)}")

    baseline = baseline.copy()
    reviewed = reviewed.copy()
    baseline["_signature"] = flow_signatures(baseline, numeric_features)
    reviewed["_signature"] = flow_signatures(reviewed, numeric_features)

    conflicts = reviewed.groupby("_signature")["attack_category"].nunique()
    if (conflicts > 1).any():
        raise ValueError("Conflicting approved labels exist for the same numeric flow signature")
    if "reviewed_at" in reviewed:
        reviewed = reviewed.sort_values("reviewed_at")
    reviewed = reviewed.drop_duplicates("_signature", keep="last")

    baseline = baseline.loc[~baseline["_signature"].isin(set(reviewed["_signature"]))]
    return pd.concat([baseline, reviewed], ignore_index=True, sort=False).drop(columns="_signature")


def main():
    parser = argparse.ArgumentParser(description="Train a separate candidate using reviewed corrections; never overwrite active models.")
    parser.add_argument("--feedback", type=Path, default=settings.processed / "reviewed_feedback.csv")
    parser.add_argument("--output", type=Path, default=settings.artifacts / "candidates/reviewed")
    args = parser.parse_args()
    destinations = [args.output / "models", args.output / "evaluation", args.output / "processed"]
    protected = [settings.artifacts / "models", settings.artifacts / "evaluation", settings.processed]
    if any(destination.resolve().is_relative_to(path.resolve()) or path.resolve().is_relative_to(destination.resolve())
           for destination in destinations for path in protected):
        parser.error("Candidate output must not overlap active models, evaluation reports, or processed data")
    reviewed = pd.read_csv(args.feedback)
    if reviewed.empty:
        parser.error("No approved corrections are available for candidate training")
    active = json.loads((settings.artifacts / "models/metadata.json").read_text())
    baseline = pd.read_csv(settings.processed / "incidents.csv")
    profile = json.loads((settings.processed / "profile.json").read_text())
    combined = merge_reviewed_feedback(baseline, reviewed, profile["numeric_features"])
    candidate_data = args.output / "processed"
    candidate_data.mkdir(parents=True, exist_ok=True)
    combined.to_csv(candidate_data / "incidents.csv", index=False)
    (candidate_data / "profile.json").write_text(json.dumps(profile, indent=2), encoding="utf-8")
    benchmark = pd.read_csv(settings.processed / "test.csv")
    candidate = train_models(candidate_data, args.output, fixed_test=benchmark)
    comparison = {"active_model": active["version"], "candidate_model": candidate["version"],
                  "active_macro_f1": active["test_metrics"]["macro avg"]["f1-score"],
                  "candidate_macro_f1": candidate["test_metrics"]["macro avg"]["f1-score"],
                  "promotion": "manual_review_required", "benchmark": "Same active holdout; matching feature signatures excluded from candidate training.",
                  "limitation": "Repeated selection against the active benchmark can overfit its feedback; use an independent external benchmark before deployment."}
    (args.output / "comparison.json").write_text(json.dumps(comparison, indent=2), encoding="utf-8")
    print(json.dumps(comparison, indent=2))


if __name__ == "__main__":
    main()
