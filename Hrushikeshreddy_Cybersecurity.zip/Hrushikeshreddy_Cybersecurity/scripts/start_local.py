import json
import argparse
import os
from pathlib import Path
import socket
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]


def free_port(start: int) -> int:
    for port in range(start, start + 20):
        with socket.socket() as sock:
            try:
                sock.bind(("127.0.0.1", port))
            except OSError:
                continue
            return port
    raise RuntimeError("No available local port")


def wait_for_servers(processes, endpoints, timeout: float) -> bool:
    import httpx

    deadline = time.monotonic() + timeout
    with httpx.Client(timeout=2) as client:
        while time.monotonic() < deadline:
            if any(process.poll() is not None for _, process in processes):
                return False
            try:
                if all(client.get(url).status_code == 200 for url in endpoints):
                    return True
            except httpx.RequestError:
                pass
            time.sleep(0.25)
    return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--restart", action="store_true", help="Restart only previously recorded project server processes")
    parser.add_argument("--offline", action="store_true", help="Use local providers for this run without changing the private .env")
    parser.add_argument("--startup-timeout", type=float, default=60, help="Seconds to wait for both local services (default: 60)")
    args = parser.parse_args()
    if not 0 < args.startup_timeout <= 300:
        parser.error("--startup-timeout must be greater than 0 and at most 300 seconds")
    artifacts = ROOT / "artifacts"
    artifacts.mkdir(exist_ok=True)
    runtime_path = artifacts / "runtime.json"
    if args.restart and runtime_path.exists():
        runtime = json.loads(runtime_path.read_text())
        for name, pid in runtime.get("processes", {}).items():
            command = subprocess.run(["ps", "-p", str(pid), "-o", "command="], capture_output=True, text=True).stdout
            expected = {"backend": any(entry in command for entry in ("uvicorn src.main:app", "uvicorn app.main:app")),
                        "frontend": "vite" in command or "npm run dev" in command}.get(name, False)
            cwd = subprocess.run(["lsof", "-a", "-p", str(pid), "-d", "cwd", "-Fn"], capture_output=True, text=True).stdout
            owned_directory = any(line in {f"n{ROOT}", f"n{ROOT / 'frontend'}"} for line in cwd.splitlines())
            if owned_directory and expected:
                if os.getpgid(pid) == pid:
                    os.killpg(pid, signal.SIGTERM)
                else:
                    os.kill(pid, signal.SIGTERM)
        time.sleep(1)
    backend_port = free_port(8000)
    api_url = f"http://127.0.0.1:{backend_port}"
    env = {**os.environ, "VITE_API_BASE_URL": api_url}
    if args.offline:
        env["LLM_PROVIDER"] = "local"
    frontend_port = free_port(5173)
    commands = [
        ("backend", [sys.executable, "-m", "uvicorn", "src.main:app", "--host", "127.0.0.1", "--port", str(backend_port)]),
        ("frontend", ["node", str(ROOT / "frontend/node_modules/vite/bin/vite.js"), "--host", "127.0.0.1", "--port", str(frontend_port), "--strictPort"]),
    ]
    urls = {"api_url": api_url, "frontend_url": f"http://127.0.0.1:{frontend_port}"}
    endpoints = [api_url + "/ready", urls["frontend_url"] + "/"]
    processes = []
    for name, command in commands:
        with (artifacts / f"{name}.log").open("ab") as log:
            cwd = ROOT / "frontend" if name == "frontend" else ROOT
            process = subprocess.Popen(command, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        processes.append((name, process))
    if not wait_for_servers(processes, endpoints, args.startup_timeout):
        for _, process in processes:
            if process.poll() is None:
                process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
        raise RuntimeError("Local servers did not start; inspect artifacts/backend.log and the frontend log in artifacts/")
    runtime = {**urls, "offline": args.offline, "processes": {name: process.pid for name, process in processes}}
    (artifacts / "runtime.json").write_text(json.dumps(runtime, indent=2), encoding="utf-8")
    print(json.dumps(runtime, indent=2))


if __name__ == "__main__":
    main()
