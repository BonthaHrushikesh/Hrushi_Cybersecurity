import pytest

from src.services.provider_resilience import CircuitOpenError, ProviderCircuit


def test_circuit_skips_provider_and_recovers_after_cooldown(monkeypatch):
    clock = [10.0]
    monkeypatch.setattr("src.services.provider_resilience.monotonic", lambda: clock[0])
    circuit = ProviderCircuit(2, 60)
    calls = []

    def fail():
        calls.append(1)
        raise TimeoutError("private provider error")

    for _ in range(2):
        with pytest.raises(TimeoutError):
            circuit.call(fail)
    with pytest.raises(CircuitOpenError):
        circuit.call(fail)
    assert len(calls) == 2
    clock[0] += 61
    assert circuit.call(lambda: "recovered") == "recovered"
    assert circuit.call(lambda: "available") == "available"


def test_empty_generated_analysis_is_rejected(investigation):
    from src.api.schemas import Analysis
    from src.services.recommendations import validate_grounding

    analysis = Analysis.model_validate(investigation["analysis"])
    analysis.immediate_investigation = []
    with pytest.raises(ValueError, match="omits evidence"):
        validate_grounding(analysis, {})


def test_provider_failure_reason_reports_safe_schema_and_truncation_details():
    from pydantic import BaseModel, ValidationError
    from src.services.provider_resilience import provider_failure_reason

    class StructuredOutput(BaseModel):
        score: int

    with pytest.raises(ValidationError) as captured:
        StructuredOutput.model_validate({"score": "PRIVATE_RESPONSE_FRAGMENT"})
    schema_detail = provider_failure_reason(captured.value)
    truncated_detail = provider_failure_reason(ValueError("NVIDIA did not complete the response"))

    assert "required schema" in schema_detail
    assert "PRIVATE_RESPONSE_FRAGMENT" not in schema_detail
    assert "complete structured response" in truncated_detail
