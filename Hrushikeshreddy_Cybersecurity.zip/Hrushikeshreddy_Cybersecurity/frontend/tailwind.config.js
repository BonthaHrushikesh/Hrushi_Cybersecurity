/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        void: '#070707', ink: '#0D0D0D', panel: '#111111', raised: '#151515',
        gold: '#D4AF37', brightGold: '#F4D675', mutedGold: '#9C7C26',
      },
      boxShadow: { panel: '0 14px 45px rgba(0,0,0,.28)' },
      fontFamily: { sans: ['Inter', 'ui-sans-serif', 'system-ui'], mono: ['JetBrains Mono', 'ui-monospace', 'monospace'] },
    },
  },
  plugins: [],
}
