from dataclasses import replace
from pathlib import Path

from fastapi.testclient import TestClient
import pytest

from src.api.application import create_app
from src.api.schemas import FlowInput, SearchRequest
from src.services.recommendations import evidence_payload, local_analysis
from src.utils.config import ROOT, settings


@pytest.mark.parametrize("path", ["frontend/.env.local", "src/.env", "src/.env.production", "src/.DS_Store", "src/private.pem", "src/private.key"])
def test_submission_allowlist_excludes_environment_variants_and_private_files(path):
    from scripts.package_submission import allowed

    assert not allowed(Path(path))


def test_submission_allowlist_preserves_public_example_and_canonical_source():
    from scripts.package_submission import REQUIRED, allowed

    assert allowed(Path(".env.example"))
    assert allowed(Path("src/services/models.py"))
    assert "src/main.py" in REQUIRED and "src/api/application.py" in REQUIRED


def test_legacy_entrypoint_and_saved_embedding_import_stay_compatible():
    from app.main import app as legacy_app
    from app.services.embeddings import EmbeddingService as legacy_embeddings
    from src.main import app
    from src.services.embeddings import EmbeddingService

    assert legacy_app is app
    assert legacy_embeddings is EmbeddingService
    assert ROOT == Path(__file__).resolve().parents[1]


@pytest.mark.parametrize("contents", [None, "not-json", '{"DDoS": {"flow_bytes_s": NaN}}'])
def test_missing_or_corrupt_optional_pattern_report_keeps_global_importance(tmp_path, contents):
    for name in ["models", "index"]:
        (tmp_path / name).symlink_to(settings.artifacts / name, target_is_directory=True)
    if contents is not None:
        directory = tmp_path / "evaluation"
        directory.mkdir()
        (directory / "attack_patterns.json").write_text(contents)
    with TestClient(create_app(replace(settings, artifacts=tmp_path, llm_provider="local"))) as client:
        response = client.get("/api/v1/explain/global")
        assert response.status_code == 200
        assert response.json()["global_importance"]
        assert response.json()["attack_patterns"] == {}
        assert response.json()["limitations"]


def test_metadata_port_can_supply_fourth_required_feature(client):
    response = client.post("/api/v1/classify", json={"features": {
        "flow_duration": 1000, "flow_packets_s": 100, "flow_bytes_s": 10000}, "metadata": {"destination_port": 80}})
    assert response.status_code == 200


def test_extremely_large_numeric_input_is_a_validation_error(client):
    response = client.post("/api/v1/classify", json={"features": {
        "destination_port": 80, "flow_duration": 10 ** 400, "flow_packets_s": 100, "flow_bytes_s": 10000}})
    assert response.status_code == 422
    assert "input" not in response.json()["detail"][0]


def test_local_playbook_does_not_claim_supplied_metadata_is_absent(client, sample):
    services = client.app.state.services
    flow = FlowInput(features=sample["features"], metadata={"source_ip": "192.0.2.1", "destination_ip": "198.51.100.2",
                     "protocol": "TCP", "timestamp": "2026-10-11T12:00:00Z"})
    prediction = services.models.classify(flow)
    anomaly = services.models.anomaly(flow)
    risk = services.risk.score(flow, prediction, anomaly)
    retrieval = services.retrieval.search(SearchRequest(query="DDoS traffic"))
    evidence = evidence_payload(flow, prediction, anomaly, risk, retrieval, services.models.explain(flow))
    action = local_analysis(evidence).further_evidence[0]
    assert "supplied event metadata" in action.action
    assert "lacks" not in action.evidence
