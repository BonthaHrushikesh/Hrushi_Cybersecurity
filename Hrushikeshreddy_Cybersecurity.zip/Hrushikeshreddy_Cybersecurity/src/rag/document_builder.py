from src.utils.features import SEVERITY_PRIORS
from src.services.risk import severity_for

ALIASES = {
    "BENIGN": "normal legitimate baseline traffic",
    "Brute Force": "authentication password guessing repeated login attempts FTP SSH",
    "DoS": "denial of service resource exhaustion flooding",
    "DDoS": "distributed denial of service traffic flooding",
    "PortScan": "port scanning reconnaissance service discovery",
    "Bot": "botnet automated host activity command and control",
    "Web Attack": "web application attack HTTP injection cross site scripting authentication",
    "Infiltration": "unauthorized intrusion infiltration",
    "Heartbleed": "heartbeat vulnerability memory disclosure",
}


def flow_document(features: dict, metadata: dict | None = None) -> str:
    metadata = metadata or {}
    parts = [f"Network flow to destination port {int(features.get('destination_port', 0))}."]
    if metadata.get("protocol"):
        parts.append(f"Protocol {metadata['protocol']}.")
    indicators = [
        ("flow_duration", "flow duration in microseconds"),
        ("flow_packets_s", "packet rate packets per second"),
        ("flow_bytes_s", "byte throughput bytes per second"),
        ("total_fwd_packets", "forward packet count"),
        ("packet_length_mean", "mean packet length bytes"),
        ("flow_iat_mean", "mean inter arrival time microseconds"),
        ("syn_flag_count", "SYN flag count"), ("rst_flag_count", "RST flag count"),
        ("ack_flag_count", "ACK flag count"), ("psh_flag_count", "PSH flag count"),
    ]
    parts.extend(f"Observed {description}: {features[name]:.4g}." for name, description in indicators if name in features)
    rate = features.get("flow_packets_s", 0)
    parts.append("High packet activity." if rate > 10000 else "Moderate packet activity." if rate > 100 else "Low packet activity.")
    if features.get("flow_bytes_s", 0) > 1_000_000:
        parts.append("High byte throughput.")
    if "packet_length_mean" in features and features["packet_length_mean"] < 80:
        parts.append("Small packets.")
    parts.append("Source, destination host, time, and protocol are unknown unless explicitly supplied.")
    return " ".join(parts)


def incident_document(features: dict, metadata: dict, category: str, original: str) -> str:
    return flow_document(features, metadata) + f" Historical label: {category}; original label: {original}. Attack family vocabulary: {ALIASES.get(category, category)}."


def historical_risk(category: str) -> tuple[float, str]:
    score = round(SEVERITY_PRIORS.get(category, 0.5) * 100, 2)
    return score, severity_for(score)[0]
