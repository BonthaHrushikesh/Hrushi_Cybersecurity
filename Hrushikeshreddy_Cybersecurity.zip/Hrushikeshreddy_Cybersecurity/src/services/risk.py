import numpy as np

from src.utils.features import SEVERITY_PRIORS
from src.api.schemas import AnomalyResult, FlowInput, Prediction, RiskResult

SIGNALS = ["malicious_probability", "anomaly_percentile", "malicious_confidence", "attack_prior", "traffic_indicators"]


def severity_for(score: float) -> tuple[str, str]:
    if score >= 80:
        return "CRITICAL", "P1"
    if score >= 60:
        return "HIGH", "P2"
    if score >= 30:
        return "MEDIUM", "P3"
    return "LOW", "P4"


class RiskEngine:
    def __init__(self, weights: tuple[float, ...]):
        if len(weights) != 5 or abs(sum(weights) - 1) > 1e-6 or any(x < 0 for x in weights):
            raise ValueError("Risk weights must be five nonnegative values summing to one")
        self.weights = dict(zip(SIGNALS, weights))

    def score(self, flow: FlowInput, prediction: Prediction, anomaly: AnomalyResult) -> RiskResult:
        f = flow.features
        packet = min(1.0, np.log1p(f.get("flow_packets_s", 0)) / np.log1p(100_000))
        byte = min(1.0, np.log1p(f.get("flow_bytes_s", 0)) / np.log1p(100_000_000))
        flags = min(1.0, (f.get("syn_flag_count", 0) + f.get("rst_flag_count", 0)) / 20)
        traffic = float(0.5 * packet + 0.3 * byte + 0.2 * flags)
        components = {
            "malicious_probability": prediction.malicious_probability,
            "anomaly_percentile": anomaly.normalized_anomaly_risk,
            "malicious_confidence": prediction.classification_confidence if prediction.predicted_attack_type != "BENIGN" else 0.0,
            "attack_prior": SEVERITY_PRIORS.get(prediction.predicted_attack_type, 0.5),
            "traffic_indicators": traffic,
        }
        score = round(float(100 * sum(self.weights[k] * components[k] for k in SIGNALS)), 2)
        severity, priority = severity_for(score)
        explanation = (f"{priority}: model predicts {prediction.predicted_attack_type} with {prediction.classification_confidence:.1%} confidence; "
                       f"malicious confidence {prediction.malicious_probability:.1%}; anomaly percentile {anomaly.normalized_anomaly_risk:.1%}. "
                       "Score is a configurable triage policy, not a calibrated probability. Historical label similarity does not establish a new attack.")
        return RiskResult(risk_score=score, severity=severity, priority=priority, components=components, weights=self.weights, explanation=explanation)
