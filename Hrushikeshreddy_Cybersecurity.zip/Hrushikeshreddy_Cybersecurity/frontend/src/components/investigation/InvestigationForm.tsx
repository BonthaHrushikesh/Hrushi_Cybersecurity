import { zodResolver } from "@hookform/resolvers/zod";
import { FileUp, Play, RotateCcw } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { investigationApi } from '../../api';
import { useSettings } from '../../store/settings';
import { useForm } from "react-hook-form";
import { z } from "zod";
import type {
  HistoricalIncident,
  InvestigationRequest,
  Protocol,
  NetworkFlow,
} from "../../types";

const numeric = (label: string, max = 1e15) =>
  z.preprocess(value => value === '' ? undefined : value, z.coerce
    .number({ invalid_type_error: `${label} must be a number` })
    .min(0, `${label} cannot be negative`)
    .max(max));
const optionalNumeric = (label: string) => z.preprocess(value => value === '' || value === undefined ? undefined : value, numeric(label).optional());
const optionalPort = z.preprocess(
  (value) => (value === "" || value === undefined ? undefined : value),
  z.coerce.number().int().min(0).max(65535).optional(),
);
const schema = z.object({
  source_ip: z.string().ip().optional().or(z.literal("")),
  destination_ip: z.string().ip().optional().or(z.literal("")),
  source_port: optionalPort,
  destination_port: z.preprocess(value => value === '' ? undefined : value,
    z.coerce.number({ invalid_type_error: 'Destination port is required' }).int().min(0).max(65535)),
  protocol: z.enum(["TCP", "UDP", "ICMP"]).or(z.literal("")),
  timestamp: z.string().optional(),
  flow_duration: numeric("Flow duration"),
  total_fwd_packets: optionalNumeric("Forward packets"),
  total_backward_packets: optionalNumeric("Backward packets"),
  total_length_of_fwd_packets: optionalNumeric("Forward bytes"),
  total_length_of_bwd_packets: optionalNumeric("Backward bytes"),
  flow_bytes_s: numeric("Flow bytes/s"),
  flow_packets_s: numeric("Flow packets/s"),
  flow_iat_mean: optionalNumeric("Flow IAT mean"),
  packet_length_mean: optionalNumeric("Packet length mean"),
  syn_flag_count: optionalNumeric("SYN count"),
  rst_flag_count: optionalNumeric("RST count"),
  ack_flag_count: optionalNumeric("ACK count"),
  average_packet_size: optionalNumeric("Average packet size"),
  active_mean: optionalNumeric("Active mean"),
  idle_mean: optionalNumeric("Idle mean"),
  query: z.string().min(3).max(1000),
  top_k: z.coerce.number().int().min(1).max(30),
  alpha: z.coerce.number().min(0).max(1),
  use_llm: z.boolean(),
  judge: z.boolean(),
});
type FormValues = z.infer<typeof schema>;
const defaults: FormValues = {
  source_ip: "",
  destination_ip: "",
  source_port: undefined,
  destination_port: 80,
  protocol: "",
  timestamp: "",
  flow_duration: 1450000,
  total_fwd_packets: 640,
  total_backward_packets: 12,
  total_length_of_fwd_packets: 480000,
  total_length_of_bwd_packets: 6400,
  flow_bytes_s: 9200000,
  flow_packets_s: 28000,
  flow_iat_mean: 35.7,
  packet_length_mean: 745,
  syn_flag_count: 18,
  rst_flag_count: 5,
  ack_flag_count: 3,
  average_packet_size: 752,
  active_mean: 980000,
  idle_mean: 1200,
  query:
    "Investigate this network flow and retrieve similar historical incidents",
  top_k: 5,
  alpha: 0.65,
  use_llm: true,
  judge: true,
};
const featureFields: [keyof FormValues, string, string][] = [
  ["flow_duration", "Flow duration", "μs"],
  ["flow_packets_s", "Flow packets/s", "pkt/s"],
  ["flow_bytes_s", "Flow bytes/s", "B/s"],
  ["total_fwd_packets", "Forward packets", "count"],
  ["total_backward_packets", "Backward packets", "count"],
  ["total_length_of_fwd_packets", "Forward bytes", "bytes"],
  ["total_length_of_bwd_packets", "Backward bytes", "bytes"],
  ["flow_iat_mean", "Flow IAT mean", "μs"],
  ["packet_length_mean", "Packet length mean", "bytes"],
  ["average_packet_size", "Average packet size", "bytes"],
  ["syn_flag_count", "SYN flags", "count"],
  ["rst_flag_count", "RST flags", "count"],
  ["ack_flag_count", "ACK flags", "count"],
  ["active_mean", "Active mean", "μs"],
  ["idle_mean", "Idle mean", "μs"],
];

function sampleToValues(sample: NetworkFlow): Partial<FormValues> {
  const m = sample.metadata || {};
  return {
    ...sample.features,
    source_ip: m.source_ip || "",
    destination_ip: m.destination_ip || "",
    source_port: m.source_port ?? undefined,
    destination_port:
      m.destination_port ?? sample.features.destination_port ?? 0,
    protocol: (m.protocol || "") as Protocol | "",
    timestamp: m.timestamp ? new Date(new Date(m.timestamp).getTime() - new Date(m.timestamp).getTimezoneOffset() * 60000).toISOString().slice(0, 16) : "",
  };
}

export function InvestigationForm({
  samples = [],
  pending,
  onSubmit,
  initialJudge = true,
}: {
  samples?: HistoricalIncident[];
  pending: boolean;
  onSubmit: (request: InvestigationRequest) => void;
  initialJudge?: boolean;
}) {
  const [mode, setMode] = useState<"manual" | "upload">("manual");
  const settings = useSettings();
  const configuredDefaults = useMemo(() => ({ ...defaults, top_k: settings.resultCount, alpha: settings.hybridAlpha, judge: initialJudge }), [settings, initialJudge]);
  const loadedFeatures = useRef<Record<string, number>>({});
  const loadedFlowId = useRef<string | null | undefined>(undefined);
  const loadedTimestamp = useRef<{ display: string; original: string | null | undefined }>({ display: '', original: undefined });
  const [importError, setImportError] = useState('');
  const [importPending, setImportPending] = useState(false);
  const sampleLoaded = useRef(false);
  const {
    register,
    handleSubmit,
    getValues,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: configuredDefaults,
  });
  const errorList = useMemo(
    () =>
      Object.values(errors)
        .map((error) => error?.message)
        .filter(Boolean) as string[],
    [errors],
  );
  const loadFlow = useCallback((flow: NetworkFlow) => {
    loadedFeatures.current = { ...flow.features };
    loadedFlowId.current = flow.metadata?.flow_id;
    const values = sampleToValues(flow);
    loadedTimestamp.current = { display: values.timestamp || '', original: flow.metadata?.timestamp };
    const absent = Object.fromEntries(featureFields.map(([name]) => [name, '']));
    reset({ ...configuredDefaults, ...absent, ...values, use_llm: getValues('use_llm'), judge: getValues('judge') });
    setImportError('');
  }, [reset, getValues, configuredDefaults]);
  const submit = (values: FormValues) => {
    const {
      source_ip,
      destination_ip,
      source_port,
      destination_port,
      protocol,
      timestamp,
      query,
      top_k,
      alpha,
      use_llm,
      judge,
      ...features
    } = values;
    const observed = { ...loadedFeatures.current };
    for (const [name, value] of Object.entries(features)) {
      if (value === undefined) delete observed[name];
      else observed[name] = value;
    }
    onSubmit({
      query,
      top_k,
      alpha,
      use_llm,
      judge,
      flow: {
        features: { ...observed, destination_port },
        metadata: {
          flow_id: loadedFlowId.current || null,
          source_ip: source_ip || null,
          destination_ip: destination_ip || null,
          source_port: source_port ?? null,
          destination_port,
          protocol: protocol || null,
          timestamp: timestamp ? (timestamp === loadedTimestamp.current.display && loadedTimestamp.current.original ? loadedTimestamp.current.original : new Date(timestamp).toISOString()) : null,
        },
      },
    });
  };
  const upload = async (file?: File) => {
    if (!file) return;
    if (file.size > 45000) { setImportError('Select a flow CSV smaller than 45 KB.'); return; }
    setImportPending(true);
    setImportError('');
    try { loadFlow(await investigationApi.parseCSV(await file.text())); }
    catch (error) { setImportError(error instanceof Error ? error.message : 'CSV could not be imported.'); }
    finally { setImportPending(false); }
  };
  useEffect(() => {
    if (sampleLoaded.current || samples.length === 0) return;
    const sample =
      samples.find((item) => item.attack_type === "DDoS") || samples[0];
    loadFlow(sample);
    sampleLoaded.current = true;
  }, [samples, loadFlow]);
  return (
    <form onSubmit={handleSubmit(submit)} className="space-y-5">
      <div className="flex w-fit rounded-lg border border-white/10 bg-black p-1">
        <button
          type="button"
          onClick={() => setMode("manual")}
          className={`rounded-md px-4 py-2 text-xs font-semibold ${mode === "manual" ? "bg-gold text-black" : "text-zinc-500"}`}
        >
          Manual entry
        </button>
        <button
          type="button"
          onClick={() => setMode("upload")}
          className={`rounded-md px-4 py-2 text-xs font-semibold ${mode === "upload" ? "bg-gold text-black" : "text-zinc-500"}`}
        >
          CSV upload
        </button>
      </div>
      {mode === "upload" && (
        <label className="flex min-h-32 cursor-pointer flex-col items-center justify-center rounded-lg border border-dashed border-gold/30 bg-gold/[.025] text-center">
          <FileUp className="text-gold" />
          <strong className="mt-2 text-sm">
            Select a CIC-IDS2017 flow CSV
          </strong>
          <span className="mt-1 text-xs text-zinc-500">
            The first data row is loaded into the reviewable form below.
          </span>
          <input
            type="file"
            accept=".csv,text/csv"
            className="sr-only"
            onChange={(e) => upload(e.target.files?.[0])}
          />
        </label>
      )}
      <section className="panel">
        <div className="panel-header">
          <div>
            <p className="eyebrow mb-1">Context</p>
            <h2 className="text-base font-semibold">Network metadata</h2>
          </div>
          <select
            className="field max-w-56"
            defaultValue=""
            onChange={(e) => {
              const sample = samples.find(
                (x) => x.incident_id === e.target.value,
              );
              if (sample) loadFlow(sample);
            }}
          >
            <option value="">Load sample flow...</option>
            {samples.map((x) => (
              <option key={x.incident_id} value={x.incident_id}>
                {x.attack_type} · {x.incident_id.slice(0, 12)}
              </option>
            ))}
          </select>
        </div>
        <div className="grid gap-4 p-5 sm:grid-cols-2 xl:grid-cols-3">
          {[
            ["source_ip", "Source IP"],
            ["destination_ip", "Destination IP"],
            ["source_port", "Source port"],
            ["destination_port", "Destination port"],
            ["timestamp", "Timestamp"],
          ].map(([name, label]) => (
            <label key={name}>
              <span className="label">{label}</span>
              <input
                className="field"
                type={
                  name === "timestamp"
                    ? "datetime-local"
                    : name.includes("port")
                      ? "number"
                      : "text"
                }
                {...register(name as keyof FormValues)}
              />
            </label>
          ))}
          <label>
            <span className="label">Protocol</span>
            <select className="field" {...register("protocol")}>
              <option value="">Not provided</option>
              <option>TCP</option>
              <option>UDP</option>
              <option>ICMP</option>
            </select>
          </label>
        </div>
      </section>
      <section className="panel">
        <div className="panel-header">
          <div>
            <p className="eyebrow mb-1">Telemetry</p>
            <h2 className="text-base font-semibold">Traffic features</h2>
          </div>
          <span className="text-xs text-zinc-500">
            Non-negative finite values
          </span>
        </div>
        <div className="grid gap-4 p-5 sm:grid-cols-2 xl:grid-cols-3">
          {featureFields.map(([name, label, unit]) => (
            <label key={name}>
              <span className="label">
                {label} <span className="text-zinc-600">({unit})</span>
              </span>
              <input
                className="field font-mono"
                type="number"
                step="any"
                {...register(name)}
              />
            </label>
          ))}
        </div>
      </section>
      <section className="panel p-5">
        <label>
          <span className="label">Investigation objective</span>
          <textarea
            className="field min-h-24 resize-y"
            {...register("query")}
          />
        </label>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <label>
            <span className="label">Historical matches</span>
            <input className="field" type="number" {...register("top_k")} />
          </label>
          <label>
            <span className="label">Semantic weight: hybrid search</span>
            <input
              className="w-full accent-[#D4AF37]"
              type="range"
              min="0"
              max="1"
              step=".05"
              {...register("alpha")}
            />
          </label>
          <label className="flex items-center gap-3 pt-5 text-sm text-zinc-300">
            <input
              type="checkbox"
              className="h-4 w-4 accent-[#D4AF37]"
              {...register("use_llm")}
            />
            Use configured LLM
          </label>
          <label className="flex items-center gap-3 pt-5 text-sm text-zinc-300">
            <input
              type="checkbox"
              className="h-4 w-4 accent-[#D4AF37]"
              {...register("judge")}
            />
            Run LLM judge
          </label>
        </div>
      </section>
      {(importError || importPending) && <p role={importError ? 'alert' : 'status'} className="text-sm text-amber-300">{importError || 'Validating CSV...'}</p>}
      {errorList.length > 0 && (
        <div className="rounded-lg border border-red-500/25 bg-red-500/[.07] px-4 py-3 text-sm text-red-300">
          {errorList[0]}
        </div>
      )}
      <div className="flex flex-wrap justify-end gap-3">
        <button
          type="button"
          className="btn-secondary"
          onClick={() => { loadedFeatures.current = {}; loadedFlowId.current = undefined; loadedTimestamp.current = { display: '', original: undefined }; reset(configuredDefaults); setImportError(''); }}
        >
          <RotateCcw size={15} />
          Reset
        </button>
        <button disabled={pending || importPending} className="btn-primary" type="submit">
          <Play size={15} />
          {pending ? "Analyzing..." : "Run investigation"}
        </button>
      </div>
    </form>
  );
}
