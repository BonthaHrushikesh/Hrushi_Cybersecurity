import { Bot, Send } from 'lucide-react'
import { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { ragApi } from '../api'
import { PageHeader, Panel, AttackBadge, SeverityBadge } from '../components/ui'
import { useSettings } from '../store/settings'

const prompts = ['Find historical SSH brute-force activity and recommend investigation steps.', 'Compare DDoS traffic with denial-of-service incidents.', 'What evidence is associated with botnet command and control?']

export function AssistantPage() {
  const settings = useSettings()
  const [input, setInput] = useState('')
  const [question, setQuestion] = useState('')
  const [useLLM, setUseLLM] = useState(true)
  const mutation = useMutation({ mutationFn: (query: string) => ragApi.answer({ query, top_k: settings.resultCount, alpha: settings.hybridAlpha, use_llm: useLLM, fusion: 'rrf', expand_query: true, diversify: true }) })
  const ask = (value = input) => {
    if (value.trim().length < 3 || mutation.isPending) return
    setQuestion(value)
    mutation.mutate(value)
    setInput('')
  }
  const result = mutation.data
  return <div>
    <PageHeader eyebrow="Evidence assistant" title="AI Investigation Assistant" description="Historical evidence and incident analysis" />
    <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_320px]">
      <section className="min-w-0">
        <div className="mb-4 flex items-center justify-between gap-3 border-b border-white/[.07] pb-4">
          <Bot size={20} className="text-gold" />
          <label className="flex items-center gap-2 text-sm text-zinc-400"><input type="checkbox" checked={useLLM} onChange={event => setUseLLM(event.target.checked)} className="accent-[#D4AF37]" />Use configured LLM</label>
        </div>
        {question && <p className="mb-5 whitespace-pre-wrap break-words text-sm text-zinc-200">{question}</p>}
        {mutation.isPending && <div className="skeleton mb-5 h-40" aria-label="Generating answer" />}
        {mutation.isError && <p role="alert" className="mb-5 text-sm text-red-300">{mutation.error.message}</p>}
        {result && !mutation.isPending && !mutation.isError && <div className="mb-6 space-y-5">
          <div className="flex flex-wrap gap-3 text-xs text-zinc-500"><span>{result.provider === 'anthropic' ? 'Claude analysis' : result.provider === 'openai' ? 'OpenAI analysis' : result.provider === 'local_fallback' ? 'Local fallback' : 'Local evidence extract'}</span><span>{result.context_incident_ids.length} evidence records</span><span>{result.retrieval.latency_ms.toFixed(0)} ms retrieval</span></div>
          <p className="whitespace-pre-wrap break-words text-sm leading-7 text-zinc-300">{result.analysis.answer}</p>
          <div><h3 className="mb-2 text-sm font-medium text-zinc-200">Next Steps</h3><ul className="list-disc space-y-2 pl-5 text-sm text-zinc-400">{result.analysis.recommended_next_steps.map((step, index) => <li key={index}>{step}</li>)}</ul></div>
          <div><h3 className="mb-2 text-sm font-medium text-zinc-200">Evidence Gaps</h3><ul className="list-disc space-y-2 pl-5 text-xs leading-5 text-zinc-500">{result.analysis.evidence_gaps.map((gap, index) => <li key={index}>{gap}</li>)}</ul></div>
          <div className="space-y-3">{result.retrieval.results.filter(hit => result.context_incident_ids.includes(hit.incident_id)).map(hit => <Link to={`/incidents/${encodeURIComponent(hit.incident_id)}`} key={hit.incident_id} className="block rounded-lg border border-white/[.07] p-4 hover:border-gold/30"><div className="flex flex-wrap items-center gap-2"><AttackBadge attack={hit.attack_type} /><SeverityBadge severity={hit.severity} /><span className="break-all font-mono text-xs text-zinc-500">{hit.incident_id}</span></div><p className="mt-2 line-clamp-2 text-xs leading-5 text-zinc-500">{hit.document}</p></Link>)}</div>
        </div>}
        <form onSubmit={event => { event.preventDefault(); ask() }} className="flex gap-2 border-t border-white/[.07] pt-4">
          <input className="field min-w-0" value={input} onChange={event => setInput(event.target.value)} maxLength={1000} placeholder="Ask a defensive incident question..." aria-label="Incident question" />
          <button type="submit" className="icon-btn shrink-0 text-gold" disabled={mutation.isPending || input.trim().length < 3} aria-label="Send question" title="Send question"><Send size={16} /></button>
        </form>
      </section>
      <Panel title="Suggested Questions" eyebrow="Historical evidence"><div className="space-y-2">{prompts.map(prompt => <button key={prompt} disabled={mutation.isPending} onClick={() => ask(prompt)} className="w-full rounded-lg border border-white/[.07] p-3 text-left text-xs leading-5 text-zinc-400 hover:border-gold/30">{prompt}</button>)}</div></Panel>
    </div>
  </div>
}
