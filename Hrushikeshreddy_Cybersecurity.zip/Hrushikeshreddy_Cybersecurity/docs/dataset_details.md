# Dataset Details

Participant: Hrushikeshreddy. Snapshot: 11 October 2026.

## Dataset Source, Format, And Purpose

CIC-IDS2017, Canadian Institute for Cybersecurity, University of New Brunswick.
[Official dataset](https://www.unb.ca/cic/datasets/ids-2017.html).
Original distribution includes CSV network flows and PCAP captures. The pipeline
consumes CSV/Parquet flows; raw packet capture processing is not implemented.
The dataset supports classification, historical retrieval, metadata filtering,
triage, anomaly analysis, explainability, and defensive investigation.

Primary local source: eight metadata-rich CSVs in `TrafficLabelling `
(trailing space). `MachineLearningCVE` is a numeric-export cross-check, not
concatenated into the corpus. Seven export pairs match exactly; Monday requires
tolerance comparison and does not have complete exact-signature agreement.

## Key Fields

| Family | Examples | Use |
|---|---|---|
| Metadata | Flow ID, source/destination IP, source/destination port, protocol, timestamp | Filtering and analyst correlation |
| Volume | Forward/backward packets and bytes | Traffic behavior |
| Rates/timing | Duration, Bytes/s, Packets/s, IAT, Active/Idle statistics | Burst/slow-flow/anomaly signals |
| Packet/flag statistics | Packet Length Mean, Average Packet Size, SYN/RST/ACK | Attack-associated patterns |
| Label | BENIGN and original attack subtype | Target, never ML numeric input |

Nine normalized categories: BENIGN, Bot, Brute Force, DDoS, DoS, Heartbleed,
Infiltration, PortScan, Web Attack. Original subtypes remain in evidence.
Identifiers, labels, timestamps, and IPs are excluded from predictive features.
Destination port is an observed feature as well as metadata.

## Preparation

| Stage | Count |
|---|---:|
| Parsed rows | 3,119,345 |
| Unlabeled malformed rows excluded | 288,602 |
| Labeled population | 2,830,743 |
| Prepared sample | 20,273 |
| Raw / derived numeric inputs | 77 / 3 |
| Initial training / validation | 12,974 / 3,244 |
| Refit training and indexed history | 16,218 |
| Held-out test | 4,055 |

Streaming cp1252 decoding, alias normalization, protocol/IP/port validation,
and day-first timestamp parsing precede seeded sampling. A duplicated forward
header-length column is verified equivalent before removal. Nonfinite and
negative measurement sentinels become missing; imputation uses training medians.
Uniform random-priority sampling, seed 42, caps each original label at 2,000.
Exact numeric duplicates and conflicts are removed within the retained sample
before splitting; no full-file duplicate count is claimed.

Derived inputs are duration_seconds, forward_bytes_per_packet, and
packet_rate_asymmetry. Validation macro F1 selects the model. Test rows are
excluded from final training and the history corpus.

## Metadata And Timestamp Provenance

Real source/destination IPs, ports, protocol, and timestamps are retained.
One prepared record has missing protocol; all indexed records have protocol.
Missing/invalid metadata never matches a filter.

UTC was assigned to naive timestamps from the user's conditional declaration,
not independently verified from the source. Raw source_timestamp strings remain
available. No invented AM/PM, clock-hour, or host corrections were applied.
Confirm source timezone before operational correlation.

## Portable Data And Limitations

`data/sample_data/cicids2017_labelled_sample.csv` is a real 467-row sample across
all nine categories, with metadata. It supports fresh-checkout training without
large raw files. Demo results have their own model version and smaller test set.
The older seven-category sample remains a legacy fixture, not the default.

Class sampling changes prevalence. Probabilities are uncalibrated; random
holdouts may share related sessions. Host/time-disjoint evaluation has not been
performed. Heartbleed has 11 prepared/two test rows; Infiltration 36/seven.
Neither supports strong rare-attack generalization claims. Download large raw
exports separately; they are excluded from the submission ZIP.
