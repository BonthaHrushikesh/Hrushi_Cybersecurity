from copy import deepcopy
from dataclasses import replace
import json
from types import SimpleNamespace

import pytest

from src.utils.config import settings
from src.api.application import Services
from src.agents.quality_judge import DIMENSIONS
from scripts.check_prd_readiness import QUALITY_METRICS, live_evidence_checks, quality_evidence_checks, quality_measurement_evidence
from scripts.start_local import wait_for_servers


@pytest.fixture
def quality_fixture():
    config = replace(settings, llm_provider="anthropic")
    model = {"version": "fixture-model", "classes": ["BENIGN", "DDoS"]}
    # Synthetic report fixtures verify validation; they do not establish live quality.
    report = {"model_version": model["version"], "llm_provider": config.llm_provider,
              "generation_model": config.generation_model, "judge_model": config.evaluation_model,
              "live_generation_verified": True, "live_judge_verified": True, "llm_metrics_status": "completed",
              "analysis_providers": {category: "anthropic" for category in model["classes"]},
              "judge_results": {category: {"status": "completed", "provider": "anthropic", "dimensions": {
                  name: {"score": 4, "reason": "Synthetic validation fixture"} for name in DIMENSIONS}}
                  for category in model["classes"]},
              "llm_metrics": [{"category": category, "metrics": [{"metric": name, "status": "completed", "score": .8}
                              for name in QUALITY_METRICS]} for category in model["classes"]]}
    return report, model, config


def test_complete_matching_quality_evidence_is_accepted(quality_fixture):
    assert quality_evidence_checks(*quality_fixture) == (True, True, True)
    assert quality_measurement_evidence(*quality_fixture)


def test_partial_current_quality_scores_are_measured_but_not_complete(quality_fixture):
    report, model, config = quality_fixture
    report["llm_metrics_status"] = "partial"
    report["live_generation_verified"] = False
    report["analysis_providers"]["DDoS"] = "local_fallback"
    report["llm_metrics"][0]["metrics"] = report["llm_metrics"][0]["metrics"][:1]
    assert quality_measurement_evidence(report, model, config)
    assert quality_evidence_checks(report, model, config)[2] is False


def test_matching_focused_live_evidence_is_accepted(quality_fixture):
    _, model, config = quality_fixture
    dimensions = {name: {"score": 4, "reason": "Synthetic validation fixture"} for name in DIMENSIONS}
    report = {
        "status": "completed", "model_version": model["version"], "llm_provider": config.llm_provider,
        "generation_model": config.generation_model, "judge_model": config.evaluation_model,
        "checks": {"investigation_provider_verified": True, "judge_completed": True, "rag_provider_verified": True},
        "investigation": {"analysis_provider": config.llm_provider,
                          "judge": {"status": "completed", "provider": config.llm_provider, "dimensions": dimensions}},
        "rag_answer": {"provider": config.llm_provider},
    }
    assert live_evidence_checks(report, model, config) == (True, True)
    report["generation_model"] = "stale-model"
    assert live_evidence_checks(report, model, config) == (False, False)


@pytest.mark.parametrize("field", ["model_version", "llm_provider", "generation_model", "judge_model"])
def test_stale_quality_provenance_cannot_satisfy_prd(quality_fixture, field):
    report, model, config = quality_fixture
    report[field] = "another-version-or-provider"
    assert quality_evidence_checks(report, model, config) == (False, False, False)


def test_fallback_generation_is_not_live_quality_evidence(quality_fixture):
    report, model, config = quality_fixture
    report["analysis_providers"]["DDoS"] = "local_fallback"
    assert quality_evidence_checks(report, model, config)[0] is False


@pytest.mark.parametrize("failure", ["missing_dimension", "different_provider", "unavailable", "empty_reason"])
def test_incomplete_judge_result_is_not_prd_evidence(quality_fixture, failure):
    report, model, config = quality_fixture
    judge = report["judge_results"]["DDoS"]
    if failure == "missing_dimension":
        judge["dimensions"].pop("safety")
    elif failure == "different_provider":
        judge["provider"] = "openai"
    elif failure == "unavailable":
        judge["status"] = "unavailable"
    else:
        judge["dimensions"]["safety"]["reason"] = " "
    assert quality_evidence_checks(report, model, config)[1] is False


@pytest.mark.parametrize("failure", ["missing_metric", "missing_category", "failed_metric", "invalid_score", "duplicate_category"])
def test_incomplete_metric_report_is_not_prd_evidence(quality_fixture, failure):
    report, model, config = quality_fixture
    if failure == "missing_metric":
        report["llm_metrics"][0]["metrics"].pop()
    elif failure == "missing_category":
        report["llm_metrics"].pop()
    elif failure == "failed_metric":
        report["llm_metrics"][0]["metrics"][0]["status"] = "unavailable"
    elif failure == "duplicate_category":
        report["llm_metrics"].append(deepcopy(report["llm_metrics"][0]))
    else:
        report["llm_metrics"][0]["metrics"][0]["score"] = float("nan")
    assert quality_evidence_checks(report, model, config)[2] is False


@pytest.mark.parametrize("mismatch", ["model", "index"])
def test_mixed_artifact_versions_do_not_enable_analysis(tmp_path, monkeypatch, mismatch):
    import src.api.application

    model = SimpleNamespace(bundle={"version": "active"}, metadata={"version": "other" if mismatch == "model" else "active"})
    index = SimpleNamespace(metadata={"model_version": "other" if mismatch == "index" else "active"})
    monkeypatch.setattr(src.api.application, "ModelService", lambda path: model)
    monkeypatch.setattr(src.api.application, "RetrievalService", lambda *args: index)
    services = Services(replace(settings, artifacts=tmp_path))
    assert services.orchestrator is None
    assert "Rebuild compatible artifacts" in services.load_error


def test_explicit_offline_evaluation_never_uses_configured_provider(tmp_path, monkeypatch, investigation):
    import src.api.application
    import evaluation.evaluation_dataset
    from evaluation.deepeval_runner import run

    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-only-key")
    config = replace(settings, llm_provider="anthropic", artifacts=tmp_path)
    stub = SimpleNamespace(orchestrator=SimpleNamespace(persist=False), models=SimpleNamespace(bundle={"version": "fixture-model"}))
    monkeypatch.setattr(src.api.application, "Services", lambda config: stub)

    def cases(services, *, use_llm, judge):
        assert use_llm is False and judge is False
        return [{"input": "Investigate defensive traffic", "actual_output": json.dumps(investigation["analysis"]),
                 "retrieval_context": [json.dumps({"incident_id": hit["incident_id"]}) for hit in investigation["retrieval"]["results"]],
                 "metadata": {"category": "DDoS", "analysis_provider": "local_evidence_playbook", "judge": None}}]

    monkeypatch.setattr(evaluation.evaluation_dataset, "build_cases", cases)
    report = run(offline=True, config=config)
    assert report["llm_metrics_status"] == "not_run_offline"
    assert report["llm_metrics"] == []
    assert not report["live_generation_verified"] and not report["live_judge_verified"]


@pytest.mark.parametrize("state", ["slow_start", "timeout", "exited"])
def test_server_readiness_waits_for_deadline_and_detects_failed_processes(monkeypatch, state):
    from contextlib import nullcontext
    import httpx
    import scripts.start_local

    clock = [0.0]
    monkeypatch.setattr(scripts.start_local.time, "monotonic", lambda: clock[0])
    monkeypatch.setattr(scripts.start_local.time, "sleep", lambda seconds: clock.__setitem__(0, clock[0] + seconds))

    def get(url):
        if state == "timeout" or clock[0] < 15:
            raise httpx.ConnectError("Offline readiness fixture")
        return SimpleNamespace(status_code=200)

    monkeypatch.setattr(httpx, "Client", lambda **kwargs: nullcontext(SimpleNamespace(get=get)))
    processes = [("backend", SimpleNamespace(poll=lambda: 1 if state == "exited" else None))]
    assert wait_for_servers(processes, ["http://fixture/health"], timeout=60) is (state == "slow_start")
    assert clock[0] == {"slow_start": 15, "timeout": 60, "exited": 0}[state]
