import { cleanup, fireEvent, render, screen, within } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { demoInvestigation } from '../../demo/data'
import { InvestigationResultView } from './InvestigationResultView'

vi.mock('recharts',()=>({
  ResponsiveContainer:({children}:{children:React.ReactNode})=><div>{children}</div>,
  BarChart:({children}:{children:React.ReactNode})=><div>{children}</div>, Bar:()=>null, CartesianGrid:()=>null, Cell:()=>null, Tooltip:()=>null, XAxis:()=>null, YAxis:()=>null,
}))

describe('investigation result',()=>{
  afterEach(cleanup)
  it('separates prediction confidence from analyst validation',()=>{
    render(<InvestigationResultView result={demoInvestigation}/>)
    expect(screen.getAllByText('DDoS').length).toBeGreaterThan(0)
    expect(screen.getByText(/requires analyst verification/i)).toBeInTheDocument()
    expect(screen.getByText('Observed Evidence')).toBeInTheDocument()
    expect(screen.getByLabelText(/Risk score 92/)).toBeInTheDocument()
  })

  it('explains a skipped judge rather than hiding the validation section', () => {
    render(<InvestigationResultView result={demoInvestigation} />)
    fireEvent.click(screen.getByRole('button', { name: 'workflow' }))
    const panel = screen.getByRole('heading', { name: 'Judge Validation' }).closest('section')!
    expect(within(panel).getByText('NOT REQUESTED')).toBeInTheDocument()
    expect(within(panel).getByText(/LLM judging was disabled/)).toBeInTheDocument()
  })

  it('shows an unavailable judge reason without inventing scores', () => {
    render(<InvestigationResultView result={{ ...demoInvestigation,
      judge: { status: 'unavailable', provider: 'anthropic', dimensions: {}, limitation: 'Synthetic authentication failure (HTTP 401).' },
    }} />)
    fireEvent.click(screen.getByRole('button', { name: 'workflow' }))
    const panel = screen.getByRole('heading', { name: 'Judge Validation' }).closest('section')!
    expect(within(panel).getByText('UNAVAILABLE')).toBeInTheDocument()
    expect(within(panel).getByText('Synthetic authentication failure (HTTP 401).')).toBeInTheDocument()
    expect(within(panel).queryByText(/\/5/)).not.toBeInTheDocument()
  })
})
