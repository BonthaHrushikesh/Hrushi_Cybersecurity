# REST API Documentation

Participant: Hrushikeshreddy. Snapshot: 11 October 2026.
FastAPI/Uvicorn exposes JSON REST endpoints. Interactive contracts: /docs;
machine-readable complete schema: /openapi.json and docs/examples/openapi.json.
Every operation's request/response format and measured example is appended in
API_Examples.md and included in the API Documentation PDF.

## Deployment And Safety

Bind to localhost. This capstone API has no enterprise authentication; do not
expose it to a public network. Keys remain backend-only. Errors never echo
credentials or complete request bodies. X-Request-ID identifies API requests.

/health is diagnostic and remains reachable when artifacts are absent;
/ready returns 503 until the model/index are ready. System status separates
credentials configured from provider authentication and reports circuit state.

## Inputs

FlowInput contains a features object and optional metadata. Required observed
fields: destination_port, flow_duration, flow_packets_s, flow_bytes_s.
Destination port may instead be supplied in metadata. Numeric values must be
finite, non-boolean, supported, and within the validated bounds. Dataset aliases
are accepted. Unknown fields, duplicate aliases, inconsistent ports, invalid IPs,
unsupported protocols, and naive event timestamps are rejected. Missing optional
features remain missing and use saved training medians, with warnings.

SearchRequest supports query, top_k (1-30), alpha (0-1), mode
(keyword/semantic/hybrid), fusion (weighted/rrf), expand_query, diversify,
and filters. Metadata filters compose with AND: attack type, source/destination
IP, source/destination ports, protocol, flow ID, exact timestamp, time range,
severity, minimum historical risk. Null metadata never matches. Genuine metadata
exists in the primary TrafficLabelling corpus; UTC is user-declared provenance.

InvestigationRequest adds flow, use_llm, and judge. Explicitly set use_llm=false
and judge=false for a no-provider demonstration. RAGRequest uses use_llm for
cited historical answering. Historical severity/risk is a labeled category
prior, distinct from calculated new-investigation risk. LLM failures use a
declared local narrative fallback; unavailable judge scores remain absent.

## Endpoint Inventory

| Method | Endpoint | Input | Output |
|---|---|---|---|
| GET | /health | None | Diagnostic readiness/model flags |
| GET | /ready | None | Same flags, HTTP 503 if unready |
| GET | /api/v1/system/status | None | Configuration/connectivity/circuits/limits, no secrets |
| POST | /api/v1/flows/parse | csv_text | Validated first flow from CSV |
| GET | /api/v1/model/info | None | Version/features/splits/measured model metadata |
| POST | /api/v1/classify | FlowInput | Attack probabilities and binary intrusion confidence |
| POST | /api/v1/anomaly | FlowInput | Raw score/benign-reference percentile |
| POST | /api/v1/risk | FlowInput | Severity, P1-P4, components, weights |
| POST | /api/v1/search | SearchRequest | Ranked history with semantic/keyword/fused scores |
| POST | /api/v1/rag/answer | RAGRequest | Cited answer/evidence gaps/provider/history |
| POST | /api/v1/investigate | InvestigationRequest | Full seven-role investigation |
| POST | /api/v1/explain | FlowInput | TreeSHAP baseline/contributions/reconstruction |
| POST | /api/v1/recommend | InvestigationRequest | Full investigation with recommendations |
| POST | /api/v1/feedback | FeedbackRequest | HTTP 201, pending-review record ID |
| GET | /api/v1/feedback | None | Feedback list |
| GET | /api/v1/incidents | limit query, clamped 1-1000 | items/total saved summaries |
| GET | /api/v1/incidents/{incident_id} | Path ID | Saved investigation or historical record |
| GET | /api/v1/incidents/{incident_id}/report | Saved investigation ID | Downloadable text/markdown |
| GET | /api/v1/metrics | None | Saved counts, history counts, data profile, version-checked evaluations |
| GET | /api/v1/explain/global | None | Impurity importance/category median associations |
| GET | /api/v1/samples | None | One actual historical flow per available category |

The root redirects to /docs. Framework-generated /docs, /redoc, and /openapi.json
provide schema navigation rather than business operations.

## Errors And Examples

422: validation failure. 404: unknown incident/feedback reference.
413: configured request-size limit exceeded (default 65,536 bytes).
503: model/index setup required. 500: sanitized unexpected failure.
Failed optional providers generally return successful local analysis with an
explicit fallback/provider limitation, not a fabricated hosted result.

CSV parsing uses the standard CSV parser, quoted-field support, alias validation,
and only the first data record. Target labels are ignored; malformed/nonfinite
features and timezone-free event inputs are rejected.

Measured examples use an isolated temporary database, real observed sample
fields, and only local providers. They do not add documentation incidents to the
active DB and do not contact Claude/OpenAI. Arrays/large fields in the PDF are
explicitly abridged; full actual requests/responses are in
docs/examples/api_examples.json. Model metrics/examples belong to the version
recorded in each response, not every future demo run.
