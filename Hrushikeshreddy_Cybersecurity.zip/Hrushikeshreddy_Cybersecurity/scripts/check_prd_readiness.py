import json
import math
from pathlib import Path
import sys
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd

from src.utils.config import settings
from src.utils.features import CANONICAL_LABELS
from src.api.schemas import JudgeDimensions
from src.services.artifact_reports import connection_report, read_report, write_report

QUALITY_METRICS = {"Answer Relevancy", "Faithfulness", "Contextual Precision", "Contextual Recall", "Hallucination"}


def live_evidence_checks(live, model, config):
    """Validate focused provider smoke evidence independently of DeepEval."""
    current = config.llm_provider != "local" and all([
        live.get("status") == "completed",
        live.get("model_version") == model["version"],
        live.get("llm_provider") == config.llm_provider,
        live.get("generation_model") == config.generation_model,
        live.get("judge_model") == config.evaluation_model,
    ])
    checks = live.get("checks")
    checks = checks if isinstance(checks, dict) else {}
    investigation = live.get("investigation")
    investigation = investigation if isinstance(investigation, dict) else {}
    rag = live.get("rag_answer")
    rag = rag if isinstance(rag, dict) else {}
    generation = current and all([
        checks.get("investigation_provider_verified") is True,
        checks.get("rag_provider_verified") is True,
        investigation.get("analysis_provider") == config.llm_provider,
        rag.get("provider") == config.llm_provider,
    ])
    judge_result = investigation.get("judge")
    judge_result = judge_result if isinstance(judge_result, dict) else {}
    try:
        dimensions = JudgeDimensions.model_validate(judge_result.get("dimensions", {}))
        valid_dimensions = all(score.reason.strip() for _, score in dimensions)
    except ValueError:
        valid_dimensions = False
    judge = current and all([
        checks.get("judge_completed") is True,
        judge_result.get("status") == "completed",
        judge_result.get("provider") == config.llm_provider,
        valid_dimensions,
    ])
    return bool(generation), bool(judge)


def quality_evidence_checks(quality, model, config):
    expected = set(model["classes"])
    current = bool(expected) and config.llm_provider != "local" and all([
        quality.get("model_version") == model["version"],
        quality.get("llm_provider") == config.llm_provider,
        quality.get("generation_model") == config.generation_model,
        quality.get("judge_model") == config.evaluation_model,
    ])
    providers = quality.get("analysis_providers")
    providers = providers if isinstance(providers, dict) else {}
    generation = current and quality.get("live_generation_verified") is True and all(
        providers.get(category) == config.llm_provider for category in expected)

    def valid_judge(result):
        if not isinstance(result, dict) or result.get("status") != "completed" or result.get("provider") != config.llm_provider:
            return False
        try:
            dimensions = JudgeDimensions.model_validate(result.get("dimensions", {}))
            return all(score.reason.strip() for _, score in dimensions)
        except ValueError:
            return False

    judges = quality.get("judge_results")
    judges = judges if isinstance(judges, dict) else {}
    judge = current and quality.get("live_judge_verified") is True and all(valid_judge(judges.get(category)) for category in expected)

    def measured(category):
        values = quality.get("llm_metrics")
        values = values if isinstance(values, list) else []
        rows = [row for row in values if isinstance(row, dict) and row.get("category") == category]
        if len(rows) != 1:
            return False
        metrics = rows[0].get("metrics")
        if not isinstance(metrics, list) or not all(isinstance(item, dict) for item in metrics):
            return False
        names = {item.get("metric") for item in metrics}
        return QUALITY_METRICS <= names and all(
            item.get("status") == "completed" and isinstance(item.get("score"), (int, float))
            and not isinstance(item["score"], bool) and math.isfinite(item["score"]) and 0 <= item["score"] <= 1
            for item in metrics)

    metrics = current and quality.get("llm_metrics_status") == "completed" and all(measured(category) for category in expected)
    return bool(generation), bool(judge), bool(metrics)


def quality_measurement_evidence(quality, model, config):
    """Accept at least one real, current-model DeepEval score as measured evidence."""
    current = config.llm_provider != "local" and all([
        quality.get("llm_metrics_status") in {"partial", "completed"},
        quality.get("model_version") == model["version"],
        quality.get("llm_provider") == config.llm_provider,
        quality.get("generation_model") == config.generation_model,
        quality.get("judge_model") == config.evaluation_model,
    ])
    if not current:
        return False
    expected = set(model["classes"])
    rows = quality.get("llm_metrics")
    if not isinstance(rows, list):
        return False
    for row in rows:
        if not isinstance(row, dict) or row.get("category") not in expected:
            continue
        metrics = row.get("metrics")
        if not isinstance(metrics, list):
            continue
        if any(
            isinstance(metric, dict)
            and metric.get("metric") in QUALITY_METRICS
            and metric.get("status") == "completed"
            and isinstance(metric.get("score"), (int, float))
            and not isinstance(metric["score"], bool)
            and math.isfinite(metric["score"])
            and 0 <= metric["score"] <= 1
            for metric in metrics
        ):
            return True
    return False


def assess(config=settings):
    profile = json.loads((config.processed / "profile.json").read_text())
    model = json.loads((config.artifacts / "models/metadata.json").read_text())
    fields = ["source_ip", "destination_ip", "source_port", "destination_port", "protocol", "timestamp"]
    history = pd.read_csv(config.processed / "historical.csv", usecols=lambda name: name in fields)
    counts = {name: int(history[name].notna().sum()) if name in history else 0 for name in fields}
    missing = [name for name, count in counts.items() if not count]
    complete_records = int(history[fields].notna().all(axis=1).sum()) if not missing else 0
    absent_classes = sorted(set(CANONICAL_LABELS) - set(model["classes"]))
    path = config.artifacts / "evaluation/deepeval.json"
    quality = read_report(path) if path.exists() else {}
    quality_generation, quality_judge, metrics_complete = quality_evidence_checks(quality, model, config)
    metrics_measured = quality_measurement_evidence(quality, model, config)
    live_path = config.artifacts / "evaluation/live_verification.json"
    live = read_report(live_path) if live_path.exists() else {}
    live_generation, live_judge = live_evidence_checks(live, model, config)
    generation = quality_generation or live_generation
    judge = quality_judge or live_judge
    checks = {"historical_metadata": complete_records > 0, "all_prd_attack_categories": not absent_classes,
              "live_generation_evidence": bool(generation), "live_judge_evidence": bool(judge),
              "deepeval_quality_measured": bool(metrics_measured), "deepeval_quality_complete": bool(metrics_complete)}
    blockers = []
    if missing:
        blockers.append("Historical metadata missing: " + ", ".join(missing))
    elif not complete_records:
        blockers.append("No historical record has all required metadata fields available together.")
    if absent_classes:
        blockers.append("Active model has no training coverage for: " + ", ".join(absent_classes))
    if not generation:
        blockers.append("Live generation evidence is incomplete or does not match the active model and provider configuration.")
    if not judge:
        blockers.append("Live judge evidence is incomplete or does not match the active model and provider configuration.")
    if not metrics_complete:
        blockers.append("Full category-level DeepEval quality metrics have not been completed for the active model and provider configuration.")
    if not generation or not judge or not metrics_complete:
        connection_path = config.artifacts / "evaluation/provider_connection.json"
        if connection_path.exists():
            connection = connection_report(config)
            if (connection.get("provider") == config.llm_provider and
                    connection.get("generation_model") == config.generation_model and
                    connection.get("judge_model") == config.evaluation_model and connection.get("status") == "failed"):
                status = connection.get("http_status")
                code = f" (HTTP {status})" if isinstance(status, int) else ""
                blockers.append(f"Provider authentication check failed{code}; live evaluation requires a successful provider connection.")
    return {"status": "demonstrated" if all(checks.values()) else "incomplete", "checks": checks,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "model_version": model["version"], "source_dataset": profile["source_name"], "metadata_record_counts": counts,
            "complete_metadata_records": complete_records,
            "missing_attack_categories": absent_classes, "key_configured": config.credentials_configured,
            "quality_metrics_status": quality.get("llm_metrics_status", "not_run"), "blockers": blockers,
            "scope": "Reports whether DeepEval scores exist and whether full category coverage is complete; measurement does not mean scores passed quality thresholds."}


if __name__ == "__main__":
    result = assess()
    path = settings.artifacts / "evaluation/prd_readiness.json"
    write_report(path, result)
    print(json.dumps(result, indent=2))
