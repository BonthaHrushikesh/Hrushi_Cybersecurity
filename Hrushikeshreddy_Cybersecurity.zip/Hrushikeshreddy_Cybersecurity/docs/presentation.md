# Panel Presentation: 10 Minutes

Participant: **Hrushikeshreddy**.
Project: **AI-Powered Cybersecurity Incident Response Assistant**.
Ten slides; planned speaking/demo time: **600 seconds**.
The slides stay short. Speaker notes below provide the explanation to practise.
Results describe model cicids-aa6f46dbeb on the full sampled TrafficLabelling run,
not the smaller portable demo. Hosted Claude generation and quality checks are
deferred; the working demonstration uses local evidence-based recommendations.

## Slide 1: AI-Powered Cybersecurity Incident Response Assistant (40 Seconds)

Content:
- Helps analysts investigate suspicious network traffic.
- Combines predictions, historical evidence, and clear next steps.
- Supports human decisions; never blocks traffic automatically.

Visual: The actual dashboard with historical traffic counts.

Speaker notes:
Hello, I am Hrushikeshreddy. My project is an AI-powered cybersecurity incident response assistant. Security teams receive many network alerts, but each alert needs investigation before anyone can decide what it means. My project brings the main investigation tasks into one application: identify a possible attack, find similar past incidents, explain the evidence, and suggest defensive next steps. The important boundary is that this is an analyst assistant. It does not independently confirm a compromise or block traffic. The analyst remains responsible for the final decision.

## Slide 2: Why This Project Is Needed (45 Seconds)

Content:
- An alert rarely contains enough information for a decision.
- Analysts need attack context, historical examples, and priority.
- One investigation record brings these pieces together.

Visual: Three analyst questions matched to the assistant's outputs.

Speaker notes:
An analyst usually needs to answer three questions. First, has similar activity happened before? Second, what traffic characteristics suggest a particular attack? Third, which alerts should be investigated first? Without an integrated tool, the analyst switches between records, models, dashboards, and response guidance. This project connects those steps. It returns comparable incidents, a predicted category, a priority score, explanations, and investigation actions in one record. Faster investigation is the business objective; I have not claimed a measured reduction in analyst time because that would require a separate user study.

## Slide 3: The Dataset And Preparation (60 Seconds)

Content:
- CIC-IDS2017 provides labeled benign and attack traffic.
- 20,273 prepared flows; nine categories; 80 model inputs.
- Training history and final test data remain separate.

Visual: Prepared data split, feature count, and category coverage.

Speaker notes:
I used the metadata-rich TrafficLabelling CSVs from CIC-IDS2017. A network flow is a summary of a connection: addresses, ports, duration, packet counts, byte rates, timing, and flags. The scan parsed about 3.12 million rows and excluded unlabeled records. For reproducible local training, I retained 20,273 flows using seeded sampling, cleaned invalid measurements, and removed exact duplicates within that sample. There are 77 raw numeric features and three derived features, giving 80 model inputs. The nine categories include benign traffic, brute force, denial of service, bot activity, port scanning, web attacks, infiltration, and Heartbleed. Final training and historical retrieval use 16,218 rows; the untouched test set has 4,055. Source times use user-declared UTC, not an independently verified timezone.

## Slide 4: How The System Works (55 Seconds)

Content:
- Prepare the data, then build models and a history index.
- React sends analyst requests to the FastAPI backend.
- Specialist agents combine evidence into one result.

Visual: Separate offline preparation and online investigation paths.

Speaker notes:
The architecture has two parts. Offline, preprocessing creates clean flow records. Training builds the attack, intrusion, and anomaly models. Each historical flow becomes one document, which is indexed for retrieval. Online, the analyst uses the React interface, and FastAPI validates the request. The workflow then calls the relevant model, retrieval, risk, explanation, and response services. Python handles the backend; FAISS stores the vector index; BM25 handles keyword matching; SQLite stores investigations and feedback. The code follows the src API, agents, RAG, services, and utilities structure. Hosted Claude or OpenAI can provide structured narrative, but the current demo uses the local provider.

## Slide 5: Finding Similar Historical Incidents (60 Seconds)

Content:
- BM25 finds matching words; LSA finds related traffic descriptions.
- Hybrid ranking combines both kinds of evidence.
- Filters narrow results by attack, protocol, IP, port, and time.

Visual: Keyword and semantic retrieval merging into ranked, cited evidence.

Speaker notes:
RAG means retrieving relevant evidence before producing an answer. Here, each historical flow has a readable document and a stable incident ID. Keyword search uses BM25, which helps with exact terms such as SSH or port numbers. The active semantic baseline uses TF-IDF and LSA vectors in FAISS; it is not a pretrained language model. Hybrid search combines the rankings. The advanced path also expands attack vocabulary, compares observed flow features, and avoids repetitive evidence. Metadata filters are combined with AND, and missing metadata never silently matches. The answer cites supplied incident IDs and states evidence gaps. Similarity tells us that past traffic is related; it does not prove that a new flow is malicious.

## Slide 6: Prediction, Priority, And Explanation (60 Seconds)

Content:
- Random Forest predicts attack type and intrusion likelihood.
- Isolation Forest checks unusualness; policy assigns P1-P4 priority.
- TreeSHAP explains which features influenced the prediction.

Visual: Three separate questions: what, how urgent, and why.

Speaker notes:
The models answer different questions. The multiclass Random Forest predicts the attack category. A separate binary Random Forest estimates malicious-versus-benign confidence. Isolation Forest compares the flow with benign training traffic to identify unusualness. These signals remain separate because unusual traffic is not automatically an attack. A transparent five-signal policy produces a score from zero to one hundred and maps it to priority P1 through P4. P1 is the highest investigation priority. TreeSHAP explains which observed or imputed features pushed the classifier toward or away from its prediction. These are model explanations, not proof of causation, and the risk score is a policy score rather than a calibrated probability.

## Slide 7: Agents And Safety Checks (50 Seconds)

Content:
- Seven specialist roles share validated evidence and a visible trace.
- Inputs and citations are checked before results are returned.
- Local fallbacks preserve analysis; unavailable judge scores stay absent.

Visual: The seven workflow roles, with hosted response and judge clearly optional.

Speaker notes:
The workflow contains detection, anomaly, retrieval, risk, explainability, response, and an optional quality judge. These are specialist tool-using roles with shared state and defined dependencies, not seven independent chatbots. Each step records its status and timing. Input validation rejects invalid ports, IPs, feature names, nonfinite values, and unsupported queries. Generated outputs must follow the schema and cite only supplied historical IDs. If a requested provider fails, the application returns an explicitly labeled local playbook. It never invents a judge score. The optional judge evaluates analysis against evidence once a valid provider is available. No agent executes containment actions.

## Slide 8: Results And Honest Limitations (60 Seconds)

Content:
- Attack classification: 99.21% accuracy on the sampled holdout.
- Retrieval: 62.86% unassisted versus 95.24% model-assisted Precision@5.
- 173 backend tests, 20 React tests, and nine offline checks passed.
- Hosted LLM quality and independent-network validation remain pending.

Visual: Measured results with the benchmark and evaluation scope stated.

Speaker notes:
The attack classifier achieved 99.21 percent accuracy and a macro F1 of 0.9743 on 4,055 held-out flows. Macro F1 considers every category, which matters when classes have different sizes. For retrieval, Precision at five means the proportion of the top five results in the expected category. Across 42 queries, the unassisted baseline achieved 62.86 percent and the model-assisted hybrid path 95.24 percent. The assisted path adds predicted-category vocabulary, so it can also reinforce model mistakes. The backend and React test suites passed, and nine offline DeepEval structural checks passed. These checks verify sections and citation membership, not prose faithfulness. Rare-class test support is tiny, the split is random, and hosted generation, judge, and quality metrics remain deferred.

## Slide 9: Live Demonstration (120 Seconds)

Content:
- Open historical traffic and select a complete DDoS sample.
- Run locally; inspect prediction, priority, and similar incidents.
- Review the explanation and defensive recommendations.
- Submit feedback and show its pending-review status.

Visual: The actual saved investigation as a backup to the live demonstration.

Speaker notes:
I will show one complete investigation using an actual dataset sample. I will keep hosted generation and judging switched off so the demonstration is reproducible and does not depend on the deferred key. First, the dashboard distinguishes historical records from investigations that analysts have actually run. Next, I will submit the DDoS sample and read the returned category, anomaly signal, risk, and priority. I will open one historical match, point out its evidence ID, and connect one feature explanation to an investigation action. Finally, I will submit analyst feedback. It stays pending review and does not silently retrain the model.

Demo sequence:
1. 0-15 seconds: Open Dashboard. Show historical counts, not live sensor statistics.
2. 15-35 seconds: Open Investigate, choose DDoS, disable hosted generation and judge, then run.
3. 35-55 seconds: Read the returned category, confidence, risk, and priority; do not assume a fixed value.
4. 55-75 seconds: Open a historical match and identify the cited record and real metadata.
5. 75-95 seconds: Show TreeSHAP and defensive response; distinguish inference from confirmation.
6. 95-110 seconds: Submit feedback and show pending review.
7. 110-120 seconds: Show the agent trace or API documentation.

Backup: Use the saved investigation screenshot if the live environment is unavailable.
Start the local demo with `python scripts/start_local.py --restart --offline`.

## Slide 10: What I Delivered And What Comes Next (50 Seconds)

Content:
- Working local API, React workspace, models, retrieval, and feedback.
- Source code, documentation, measured reports, and sample data.
- Next: validate hosted AI and test on independent network data.
- Humans remain responsible for response decisions.

Visual: Implemented local capabilities separated from the deferred work.

Speaker notes:
The deliverable is an executable local microservice with a React analyst workspace, trained models, historical retrieval, explainability, defensive playbooks, and reviewed feedback. The submission includes source code, a real portable sample, named PDFs, API examples, and measured evaluation reports. The extracted ZIP was also tested separately. The next steps are to connect a valid provider, collect real generation and judge evidence, and run hosted DeepEval quality metrics. Independent time or host-based testing and realistic calibration are also needed before deployment. React is a deliberate choice that needs organizer acceptance because the guidelines specify Streamlit, and repository upload/access remain submission steps. My main learning is that useful AI assistance requires traceable evidence and honest uncertainty, not just confident text.

## Likely Panel Questions

| Question | Simple answer |
|---|---|
| What is a network flow? | A summary of a connection, such as its hosts, ports, packets, bytes, duration, and timing. |
| What makes this RAG? | The assistant retrieves actual historical flow records and uses their IDs and observations as evidence before forming an answer. |
| Why combine keyword and semantic search? | Exact terms and related descriptions provide different retrieval signals. |
| Which embedding model is active? | TF-IDF plus 96-dimensional LSA. MiniLM is optional and was not the measured default. |
| Does the LLM classify the attack? | No. The trained tabular model predicts the category; optional LLMs explain supplied evidence. |
| Why use separate intrusion and anomaly models? | Intrusion confidence and unusualness are different signals; neither is automatic confirmation. |
| Is a 90 risk score a 90% attack probability? | No. It is a weighted triage-policy score. |
| What does SHAP explain? | How features influenced the classifier's output, not the real-world cause of the attack. |
| Are the agents autonomous? | They are specialist workflow roles; they do not execute remediation. |
| How does feedback improve the project? | Reviewed corrections can train a separate candidate, which must be evaluated before manual promotion. |
| Why are the scores high? | The benchmark is discriminative, but random sampled splits and related sessions can overstate real-network performance. |
| Are the DeepEval checks live quality scores? | No. The nine offline checks are structural; hosted quality measurements remain deferred. |
| Can this run without a key? | Yes, for ML, retrieval, risk, explanations, feedback, and clearly labeled local recommendations. |
| Why React instead of Streamlit? | React was the participant's requested frontend; organizer acceptance remains pending. |

Delivery tips: Explain one idea at a time. Define RAG, SHAP, and Precision@5 when
first used. Read the actual demo output rather than memorizing a risk value.
Present benchmark results with their limits. Do not claim live Claude or judge
quality until those calls have genuinely succeeded.
