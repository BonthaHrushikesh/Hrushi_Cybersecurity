import json
from datetime import datetime, timezone
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.utils.config import settings
from src.services.artifact_reports import write_report


def probe(config=settings):
    result = {"provider": config.llm_provider, "key_present": config.credentials_configured,
              "generation_model": config.generation_model, "judge_model": config.evaluation_model}
    if not config.credentials_configured:
        return {**result, "status": "not_configured"}
    try:
        if config.llm_provider == "anthropic":
            from anthropic import Anthropic
            with Anthropic(timeout=config.llm_timeout_seconds, max_retries=0) as client:
                client.models.list(limit=1)
        else:
            from openai import OpenAI
            with OpenAI(timeout=config.llm_timeout_seconds, max_retries=0) as client:
                client.models.list()
        return {**result, "status": "authenticated",
                "limitation": "Authentication only; run verify_live_llm.py to verify generation and judging."}
    except Exception as error:
        # Provider exception messages and response bodies may contain sensitive data.
        return {**result, "status": "failed", "error_type": type(error).__name__,
                "http_status": getattr(error, "status_code", None)}


def save_probe(config=settings):
    report = {**probe(config), "created_at": datetime.now(timezone.utc).isoformat(), "credential_fingerprint": config.credential_fingerprint}
    path = config.artifacts / "evaluation/provider_connection.json"
    write_report(path, report)
    return report


if __name__ == "__main__":
    report = save_probe()
    print(json.dumps({key: value for key, value in report.items() if key != "credential_fingerprint"}, indent=2))
    sys.exit(0 if report["status"] == "authenticated" else 2)
