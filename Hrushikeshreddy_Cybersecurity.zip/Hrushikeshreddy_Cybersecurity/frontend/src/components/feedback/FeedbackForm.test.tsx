import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { feedbackApi } from '../../api'
import { FeedbackForm } from './FeedbackForm'

vi.mock('../../api', () => ({ feedbackApi: { submit: vi.fn() } }))
afterEach(() => { cleanup(); vi.clearAllMocks() })

describe('feedback belongs to the selected incident', () => {
  it('clears success and draft corrections when another incident is selected', async () => {
    vi.mocked(feedbackApi.submit).mockResolvedValue({ feedback_id: 1, incident_id: 'INV-first', status: 'pending_review' })
    const client = new QueryClient()
    const component = (id: string) => <QueryClientProvider client={client}><FeedbackForm incidentId={id} /></QueryClientProvider>
    const view = render(component('INV-first'))
    fireEvent.click(screen.getByRole('button', { name: 'Needs correction' }))
    fireEvent.change(screen.getByLabelText('Correct attack type'), { target: { value: 'DoS' } })
    fireEvent.change(screen.getByLabelText('Correct severity'), { target: { value: 'HIGH' } })
    fireEvent.change(screen.getByLabelText('Analyst note'), { target: { value: 'First incident only' } })
    fireEvent.click(screen.getByRole('button', { name: 'Submit feedback' }))
    await screen.findByText('Feedback recorded for analyst review. Thank you.')

    view.rerender(component('INV-second'))
    expect(screen.queryByText('Feedback recorded for analyst review. Thank you.')).toBeNull()
    expect(screen.getByRole('button', { name: 'Submit feedback' })).toBeDisabled()
    expect(screen.getByLabelText('Correct attack type')).toHaveValue('')
    expect(screen.getByLabelText('Correct severity')).toHaveValue('')
    expect(screen.getByLabelText('Analyst note')).toHaveValue('')
    fireEvent.click(screen.getByRole('button', { name: 'Useful' }))
    fireEvent.click(screen.getByRole('button', { name: 'Submit feedback' }))
    await screen.findByText('Feedback recorded for analyst review. Thank you.')
    expect(vi.mocked(feedbackApi.submit).mock.calls[1][0]).toEqual({
      incident_id: 'INV-second', helpful: true, comment: '', corrected_attack_type: null, corrected_severity: null,
    })
  })
})
