import numpy as np
import pytest

from src.services.retrieval import combine_scores


def test_hybrid_scores_respect_alpha_and_zero_keyword_case():
    semantic, keyword = np.array([0.2, 0.9]), np.array([10., 5.])
    score, normalized = combine_scores(semantic, keyword, 0.6)
    assert score == pytest.approx([0.52, 0.74])
    assert normalized == pytest.approx([1, 0.5])
    assert combine_scores(semantic, keyword, 1)[0] == pytest.approx(semantic)
    assert combine_scores(semantic, np.zeros(2), 0.6)[0] == pytest.approx(semantic * 0.6)


def test_combined_filters_and_missing_metadata(client):
    response = client.post("/api/v1/search", json={"query": "DDoS traffic flooding", "filters": {"attack_type": "DDoS", "destination_port": 80, "min_risk_score": 80}, "top_k": 5})
    assert response.status_code == 200
    hits = response.json()["results"]
    assert hits
    assert all(x["attack_type"] == "DDoS" and x["metadata"]["destination_port"] == 80 for x in hits)
    assert all(0 <= x["similarity_score"] <= 1 for x in hits)
    tcp = client.post("/api/v1/search", json={"query": "DDoS", "filters": {"protocol": "TCP"}}).json()["results"]
    assert all(hit["metadata"]["protocol"] == "TCP" for hit in tcp)


def test_missing_metadata_does_not_match_supplied_filter(client):
    incident = client.app.state.services.retrieval.incidents[0]
    original = incident.metadata.copy()
    try:
        incident.metadata.update(flow_id="metadata-missing-unit-fixture", protocol=None)
        response = client.post("/api/v1/search", json={"query": "network flow", "filters": {
            "flow_id": "metadata-missing-unit-fixture", "protocol": "TCP"}})
        assert response.status_code == 200
        assert response.json()["results"] == []
    finally:
        incident.metadata = original


def test_timestamp_filters_compare_datetimes_and_accept_fractional_seconds(client):
    incident = client.app.state.services.retrieval.incidents[0]
    original = incident.metadata.copy()
    try:
        incident.metadata.update(source_ip="192.0.2.123", timestamp="2026-10-07T12:00:00.500000Z", protocol="TCP", source_port=49152)
        filters = {"source_ip": "192.0.2.123", "protocol": "TCP", "source_port": 49152,
                   "timestamp_min": "2026-10-07T12:00:00Z", "timestamp_max": "2026-10-07T12:00:00.600000Z"}
        results = client.post("/api/v1/search", json={"query": "network flow", "filters": filters}).json()["results"]
        assert [x["incident_id"] for x in results] == [incident.incident_id]
        filters["timestamp_min"] = "2026-10-07T12:00:00.600000Z"
        assert client.post("/api/v1/search", json={"query": "network flow", "filters": filters}).json()["results"] == []
        exact = {"source_ip": "192.0.2.123", "timestamp": "2026-10-07T14:00:00.5+02:00"}
        assert client.post("/api/v1/search", json={"query": "network flow", "filters": exact}).json()["results"]
    finally:
        incident.metadata = original
