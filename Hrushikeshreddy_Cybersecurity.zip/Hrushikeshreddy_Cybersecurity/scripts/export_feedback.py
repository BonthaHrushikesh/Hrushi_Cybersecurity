import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pandas as pd

from src.utils.config import settings
from src.services.repository import Repository


def main():
    parser = argparse.ArgumentParser(description="Review feedback or export approved corrections for a future candidate training run.")
    parser.add_argument("--approve", type=int)
    parser.add_argument("--reject", type=int)
    parser.add_argument("--output", type=Path, default=settings.processed / "reviewed_feedback.csv")
    args = parser.parse_args()
    repository = Repository(settings.artifacts / "incidents.sqlite")
    if args.approve is not None:
        repository.review_feedback(args.approve, "approved")
    if args.reject is not None:
        repository.review_feedback(args.reject, "rejected")
    rows = []
    for item in repository.reviewed_rows():
        request = json.loads(item["request_json"])
        rows.append({**request["flow"]["features"], "attack_category": item["corrected_attack_type"],
                     "original_label": item["corrected_attack_type"], "incident_id": item["incident_id"],
                     "feedback_id": item["id"], "reviewed_at": item["created_at"]})
    if rows:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(rows).drop_duplicates("incident_id", keep="last").to_csv(args.output, index=False)
    print(json.dumps({"approved_corrected_rows": len(rows), "output": str(args.output) if rows else None,
                      "next_step": "Train a candidate in a separate ARTIFACT_DIR and evaluate before manually promoting artifacts."}, indent=2))


if __name__ == "__main__":
    main()
