import { ChevronLeft, ChevronRight, Eye, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import type { HistoricalFlowSummary, IncidentSummary } from "../../types";
import { AttackBadge, EmptyState, SeverityBadge } from "../ui";
import { formatDate } from "../../utils/format";

type TableRecord = IncidentSummary | HistoricalFlowSummary;
interface ServerPagination {
  page: number;
  total: number;
  query: string;
  sort: "risk" | "time";
  pending: boolean;
  onPageChange: (page: number) => void;
  onQueryChange: (query: string) => void;
  onSortChange: (sort: "risk" | "time") => void;
}
const recordTime = (record: TableRecord) => "created_at" in record ? record.created_at : record.timestamp;

export function IncidentTable({
  incidents,
  pageSize = 8,
  showSearch = true,
  onSelect,
  kind = "investigation",
  serverPagination,
}: {
  incidents: TableRecord[];
  pageSize?: number;
  showSearch?: boolean;
  onSelect?: (id: string) => void;
  kind?: "investigation" | "historical";
  serverPagination?: ServerPagination;
}) {
  const navigate = useNavigate();
  const open = (id: string) => {
    if (onSelect) onSelect(id);
    else navigate(`/incidents/${encodeURIComponent(id)}`);
  };
  const [localQuery, setQuery] = useState(""),
    [page, setPage] = useState(0),
    [localSort, setSort] = useState<"risk" | "time">("time");
  const query = serverPagination?.query ?? localQuery;
  const sort = serverPagination?.sort ?? localSort;
  const remote = serverPagination !== undefined;
  const rows = useMemo(
    () =>
      remote ? incidents : incidents
        .filter((x) =>
          `${x.incident_id} ${x.attack_type} ${"priority" in x ? x.priority : x.severity}`
            .toLowerCase()
            .includes(query.toLowerCase()),
        )
        .sort((a, b) =>
          sort === "risk"
            ? b.risk_score - a.risk_score
            : (Date.parse(recordTime(b) || "") || 0) - (Date.parse(recordTime(a) || "") || 0),
        ),
    [incidents, query, sort, remote],
  );
  const total = serverPagination?.total ?? rows.length;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const currentPage = Math.min(serverPagination?.page ?? page, pages - 1);
  const visible = remote ? rows : rows.slice(currentPage * pageSize, (currentPage + 1) * pageSize);
  const changePage = serverPagination?.onPageChange ?? setPage;
  return (
    <div>
      {showSearch && (
        <div className="mb-4 flex flex-col gap-2 sm:flex-row">
          <label className="relative flex-1">
            <span className="sr-only">Search incidents</span>
            <Search size={15} className="absolute left-3 top-3 text-zinc-600" />
            <input
              className="field pl-9"
              placeholder="Filter incidents..."
              value={query}
              maxLength={remote ? 200 : undefined}
              onChange={(e) => {
                if (serverPagination) serverPagination.onQueryChange(e.target.value);
                else { setQuery(e.target.value); setPage(0); }
              }}
            />
          </label>
          <select
            className="field sm:w-40"
            value={sort}
            onChange={(e) => {
              const value = e.target.value as "risk" | "time";
              if (serverPagination) serverPagination.onSortChange(value);
              else { setSort(value); setPage(0); }
            }}
            aria-label="Sort incidents"
          >
            <option value="time">Newest first</option>
            <option value="risk">{kind === "historical" ? "Highest label prior" : "Highest risk"}</option>
          </select>
        </div>
      )}
      {visible.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Incident ID</th>
                <th>{kind === "historical" ? "Capture time" : "Timestamp"}</th>
                <th>Attack</th>
                <th>{kind === "historical" ? "Label prior" : "Risk"}</th>
                <th>{kind === "historical" ? "Severity" : "Priority"}</th>
                <th>Status</th>
                <th className="relative">
                  <span className="sr-only">Action</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {visible.map((row) => (
                <tr
                  key={row.incident_id}
                  className="cursor-pointer"
                  onClick={() => open(row.incident_id)}
                >
                  <td className="mono text-xs text-zinc-200">
                    {row.incident_id}
                  </td>
                  <td className="mono text-xs">
                    {formatDate(recordTime(row))}
                  </td>
                  <td>
                    <AttackBadge attack={row.attack_type} />
                  </td>
                  <td className="font-semibold tabular-nums">
                    {row.risk_score.toFixed(1)}
                  </td>
                  <td>
                    <SeverityBadge
                      severity={
                        "severity" in row ? row.severity : row.risk_score >= 80
                          ? "CRITICAL"
                          : row.risk_score >= 60
                            ? "HIGH"
                            : row.risk_score >= 30
                              ? "MEDIUM"
                              : "LOW"
                      }
                      priority={"priority" in row ? row.priority : undefined}
                    />
                  </td>
                  <td>
                    <span className="text-xs text-zinc-400">
                      {kind === "historical" ? "Historical label" : "Analysis recorded"}
                    </span>
                  </td>
                  <td>
                    <button
                      className="icon-btn h-8 w-8"
                      aria-label={`View ${row.incident_id}`}
                    >
                      <Eye size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <div className="mt-4 flex items-center justify-between text-xs text-zinc-500">
        <span>{total} records</span>
        <div className="flex items-center gap-2">
          <button
            className="icon-btn h-8 w-8"
            disabled={currentPage === 0 || serverPagination?.pending}
            onClick={() => changePage(currentPage - 1)}
            aria-label="Previous page"
          >
            <ChevronLeft size={14} />
          </button>
          <span>
            {currentPage + 1} / {pages}
          </span>
          <button
            className="icon-btn h-8 w-8"
            disabled={currentPage + 1 >= pages || serverPagination?.pending}
            onClick={() => changePage(currentPage + 1)}
            aria-label="Next page"
          >
            <ChevronRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
