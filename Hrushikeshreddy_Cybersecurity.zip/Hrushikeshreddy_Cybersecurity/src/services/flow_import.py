import csv
import math
from io import StringIO

from src.utils.features import EXTRA_FEATURES, FEATURE_NAMES, METADATA, TARGETS, normalize_column
from src.api.schemas import FlowInput


def parse_flow_csv(text: str) -> FlowInput:
    reader = csv.reader(StringIO(text.lstrip("\ufeff")), strict=True)
    try:
        header = next(reader)
        values = next(reader)
    except (StopIteration, csv.Error) as error:
        raise ValueError("CSV must contain a valid header and a data row") from error
    names = [normalize_column(name) for name in header]
    if len(names) != len(values):
        raise ValueError("CSV row does not match its header")
    if names.count("fwd_header_length") == 2:
        first, second = [index for index, name in enumerate(names) if name == "fwd_header_length"]
        try:
            agrees = values[first].strip() == values[second].strip() or float(values[first]) == float(values[second])
        except ValueError:
            agrees = False
        if not agrees:
            raise ValueError("Repeated Fwd Header Length columns disagree")
        names.pop(second)
        values.pop(second)
    if len(set(names)) != len(names):
        raise ValueError("CSV contains duplicate column names or aliases")
    features, metadata = {}, {}
    for name, raw in zip(names, values):
        value = raw.strip()
        if name in TARGETS or not value:
            continue
        if name in FEATURE_NAMES + EXTRA_FEATURES:
            try:
                features[name] = float(value)
            except ValueError:
                raise ValueError(f"Traffic feature {name} must be numeric") from None
        elif name in METADATA:
            if name == "source_port":
                try:
                    port = float(value)
                    if not math.isfinite(port) or not port.is_integer():
                        raise ValueError
                    metadata[name] = int(port)
                except ValueError:
                    raise ValueError("Source port must be an integer") from None
            elif name == "protocol":
                metadata[name] = {"6": "TCP", "6.0": "TCP", "17": "UDP", "17.0": "UDP", "1": "ICMP", "1.0": "ICMP"}.get(value, value.upper())
            else:
                metadata[name] = value
        elif name not in {"incident_id"}:
            raise ValueError("Unsupported CSV column")
    return FlowInput(features=features, metadata=metadata)
