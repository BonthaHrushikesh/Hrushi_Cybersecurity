#!/usr/bin/env python3
"""Validate slide order, figures, PowerPoint package, PDF export and timing."""

from __future__ import annotations

import json
import posixpath
import re
import shutil
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from html import escape

from PIL import Image, ImageDraw
from pypdf import PdfReader
import pymupdf

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "final_presentation"
sys.path.insert(0, str(ROOT / "scripts"))
import build_final_presentation as deck

PPTX = OUT / "AI_Cybersecurity_Incident_Response_Final_Presentation.pptx"
PDF = OUT / "AI_Cybersecurity_Incident_Response_Final_Presentation.pdf"
NOTES = OUT / "Presentation_Speaker_Notes.md"
REPORT = ROOT / "docs/evaluation_report.md"

SECTIONS = [
    "10. Problem Statement", "11. Business Need", "12. Solution Overview",
    "13. Architecture", "14. Data Flow", "15. Technology Stack",
    "16. Agent Workflow", "17. Demo", "18. Evaluation Results",
    "19. Challenges and Learnings",
]


def fail_if(conditions: list[str], message: str) -> None:
    if conditions:
        raise ValueError(message + ":\n- " + "\n- ".join(conditions))


def pptx_checks() -> tuple[int, list[int]]:
    problems: list[str] = []
    counts: list[int] = []
    with zipfile.ZipFile(PPTX) as zf:
        if zf.testzip():
            problems.append("PowerPoint ZIP member failed CRC verification")
        names = set(zf.namelist())
        slide_paths = sorted((p for p in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", p)),
                             key=lambda p: int(re.search(r"slide(\d+)", p).group(1)))
        if len(slide_paths) != 12:
            problems.append(f"PowerPoint has {len(slide_paths)} slide parts")
        for name in names:
            if name.endswith((".xml", ".rels")):
                try:
                    ET.fromstring(zf.read(name))
                except ET.ParseError as exc:
                    problems.append(f"Malformed XML part {name}: {exc}")
        for rel_path in (p for p in names if p.endswith(".rels")):
            rel_root = ET.fromstring(zf.read(rel_path))
            if rel_path == "_rels/.rels":
                source = ""
            else:
                source = rel_path.replace("/_rels/", "/")[:-5]
            for rel in rel_root:
                target = rel.attrib.get("Target", "")
                if "://" in target:
                    continue
                resolved = posixpath.normpath(posixpath.join(posixpath.dirname(source), target))
                if resolved not in names:
                    problems.append(f"Unresolved relationship from {rel_path} to {resolved}")
        slide_sections: list[str] = []
        ns = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
        for i, path in enumerate(slide_paths, 1):
            root = ET.fromstring(zf.read(path))
            editable = list(root.iter("{http://schemas.openxmlformats.org/presentationml/2006/main}sp"))
            pictures = list(root.iter("{http://schemas.openxmlformats.org/presentationml/2006/main}pic"))
            counts.append(len(editable))
            if not editable:
                problems.append(f"Slide {i} has no editable shapes")
            text = " ".join(node.text or "" for node in root.findall(".//a:t", ns))
            if i == 1 and "AI-Powered Cybersecurity" not in text:
                problems.append("Title slide is missing the project title")
            elif i == 12 and "Thank you." not in text:
                problems.append("Final slide is missing its thank-you message")
            elif 2 <= i <= 11:
                found = next((section for section in SECTIONS if section in text), None)
                slide_sections.append(found or "")
            if i == 9 and not pictures:
                problems.append("Slide 9 has no embedded project screenshot")
        if slide_sections != SECTIONS:
            problems.append(f"PowerPoint sections out of order or missing: {slide_sections}")
        if "ppt/media/investigation-result-desktop.png" not in names:
            problems.append("Embedded project screenshot is absent")
    fail_if(problems, "PowerPoint validation failed")
    return len(slide_paths), counts


def pdf_checks() -> tuple[int, int]:
    problems: list[str] = []
    reader = PdfReader(str(PDF))
    text_pages = [page.extract_text() or "" for page in reader.pages]
    if len(text_pages) != 12:
        problems.append(f"PDF has {len(text_pages)} pages")
    if text_pages and "AI-Powered Cybersecurity" not in text_pages[0]:
        problems.append("PDF page 1 is missing the project title")
    if len(text_pages) >= 12 and "Thank you." not in text_pages[11]:
        problems.append("PDF page 12 is missing its thank-you message")
    for i, (section, text) in enumerate(zip(SECTIONS, text_pages[1:11]), 2):
        if section not in text:
            problems.append(f"PDF page {i} does not show {section}")
    full_text = "\n".join(text_pages)
    required_results = ["99.21%", "0.9743", "0.9961", "0.7628", "62.86%", "95.24%", "36 / 45", "5 misses", "203 + 27"]
    for token in required_results:
        if token not in full_text:
            problems.append(f"PDF text is missing reported value {token}")
    if PDF.stat().st_size < 100_000:
        problems.append("Rendered PDF is unexpectedly small")

    doc = pymupdf.open(PDF)
    for page_num, page in enumerate(doc, 1):
        if abs(page.rect.width - 960) > 1 or abs(page.rect.height - 540) > 1:
            problems.append(f"PDF page {page_num} is not widescreen 16:9")
    # Render every page to a compact page contact sheet for a quick visual review.
    tile_w, tile_h = 660, 390
    columns = 2
    rows = (len(doc) + columns - 1) // columns
    sheet = Image.new("RGB", (tile_w * columns, tile_h * rows), "#25282a")
    for index, page in enumerate(doc):
        pix = page.get_pixmap(matrix=pymupdf.Matrix(0.52, 0.52), alpha=False)
        preview = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        preview.thumbnail((640, 360))
        tile = Image.new("RGB", (tile_w, tile_h), "#25282a")
        tile.paste(preview, ((tile_w - preview.width) // 2, 7))
        ImageDraw.Draw(tile).text((15, 370), f"Slide {index + 1}", fill="white")
        sheet.paste(tile, ((index % 2) * tile_w, (index // 2) * tile_h))
    sheet.save(OUT / "Presentation_Contact_Sheet.png", optimize=True)
    fail_if(problems, "PDF validation failed")
    return len(text_pages), len(full_text)


def spoken_words() -> tuple[int, list[tuple[int, int, int]]]:
    notes = NOTES.read_text(encoding="utf-8")
    sections = re.split(r"(?=^## (?:Opening Title Slide|Slide \d+ — ))", notes, flags=re.M)[1:]
    detail = []
    for sec in sections:
        heading = sec.splitlines()[0]
        opening = re.match(r"## Opening Title Slide \((\d+):(\d+)–(\d+):(\d+)\)", heading)
        slide = re.match(r"## Slide (\d+) — .*?\((\d+):(\d+)–(\d+):(\d+)\)", heading)
        match = opening or slide
        if not match:
            raise ValueError(f"Invalid timed speaker note heading: {heading}")
        n = 1 if opening else int(match.group(1))
        start = int(match.group(1 if opening else 2)) * 60 + int(match.group(2 if opening else 3))
        end = int(match.group(3 if opening else 4)) * 60 + int(match.group(4 if opening else 5))
        seconds = end - start
        body = sec.split("\n", 1)[1].split("\n## ", 1)[0]
        if n == 9:
            if "### Two-minute live sequence" in body:
                body = body.split("### Two-minute live sequence", 1)[1].split("**Transition:**", 1)[0]
            else:
                raise ValueError("Speaker notes do not contain the timed demo")
        else:
            body = body.split("**Transition:**", 1)[0]
            body = re.sub(r"^Planned time:.*$", "", body, flags=re.M)
            body = re.sub(r"^Presentation window:.*$", "", body, flags=re.M)
        count = len(re.findall(r"\b[\w’'-]+\b", body))
        wpm = round(count * 60 / seconds) if seconds else 0
        detail.append((n, count, wpm))
    if [n for n, _, _ in detail] != list(range(1, 13)):
        raise ValueError(f"Speaker notes must contain twelve timed sections, found: {detail}")
    if sum(slide.duration for slide in deck.make_slides()) != 600:
        raise ValueError("Required content slides do not total ten minutes")
    fast = [(n, wpm) for n, _, wpm in detail if wpm > 155]
    fail_if([f"slide {n}: {wpm} spoken words/minute" for n, wpm in fast], "Speaking pace needs shortening")
    return sum(count for _, count, _ in detail), detail


def sync_presentation_files() -> None:
    """Keep the submission-facing presentation and open notes tabs in sync."""
    target = ROOT / "presentation"
    assets = target / "assets"
    assets.mkdir(parents=True, exist_ok=True)
    copies = {
        OUT / "AI_Cybersecurity_Incident_Response_Final_Presentation.pptx": target / "Project_Presentation.pptx",
        OUT / "AI_Cybersecurity_Incident_Response_Final_Presentation.pdf": target / "Project_Presentation.pdf",
        OUT / "Presentation_Preview.html": target / "Project_Presentation.html",
        NOTES: target / "Speaker_Notes.md",
        OUT / "Presentation_Contact_Sheet.png": target / "Presentation_Contact_Sheet.png",
    }
    for source, destination in copies.items():
        shutil.copyfile(source, destination)
    shutil.copyfile(OUT / "assets/investigation-result-desktop.png", assets / "investigation-result-desktop.png")

    try:
        from markdown_it import MarkdownIt
        content = MarkdownIt("commonmark", {"html": False, "linkify": True, "typographer": True}).render(NOTES.read_text(encoding="utf-8"))
    except ImportError:
        content = "<pre>" + escape(NOTES.read_text(encoding="utf-8")) + "</pre>"
    html_page = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Presentation Speaker Notes</title><style>
*{{box-sizing:border-box}}body{{margin:0;background:#101214;color:#dedbd2;font:16px/1.65 Arial,sans-serif}}main{{max-width:920px;margin:42px auto;padding:42px 54px;background:#191c1f;border:1px solid #34393d;border-radius:12px}}h1,h2,h3{{color:#f5f2e9;line-height:1.25}}h1{{font-size:32px}}h2{{margin-top:2.3em;padding-bottom:.4em;border-bottom:1px solid #46494b;color:#f1d88a}}h3{{color:#d7b45a}}a{{color:#f1d88a}}code{{padding:.12em .35em;background:#292d30;border-radius:4px}}li{{margin:.25em 0}}@media print{{body{{background:#fff;color:#222;font-size:11pt}}main{{max-width:none;margin:0;padding:0;background:#fff;border:0;color:#222}}h1,h2,h3{{color:#111}}h2{{break-before:page;border-color:#aaa}}a{{color:#111}}}}
</style></head><body><main>{content}</main></body></html>'''
    (target / "Speaker_Notes.html").write_text(html_page, encoding="utf-8")


def main() -> None:
    for path in (PPTX, PDF, NOTES, OUT / "Demo_Walkthrough.md", REPORT):
        if not path.exists():
            raise FileNotFoundError(path)
    report = REPORT.read_text(encoding="utf-8")
    source_values = ["0.9921085", "0.9743258", "0.9961082", "0.7627583", "0.6285714", "0.9523810", "36 completed scores out of 45"]
    missing = [value for value in source_values if value not in report]
    fail_if(missing, "Evaluation report is missing source values")

    pptx_count, counts = pptx_checks()
    pdf_count, _ = pdf_checks()
    words, per_slide = spoken_words()
    if pptx_count != pdf_count:
        raise ValueError(f"PPTX/PDF slide count mismatch: {pptx_count} vs {pdf_count}")
    source = deck.make_deck()
    out_of_bounds = deck.inch_bound_violations(source)
    fail_if(out_of_bounds, "Slide elements extend outside the canvas")
    (OUT / "Presentation_Validation.md").write_text(
        deck.validation_markdown(pdf_count, pptx_count, counts, words), encoding="utf-8"
    )
    sync_presentation_files()
    print(json.dumps({"slides": pptx_count, "pdf_pages": pdf_count, "spoken_words": words,
                      "spoken_words_per_slide": per_slide, "editable_shapes_per_slide": counts,
                      "out_of_bounds": 0, "source_figures_verified": source_values,
                      "contact_sheet": str(OUT / "Presentation_Contact_Sheet.png")}, indent=2))


if __name__ == "__main__":
    main()
