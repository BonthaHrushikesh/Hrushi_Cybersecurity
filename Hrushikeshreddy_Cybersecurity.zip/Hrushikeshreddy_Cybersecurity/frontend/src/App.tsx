import { lazy, Suspense, type ReactNode } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import { AppShell } from './components/layout/AppShell'
import { LoadingSkeleton } from './components/ui'

const DashboardPage=lazy(()=>import('./pages/DashboardPage').then(module=>({default:module.DashboardPage})))
const InvestigatePage=lazy(()=>import('./pages/InvestigatePage').then(module=>({default:module.InvestigatePage})))
const IncidentsPage=lazy(()=>import('./pages/IncidentsPage').then(module=>({default:module.IncidentsPage})))
const IncidentDetailPage=lazy(()=>import('./pages/IncidentDetailPage').then(module=>({default:module.IncidentDetailPage})))
const SearchPage=lazy(()=>import('./pages/SearchPage').then(module=>({default:module.SearchPage})))
const AssistantPage=lazy(()=>import('./pages/AssistantPage').then(module=>({default:module.AssistantPage})))
const ExplainabilityPage=lazy(()=>import('./pages/ExplainabilityPage').then(module=>({default:module.ExplainabilityPage})))
const AnalyticsPage=lazy(()=>import('./pages/AnalyticsPage').then(module=>({default:module.AnalyticsPage})))
const FeedbackPage=lazy(()=>import('./pages/FeedbackPage').then(module=>({default:module.FeedbackPage})))
const SettingsPage=lazy(()=>import('./pages/SettingsPage').then(module=>({default:module.SettingsPage})))
const ModelsPage=lazy(()=>import('./pages/ModelsPage').then(module=>({default:module.ModelsPage})))
const AgentWorkflowPage=lazy(()=>import('./pages/AgentWorkflowPage').then(module=>({default:module.AgentWorkflowPage})))
const EvaluationPage=lazy(()=>import('./pages/EvaluationPage').then(module=>({default:module.EvaluationPage})))

const load=(page:ReactNode)=><Suspense fallback={<LoadingSkeleton rows={6}/>}>{page}</Suspense>
export default function App(){return <Routes><Route element={<AppShell/>}><Route index element={<Navigate to="/dashboard" replace/>}/><Route path="dashboard" element={load(<DashboardPage/>)}/><Route path="investigate" element={load(<InvestigatePage/>)}/><Route path="incidents" element={load(<IncidentsPage/>)}/><Route path="incidents/:id" element={load(<IncidentDetailPage/>)}/><Route path="rag-search" element={load(<SearchPage/>)}/><Route path="ai-analyst" element={load(<AssistantPage/>)}/><Route path="traffic-analytics" element={load(<AnalyticsPage/>)}/><Route path="models" element={load(<ModelsPage/>)}/><Route path="agent-workflow" element={load(<AgentWorkflowPage/>)}/><Route path="evaluation" element={load(<EvaluationPage/>)}/><Route path="explainability" element={load(<ExplainabilityPage/>)}/><Route path="feedback" element={load(<FeedbackPage/>)}/><Route path="settings" element={load(<SettingsPage/>)}/><Route path="search" element={<Navigate to="/rag-search" replace/>}/><Route path="assistant" element={<Navigate to="/ai-analyst" replace/>}/><Route path="analytics" element={<Navigate to="/traffic-analytics" replace/>}/><Route path="*" element={<Navigate to="/dashboard" replace/>}/></Route></Routes>}
