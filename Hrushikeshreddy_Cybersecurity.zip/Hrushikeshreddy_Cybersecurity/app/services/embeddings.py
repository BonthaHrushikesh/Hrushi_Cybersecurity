"""Load legacy joblib embedding indexes without replacing the trained artifacts."""

from src.services.embeddings import EmbeddingService

__all__ = ["EmbeddingService"]
