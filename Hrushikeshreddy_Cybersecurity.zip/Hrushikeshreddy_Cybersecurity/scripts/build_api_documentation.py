"""Capture actual local API examples in an isolated DB, never calling a provider."""

from dataclasses import replace
import json
from pathlib import Path
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi.testclient import TestClient

from src.utils.config import ROOT, settings
from src.api.application import create_app


def abridge(value, depth=0):
    if depth >= 3 and isinstance(value, (dict, list)):
        return "[abridged; see full JSON example]"
    if isinstance(value, dict):
        items = list(value.items())
        result = {key: abridge(item, depth + 1) for key, item in items[:12]}
        if len(items) > 12:
            result["_omitted_fields"] = len(items) - 12
        return result
    if isinstance(value, list):
        result = [abridge(item, depth + 1) for item in value[:2]]
        if len(value) > 2:
            result.append(f"[{len(value) - 2} more items; see full JSON example]")
        return result
    if isinstance(value, str) and len(value) > 220:
        return value[:220] + " [abridged]"
    return value


def build():
    with tempfile.TemporaryDirectory(prefix="capstone-api-") as temporary:
        directory = Path(temporary)
        for name in ["models", "index", "evaluation"]:
            (directory / name).symlink_to(settings.artifacts / name, target_is_directory=True)
        config = replace(settings, artifacts=directory, llm_provider="local")
        with TestClient(create_app(config)) as client:
            samples = client.get("/api/v1/samples").json()
            sample = next(item for item in samples if item["attack_type"] == "DDoS")
            names = ["destination_port", "flow_duration", "flow_packets_s", "flow_bytes_s"]
            flow = {"features": {name: sample["features"][name] for name in names}}
            investigation_request = {"flow": flow, "query": "Investigate observed service traffic", "use_llm": False, "judge": False}
            examples = []

            def capture(method, path, payload=None, schema_path=None):
                response = client.request(method, path, json=payload)
                if not response.is_success:
                    raise RuntimeError(f"API example failed: {method} {path} HTTP {response.status_code}")
                data = response.json() if "application/json" in response.headers.get("content-type", "") else response.text
                examples.append({"method": method, "endpoint": schema_path or path.split("?")[0],
                                 "sample_path": path, "request": payload, "status": response.status_code,
                                 "content_type": response.headers.get("content-type"), "response": data})
                return data

            for path in ["/health", "/ready", "/api/v1/system/status", "/api/v1/model/info", "/api/v1/samples"]:
                capture("GET", path)
            csv = "Destination Port,Flow Duration,Flow Packets/s,Flow Bytes/s\n" + ",".join(str(flow["features"][name]) for name in names) + "\n"
            capture("POST", "/api/v1/flows/parse", {"csv_text": csv})
            for path in ["classify", "anomaly", "risk", "explain"]:
                capture("POST", "/api/v1/" + path, flow)
            search = {"query": "Historical SSH brute force traffic", "top_k": 5, "mode": "hybrid", "fusion": "rrf", "filters": {"attack_type": "Brute Force"}}
            capture("POST", "/api/v1/search", search)
            capture("POST", "/api/v1/rag/answer", {**search, "use_llm": False})
            investigation = capture("POST", "/api/v1/investigate", investigation_request)
            capture("POST", "/api/v1/recommend", investigation_request)
            incident_id = investigation["incident_id"]
            capture("POST", "/api/v1/feedback", {"incident_id": incident_id, "helpful": True, "comment": "Local documentation example; pending review."})
            capture("GET", "/api/v1/feedback")
            capture("GET", "/api/v1/incidents?limit=20")
            capture("GET", "/api/v1/incidents/" + incident_id, schema_path="/api/v1/incidents/{incident_id}")
            capture("GET", "/api/v1/incidents/" + incident_id + "/report", schema_path="/api/v1/incidents/{incident_id}/report")
            capture("GET", "/api/v1/metrics")
            capture("GET", "/api/v1/explain/global")
            specification = client.get("/openapi.json").json()
            expected = {(method.upper(), path) for path, methods in specification["paths"].items() for method in methods if method in {"get", "post"}}
            observed = {(row["method"], row["endpoint"]) for row in examples}
            if expected != observed:
                raise RuntimeError(f"API documentation coverage mismatch: {expected - observed}")
    destination = ROOT / "docs/examples"
    destination.mkdir(parents=True, exist_ok=True)
    (destination / "openapi.json").write_text(json.dumps(specification, indent=2, allow_nan=False), encoding="utf-8")
    (destination / "api_examples.json").write_text(json.dumps(examples, indent=2, allow_nan=False), encoding="utf-8")
    sections = ["# Measured Endpoint Examples", "These examples were captured from the actual local API using an isolated temporary database and local-only providers. Requests use four observed fields from a real DDoS sample, so missing-feature warnings are expected. Responses below are explicitly abridged, not complete schemas. Complete unabridged measured examples are in docs/examples/api_examples.json; request/response types, optional fields, and validation constraints are in docs/examples/openapi.json and /docs. No live judge scores were generated."]
    for row in examples:
        operation = specification["paths"][row["endpoint"]][row["method"].lower()]
        request = operation.get("requestBody", {}).get("content", {}).get("application/json", {}).get("schema", {})
        response_schema = operation["responses"].get(str(row["status"]), {}).get("content", {})
        sections.extend([f'## {row["method"]} {row["endpoint"]}',
                         f'Request format: {json.dumps(request) if request else "No body; path/query parameters as shown."}',
                         f'Response format: HTTP {row["status"]}, {row["content_type"]}. Schema: {json.dumps(response_schema)}',
                         f'Sample request: {row["method"]} {row["sample_path"]}',
                         "```json\n" + json.dumps(row["request"], indent=2) + "\n```" if row["request"] is not None else "No request body.",
                         "Sample response (abridged):", "```json\n" + json.dumps(abridge(row["response"]), indent=2) + "\n```"])
    (ROOT / "docs/API_Examples.md").write_text("\n\n".join(sections) + "\n", encoding="utf-8")
    print(json.dumps({"documented_operations": len(examples), "external_calls": 0}))


if __name__ == "__main__":
    build()
