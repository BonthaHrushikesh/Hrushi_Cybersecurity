import { motion } from 'framer-motion'
import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import type { RiskAssessment, Severity, SHAPFeature } from '../../types'
import { severityColor } from '../../constants'

const tooltipStyle = { background:'#111', border:'1px solid rgba(212,175,55,.25)', borderRadius:8, color:'#f5f5f5', fontSize:12 }
const palette = ['#D4AF37','#F4D675','#9C7C26','#EF4444','#F97316','#3B82F6','#22C55E']

export function AttackDistributionChart({ data }: {data:Record<string,number>}) {
  const rows=Object.entries(data).map(([name,value])=>({name,value}))
  return <div className="h-64"><ResponsiveContainer><BarChart data={rows} layout="vertical" margin={{left:12,right:12}}><CartesianGrid stroke="#222" horizontal={false}/><XAxis type="number" stroke="#71717a" fontSize={11}/><YAxis type="category" dataKey="name" width={82} stroke="#a1a1aa" fontSize={11}/><Tooltip contentStyle={tooltipStyle}/><Bar dataKey="value" radius={[0,3,3,0]}>{rows.map((_,i)=><Cell fill={palette[i%palette.length]} key={i}/>)}</Bar></BarChart></ResponsiveContainer></div>
}
export function PriorityChart({ data }: {data:Record<string,number>}) {
  const map:Record<string,Severity>={P1:'CRITICAL',P2:'HIGH',P3:'MEDIUM',P4:'LOW',CRITICAL:'CRITICAL',HIGH:'HIGH',MEDIUM:'MEDIUM',LOW:'LOW'}
  const rows=Object.entries(data).map(([name,value])=>({name,value,severity:map[name]||'LOW'}))
  return <div className="h-64"><ResponsiveContainer><PieChart><Pie data={rows} dataKey="value" nameKey="name" innerRadius={58} outerRadius={87} paddingAngle={3}>{rows.map((x,i)=><Cell key={i} fill={severityColor[x.severity]}/>)}</Pie><Tooltip contentStyle={tooltipStyle}/><Legend iconType="circle" wrapperStyle={{fontSize:11}}/></PieChart></ResponsiveContainer></div>
}
export function ActivityChart({ data }: {data:Array<{time:string;incidents:number}>}) { return <div className="h-64"><ResponsiveContainer><LineChart data={data}><CartesianGrid stroke="#202020" strokeDasharray="3 3"/><XAxis dataKey="time" stroke="#71717a" fontSize={11}/><YAxis stroke="#71717a" fontSize={11}/><Tooltip contentStyle={tooltipStyle}/><Line dataKey="incidents" type="monotone" stroke="#D4AF37" strokeWidth={2} dot={false} activeDot={{r:4,fill:'#F4D675'}}/></LineChart></ResponsiveContainer></div> }
export function ShapChart({ features }: {features:SHAPFeature[]}) { const rows=features.slice(0,10).map(x=>({...x,label:x.feature.replaceAll('_',' ')}));return <div className="h-80"><ResponsiveContainer><BarChart data={rows} layout="vertical" margin={{left:32,right:20}}><CartesianGrid stroke="#202020" horizontal={false}/><XAxis type="number" stroke="#71717a" fontSize={11}/><YAxis type="category" dataKey="label" width={130} stroke="#a1a1aa" fontSize={11}/><Tooltip contentStyle={tooltipStyle}/><Bar dataKey="shap_value" radius={2}>{rows.map((x,i)=><Cell key={i} fill={x.shap_value>=0?'#D4AF37':'#3B82F6'}/>)}</Bar></BarChart></ResponsiveContainer></div> }

export function RiskGauge({ risk }: {risk:RiskAssessment}) {
  const circumference=2*Math.PI*70, progress=circumference*(1-risk.risk_score/100), color=severityColor[risk.severity]
  return <div className="relative mx-auto h-[190px] w-[190px]" aria-label={`Risk score ${risk.risk_score}, ${risk.severity}`}>
    <svg viewBox="0 0 180 180" className="-rotate-90"><circle cx="90" cy="90" r="70" fill="none" stroke="#242424" strokeWidth="12"/><motion.circle cx="90" cy="90" r="70" fill="none" stroke={color} strokeLinecap="round" strokeWidth="12" strokeDasharray={circumference} initial={{strokeDashoffset:circumference}} animate={{strokeDashoffset:progress}} transition={{duration:.8,ease:'easeOut'}}/></svg>
    <div className="absolute inset-0 flex flex-col items-center justify-center"><strong className="text-4xl tabular-nums">{risk.risk_score.toFixed(0)}</strong><span className="mt-1 text-xs font-semibold" style={{color}}>{risk.severity} RISK</span><span className="mt-1 text-[10px] text-zinc-500">{risk.priority} PRIORITY</span></div>
  </div>
}
