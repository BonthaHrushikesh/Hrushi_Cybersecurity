from src.utils.config import Settings
from src.rag.prompts import JUDGE_SYSTEM
from src.api.schemas import Analysis, JudgeOutput, JudgeResult
from src.services.provider_resilience import ProviderCircuit, provider_failure_reason
from src.services.llm_provider import generate_structured

DIMENSIONS = {"groundedness", "relevance", "correctness", "completeness", "recommendation_usefulness", "safety", "hallucination_risk"}


class JudgeService:
    def __init__(self, config: Settings):
        self.config = config
        self.circuit = ProviderCircuit(config.llm_failure_threshold, config.llm_cooldown_seconds)

    def evaluate(self, analysis: Analysis, evidence: dict) -> JudgeResult:
        if not self.config.credentials_configured:
            return JudgeResult(status="not_configured", provider="none", dimensions={},
                               limitation="LLM-as-Judge requires a configured OpenAI, Anthropic, or NVIDIA provider and its API key; offline structural checks are evaluated separately.")
        def request_judgment():
            result = generate_structured(self.config, JUDGE_SYSTEM,
                                         {"evidence_data": evidence, "analysis_data": analysis.model_dump()},
                                         JudgeOutput, judge=True)
            return JudgeResult(status="completed", provider=self.config.llm_provider, dimensions=result.dimensions.model_dump())

        try:
            return self.circuit.call(request_judgment)
        except Exception as error:
            return JudgeResult(status="unavailable", provider=self.config.llm_provider, dimensions={},
                               limitation=provider_failure_reason(error) + " No LLM quality scores were generated.")
