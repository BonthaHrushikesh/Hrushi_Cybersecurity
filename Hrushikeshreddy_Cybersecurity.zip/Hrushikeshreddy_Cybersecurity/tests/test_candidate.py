import json

import pandas as pd
import pytest

from src.utils.config import settings
from ml.train import train_models
from src.utils.features import flow_signatures
from scripts.retrain_candidate import merge_reviewed_feedback


def sampled_flows():
    return pd.read_csv(settings.processed.parent / "sample_data/sample_incidents.csv")


def benchmark_rows(sample):
    return pd.concat([group.head(min(12, max(1, len(group) // 5)))
                      for _, group in sample.groupby("attack_category")]).copy()


def test_reviewed_correction_replaces_matching_baseline_signature():
    sample = sampled_flows().head(2)
    profile = json.loads((settings.processed / "profile.json").read_text())
    corrected = sample.head(1).copy()
    corrected["incident_id"] = "INV-reviewed-correction"
    corrected["attack_category"] = "DDoS" if sample.iloc[0]["attack_category"] != "DDoS" else "BENIGN"
    corrected["original_label"] = corrected["attack_category"]
    corrected["reviewed_at"] = "2026-10-09T00:00:00+00:00"

    merged = merge_reviewed_feedback(sample, corrected, profile["numeric_features"])

    assert len(merged) == len(sample)
    assert "INV-reviewed-correction" in set(merged["incident_id"])
    assert sample.iloc[0]["incident_id"] not in set(merged["incident_id"])


def test_contradictory_reviewed_labels_are_rejected():
    sample = sampled_flows().head(1)
    profile = json.loads((settings.processed / "profile.json").read_text())
    reviewed = pd.concat([sample, sample], ignore_index=True)
    reviewed["incident_id"] = ["INV-one", "INV-two"]
    reviewed["attack_category"] = ["DDoS", "BENIGN"]

    with pytest.raises(ValueError, match="Conflicting approved labels"):
        merge_reviewed_feedback(sample, reviewed, profile["numeric_features"])


def test_reviewed_float_values_replace_equivalent_integer_flow():
    baseline = pd.DataFrame([{"destination_port": 80, "flow_duration": 1000, "incident_id": "CIC-existing", "attack_category": "BENIGN"}])
    reviewed = pd.DataFrame([{"destination_port": 80.0, "flow_duration": 1000.0, "incident_id": "INV-corrected", "attack_category": "DDoS"}])
    merged = merge_reviewed_feedback(baseline, reviewed, ["destination_port", "flow_duration"])
    assert len(merged) == 1
    assert merged.iloc[0].incident_id == "INV-corrected"
    assert merged.iloc[0].attack_category == "DDoS"


def test_numeric_signatures_normalize_missing_sentinels_and_input_types():
    frame = pd.DataFrame({"destination_port": [80, 80.0, "80"], "init_win_bytes_forward": [-1, float("nan"), float("inf")]})
    assert flow_signatures(frame, list(frame)).nunique() == 1


def test_candidate_never_trains_on_active_benchmark_signatures(tmp_path):
    sample = sampled_flows()
    benchmark = benchmark_rows(sample)
    duplicated = benchmark.head(1).copy()
    duplicated["incident_id"] = "INV-reviewed-benchmark-copy"
    source = tmp_path / "processed"
    source.mkdir()
    pd.concat([sample, duplicated], ignore_index=True).to_csv(source / "incidents.csv", index=False)
    profile = json.loads((settings.processed / "profile.json").read_text())
    (source / "profile.json").write_text(json.dumps(profile))
    metadata = train_models(source, tmp_path / "candidate", trees=6, fixed_test=benchmark)
    assert metadata["test_split_strategy"] == "fixed_active_benchmark_signatures_excluded_from_training"
    assert metadata["split_sizes"]["test"] == len(benchmark)
    assert metadata["split_sizes"]["final_training"] == len(sample) - len(benchmark)
    assert len(metadata["training_spec"]["holdout_fingerprint"]) == 64
    historical = pd.read_csv(source / "historical.csv")
    assert "INV-reviewed-benchmark-copy" not in set(historical["incident_id"])
    assert set(historical["incident_id"]).isdisjoint(benchmark["incident_id"])


def test_fixed_benchmark_truth_is_part_of_model_version(tmp_path):
    sample = sampled_flows()
    benchmark = benchmark_rows(sample)
    source = tmp_path / "processed"
    source.mkdir()
    sample.to_csv(source / "incidents.csv", index=False)
    profile = json.loads((settings.processed / "profile.json").read_text())
    (source / "profile.json").write_text(json.dumps(profile))
    first = train_models(source, tmp_path / "first", trees=6, fixed_test=benchmark)
    # Change only held-out truth in a unit fixture; training rows and selection stay identical.
    changed = benchmark.copy()
    position = changed.index[changed.attack_category == "DoS"][0]
    changed.loc[position, "attack_category"] = "DDoS"
    second = train_models(source, tmp_path / "second", trees=6, fixed_test=changed)
    assert first["name"] == second["name"]
    assert first["dataset_version"] == second["dataset_version"]
    assert first["version"] != second["version"]
