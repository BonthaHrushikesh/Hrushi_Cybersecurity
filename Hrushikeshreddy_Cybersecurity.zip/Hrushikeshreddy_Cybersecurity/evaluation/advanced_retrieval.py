import json
from datetime import datetime, timezone
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd

from src.utils.config import settings
from src.rag.document_builder import ALIASES, flow_document
from src.api.schemas import FlowInput, SearchRequest
from src.services.models import ModelService
from src.services.retrieval import RetrievalService
from evaluation.retrieval_metrics import aggregate_metrics, ranking_metrics


def evaluate():
    retrieval = RetrievalService(settings.artifacts, settings.hybrid_alpha)
    models = ModelService(settings.artifacts)
    profile = json.loads((settings.processed / 'profile.json').read_text())
    held_out = pd.read_csv(settings.processed / 'test.csv')
    totals = {category: sum(item.attack_type == category for item in retrieval.incidents)
              for category in held_out.attack_category.unique()}
    strategies = {'keyword': [], 'weighted_hybrid': [], 'advanced_rag': []}
    details = []
    for _, row in held_out.groupby('attack_category', group_keys=False).head(5).iterrows():
        features = {name: float(row[name]) for name in profile['numeric_features'] if pd.notna(row[name])}
        prediction = models.classify(FlowInput(features=features))
        category = prediction.predicted_attack_type
        query = f"Model hypothesis: {category}. {ALIASES.get(category, category)}. {flow_document(features)}"[:1000]
        options = {'keyword': {'mode': 'keyword'}, 'weighted_hybrid': {},
                   'advanced_rag': {'fusion': 'rrf', 'expand_query': True, 'diversify': True}}
        for strategy, kwargs in options.items():
            result = retrieval.search(SearchRequest(query=query, top_k=5, **kwargs),
                                      flow_features=features if strategy == 'advanced_rag' else None)
            metrics = ranking_metrics([hit.attack_type == row.attack_category for hit in result.results], totals[row.attack_category], 5)
            strategies[strategy].append(metrics)
            details.append({'strategy': strategy, 'incident_id': row.incident_id, 'expected': row.attack_category,
                            'predicted': category, 'retrieved_ids': [hit.incident_id for hit in result.results], **metrics})
    report = {'status': 'completed', 'queries_per_strategy': len(strategies['keyword']), 'k': 5,
              'created_at': datetime.now(timezone.utc).isoformat(), 'model_version': models.bundle['version'],
              'metrics': {name: aggregate_metrics(rows) for name, rows in strategies.items()},
              'limitations': ['All strategies use the same model-hypothesis query, without held-out ground-truth labels.',
                              'Category agreement is a coarse relevance proxy; diversity may reduce category precision.',
                              'This evaluation measures retrieval, not LLM answer quality.'], 'queries': details}
    path = settings.artifacts / 'evaluation/advanced_retrieval.json'
    path.write_text(json.dumps(report, indent=2))
    print(json.dumps({key: value for key, value in report.items() if key != 'queries'}, indent=2))


if __name__ == '__main__':
    evaluate()
