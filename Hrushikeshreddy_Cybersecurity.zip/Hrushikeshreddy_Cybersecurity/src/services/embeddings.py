import numpy as np
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize


class EmbeddingService:
    """Offline latent-semantic vectors or configurable pretrained sentence embeddings."""
    def __init__(self, provider: str = "lsa", model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        self.provider, self.model_name = provider, model_name
        self.vectorizer, self.reducer, self._model = None, None, None

    def fit(self, texts: list[str]) -> np.ndarray:
        if self.provider == "sentence_transformers":
            return self.encode(texts)
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), max_features=8000, sublinear_tf=True)
        sparse = self.vectorizer.fit_transform(texts)
        dimensions = min(96, sparse.shape[0] - 1, sparse.shape[1] - 1)
        if dimensions < 2:
            raise ValueError("At least three varied documents are required for the semantic index")
        self.reducer = TruncatedSVD(n_components=dimensions, random_state=42)
        return normalize(self.reducer.fit_transform(sparse)).astype("float32")

    def encode(self, texts: list[str]) -> np.ndarray:
        if self.provider == "sentence_transformers":
            if self._model is None:
                from sentence_transformers import SentenceTransformer
                self._model = SentenceTransformer(self.model_name)
            return self._model.encode(texts, normalize_embeddings=True, show_progress_bar=False).astype("float32")
        if self.vectorizer is None or self.reducer is None:
            raise RuntimeError("Embedding provider must be fitted before encoding")
        return normalize(self.reducer.transform(self.vectorizer.transform(texts))).astype("float32")

    def __getstate__(self):
        state = self.__dict__.copy()
        state["_model"] = None
        return state
