# AI-Powered Cybersecurity Incident Response Assistant

Participant: **Hrushikeshreddy**. Domain: Cybersecurity.
Recommended repository: **Hrushikeshreddy_Cybersecurity**.
[Submission details](docs/SUBMISSION_METADATA.md).

## Overview, Problem, And Business Objective

SOC analysts need to find similar incidents, interpret network-flow patterns,
classify attacks, and prioritize investigation. This local assistant brings those
tasks into one evidence-backed record: predictions, anomaly signals, historical
citations, risk policy, exact feature explanations, defensive recommendations,
and reviewed feedback. Reduced investigation time is an objective, not a measured
business outcome. The system never autonomously blocks traffic or remediates hosts.

## Solution And Technology Stack

| Component | Implementation |
|---|---|
| Languages | Python 3.12, TypeScript |
| API / frameworks | FastAPI, Uvicorn, Pydantic |
| Frontend | React, Vite, Tailwind 4, Recharts, TanStack Query |
| Attack / intrusion models | Balanced Random Forest; Extra Trees validation comparison |
| Anomaly model | Isolation Forest fitted to benign training flows |
| Explainability | Exact local TreeSHAP; separate global impurity importance |
| Embedding model | TF-IDF + 96-dimensional LSA offline baseline; optional all-MiniLM-L6-v2 |
| Vector / keyword retrieval | FAISS IndexFlatIP + BM25 |
| Advanced RAG | Query expansion, weighted/RRF fusion, flow-feature reranking, MMR, metadata filtering |
| LLM | Optional Claude Messages or OpenAI Responses; deterministic local playbook fallback |
| Evaluation | DeepEval, seven-dimension LLM judge, held-out ML/retrieval, pytest, Vitest, Playwright |
| Persistence | SQLite investigations/feedback; versioned joblib and JSON artifacts |

The explicit seven-role workflow covers detection, anomaly, retrieval, risk,
explanation, response, and optional judging. Agents share validated state.
These are specialist tool-using workflow roles, not seven independent LLM chatbots.

**Frontend choice:** React only, as requested by the participant. The submission
guidelines prescribe Streamlit; organizer acceptance of this deviation is pending.
No Streamlit dependency or frontend has been added.

## Dataset And Current Results

Primary data: eight metadata-rich CIC-IDS2017 CSVs in `TrafficLabelling `
(the local folder has a trailing space). `MachineLearningCVE` is a numeric-export
cross-check, not a duplicate training corpus.
[Official source](https://www.unb.ca/cic/datasets/ids-2017.html).

| Evidence | Current full-dataset sampled run |
|---|---:|
| Parsed / unlabeled rows excluded | 3,119,345 / 288,602 |
| Labeled rows / prepared sample | 2,830,743 / 20,273 |
| Raw / derived features | 77 / 3 |
| Training and indexed history / held-out test | 16,218 / 4,055 |
| Normalized categories | 9 |
| Attack accuracy / macro F1 | 99.21% / 0.9743 |
| Binary intrusion ROC AUC / anomaly ROC AUC | 0.9961 / 0.7628 |
| Unassisted hybrid Precision@5, 42 queries | 62.86% |
| Model-assisted weighted hybrid / advanced Precision@5 | 95.24% / 95.24% |

Active version: `cicids-aa6f46dbeb`. Heartbleed has only two test records and
Infiltration seven. UTC is a user-declared assumption, not independently verified.
Random sampled holdouts are not production guarantees; probabilities are
uncalibrated. Category agreement is a retrieval proxy, not LLM faithfulness.

The dashboard defaults to historical traffic: 14,626 attack-labeled and 1,592
benign records. Saved-investigation counters start at zero until a flow is analyzed.

## Installation And Environment Setup

Use Python 3.12 and Node 22. On a fresh checkout:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
npm --prefix frontend ci
cp .env.example .env
python scripts/seed_demo.py
python scripts/start_local.py --offline
```

Keep an existing private `.env`; do not overwrite it with the example.
The included `data/sample_data/cicids2017_labelled_sample.csv` is a **real
467-row nine-category sample**, not synthetic. Demo preparation writes isolated
`data/demo/processed` and `artifacts/demo` directories and refuses existing
outputs unless `--overwrite` is explicitly supplied. Demo metrics differ from
the full sampled run above.

The launcher prints actual free ports and waits for readiness. Restart owned
services with `python scripts/start_local.py --restart --offline`. Offline mode
selects local providers for this run without changing your private .env. Typical manual commands
in two terminals:

```bash
uvicorn src.main:app --host 127.0.0.1 --port 8000
npm --prefix frontend run dev -- --host 127.0.0.1 --port 5173
```

React: `http://127.0.0.1:5173`. OpenAPI: `http://127.0.0.1:8000/docs`.
Set `VITE_API_BASE_URL` for a different backend port. `/health` is diagnostic;
`/ready` returns 503 until both model and index load. The local workspace is
already configured for the full TrafficLabelling artifacts; no retraining is needed.

### Full Dataset Preparation

Use fresh candidate paths; only declare UTC if confirmed for your source:

```bash
python scripts/prepare_prd_dataset.py \
  --input 'TrafficLabelling ' --encoding cp1252 --day-first \
  --timestamp-timezone UTC --per-class 2000 --trees 100 \
  --processed data/candidate/processed --artifacts artifacts/candidate
```

Use `--defer-timestamps` instead when timezone is unconfirmed. Review reports,
then explicitly change `DATASET_PATH`, `PROCESSED_DIR`, and `ARTIFACT_DIR`
in `.env` and restart. No automatic model promotion occurs. Raw datasets are
excluded from the submission ZIP and must be obtained separately.

## API Key Configuration

`LLM_PROVIDER=local` needs no key for ML, retrieval, SHAP, risk, feedback, and
local evidence-based recommendations. Local playbooks are **not an LLM**.
To use Claude, privately configure the backend:

```dotenv
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=<your-private-valid-key>
CLAUDE_MODEL=claude-sonnet-4-6
CLAUDE_JUDGE_MODEL=claude-sonnet-4-6
```

OpenAI is also implemented using `LLM_PROVIDER=openai`, `OPENAI_API_KEY`,
`OPENAI_MODEL`, and `JUDGE_MODEL`. Restart after changes. Never put keys in
`VITE_` variables, chat, screenshots, source code, or GitHub.

`python scripts/check_llm_connection.py` checks authentication without incident
evidence or generation. The latest verified Claude credential was rejected
with **HTTP 401**. A nonempty key is not successful authentication. The app
continues with declared local fallbacks, not fabricated judge scores.

Enabling generation/judging sends bounded evidence to the provider and can incur
charges. Host identifiers are omitted from the LLM context. With valid
authentication and explicit consent, `python scripts/verify_live_llm.py --deepeval`
collects real generation, judge, and quality evidence. These remain outstanding.

## Sample Queries And Expected Outputs

| User question / task | Expected output |
|---|---|
| Has similar SSH brute-force traffic occurred before? | Historical IDs, semantic/BM25 scores, port 22 evidence; optional exact Brute Force filter |
| What traffic characteristics are associated with DDoS? | Cited historical rate/packet/timing observations, limitations, defensive next steps |
| Investigate a complete DDoS dataset sample | Probabilities, anomaly percentile, risk/P1-P4, TreeSHAP, recommendations, agent trace |
| Show TCP PortScan incidents on destination port 80 | AND-composed metadata filters, matching records or an honest empty result |
| Which saved incidents should be reviewed first? | Calculated investigation risk and priorities, separate from historical label priors |

The UI includes Dashboard, Investigate, Incidents, AI Analyst, RAG Search,
Traffic Analytics, Models, Agent Workflow, Evaluation, Explainability, Feedback,
and Settings, plus incident detail. Sample and CSV inputs preserve all observed
features. Feedback remains pending review until explicitly approved.

## Testing, Evaluation, And Feedback

```bash
python -m pytest -q
npm --prefix frontend run test -- --run
npm --prefix frontend run lint
npm --prefix frontend run build
python evaluation/deepeval_runner.py --offline
python evaluation/retrieval_metrics.py
python evaluation/advanced_retrieval.py
python scripts/check_prd_readiness.py
```

Reports live under the configured `ARTIFACT_DIR/evaluation`.
Offline DeepEval checks sections and citation membership only; `offline_quality.json`
never overwrites live `deepeval.json`. Hosted quality metrics and judge dimensions
are implemented, but unavailable provider results are not reported as scores.
Stale or corrupt evaluation artifacts cannot satisfy active-model evidence checks.

For optional browser testing run `python -m pip install -r requirements-dev.txt`
and `python -m playwright install chromium`, then run
`python scripts/verify_ui.py` against the launcher URLs; its provider calls are
disabled. Only approved feedback corrections are exported using
`scripts/export_feedback.py`. `scripts/retrain_candidate.py` creates separate
candidate artifacts and compares them against the same protected holdout.
Promotion is manual.

Optional neural embeddings: install `requirements-embeddings.txt`, configure
`EMBEDDING_PROVIDER=sentence_transformers`, rebuild the index, and re-evaluate.
The initial pretrained model download needs network access.

## Deliverables And Submission

[Architecture PDF](architecture/Architecture_Diagram.pdf),
[Design PDF](design/Design_Document.pdf),
[API PDF](docs/API_Documentation.pdf),
[Dataset PDF](docs/Dataset_Details.pdf),
[Evaluation PDF](docs/Evaluation_Report.pdf),
[Ten-minute presentation PDF](presentation/Project_Presentation.pdf).

Source follows the submission layout: `src/api/`, `src/agents/`, `src/rag/`,
`src/services/`, `src/utils/`, and `src/main.py`. `app/` contains only small
compatibility modules for `uvicorn app.main:app` and previously saved embedding
indexes. There is no duplicated business logic. Training, evaluation, operations,
React, and tests are in `ml/`, `evaluation/`, `scripts/`, `frontend/`, `tests/`.
See [source layout](docs/PROJECT_STRUCTURE.md) and [compliance audit](docs/GUIDELINES_COMPLIANCE.md). Presentation PDF is the
accepted alternative to PPT. See [complete briefing](docs/COMPLETE_PROJECT_BRIEF_FOR_CHATGPT.md)
and [submission checklist](SUBMISSION_CHECKLIST.md).

```bash
python scripts/build_api_documentation.py
python scripts/build_submission_artifacts.py
python scripts/package_submission.py
```

PDF rendering needs local Chrome/Chromium; `--html-only` skips rendering.
The local ZIP excludes secrets, raw datasets, dependencies, databases, and logs.
Create/upload a **separate project GitHub repository**, not the Git repository
rooted at the participant's home directory. Repository URL/access remain pending.
Docker, cloud, Kubernetes, and CI are optional; no container runtime was verified.

## Limitations

This is a capstone prototype, not a production-certified IDS. Session leakage in
random splits, sampled priors, tiny rare-class supports, source-clock ambiguity,
uncalibrated confidence, LSA language limitations, prompt-screening limits, and
current provider authentication failure are explicit. Production additionally
requires access controls, rate limits, retention policy, independent time/host
validation, and operational calibration. Recommendations require analyst review.
