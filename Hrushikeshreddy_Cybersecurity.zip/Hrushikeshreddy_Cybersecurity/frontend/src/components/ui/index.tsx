import { AlertTriangle, CheckCircle2, Inbox, RefreshCw, ShieldAlert, XCircle } from 'lucide-react'
import type { ComponentType, ReactNode } from 'react'
import type { Priority, Severity } from '../../types'
import { severityColor } from '../../constants'

export function PageHeader({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: ReactNode }) {
  return <header className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
    <div>{eyebrow && <p className="eyebrow mb-2">{eyebrow}</p>}<h1 className="text-[28px] font-semibold leading-tight text-zinc-50 lg:text-[32px]">{title}</h1>{description && <p className="mt-2 max-w-3xl text-sm text-zinc-400">{description}</p>}</div>{action}
  </header>
}

export function SeverityBadge({ severity, priority }: { severity: Severity; priority?: Priority }) {
  return <span className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold" style={{color:severityColor[severity],borderColor:`${severityColor[severity]}55`,background:`${severityColor[severity]}12`}}>
    <AlertTriangle size={12} aria-hidden="true" />{priority ? `${priority} · ` : ''}{severity}
  </span>
}
export function StatusBadge({ status }: { status: string }) {
  const good = ['online','ready','active','completed','approved','ok','passed'].includes(status.toLowerCase())
  const Icon = good ? CheckCircle2 : status.toLowerCase().includes('pending') ? AlertTriangle : XCircle
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold ${good?'bg-emerald-500/10 text-emerald-400':'bg-zinc-800 text-zinc-300'}`}><Icon size={12}/>{status.toUpperCase()}</span>
}
export function AttackBadge({ attack }: { attack: string }) { return <span className="inline-flex rounded-md border border-gold/20 bg-gold/[.07] px-2 py-1 text-xs font-medium text-brightGold">{attack}</span> }

export function MetricCard({ icon:Icon, title, value, trend, context, selected=false }: { icon:ComponentType<{size?:number}>; title:string; value:string; trend?:string; context:string; selected?:boolean }) {
  return <article className={`panel group relative min-h-[142px] overflow-hidden p-4 transition hover:-translate-y-0.5 hover:border-gold/40 ${selected?'border-gold/35':''}`}>
    {selected && <span className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brightGold to-transparent"/>}
    <div className="flex items-start justify-between"><p className="text-[11px] font-semibold uppercase tracking-[.1em] text-zinc-500">{title}</p><Icon size={17}/></div>
    <div className="mt-4 flex items-baseline gap-3"><strong className="text-[28px] font-semibold tabular-nums text-zinc-50">{value}</strong>{trend && <span className="text-xs font-medium text-emerald-400">{trend}</span>}</div>
    <p className="mt-2 text-xs text-zinc-500">{context}</p>
  </article>
}
export function DemoBanner() { return <div className="mb-5 flex items-center gap-2 rounded-lg border border-amber-400/25 bg-amber-400/[.07] px-4 py-2.5 text-xs text-amber-200"><ShieldAlert size={15}/><strong>DEMO DATA</strong><span className="text-amber-100/70">The live API is unavailable; clearly marked fallback records are shown.</span></div> }
export function LoadingSkeleton({ rows=3 }: {rows?:number}) { return <div aria-label="Loading" className="space-y-3">{Array.from({length:rows},(_,i)=><div className="skeleton h-12" key={i}/>)}</div> }
export function ErrorState({ message, onRetry }: {message:string;onRetry?:()=>void}) { return <div className="panel flex min-h-52 flex-col items-center justify-center p-8 text-center"><XCircle className="text-red-400"/><h3 className="mt-3 font-semibold">Service unavailable</h3><p className="mt-2 max-w-md text-sm text-zinc-400">{message}</p>{onRetry&&<button className="btn-secondary mt-5" onClick={onRetry}><RefreshCw size={15}/>Retry</button>}</div> }
export function EmptyState({ title='NO INCIDENTS FOUND', description='No incidents match the selected filters.', action }: {title?:string;description?:string;action?:ReactNode}) { return <div className="flex min-h-48 flex-col items-center justify-center p-8 text-center"><Inbox className="text-zinc-600"/><h3 className="mt-3 text-sm font-semibold tracking-wide text-zinc-200">{title}</h3><p className="mt-2 max-w-md text-sm text-zinc-500">{description}</p>{action&&<div className="mt-5">{action}</div>}</div> }
export function Panel({ title, eyebrow, action, children, className='' }: {title:string;eyebrow?:string;action?:ReactNode;children:ReactNode;className?:string}) { return <section className={`panel ${className}`}><div className="panel-header"><div>{eyebrow&&<p className="eyebrow mb-1">{eyebrow}</p>}<h2 className="text-base font-semibold text-zinc-100">{title}</h2></div>{action}</div><div className="p-5">{children}</div></section> }
