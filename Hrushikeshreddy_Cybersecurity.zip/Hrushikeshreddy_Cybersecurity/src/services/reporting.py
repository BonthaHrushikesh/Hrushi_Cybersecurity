def markdown_report(result: dict) -> str:
    prediction, risk, analysis = result["prediction"], result["risk"], result["analysis"]
    lines = [f"# Investigation {result['incident_id']}", "", f"Created: {result['created_at']}",
             f"Model version: {prediction['model_version']}", f"Analysis provider: {result['analysis_provider']}", "",
             "## Triage", "", f"Predicted category: {prediction['predicted_attack_type']}",
             f"Classification confidence: {prediction['classification_confidence']:.2%}",
             f"Intrusion model output: {prediction['malicious_probability']:.2%}",
             f"Risk: {risk['risk_score']:.2f}/100 | {risk['severity']} | {risk['priority']}",
             "Model probabilities are uncalibrated; the risk score is a triage policy.", "",
             "## Executive Summary", "", analysis["executive_summary"], "", "## Observed Evidence", ""]
    lines.extend(f"- {item}" for item in analysis["observed_evidence"])
    for key, title in [("immediate_investigation", "Investigation"), ("containment_considerations", "Containment Considerations"),
                       ("further_evidence", "Further Evidence"), ("longer_term_mitigation", "Mitigation")]:
        lines.extend(["", f"## {title}", ""])
        lines.extend(f"- {item['action']}\n  Evidence: {item['evidence']}" for item in analysis[key])
    lines.extend(["", "## Historical Evidence", ""])
    lines.extend(f"- {hit['incident_id']}: {hit['attack_type']}; ranking score {hit['similarity_score']:.4f}" for hit in result["retrieval"]["results"])
    lines.extend(["", "## Local Explanation", "", f"Method: {result['explanation']['method']}"])
    lines.extend(f"- {item['feature']}: contribution {item['shap_value']:+.6f}; observed {item['observed_value']}" for item in result["explanation"]["contributions"][:10])
    lines.extend(["", "## Evidence Limitations", ""])
    lines.extend(f"- {item}" for item in analysis["evidence_limitations"])
    lines.extend(["", "## Workflow", ""])
    for step in result["workflow"]:
        lines.append(f"- {step['agent']}: {step['status']} ({step['latency_ms']:.1f} ms)")
        if step.get("detail"):
            lines.append(f"  Detail: {step['detail']}")
    judge = result.get("judge")
    lines.extend(["", f"Judge: {judge['status'] if judge else 'not_requested'}", "",
                  "Recommendations are advisory. Authorized analyst review is required before response actions.", ""])
    if judge and judge.get("limitation"):
        lines.extend([f"Judge limitation: {judge['limitation']}", ""])
    return "\n".join(lines)
