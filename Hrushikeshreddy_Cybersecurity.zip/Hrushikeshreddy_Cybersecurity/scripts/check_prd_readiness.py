import json
import math
from pathlib import Path
import sys
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd

from src.utils.config import settings
from src.utils.features import CANONICAL_LABELS
from src.api.schemas import JudgeDimensions
from src.services.artifact_reports import connection_report, read_report, write_report

QUALITY_METRICS = {"Answer Relevancy", "Faithfulness", "Contextual Precision", "Contextual Recall", "Hallucination"}


def quality_evidence_checks(quality, model, config):
    expected = set(model["classes"])
    current = bool(expected) and config.llm_provider != "local" and all([
        quality.get("model_version") == model["version"],
        quality.get("llm_provider") == config.llm_provider,
        quality.get("generation_model") == config.generation_model,
        quality.get("judge_model") == config.evaluation_model,
    ])
    providers = quality.get("analysis_providers")
    providers = providers if isinstance(providers, dict) else {}
    generation = current and quality.get("live_generation_verified") is True and all(
        providers.get(category) == config.llm_provider for category in expected)

    def valid_judge(result):
        if not isinstance(result, dict) or result.get("status") != "completed" or result.get("provider") != config.llm_provider:
            return False
        try:
            dimensions = JudgeDimensions.model_validate(result.get("dimensions", {}))
            return all(score.reason.strip() for _, score in dimensions)
        except ValueError:
            return False

    judges = quality.get("judge_results")
    judges = judges if isinstance(judges, dict) else {}
    judge = current and quality.get("live_judge_verified") is True and all(valid_judge(judges.get(category)) for category in expected)

    def measured(category):
        values = quality.get("llm_metrics")
        values = values if isinstance(values, list) else []
        rows = [row for row in values if isinstance(row, dict) and row.get("category") == category]
        if len(rows) != 1:
            return False
        metrics = rows[0].get("metrics")
        if not isinstance(metrics, list) or not all(isinstance(item, dict) for item in metrics):
            return False
        names = {item.get("metric") for item in metrics}
        return QUALITY_METRICS <= names and all(
            item.get("status") == "completed" and isinstance(item.get("score"), (int, float))
            and not isinstance(item["score"], bool) and math.isfinite(item["score"]) and 0 <= item["score"] <= 1
            for item in metrics)

    metrics = current and quality.get("llm_metrics_status") == "completed" and all(measured(category) for category in expected)
    return bool(generation), bool(judge), bool(metrics)


def assess(config=settings):
    profile = json.loads((config.processed / "profile.json").read_text())
    model = json.loads((config.artifacts / "models/metadata.json").read_text())
    fields = ["source_ip", "destination_ip", "source_port", "destination_port", "protocol", "timestamp"]
    history = pd.read_csv(config.processed / "historical.csv", usecols=lambda name: name in fields)
    counts = {name: int(history[name].notna().sum()) if name in history else 0 for name in fields}
    missing = [name for name, count in counts.items() if not count]
    complete_records = int(history[fields].notna().all(axis=1).sum()) if not missing else 0
    absent_classes = sorted(set(CANONICAL_LABELS) - set(model["classes"]))
    path = config.artifacts / "evaluation/deepeval.json"
    quality = read_report(path) if path.exists() else {}
    generation, judge, metrics = quality_evidence_checks(quality, model, config)
    checks = {"historical_metadata": complete_records > 0, "all_prd_attack_categories": not absent_classes,
              "live_generation_evidence": bool(generation), "live_judge_evidence": bool(judge), "deepeval_quality_measured": bool(metrics)}
    blockers = []
    if missing:
        blockers.append("Historical metadata missing: " + ", ".join(missing))
    elif not complete_records:
        blockers.append("No historical record has all required metadata fields available together.")
    if absent_classes:
        blockers.append("Active model has no training coverage for: " + ", ".join(absent_classes))
    if not generation or not judge or not metrics:
        blockers.append("Live generation/judge/DeepEval evidence is incomplete or does not match the active model and provider configuration.")
        connection_path = config.artifacts / "evaluation/provider_connection.json"
        if connection_path.exists():
            connection = connection_report(config)
            if (connection.get("provider") == config.llm_provider and
                    connection.get("generation_model") == config.generation_model and
                    connection.get("judge_model") == config.evaluation_model and connection.get("status") == "failed"):
                status = connection.get("http_status")
                code = f" (HTTP {status})" if isinstance(status, int) else ""
                blockers.append(f"Provider authentication check failed{code}; live evaluation requires a successful provider connection.")
    return {"status": "demonstrated" if all(checks.values()) else "incomplete", "checks": checks,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "model_version": model["version"], "source_dataset": profile["source_name"], "metadata_record_counts": counts,
            "complete_metadata_records": complete_records,
            "missing_attack_categories": absent_classes, "key_configured": config.credentials_configured,
            "quality_metrics_status": quality.get("llm_metrics_status", "not_run"), "blockers": blockers,
            "scope": "Checks the three outstanding PRD demonstration gaps; quality measured does not mean quality thresholds passed."}


if __name__ == "__main__":
    result = assess()
    path = settings.artifacts / "evaluation/prd_readiness.json"
    write_report(path, result)
    print(json.dumps(result, indent=2))
