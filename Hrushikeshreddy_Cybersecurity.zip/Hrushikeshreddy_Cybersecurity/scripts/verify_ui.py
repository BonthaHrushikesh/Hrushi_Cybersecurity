import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def assert_no_overflow(page):
    assert not page.evaluate("() => document.documentElement.scrollWidth > window.innerWidth + 2"), "Page has horizontal overflow"


def main():
    runtime_path = ROOT / "artifacts/runtime.json"
    runtime = json.loads(runtime_path.read_text()) if runtime_path.exists() else {
        "frontend_url": os.getenv("FRONTEND_URL", "http://127.0.0.1:5173"),
    }
    directory = ROOT / "artifacts/figures"
    directory.mkdir(parents=True, exist_ok=True)
    errors = []
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch()
        page = browser.new_page(viewport={"width": 1440, "height": 1000})
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.goto(runtime["frontend_url"] + "/dashboard")
        page.get_by_role("heading", name="Security Operations Dashboard").wait_for(timeout=30000)
        page.locator(".recharts-responsive-container svg").first.wait_for(timeout=30000)
        page.locator(".recharts-pie-sector").first.wait_for(timeout=30000)
        page.wait_for_timeout(1800)
        assert_no_overflow(page)
        page.screenshot(path=str(directory / "dashboard-desktop.png"), full_page=True)
        page.get_by_role("button", name="Notifications", exact=True).click()
        page.get_by_role("dialog", name="Priority notifications").wait_for()
        assert_no_overflow(page)
        page.get_by_role("button", name="Close notifications").click()

        page.get_by_role("link", name="Investigate").click()
        page.get_by_role("heading", name="Investigate Network Flow").wait_for()
        page.get_by_label("Use configured LLM", exact=True).uncheck()
        page.get_by_label("Run LLM judge", exact=True).uncheck()
        page.screenshot(path=str(directory / "investigate-desktop.png"), full_page=True)
        samples = page.request.get(runtime["api_url"] + "/api/v1/samples").json()
        expected = next(item for item in samples if item["attack_type"] == "DDoS")
        with page.expect_response(lambda response: "/api/v1/investigate" in response.url and response.request.method == "POST") as investigation_response:
            page.get_by_role("button", name="Run investigation").click()
        page.get_by_role("heading", name="Observed Evidence").wait_for(timeout=30000)
        response = investigation_response.value
        assert response.status == 200
        assert response.request.post_data_json["use_llm"] is False and response.request.post_data_json["judge"] is False
        assert response.request.post_data_json["flow"]["features"] == expected["features"], "Sample features were dropped or fabricated"
        investigation_id = response.json()["incident_id"]
        page.screenshot(path=str(directory / "investigation-result-desktop.png"), full_page=True)

        page.get_by_role("link", name="RAG Search").click()
        page.get_by_role("heading", name="Threat Search").wait_for()
        page.get_by_role("button", name="Filters", exact=True).click()
        page.get_by_label("Source IP").wait_for()
        page.get_by_label("Observed before").wait_for()
        page.get_by_role("button", name="Search", exact=True).click()
        page.get_by_role("heading", name="Search Results").wait_for(timeout=60000)
        page.screenshot(path=str(directory / "search-desktop.png"), full_page=True)

        page.get_by_label("Retrieval mode").select_option("keyword")
        with page.expect_response(lambda response: "/api/v1/search" in response.url and response.request.method == "POST") as search_response:
            page.get_by_role("button", name="Search", exact=True).click()
        assert search_response.value.status == 200
        assert search_response.value.json()["alpha"] == 0

        page.get_by_role("link", name="AI Analyst").click()
        page.get_by_role("heading", name="AI Investigation Assistant").wait_for()
        page.get_by_label("Use configured LLM", exact=True).uncheck()
        page.get_by_label("Incident question").fill("Find historical DDoS incidents and investigation priorities")
        page.get_by_role("button", name="Send question").click()
        page.get_by_role("heading", name="Evidence Gaps").wait_for(timeout=60000)
        assert_no_overflow(page)
        page.screenshot(path=str(directory / "rag-answer-desktop.png"), full_page=True)

        page.get_by_role("link", name="Explainability").click()
        page.get_by_role("heading", name="Explainability & Model Insights").wait_for()
        page.locator(".recharts-responsive-container svg").first.wait_for(timeout=30000)
        page.screenshot(path=str(directory / "explainability-desktop.png"), full_page=True)

        page.get_by_role("link", name="Models", exact=True).click()
        page.get_by_role("heading", name="Model Registry", level=1).wait_for(timeout=30000)
        page.screenshot(path=str(directory / "models-desktop.png"), full_page=True)

        page.get_by_role("link", name="Agent Workflow").click()
        page.get_by_role("heading", name="Multi-Agent Workflow", level=1).wait_for(timeout=30000)
        page.screenshot(path=str(directory / "workflow-desktop.png"), full_page=True)

        page.get_by_role("link", name="Evaluation").click()
        page.get_by_role("heading", name="AI Evaluation Center", level=1).wait_for(timeout=30000)
        page.screenshot(path=str(directory / "evaluation-desktop.png"), full_page=True)
        page.get_by_role("heading", name="Retrieval Strategy Comparison").wait_for()

        for route, heading, filename in [
            ("traffic-analytics", "Security Analytics", "analytics-desktop.png"),
            ("incidents", "Incident Explorer", "incidents-desktop.png"),
            ("feedback", "Analyst Feedback", "feedback-desktop.png"),
            ("settings", "Settings", "settings-desktop.png"),
        ]:
            page.goto(runtime["frontend_url"] + "/" + route)
            page.get_by_role("heading", name=heading, level=1).wait_for(timeout=30000)
            assert_no_overflow(page)
            page.screenshot(path=str(directory / filename), full_page=True)

        page.goto(runtime["frontend_url"] + "/incidents/" + investigation_id)
        page.get_by_role("button", name="Export report").wait_for()
        with page.expect_download() as download:
            page.get_by_role("button", name="Export report").click()
        assert download.value.suggested_filename == investigation_id + ".md"
        download.value.save_as(str(directory / "downloaded-investigation.md"))

        mobile = browser.new_page(viewport={"width": 390, "height": 844}, is_mobile=True, device_scale_factor=1)
        mobile.on("pageerror", lambda error: errors.append(str(error)))
        mobile.goto(runtime["frontend_url"] + "/dashboard")
        mobile.get_by_role("heading", name="Security Operations Dashboard").wait_for(timeout=30000)
        mobile.locator(".recharts-pie-sector").first.wait_for(timeout=30000)
        mobile.wait_for_timeout(1800)
        assert_no_overflow(mobile)
        mobile.screenshot(path=str(directory / "dashboard-mobile.png"), full_page=True)
        mobile.get_by_role("button", name="Open navigation").click()
        mobile.get_by_role("link", name="Investigate").click()
        mobile.get_by_role("heading", name="Investigate Network Flow").wait_for()
        assert_no_overflow(mobile)
        mobile.screenshot(path=str(directory / "investigate-mobile.png"), full_page=True)
        mobile.goto(runtime["frontend_url"] + "/assistant")
        mobile.get_by_role("heading", name="AI Investigation Assistant").wait_for(timeout=30000)
        mobile.get_by_label("Use configured LLM", exact=True).uncheck()
        mobile.get_by_label("Incident question").fill("Find historical SSH brute force incidents")
        mobile.get_by_role("button", name="Send question").click()
        mobile.get_by_role("heading", name="Evidence Gaps").wait_for(timeout=60000)
        assert_no_overflow(mobile)
        mobile.screenshot(path=str(directory / "rag-answer-mobile.png"), full_page=True)
        mobile.goto(runtime["frontend_url"] + "/settings")
        mobile.get_by_role("heading", name="Service Readiness").wait_for()
        assert_no_overflow(mobile)
        mobile.screenshot(path=str(directory / "settings-mobile.png"), full_page=True)

        unavailable = browser.new_page(viewport={"width": 1440, "height": 1000})
        unavailable.route("**/api/v1/metrics", lambda route: route.fulfill(status=503, json={"detail": "Unavailable test service"}))
        unavailable.goto(runtime["frontend_url"] + "/dashboard")
        unavailable.get_by_text("Live operational metrics are unavailable.", exact=True).wait_for(timeout=15000)
        assert unavailable.get_by_text("DEMO DATA", exact=True).count() == 0
        unavailable.screenshot(path=str(directory / "unavailable-desktop.png"), full_page=True)
        assert not errors, errors
        browser.close()

    report = {"status": "passed", "provider_mode": "local_only", "browser_errors": errors, "screenshots": [
        "dashboard-desktop.png", "investigate-desktop.png", "search-desktop.png",
        "investigation-result-desktop.png", "explainability-desktop.png",
        "models-desktop.png", "workflow-desktop.png", "evaluation-desktop.png",
        "dashboard-mobile.png", "investigate-mobile.png",
        "rag-answer-desktop.png", "rag-answer-mobile.png",
        "analytics-desktop.png", "incidents-desktop.png", "feedback-desktop.png",
        "settings-desktop.png", "settings-mobile.png", "unavailable-desktop.png",
    ]}
    (ROOT / "artifacts/evaluation/browser.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
