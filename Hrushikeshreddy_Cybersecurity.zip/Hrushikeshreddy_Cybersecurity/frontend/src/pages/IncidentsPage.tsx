import { useNavigate } from 'react-router-dom'
import { dashboardApi } from '../api'
import { IncidentTable } from '../components/tables/IncidentTable'
import { ErrorState, LoadingSkeleton, PageHeader, Panel } from '../components/ui'
import { demoMetrics } from '../demo/data'
import { useApiResource } from '../hooks/useApiResource'

export function IncidentsPage(){const navigate=useNavigate();const query=useApiResource(['incident-list'],dashboardApi.incidents,{items:demoMetrics.recent_incidents,total:demoMetrics.recent_incidents.length});return <div><PageHeader eyebrow="Case management" title="Incident Explorer" description="Search, sort, and inspect completed investigations with risk-based prioritization."/>{query.isLoading?<LoadingSkeleton rows={7}/>:query.isError&&!query.data?<ErrorState message="Incident records are unavailable." onRetry={()=>query.refetch()}/>:<Panel title="Investigations" eyebrow={`${query.data?.total||0} records`}><IncidentTable incidents={query.data?.items||[]} onSelect={id=>navigate(`/incidents/${encodeURIComponent(id)}`)}/></Panel>}</div>}
