# Presentation Speaker Notes

**Project:** AI-Powered Cybersecurity Incident Response Assistant  
**Presenter:** Hrushikeshreddy  
**Duration:** 10 minutes of required content plus a 15-second title and 15-second close (10:30 total).  
**Presentation order:** Title slide, sections 10–19, thank-you slide.

The measured classifier and retrieval results below are from the full sampled CIC-IDS2017 run. They do not describe the smaller portable demo. Keep the terms **prediction**, **similarity**, and **priority** distinct: none independently confirms a compromise. The hosted DeepEval result is partial, not an overall quality pass.

## Opening Title Slide (0:00–0:15)

Introduce the project as an explainable, evidence-backed assistant for network-flow investigations. Set the expectation that it supports analyst review: models and retrieval provide signals and context, while a person decides what to do.

## Slide 2 — 10. Problem Statement (0:15–1:00)

Security teams see many network alerts: a burst of connections, unusual packet rates, or a connection to an exposed service. The alert describes observed activity, but it does not tell us intent. A high traffic rate could resemble denial-of-service behavior, yet the analyst still needs to check the model signal, compare it with history, and decide what evidence to collect. Today those clues can be spread across dashboards and reports. The project addresses that gap by bringing evidence into one reviewable investigation. **Transition:** That same gap creates a business need for a more consistent workflow.

## Slide 3 — 11. Business Need (1:00–1:45)

The workflow has three jobs: identify signals, investigate them in context, and prioritize what needs attention. The practical value is not an unproven promise that an AI system will replace an analyst. It is that the analyst can inspect prediction, related records, explanation, and response suggestions in one place. That should make investigations easier to review and reduce context switching. I did not run a user study, so I cannot claim a measured reduction in investigation time or cost. **Transition:** I built the assistant to support those three jobs.

## Slide 4 — 12. Solution Overview (1:45–2:40)

An analyst supplies one network flow, often from a sample or CSV. Separate model outputs describe the predicted attack category, intrusion likelihood, and unusualness. The retrieval service looks for comparable historical flows, while a risk policy assigns a triage priority. SHAP shows which measured features influenced the classifier's prediction; those contributions are not proof of cause. A response service suggests defensive investigation steps. A hosted language model is optional: its structure and evidence references are checked, and a local playbook is available when hosted generation cannot be used. The analyst reviews the evidence and decides what to do. **Transition:** Here is how those pieces are arranged.

## Slide 5 — 13. Architecture (2:40–3:35)

There are two parts to the architecture. Offline, the data pipeline prepares CIC-IDS2017, trains and evaluates the models, and constructs the historical search index. Those saved assets are then loaded by the local application. Online, a React and TypeScript dashboard sends typed requests to FastAPI, where Pydantic validates the input. Specialist services coordinate classification, anomaly scoring, risk, SHAP, and retrieval. Retrieval combines TF-IDF/LSA vectors in FAISS with BM25 keyword scoring. Response generation can use the local evidence playbook or an optional provider. SQLite stores investigation and feedback records. **Transition:** I will follow one flow through that request path.

## Slide 6 — 14. Data Flow (3:35–4:30)

The API first checks flow features and metadata. The model services then return their separate predictions, and hybrid search ranks historical records. Similarity helps us find context; a match does not show that the new flow is the same attack. The risk policy uses configured signals to set a priority, and TreeSHAP displays feature contributions for the classifier result. If a generated response is requested, validation checks the structure and cited evidence before the response is used. The investigation is saved. Analyst feedback is retained for review; it does not automatically retrain the active model. **Transition:** These steps use a deliberately practical technology stack.

## Slide 7 — 15. Technology Stack (4:30–5:15)

The interface is React, TypeScript, Vite, Tailwind CSS, and Recharts. The service is Python with FastAPI, Pydantic, and pandas. Scikit-learn supplies the Random Forest classifier and Isolation Forest anomaly model; SHAP provides the feature-contribution view. For retrieval, the reported default is TF-IDF with latent semantic analysis, indexed in FAISS, alongside BM25. An optional NVIDIA Nemotron or other configured provider can write a response, and DeepEval measures selected quality dimensions. SQLite holds mutable investigation and feedback state. The measured system did not use pretrained sentence embeddings by default. **Transition:** These components are coordinated as specialist workflow roles.

## Slide 8 — 16. Agent Workflow (5:15–6:20)

The workflow roles run in sequence: detection, anomaly analysis, retrieval, risk assessment, explainability, response recommendation, and optional quality judging. A shared orchestrator checks what each step requires and what it returns, then records each role's status and timing. Calling them agents describes the coordinated software workflow; they are not seven independent autonomous chatbots. The response role proposes defensive steps but cannot execute containment. The quality judge needs a working, configured provider. If response generation fails validation, the local evidence-based playbook can still provide guidance; missing judge scores stay missing. The analyst makes the final decision. **Transition:** I will show that path in the running local app.

## Slide 9 — 17. Demo (6:20–8:20)

### Before presenting

1. From the project root, run `python scripts/start_local.py --restart --offline`.
2. Open the frontend URL printed by the launcher. It chooses available local ports; do not assume a deployment URL.
3. Confirm the Dashboard and Investigate pages load. The form auto-loads a supplied DDoS flow when available.
4. Keep **Use configured LLM** and **Run LLM judge** off for a deterministic offline walkthrough. The models, hybrid retrieval, SHAP, and local playbook do not need an LLM key.
5. Keep [the saved investigation screenshot](assets/investigation-result-desktop.png) ready as a visual backup.

### Two-minute live sequence

- **0:00–0:15 — Dashboard:** Point out the difference between historical dataset counts and incidents investigated in this session.
- **0:15–0:35 — Investigate:** Open the supplied DDoS flow and run with hosted generation and judging disabled.
- **0:35–0:55 — Signals:** Show attack category, probability, anomaly percentile, and policy priority as distinct values.
- **0:55–1:15 — Evidence:** Open one retrieved historical record. Explain that a similar record is context, not proof.
- **1:15–1:35 — Explain and respond:** Show SHAP feature contributions, the local playbook, and the agent trace. Point out validation or fallback status if visible.
- **1:35–1:55 — Feedback:** Show the feedback controls on the investigation and the feedback sections under AI Analyst and RAG Search. Submissions are saved for review; they do not retrain the model.
- **1:55–2:00 — Close demo:** Return to the investigation summary and restate that the analyst decides on any response action.

If time is short, prioritize the prediction, one retrieved record, SHAP explanation, local recommendation, and feedback status. If the live app is unavailable, use the saved screenshot and explain the same sequence. Do not describe an unavailable hosted judge as having produced scores.

**Transition:** These are the measured results and the limits I used to interpret them.

## Slide 10 — 18. Evaluation Results (8:20–9:35)

The nine-category Random Forest achieved 99.21 percent accuracy and 0.9743 macro F1 on a sampled holdout of 4,055 flows. The binary intrusion ROC AUC is 0.9961; the separate anomaly detector's ROC AUC is 0.7628. Retrieval Precision@5 rose from 62.86 percent for the unassisted baseline to 95.24 percent for the model-assisted hybrid on 42 held-out queries. Relevance here means same-category membership, a coarse proxy, and the assisted query uses model-derived hints. Hosted DeepEval completed 36 of 45 scores; five completed scores missed thresholds and nine scores were unavailable. That is partial measurement, not a quality pass. The release snapshot also recorded 203 backend and 27 React tests passing. The random sampled split and small rare-class support mean independent real-network validation remains necessary. **Transition:** Those limits shaped the next steps I would take.

## Slide 11 — 19. Challenges and Learnings (9:35–10:15)

The challenges were imbalanced traffic data, small rare-class holdouts, and hosted responses that can fail schema or citation checks. I learned to validate each hand-off and keep prediction, evidence and policy distinct. Next I would test with time- and host-separated data, complete quality coverage, study analyst usability, and add production-grade access controls. This prototype provides evidence for triage; a human analyst remains accountable for decisions. **Transition:** I will close with that central design principle.

## Slide 12 — Thank You (10:15–10:30)

Thank the audience and invite questions. The main takeaway is that evidence supports triage while the analyst makes the decision.

## Likely evaluator questions

**Does the system confirm compromise or block traffic?** No. It provides evidence and defensive options for analyst review.

**Is the risk score a probability?** No. It is a configurable triage-policy score. The classifier probabilities are separate.

**Does the language model classify the flow?** No. The tabular classifier predicts its category; a configured LLM may summarize supplied evidence.

**What does retrieval Precision@5 mean?** In this benchmark, it is the share of the top five results with the expected category. That is a coarse relevance proxy, not factual accuracy.

**Why is DeepEval incomplete?** Thirty-six of forty-five scores completed; eight metric calls errored and one timed out. Five completed scores missed thresholds.

**Did the project prove analyst time savings?** No. Reduced context switching is an intended benefit; a user study is needed.

**Can I run the demo without a key?** Yes. With the local/offline option, the model, retrieval, explanation, policy, and playbook work without hosted generation.
