import { render, screen } from '@testing-library/react'
import { describe, expect, it } from 'vitest'
import { DemoBanner, SeverityBadge } from './index'

describe('security UI primitives',()=>{
  it('communicates severity and priority in text',()=>{
    render(<SeverityBadge severity="CRITICAL" priority="P1"/>)
    expect(screen.getByText(/P1.*CRITICAL/)).toBeInTheDocument()
  })

  it('labels fallback records as demo data',()=>{
    render(<DemoBanner/>)
    expect(screen.getByText('DEMO DATA')).toBeInTheDocument()
    expect(screen.getByText(/live API is unavailable/i)).toBeInTheDocument()
  })
})
