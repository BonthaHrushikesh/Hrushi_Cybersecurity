import json
from collections import Counter
from datetime import datetime, timezone
from heapq import nlargest
from pathlib import Path
import re
from time import perf_counter

import faiss
import joblib
import numpy as np
from rank_bm25 import BM25Okapi

from src.api.schemas import HistoricalFlowSummary, HistoricalIncident, HistoricalMetrics, SearchHit, SearchRequest, SearchResult
from src.rag.ranking import expand_terms, reciprocal_rank_fusion, flow_similarity, select_diverse


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


def observed_time(value) -> datetime | None:
    try:
        observed = datetime.fromisoformat(value.replace("Z", "+00:00")) if isinstance(value, str) else value
        if isinstance(observed, datetime) and observed.tzinfo is not None:
            return observed.astimezone(timezone.utc)
    except (TypeError, ValueError):
        pass
    return None


def combine_scores(semantic: np.ndarray, keyword: np.ndarray, alpha: float) -> tuple[np.ndarray, np.ndarray]:
    positive = np.maximum(keyword, 0)
    normalized = positive / positive.max() if len(positive) and positive.max() > 0 else np.zeros_like(positive)
    return alpha * np.clip(semantic, 0, 1) + (1 - alpha) * normalized, normalized


def summarize_history(incidents: list[HistoricalIncident]) -> HistoricalMetrics:
    attacks, severities, days = Counter(), Counter(), Counter()
    dated = []
    missing = 0
    for incident in incidents:
        attacks[incident.attack_type] += 1
        severities[incident.severity] += 1
        value = incident.metadata.get("timestamp")
        observed = observed_time(value)
        if observed is not None:
            days[observed.date().isoformat()] += 1
        else:
            observed = None
            missing += 1
        dated.append((observed.timestamp() if observed else float("-inf"), incident, observed))
    latest = nlargest(20, dated, key=lambda row: (row[0], row[1].incident_id))
    return HistoricalMetrics(
        total_records=len(incidents), benign=attacks.get("BENIGN", 0),
        malicious=len(incidents) - attacks.get("BENIGN", 0),
        attack_distribution=dict(sorted(attacks.items())), severity_distribution=dict(severities),
        activity=[{"time": day, "incidents": count} for day, count in sorted(days.items())], timestamp_missing=missing,
        recent_records=[HistoricalFlowSummary(incident_id=incident.incident_id,
                                             timestamp=observed.isoformat() if observed else None,
                                             attack_type=incident.attack_type, severity=incident.severity,
                                             risk_score=incident.risk_score, risk_source=incident.risk_source)
                        for _, incident, observed in latest],
    )


class RetrievalService:
    def __init__(self, artifacts: Path, alpha: float = 0.65):
        directory = artifacts / "index"
        self.metadata = json.loads((directory / "metadata.json").read_text())
        self.incidents = [HistoricalIncident.model_validate(x) for x in json.loads((directory / "documents.json").read_text())]
        self.by_id = {x.incident_id: x for x in self.incidents}
        self.embeddings = joblib.load(directory / "embeddings.joblib")
        self.index = faiss.read_index(str(directory / "vectors.faiss"))
        self.bm25 = BM25Okapi([tokenize(x.document) for x in self.incidents])
        self.alpha = alpha
        if self.index.ntotal != len(self.incidents):
            raise ValueError("Vector index and incident documents have different lengths; rebuild the index")

    def summary(self) -> HistoricalMetrics:
        return summarize_history(self.incidents)

    def search(self, request: SearchRequest, exclude_id: str | None = None, flow_features: dict | None = None) -> SearchResult:
        started = perf_counter()
        filters = request.filters.model_dump(mode="json", exclude_none=True)
        eligible = []
        for i, incident in enumerate(self.incidents):
            if incident.incident_id == exclude_id:
                continue
            matched = True
            for name, value in filters.items():
                if name == "attack_type":
                    matched = matched and incident.attack_type == value
                elif name == "severity":
                    matched = matched and incident.severity == value
                elif name == "min_risk_score":
                    matched = matched and incident.risk_score >= value
                elif name in {"timestamp", "timestamp_min", "timestamp_max"}:
                    observed = observed_time(incident.metadata.get("timestamp"))
                    if observed is None:
                        matched = False
                    else:
                        boundary = getattr(request.filters, name)
                        if name == "timestamp_min":
                            matched = matched and observed >= boundary
                        elif name == "timestamp_max":
                            matched = matched and observed <= boundary
                        else:
                            matched = matched and observed == boundary
                else:
                    matched = matched and incident.metadata.get(name) == value
            if matched:
                eligible.append(i)
        alpha = request.alpha if request.alpha is not None else self.alpha
        alpha = 0.0 if request.mode == "keyword" else 1.0 if request.mode == "semantic" else alpha
        terms = expand_terms(request.query) if request.expand_query else []
        strategy = request.mode + "_" + request.fusion
        if not eligible:
            return SearchResult(results=[], alpha=alpha, embedding_provider=self.embeddings.provider,
                                latency_ms=(perf_counter() - started) * 1000,
                                strategy=strategy, expanded_terms=terms,
                                limitations=["No historical records match the filters. Missing metadata never matches a supplied filter."])
        semantic_all = np.zeros(len(self.incidents), dtype=float)
        limitations = ["Similarity scores are ranking scores, not attack probabilities.", "Historical severity uses the documented label prior, not an investigation score."]
        if alpha > 0:
            try:
                vector = self.embeddings.encode([request.query + " " + " ".join(terms)])
                scores, ids = self.index.search(vector, len(self.incidents))
                valid = ids[0] >= 0
                semantic_all[ids[0][valid]] = scores[0][valid]
            except Exception:
                if request.mode == "semantic":
                    return SearchResult(results=[], alpha=alpha, embedding_provider=self.embeddings.provider,
                                        latency_ms=(perf_counter() - started) * 1000, strategy="semantic_unavailable",
                                        expanded_terms=terms, candidate_count=len(eligible), limitations=["Semantic retrieval is unavailable; no semantic matches were generated."])
                alpha = 0.0
                strategy = "keyword_fallback"
                limitations.append("Semantic retrieval failed; BM25 keyword retrieval was used.")
        keyword_all = self.bm25.get_scores(tokenize(request.query)) if alpha < 1 else np.zeros(len(self.incidents))
        if terms and alpha < 1:
            keyword_all = keyword_all + 0.25 * self.bm25.get_scores(terms)
        semantic, keyword = semantic_all[eligible], keyword_all[eligible]
        hybrid, normalized = combine_scores(semantic, keyword, alpha)
        if request.fusion == "rrf" and request.mode == "hybrid":
            hybrid = reciprocal_rank_fusion(semantic, np.maximum(keyword, 0), alpha, max(100, request.top_k * 5))
        candidates = np.argsort(-hybrid, kind="stable")
        candidates = candidates[hybrid[candidates] > 1e-8][:max(100, request.top_k * 5)]
        feature_scores = {}
        if flow_features and len(candidates):
            for i in candidates:
                feature_scores[int(i)] = flow_similarity(flow_features, self.incidents[eligible[i]].features)
                hybrid[i] = 0.75 * hybrid[i] + 0.25 * feature_scores[int(i)]
            candidates = sorted(candidates, key=lambda i: -hybrid[i])
            strategy += "_flow_reranked"
            limitations.append("Feature reranking compares observed log-scaled traffic measurements; it is not calibrated attack evidence.")
        if request.diversify and len(candidates):
            # Reconstruct only the candidate pool, rather than the full vector corpus.
            vectors = {int(i): self.index.reconstruct(int(eligible[i])) for i in candidates}
            ranked = select_diverse(candidates, hybrid, vectors, request.top_k)
            strategy += "_diverse"
        else:
            ranked = candidates[:request.top_k]
        hits = [SearchHit(**self.incidents[eligible[i]].model_dump(), similarity_score=float(hybrid[i]),
                          semantic_score=float(np.clip(semantic[i], 0, 1)), keyword_score=float(keyword[i]),
                          normalized_keyword_score=float(normalized[i]), feature_similarity=feature_scores.get(int(i))) for i in ranked]
        return SearchResult(results=hits, alpha=alpha, embedding_provider=self.embeddings.provider,
                            latency_ms=round((perf_counter() - started) * 1000, 3),
                            strategy=strategy, expanded_terms=terms, candidate_count=len(eligible), limitations=limitations)
