# Panel Presentation: 10 Minutes

Participant: **Hrushikeshreddy**.  
Project: **AI-Powered Cybersecurity Incident Response Assistant**.  
Ten slides follow the required presentation sections 10–19 in order and total
600 seconds. The measured ML results describe model cicids-aa6f46dbeb on the full
sampled TrafficLabelling run, not the smaller portable demo. The hosted
DeepEval result is partial. A recent synthetic API check passed structured
recommendation and all seven judge dimensions; the RAG guardrail rejected an
answer that omitted an inline citation. The deck does not claim hosted output is
always available.

## Slide 1: 10. Problem Statement (45 Seconds)

Content:
- Network alerts contain measurements, not a confirmed explanation of an incident.
- Analysts must connect traffic, history, model signals, and response guidance.
- Fragmented tools make it difficult to compare evidence and record a decision.

Visual: Opening thesis and the gap between an alert and a defensible decision.

Speaker notes:
The problem is the gap between receiving a network alert and deciding what to investigate. A flow record contains measurements such as ports, packet rates, and duration. Those measurements do not establish intent, compromise, or business impact. Analysts still need to find comparable history, understand the model's view, decide how urgent the event is, and plan safe evidence collection. When these steps are split across tools, it is harder to see how the decision was reached. My project brings those pieces together while keeping the decision with the analyst.

## Slide 2: 11. Business Need (45 Seconds)

Content:
- Bring historical context, priority, and investigation guidance into one workspace.
- Make recommendations traceable to observed features and retrieved records.
- Reduce context switching as a design goal; analyst time savings were not measured.

Visual: Three analyst needs matched to the product's evidence, triage, and audit outputs.

Speaker notes:
The business need is a more consistent investigation workflow. An analyst needs context about similar activity, a transparent way to order work, and a record of why a recommendation was made. The assistant presents prediction, priority, feature explanation, related records, and response guidance in one investigation. The goal is to reduce context switching and make triage easier to review. I have not measured analyst time saved or return on investment, so I present those as goals for a future user study rather than proven outcomes.

## Slide 3: 12. Solution Overview (55 Seconds)

Content:
- Predict attack category, intrusion likelihood, and unusualness as separate signals.
- Retrieve comparable historical flows and explain classifier contributions.
- Return defensive next steps with local fallback when hosted output is unavailable.

Visual: Flow input becomes prediction, evidence, explanation, and analyst-reviewed guidance.

Speaker notes:
The solution accepts a flow from a sample, CSV, or analyst input. Separate models estimate the attack category, binary intrusion likelihood, and unusualness. Retrieval finds related historical flow records, while a triage policy combines signals into a priority. TreeSHAP shows which features influenced the category prediction. A response service produces defensive investigation steps. A hosted model can help summarize the evidence, but the application validates the structure and citations and falls back to a local playbook when needed. It never blocks traffic or confirms a compromise by itself.

## Slide 4: 13. Architecture (55 Seconds)

Content:
- Offline preparation trains models and builds the searchable historical index.
- React calls a FastAPI service that coordinates typed Python components.
- SQLite stores investigation and feedback records; hosted LLM use is optional.

Visual: Offline data and model preparation connected to the online analyst workflow.

Speaker notes:
The architecture separates offline preparation from online investigation. Offline, Python cleans and samples the CIC-IDS2017 data, trains the classifiers, and builds a retrieval index over historical flows. Online, the React interface submits requests to FastAPI. The service validates inputs and coordinates prediction, anomaly analysis, retrieval, risk scoring, explanation, and response services. FAISS supports vector search, BM25 supports keyword search, and SQLite stores investigation and feedback records. NVIDIA, OpenAI, or Anthropic can provide structured responses when configured, but the core local workflow does not depend on a hosted model.

## Slide 5: 14. Data Flow (55 Seconds)

Content:
- Validate flow features and metadata before using the active model.
- Run prediction, anomaly scoring, retrieval, triage, and feature explanation.
- Validate cited evidence and persist the result; keep analyst feedback under review.

Visual: Validated flow → model signals → evidence and explanations → response → reviewed record.

Speaker notes:
First, the API checks that a request contains supported, finite features and valid metadata. The prediction services calculate attack class, intrusion likelihood, and anomaly score. Retrieval searches the historical index and returns candidate records with stable IDs. The risk policy assigns priority, and TreeSHAP creates a feature explanation. These outputs are assembled into an evidence package for the response service. If hosted generation is enabled, the package is sent to the configured provider; the result must pass schema, citation, and safety checks. The application then returns and saves the investigation. Feedback remains pending until reviewed and is not used for automatic retraining.

## Slide 6: 15. Technology Stack (45 Seconds)

Content:
- Python, FastAPI, Pydantic, pandas, and scikit-learn power the backend.
- React, TypeScript, and Vite provide the analyst interface.
- FAISS, TF-IDF/LSA, BM25, SQLite, SHAP, and DeepEval support retrieval and evaluation.

Visual: Backend, interface, retrieval, and evaluation technologies grouped by role.

Speaker notes:
The backend uses Python with FastAPI and Pydantic for typed request and response validation. Pandas prepares data; scikit-learn provides Random Forest and Isolation Forest models; SHAP explains classifier output. The frontend uses React with TypeScript and Vite. Retrieval combines BM25 keyword scoring with TF-IDF and LSA vectors indexed in FAISS. SQLite stores investigation and feedback history. DeepEval measures hosted quality dimensions, and an optional NVIDIA Nemotron model handles generation and judging. The default embedding path is TF-IDF and LSA; the optional pretrained embedding package is not part of the measured baseline.

## Slide 7: 16. Agent Workflow (65 Seconds)

Content:
- Detection, anomaly, retrieval, risk, and explainability roles build shared evidence.
- Response uses a grounded playbook or validated hosted output; judge is optional.
- The analyst reviews findings and authorizes every response action.

Visual: Seven specialist roles with explicit human review at the end.

Speaker notes:
The workflow has seven specialist roles: detection, anomaly analysis, retrieval, risk scoring, explainability, response recommendation, and quality judging. They share a validated investigation record and expose status and timing in the agent trace. These are coordinated software components, not seven independent autonomous chatbots. The response role proposes defensive log checks and containment considerations. It does not execute them. The quality judge is optional and returns scores only when a valid provider response is available. If generation fails or fails validation, the local evidence-based playbook can still provide a recommendation, while unavailable judge scores remain absent.

## Slide 8: 17. Demo (120 Seconds)

Content:
- Open a supplied DDoS sample and run the local investigation.
- Review prediction, priority, SHAP explanation, and comparable history.
- Show the response, agent trace, and feedback review state.

Visual: A saved local investigation result as backup for the live demo.

Speaker notes:
I will demonstrate the application locally using a supplied sample so that the walkthrough does not depend on a hosted API key. On the dashboard I will distinguish historical dataset counts from investigations actually run in the application. I will open Investigate, select the DDoS sample, leave hosted generation and judging disabled, and run the request. I will review the model's predicted category and probabilities, then point out the separate anomaly result and triage priority. Next I will inspect a SHAP explanation and open one retrieved historical record, making clear that similarity does not confirm an attack. I will show the local defensive playbook and the agent trace. Finally, I will submit feedback and show that it remains pending review.

Demo sequence:
1. 0–15 seconds: Open the dashboard and explain historical versus newly investigated records.
2. 15–35 seconds: Open Investigate, choose the supplied DDoS sample, and run in local mode.
3. 35–55 seconds: Review category, confidence, anomaly signal, and P1–P4 priority.
4. 55–75 seconds: Open one retrieved historical match and inspect its incident ID and features.
5. 75–95 seconds: Show the SHAP explanation, local response, and evidence limitations.
6. 95–110 seconds: Submit feedback and show its pending-review status.
7. 110–120 seconds: Show the workflow trace or API documentation.

Backup: Use the saved investigation screenshot if the live environment is unavailable. Start with python scripts/start_local.py --restart --offline.

## Slide 9: 18. Evaluation Results (75 Seconds)

Content:
- Attack classification: 99.21% accuracy and 0.9743 macro F1 on 4,055 holdout flows.
- Retrieval Precision@5: 62.86% baseline and 95.24% model-assisted across 42 queries.
- Hosted DeepEval: 36/45 scores completed; five completed scores missed thresholds.

Visual: Held-out classification, retrieval lift, and honest hosted-quality coverage.

Speaker notes:
The Random Forest achieved 99.21 percent multiclass accuracy and a macro F1 of 0.9743 on the sampled holdout of 4,055 flows. The retrieval benchmark used 42 held-out queries and the top five results. Same-category precision was 62.86 percent for the unassisted baseline and 95.24 percent for the model-assisted path. That category match is a coarse retrieval proxy, not a measure of factual accuracy. The hosted DeepEval run measured 36 of 45 scores across nine categories. Five completed scores missed thresholds; eight metric calls failed and one timed out. Seven case generations used NVIDIA and all nine judge calls completed. This is partial evidence, not a quality pass. The backend and React regression suites reported 203 and 27 passing tests in the submission snapshot.

## Slide 10: 19. Challenges and Learnings (40 Seconds)

Content:
- Rare categories and random sampled splits limit confidence in real-network performance.
- Hosted outputs can fail structure or citation checks; fallback and honest missing scores matter.
- Next: temporal/host-separated validation, fuller quality coverage, and analyst usability study.

Visual: Constraints, engineering lessons, next validation, and a clear close for questions.

Speaker notes:
The main challenges are small rare-class support, a random sampled split, and inconsistent hosted responses. A model can return a successful HTTP response whose content still fails schema or citation validation. I learned to keep model inference, triage policy, and historical evidence separate, validate citations, and preserve a useful local path without inventing quality scores. Next I would test with time- or host-separated data, complete unavailable quality measurements, and study the workflow with analysts. Until then, the system should be treated as a capstone prototype, with response decisions kept under human control.

## Likely Panel Questions

| Question | Simple answer |
|---|---|
| Does the assistant confirm a compromise or block traffic? | No. It gives evidence and defensive options; an analyst decides what to do. |
| Does the LLM classify the attack? | No. The trained tabular model predicts the category; the optional LLM summarizes supplied evidence. |
| Is a risk score a probability? | No. It is a weighted triage-policy score, separate from model probabilities. |
| What does Precision@5 measure here? | The share of the top five retrieved flows with the expected category; category is a coarse relevance proxy. |
| Why is DeepEval partial? | Eight metric calls failed and one timed out; the run completed 36 of 45 scores, with five threshold misses. |
| Did you prove analyst time savings? | No. Reduced context switching is the business goal; time savings need a user study. |
| What is the main validation limitation? | The split is random and sampled; independent host- or time-separated data is still needed. |
| Can the demo run without a private API key? | Yes. The local models, retrieval, triage, explanation, and playbook work with hosted generation disabled. |

Delivery tips: Define SHAP and Precision@5 in plain language, use the local demo, distinguish prediction from confirmation, and present partial hosted quality scores as partial.
