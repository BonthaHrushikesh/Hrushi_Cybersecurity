import { ThumbsDown, ThumbsUp } from 'lucide-react'
import { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { feedbackApi } from '../../api'
import type { FeedbackInteractionType } from '../../types'

export function InteractionFeedbackForm({
  interactionType,
  context,
}: {
  interactionType: FeedbackInteractionType
  context: string
}) {
  const [helpful, setHelpful] = useState<boolean | null>(null)
  const [comment, setComment] = useState('')
  const mutation = useMutation({ mutationFn: feedbackApi.submit })

  const submit = () => {
    if (helpful === null) return
    mutation.mutate({ interaction_type: interactionType, context, helpful, comment })
  }

  if (mutation.isSuccess) {
    return <p role="status" className="rounded-lg border border-emerald-400/20 bg-emerald-400/[.05] p-4 text-sm text-emerald-300">
      Feedback recorded for analyst review. The question or search phrase is attached; the full response is not saved here.
    </p>
  }

  return <div className="space-y-4">
    <div>
      <span className="label">Was this {interactionType === 'ai_analyst' ? 'answer' : 'search'} useful?</span>
      <div className="flex flex-wrap gap-2">
        <button type="button" onClick={() => setHelpful(true)} className={`btn-secondary ${helpful === true ? 'border-emerald-400/40 text-emerald-300' : ''}`}>
          <ThumbsUp size={15} />Useful
        </button>
        <button type="button" onClick={() => setHelpful(false)} className={`btn-secondary ${helpful === false ? 'border-red-400/40 text-red-300' : ''}`}>
          <ThumbsDown size={15} />Needs improvement
        </button>
      </div>
    </div>
    <label>
      <span className="label">Optional note</span>
      <textarea maxLength={2000} className="field min-h-20" value={comment} onChange={event => setComment(event.target.value)} placeholder="What should be clearer, more relevant, or better grounded?" />
    </label>
    {mutation.isError && <p role="alert" className="text-xs text-red-400">Feedback could not be submitted. Check that the API is available and try again.</p>}
    <button type="button" className="btn-primary" disabled={helpful === null || mutation.isPending} onClick={submit}>
      {mutation.isPending ? 'Submitting...' : 'Submit feedback'}
    </button>
    <p className="text-xs text-zinc-600">Feedback is stored for human review and does not change the model automatically.</p>
  </div>
}
