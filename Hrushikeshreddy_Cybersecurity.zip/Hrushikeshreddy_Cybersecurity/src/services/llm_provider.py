import json
import os
from typing import TypeVar

from pydantic import BaseModel

from src.utils.config import Settings

Output = TypeVar("Output", bound=BaseModel)


def nvidia_completion(config: Settings, instructions: str, content: str,
                      schema: type[Output] | None = None, *, judge: bool = False, max_tokens: int = 4096):
    from openai import OpenAI

    options = {}
    if "nemotron" in (config.evaluation_model if judge else config.generation_model).lower():
        options["extra_body"] = {"chat_template_kwargs": {"enable_thinking": config.nvidia_enable_thinking}}
    if schema is not None:
        options["response_format"] = {"type": "json_schema", "json_schema": {
            "name": schema.__name__, "schema": schema.model_json_schema(), "strict": True}}
        instructions += " Return only a JSON object conforming to the supplied response schema."
    with OpenAI(api_key=os.getenv("NVIDIA_API_KEY"), base_url=config.nvidia_base_url,
                timeout=config.llm_timeout_seconds, max_retries=0) as client:
        response = client.chat.completions.create(
            model=config.evaluation_model if judge else config.generation_model,
            messages=[{"role": "system", "content": instructions}, {"role": "user", "content": content}],
            temperature=0.1, max_tokens=max_tokens, stream=False, **options)
    if not response.choices or response.choices[0].finish_reason != "stop":
        raise ValueError("NVIDIA did not complete the response")
    message = response.choices[0].message
    if message.refusal or not message.content:
        raise ValueError("NVIDIA returned no usable output")
    return schema.model_validate_json(message.content) if schema is not None else message.content


def generate_structured(config: Settings, instructions: str, payload: dict,
                        schema: type[Output], *, judge: bool = False) -> Output:
    model = config.evaluation_model if judge else config.generation_model
    content = json.dumps(payload, allow_nan=False)
    if config.llm_provider == "openai":
        from openai import OpenAI

        with OpenAI(timeout=config.llm_timeout_seconds, max_retries=0) as client:
            response = client.responses.parse(model=model, instructions=instructions, input=content,
                                              text_format=schema, store=False)
        parsed = response.output_parsed
    elif config.llm_provider == "anthropic":
        from anthropic import Anthropic

        with Anthropic(timeout=config.llm_timeout_seconds, max_retries=0) as client:
            response = client.messages.parse(model=model, system=instructions, max_tokens=4096,
                                             messages=[{"role": "user", "content": content}], output_format=schema)
        if response.stop_reason != "end_turn":
            raise ValueError("Claude did not complete the structured response")
        parsed = response.parsed_output
    elif config.llm_provider == "nvidia":
        parsed = nvidia_completion(config, instructions, content, schema, judge=judge)
    else:
        raise ValueError("Structured generation requires a remote LLM provider")
    if parsed is None:
        raise ValueError("Provider returned no structured output")
    return schema.model_validate(parsed)
