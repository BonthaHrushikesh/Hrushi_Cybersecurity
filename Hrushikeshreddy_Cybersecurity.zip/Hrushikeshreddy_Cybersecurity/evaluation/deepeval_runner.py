import argparse
import json
import math
import os
from pathlib import Path
import sys
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("DEEPEVAL_TELEMETRY_OPT_OUT", "YES")
os.environ.setdefault("CONFIDENT_TELEMETRY_OPT_OUT", "YES")

from src.utils.config import settings
from src.services.artifact_reports import write_report


def structural_score(test_case) -> tuple[float, str]:
    """A verifiable local check, not an LLM assessment of prose quality."""
    try:
        from src.api.schemas import Analysis
        analysis = Analysis.model_validate_json(test_case.actual_output)
        documents = [json.loads(x) for x in test_case.retrieval_context]
        available = {x["incident_id"] for x in documents if "incident_id" in x}
        supported = set(analysis.historical_incident_ids) <= available
        complete = all([analysis.executive_summary, analysis.model_inference, analysis.evidence_limitations,
                        analysis.immediate_investigation, analysis.containment_considerations,
                        analysis.further_evidence, analysis.longer_term_mitigation])
        score = float(supported and complete)
        return score, f"Citation IDs supported={supported}; required analysis sections present={complete}. This does not verify every factual claim."
    except (ValueError, TypeError, KeyError):
        return 0.0, "Analysis or supplied context failed structural validation."


def build_structural_metric():
    from deepeval.metrics import BaseMetric

    class StructuralGroundingMetric(BaseMetric):
        threshold = 1.0
        async_mode = False
        strict_mode = True
        evaluation_model = "local_structure_checker"

        def measure(self, test_case, *args, **kwargs):
            self.score, self.reason = structural_score(test_case)
            self.success = self.score >= self.threshold
            return self.score

        async def a_measure(self, test_case, *args, **kwargs):
            return self.measure(test_case)

        def is_successful(self):
            return self.success

        @property
        def __name__(self):
            return "Structural grounding (non-LLM)"

    return StructuralGroundingMetric()


def quality_limitation(report: dict, case_count: int) -> str:
    """Summarize coverage and threshold failures without exposing judge prompts."""
    metric_items = [item for row in report.get("llm_metrics", []) for item in row.get("metrics", [])]
    completed = sum(item.get("status") == "completed" for item in metric_items)
    threshold_failures = sum(item.get("passed") is False for item in metric_items)
    analysis_providers = report.get("analysis_providers", {})
    local_fallbacks = sum(provider != report.get("llm_provider") for provider in analysis_providers.values())
    return (
        f"Hosted DeepEval completed {completed}/{len(metric_items)} metric scores across {case_count} cases; "
        f"{len(metric_items) - completed} metric calls were unavailable and {threshold_failures} completed scores "
        f"missed their thresholds. {local_fallbacks} case generations used local fallback. "
        "See per-category results before drawing a quality conclusion."
    )


def run(offline: bool = False, config=settings) -> dict:
    from deepeval.test_case import LLMTestCase
    from src.api.application import Services
    from evaluation.evaluation_dataset import build_cases

    services = Services(config)
    if services.orchestrator is None:
        raise RuntimeError(services.load_error)
    services.orchestrator.persist = False
    live = not offline and config.credentials_configured
    dataset = build_cases(services, use_llm=live, judge=live)
    directory = config.artifacts / "evaluation"
    directory.mkdir(parents=True, exist_ok=True)
    cases_path = directory / ("offline_rag_cases.json" if offline else "rag_cases.json")
    cases_path.write_text(json.dumps(dataset, indent=2, allow_nan=False), encoding="utf-8")
    cases = [LLMTestCase(**item) for item in dataset]
    structural = build_structural_metric()
    checks = [{"category": case.metadata["category"], "score": structural.measure(case), "reason": structural.reason} for case in cases]
    report = {"framework": "DeepEval", "case_count": len(cases), "offline_structural_checks": checks,
              "llm_metrics_status": "not_run_offline" if offline else "not_configured", "llm_metrics": [],
              "created_at": datetime.now(timezone.utc).isoformat(), "model_version": services.models.bundle["version"],
              "llm_provider": config.llm_provider,
              "generation_model": config.generation_model, "judge_model": config.evaluation_model,
              "analysis_providers": {case.metadata["category"]: case.metadata["analysis_provider"] for case in cases},
              "judge_results": {case.metadata["category"]: case.metadata["judge"] for case in cases}}
    provider_responded = any(value == config.llm_provider for value in report["analysis_providers"].values()) and any(value and value["status"] == "completed" for value in report["judge_results"].values())
    if live and provider_responded:
        from deepeval.metrics import (AnswerRelevancyMetric, FaithfulnessMetric, ContextualPrecisionMetric,
                                      ContextualRecallMetric, HallucinationMetric)
        model = config.evaluation_model
        if config.llm_provider == "anthropic":
            from deepeval.models import AnthropicModel
            model = AnthropicModel(model=config.evaluation_model, api_key=os.getenv(config.api_key_env),
                                   timeout=config.llm_timeout_seconds, max_retries=0, max_tokens=4096)
        elif config.llm_provider == "nvidia":
            from evaluation.nvidia_judge import NvidiaJudgeModel
            model = NvidiaJudgeModel(config)
        metrics = [AnswerRelevancyMetric(model=model), FaithfulnessMetric(model=model),
                   ContextualPrecisionMetric(model=model), ContextualRecallMetric(model=model),
                   HallucinationMetric(model=model)]
        for case in cases:
            values = []
            for metric in metrics:
                try:
                    metric.measure(case)
                    if (isinstance(metric.score, bool) or not isinstance(metric.score, (int, float)) or
                            not math.isfinite(metric.score) or not 0 <= metric.score <= 1):
                        raise ValueError("Metric did not return a finite quality score")
                    values.append({"metric": metric.__name__, "status": "completed", "score": metric.score,
                                   "reason": metric.reason, "passed": metric.is_successful()})
                except Exception as error:
                    values.append({"metric": metric.__name__, "status": "unavailable", "error_type": type(error).__name__})
            report["llm_metrics"].append({"category": case.metadata["category"], "metrics": values})
        failed = any(item["status"] != "completed" for row in report["llm_metrics"] for item in row["metrics"])
        report["llm_metrics_status"] = "partial" if failed else "completed"
        report["live_generation_verified"] = all(provider == config.llm_provider for provider in report["analysis_providers"].values())
        report["live_judge_verified"] = all(result and result["status"] == "completed" for result in report["judge_results"].values())
        report["limitation"] = quality_limitation(report, len(cases))
    else:
        report["limitation"] = "Built-in DeepEval quality metrics require a configured judge provider; no quality scores were fabricated. Offline checks verify structure and citation membership only."
        if offline:
            report["limitation"] = "Offline evaluation was requested; no LLM quality calls were made. Structural checks verify sections and citation membership, not prose quality."
        if live:
            report["llm_metrics_status"] = "unavailable"
            report["limitation"] = "Live generation/judging could not be verified; additional quality requests were skipped."
        report["live_generation_verified"] = report["live_judge_verified"] = False
    write_report(directory / ("offline_quality.json" if offline else "deepeval.json"), report)
    print(json.dumps({"framework": report["framework"], "cases": len(cases), "llm_metrics_status": report["llm_metrics_status"], "structural_checks_passed": sum(x["score"] == 1 for x in checks)}, indent=2))
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--offline", action="store_true")
    run(parser.parse_args().offline)
