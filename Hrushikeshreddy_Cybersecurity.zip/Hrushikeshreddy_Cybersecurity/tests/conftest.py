from dataclasses import replace
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pytest
from fastapi.testclient import TestClient

from src.utils.config import settings
from src.api.application import create_app


@pytest.fixture(scope="session")
def client(tmp_path_factory):
    artifacts = tmp_path_factory.mktemp("artifacts")
    for name in ["models", "index", "evaluation"]:
        (artifacts / name).symlink_to(settings.artifacts / name, target_is_directory=True)
    config = replace(settings, artifacts=artifacts, llm_provider="local")
    with TestClient(create_app(config)) as instance:
        yield instance


@pytest.fixture(scope="session")
def sample(client):
    return next(x for x in client.get("/api/v1/samples").json() if x["attack_type"] == "DDoS")


@pytest.fixture(scope="session")
def investigation(client, sample):
    response = client.post("/api/v1/investigate", json={"flow": {"features": sample["features"]}, "query": "Investigate this suspicious denial of service flow", "use_llm": False, "judge": True})
    assert response.status_code == 200, response.text
    return response.json()
