import json
import os
from pathlib import Path
import tempfile


def _reject_nonfinite(value):
    raise ValueError("Report contains a non-finite JSON number")


def read_report(path: Path) -> dict:
    try:
        report = json.loads(path.read_text(encoding="utf-8"), parse_constant=_reject_nonfinite)
        if isinstance(report, dict):
            return report
    except (OSError, ValueError):
        pass
    return {"status": "unavailable", "limitation": "Report artifact is missing or unreadable."}


def write_report(path: Path, report: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, prefix=path.name, suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(report, handle, indent=2, allow_nan=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary:
            temporary.unlink(missing_ok=True)


def model_report(path: Path, model_version: str) -> dict:
    report = read_report(path)
    if report.get("status") == "unavailable":
        return report
    version = report.get("model_version", report.get("version"))
    if version != model_version:
        return {"status": "stale" if version else "unverified", "model_version": version,
                "limitation": "Rerun this evaluation for the active model; report provenance does not match."}
    return report


def connection_report(config) -> dict:
    if config.llm_provider == "local":
        return {"status": "not_required", "limitation": "Local providers are selected; no hosted authentication is required."}
    report = read_report(config.artifacts / "evaluation/provider_connection.json")
    matches = all([report.get("provider") == config.llm_provider,
                   report.get("generation_model") == config.generation_model,
                   report.get("judge_model") == config.evaluation_model,
                   report.get("credential_fingerprint") == config.credential_fingerprint])
    if report.get("status") != "unavailable" and not matches:
        report = {"status": "not_probed", "limitation": "Provider configuration or credentials changed; authentication must be rechecked."}
    return {key: value for key, value in report.items() if key != "credential_fingerprint"}
