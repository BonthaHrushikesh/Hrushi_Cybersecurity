import { BrainCircuit, Info, Scale } from "lucide-react";
import { healthApi, explainApi } from "../api";
import { ShapChart } from "../components/charts";
import {
  LoadingSkeleton,
  ErrorState,
  MetricCard,
  PageHeader,
  Panel,
} from "../components/ui";
import { demoExplanation, demoModel } from "../demo/data";
import { useApiResource } from "../hooks/useApiResource";
import { formatNumber, titleCase } from "../utils/format";

export function ExplainabilityPage() {
  const global = useApiResource(
    ["global-explain"],
    explainApi.global,
    demoExplanation,
  );
  const model = useApiResource(["model-info"], healthApi.model, demoModel);
  if (global.isLoading || model.isLoading) return <LoadingSkeleton rows={7} />;
  if (!global.data || !model.data) return <ErrorState message="Model explanations are unavailable." onRetry={() => { global.refetch(); model.refetch(); }} />;
  const metadata = model.data?.metadata || {};
  const importance = global.data?.global_importance || [];
  const local = importance.map((item) => ({
    feature: item.feature,
    observed_value: null,
    shap_value: item.importance,
    direction: "global importance",
  }));
  const patterns = global.data?.attack_patterns || {};
  return (
    <div>
      <PageHeader
        eyebrow="Model intelligence"
        title="Explainability & Model Insights"
        description="Inspect global feature importance, attack-pattern profiles, and the limits of model explanation."
      />
      {global.data.limitations?.map((limitation) => <p key={limitation} role="status" className="mb-4 border-l-2 border-amber-400 bg-amber-400/5 px-3 py-2 text-xs text-amber-200">{limitation}</p>)}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          icon={BrainCircuit}
          title="Model"
          value={String(metadata.name || "Ensemble")}
          context={String(metadata.version || "Version unavailable")}
          selected
        />
        <MetricCard
          icon={Scale}
          title="Classes"
          value={String(
            Array.isArray(metadata.classes) ? metadata.classes.length : "—",
          )}
          context="CIC-IDS2017 categories"
        />
        <MetricCard
          icon={Info}
          title="Method"
          value="TreeSHAP"
          context="Exact local contribution analysis"
        />
        <MetricCard
          icon={BrainCircuit}
          title="Features"
          value={String(importance.length)}
          context="Ranked global importance"
        />
      </div>
      <div className="mt-5 grid gap-5 xl:grid-cols-[1.2fr_.8fr]">
        <Panel
          title="Global Feature Importance"
          eyebrow={global.data?.importance_method || "Model metadata"}
        >
          <ShapChart
            features={local}
          />
          <p className="text-xs text-zinc-500">
            Global importance summarizes model usage across training data. It is
            not causal evidence.
          </p>
        </Panel>
        <Panel title="Interpretation Guide" eyebrow="Responsible use">
          <div className="space-y-4 text-sm text-zinc-400">
            <div>
              <strong className="text-zinc-200">
                Positive local contribution
              </strong>
              <p className="mt-1 text-xs leading-5">
                Pushes the prediction toward the selected attack class for that
                flow.
              </p>
            </div>
            <div>
              <strong className="text-zinc-200">
                Negative local contribution
              </strong>
              <p className="mt-1 text-xs leading-5">
                Pushes the prediction away from the selected attack class.
              </p>
            </div>
            <div>
              <strong className="text-zinc-200">Operational boundary</strong>
              <p className="mt-1 text-xs leading-5">
                Feature attribution explains model behavior, not attacker
                intent, attribution, or business impact.
              </p>
            </div>
          </div>
        </Panel>
        <Panel
          title="Attack Pattern Profiles"
          eyebrow="Dataset relationships"
          className="xl:col-span-2"
        >
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Attack type</th>
                  <th>Flow packets/s</th>
                  <th>Flow bytes/s</th>
                  <th>Duration</th>
                  <th>Destination port</th>
                </tr>
              </thead>
              <tbody>
                {!Object.keys(patterns).length && <tr><td colSpan={5} className="py-8 text-center text-zinc-500">Attack-pattern profiles are unavailable.</td></tr>}
                {Object.entries(patterns)
                  .slice(0, 12)
                  .map(([attack, values]) => (
                    <tr key={attack}>
                      <td className="font-medium text-zinc-100">
                        {titleCase(attack)}
                      </td>
                      {[
                        "flow_packets_s",
                        "flow_bytes_s",
                        "flow_duration",
                        "destination_port",
                      ].map((key) => (
                        <td key={key} className="font-mono text-xs">
                          {typeof values[key] === 'number' && Number.isFinite(values[key]) ? formatNumber(values[key]) : 'Not provided'}
                        </td>
                      ))}
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
          <p className="mt-4 text-xs text-zinc-600">{global.data?.note}</p>
        </Panel>
      </div>
    </div>
  );
}
