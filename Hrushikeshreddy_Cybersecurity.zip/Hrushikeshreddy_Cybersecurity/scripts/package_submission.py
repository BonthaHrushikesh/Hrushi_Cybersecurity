"""Build a local, allowlisted submission ZIP. Never publishes or reads parent Git."""

import argparse
import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZIP_DEFLATED, ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dotenv import dotenv_values

from src.utils.config import ROOT, settings


PROJECT = "Hrushikeshreddy_Cybersecurity"
DIRECTORIES = ["src", "app", "ml", "scripts", "evaluation", "tests", "frontend", "docs", "architecture", "design", "presentation", ".github"]
ROOT_FILES = ["README.md", "SUBMISSION_CHECKLIST.md", "requirements.txt", "requirements-dev.txt", "requirements-embeddings.txt", ".env.example", ".gitignore", ".dockerignore", "Dockerfile", "docker-compose.yml", "pytest.ini"]
REQUIRED = ["architecture/Architecture_Diagram.pdf", "design/Design_Document.pdf", "docs/API_Documentation.pdf", "docs/Dataset_Details.pdf", "docs/Evaluation_Report.pdf", "presentation/Project_Presentation.pdf", "data/sample_data/cicids2017_labelled_sample.csv", "README.md", "src/main.py", "src/api/application.py", "src/agents/orchestrator.py", "src/rag/document_builder.py", "src/services/models.py", "src/utils/config.py", "app/services/embeddings.py"]
REPORTS = ["classification", "retrieval", "advanced_retrieval", "offline_quality", "prd_readiness", "source_comparison"]
SCREENSHOTS = ["dashboard-desktop", "dashboard-mobile", "models-desktop", "search-desktop", "workflow-desktop", "explainability-desktop", "evaluation-desktop", "investigation-result-desktop"]


def allowed(path):
    forbidden = {"node_modules", "dist", "__pycache__", ".pytest_cache", ".git", ".venv"}
    environment_file = path.name.startswith(".env") and path.name != ".env.example"
    return not forbidden.intersection(path.parts) and path.suffix not in {".pyc", ".log", ".db", ".sqlite", ".sqlite3", ".sqlite-wal", ".sqlite-shm", ".tsbuildinfo", ".pem", ".key"} and not environment_file and path.name != ".DS_Store" and not path.is_symlink()


def build(output):
    files = {}
    for directory in DIRECTORIES:
        for path in (ROOT / directory).rglob("*"):
            relative = path.relative_to(ROOT)
            if path.is_file() and allowed(relative) and not path.is_symlink():
                if relative.as_posix() in {"frontend/vite.config.js", "frontend/vite.config.d.ts"}:
                    continue
                if relative.as_posix() in {"docs/AI_Cybersecurity_SOC_Architecture.pdf", "docs/architecture_report.html"}:
                    continue
                files[relative.as_posix()] = path.read_bytes()
    for name in ROOT_FILES:
        path = ROOT / name
        if path.exists():
            files[name] = path.read_bytes()
    for path in (ROOT / "data/sample_data").glob("*.csv"):
        files[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    for name in SCREENSHOTS:
        path = ROOT / f"artifacts/figures/{name}.png"
        if path.exists():
            files[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    for name in REPORTS:
        path = settings.artifacts / "evaluation" / f"{name}.json"
        if path.exists():
            data = json.loads(path.read_text())
            files[f"docs/evidence/{name}.json"] = json.dumps(data, indent=2, allow_nan=False).encode()
    missing = [name for name in REQUIRED if name not in files]
    if missing:
        raise ValueError(f"Required deliverables missing: {missing}")
    private = dotenv_values(ROOT / ".env")
    secrets = [value.encode() for key, value in private.items() if value and any(word in key.upper() for word in ["API_KEY", "TOKEN", "PASSWORD", "SECRET"]) and len(value) >= 8]
    text_suffixes = {".py", ".ts", ".tsx", ".js", ".json", ".html", ".md", ".txt", ".yaml", ".yml", ".toml", ".csv", ".css"}
    for name, payload in files.items():
        if Path(name).suffix in text_suffixes or name.startswith("."):
            if any(secret in payload for secret in secrets):
                raise ValueError(f"Private credential detected in candidate file: {name}")
            if b'"credential_fingerprint"' in payload and name.startswith("docs/"):
                raise ValueError(f"Private probe data detected: {name}")
    manifest = {"project": PROJECT, "participant": "Hrushikeshreddy", "github_profile": "https://github.com/BonthaHrushikesh",
                "repository_url": None, "frontend": "React only by participant request; Streamlit guideline deviation pending acceptance",
                "live_llm_evidence": "Deferred by participant; hosted generation, judge, and quality measurements are not verified",
                "files": {name: hashlib.sha256(value).hexdigest() for name, value in sorted(files.items())}}
    files["SUBMISSION_MANIFEST.json"] = json.dumps(manifest, indent=2).encode()
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(".tmp")
    try:
        with ZipFile(temporary, "w", ZIP_DEFLATED) as archive:
            for name, payload in sorted(files.items()):
                archive.writestr(f"{PROJECT}/{name}", payload)
        temporary.replace(output)
    finally:
        temporary.unlink(missing_ok=True)
    print(json.dumps({"archive": str(output), "files": len(files), "bytes": output.stat().st_size,
                      "secrets_excluded": True, "published": False}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "submission" / f"{PROJECT}.zip")
    build(parser.parse_args().output)
