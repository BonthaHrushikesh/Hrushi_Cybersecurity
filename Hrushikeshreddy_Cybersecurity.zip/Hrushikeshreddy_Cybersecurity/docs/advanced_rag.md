# Advanced Retrieval And Grounded Answers

The search API supports three modes: hybrid, keyword (BM25 only), and semantic
(FAISS only). Keyword mode does not call the embedding provider. Metadata filters
are applied before eligible records are ranked, and missing metadata never matches
a supplied filter.

The weighted baseline remains available. Advanced hybrid retrieval uses weighted
reciprocal-rank fusion of positive semantic and keyword results, with rank constant
60 and a bounded candidate pool. This avoids relying on comparable BM25/cosine
score scales. Scores remain ranking indicators, not probabilities.

Optional domain query expansion recognizes terms such as SQLi, XSS, C2, SSH,
brute force, and DDoS. Original BM25 terms retain full weight; expansion terms have
quarter weight. Expansion never invents measured flow data or applies inferred
metadata filters. Optional MMR evidence selection penalizes redundant semantic
vectors. During investigations, candidates are reranked using log-scaled observed
traffic-feature similarity and exact destination-port agreement. Historical labels
are not used by this feature-distance calculation. Model hypotheses remain soft
query hints and can reinforce classification errors.

Investigations and RAG answers default to advanced fusion, expansion, and diversity.
The /api/v1/search default preserves the weighted baseline. Threat Search exposes
mode selection and an advanced-ranking toggle.

POST /api/v1/rag/answer retrieves historical evidence and generates a structured
answer, cited IDs, evidence gaps, and next steps. Context packing limits historical
evidence to 18,000 characters. It passes structured traffic facts and metadata
availability, omitting host values and raw document prose. Generated answers must
cite supplied IDs inline; unknown citations, unsupported CVEs, common unsafe
patterns, malformed output, and provider failures trigger an explicitly labeled
local evidence extract. No history produces an insufficient-evidence answer.

The AI Analyst page calls this endpoint directly. OpenAI generation requires
LLM_PROVIDER=openai and OPENAI_API_KEY in .env. Local mode remains executable
without a key and is explicitly labeled. Built-in citation validation does not
establish the correctness of every natural-language claim. The existing
investigation endpoint can request the separate LLM-as-Judge assessment.

Example search:

```json
{
  "query": "SSH brute force repeated authentication failures",
  "mode": "hybrid",
  "fusion": "rrf",
  "expand_query": true,
  "diversify": true,
  "top_k": 8,
  "filters": {"attack_type": "Brute Force"}
}
```

Use the same JSON with use_llm=true for /api/v1/rag/answer.
Run python evaluation/advanced_retrieval.py for a measured comparison on 35
held-out flows. Results are saved separately to
artifacts/evaluation/advanced_retrieval.json, retaining previous benchmark reports.

The shipped embedding index uses LSA unless rebuilt with sentence_transformers.
The existing requirements-embeddings.txt and build_index.py support pretrained
sentence embeddings; switching requires installation, a model download, index
rebuild, and backend restart. No neural reranker is claimed by this implementation.
