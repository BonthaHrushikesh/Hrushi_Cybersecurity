import { AlertTriangle, Database, RadioTower, RefreshCw, ScanLine, ShieldAlert, ShieldCheck } from "lucide-react";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { dashboardApi } from "../api";
import {
  ActivityChart,
  AttackDistributionChart,
  PriorityChart,
} from "../components/charts";
import { IncidentTable } from "../components/tables/IncidentTable";
import { MetricCard, PageHeader, Panel, LoadingSkeleton, ErrorState } from "../components/ui";
import { demoMetrics } from "../demo/data";
import { useApiResource } from "../hooks/useApiResource";
import { formatNumber } from "../utils/format";

export function DashboardPage() {
  const navigate = useNavigate();
  const [scope, setScope] = useState<"historical" | "investigations">("historical");
  const metrics = useApiResource(
    ["metrics"],
    dashboardApi.metrics,
    demoMetrics,
  );
  const data = metrics.data || demoMetrics;
  const history = data.historical_summary;
  const historical = scope === "historical";
  const critical = data.priority_distribution.P1 || 0;
  const avgRisk = data.recent_incidents.length
    ? data.recent_incidents.reduce((s, x) => s + x.risk_score, 0) /
      data.recent_incidents.length
    : 0;
  const activity = useMemo(() => {
    const bins = new Map<string, number>();
    data.recent_incidents.forEach((item) => {
      const key = new Date(item.created_at).toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      });
      bins.set(key, (bins.get(key) || 0) + 1);
    });
    return [...bins].map(([time, incidents]) => ({ time, incidents }));
  }, [data]);
  if (!metrics.data) return metrics.isLoading ? <LoadingSkeleton rows={8} /> : <ErrorState message="Live operational metrics are unavailable." onRetry={() => metrics.refetch()} />;
  return (
    <div>
      <PageHeader
        eyebrow="SOC overview"
        title="Security Operations Dashboard"
        description="Historical network traffic and saved analyst investigations."
        action={
          <button
            className="btn-primary"
            onClick={() => navigate("/investigate")}
          >
            <ScanLine size={15} />
            Investigate flow
          </button>
        }
      />
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3 border-b border-white/[.07] pb-4">
        <div role="tablist" aria-label="Dashboard data source" className="flex max-w-full rounded-md border border-white/10 p-1">
          <button role="tab" aria-selected={historical} onClick={() => setScope("historical")} className={`inline-flex min-h-9 items-center gap-2 rounded px-3 text-sm ${historical ? 'bg-gold/10 text-gold' : 'text-zinc-500'}`}><Database size={15} />Historical traffic</button>
          <button role="tab" aria-selected={!historical} onClick={() => setScope("investigations")} className={`inline-flex min-h-9 items-center gap-2 rounded px-3 text-sm ${!historical ? 'bg-gold/10 text-gold' : 'text-zinc-500'}`}><ScanLine size={15} />Investigations</button>
        </div>
        <button className="icon-btn" aria-label="Refresh dashboard" title="Refresh dashboard" disabled={metrics.isFetching} onClick={() => metrics.refetch()}><RefreshCw size={16} className={metrics.isFetching ? 'animate-spin' : ''} /></button>
      </div>
      {historical && !history ? (
        <ErrorState message="Historical traffic summary is unavailable." onRetry={() => metrics.refetch()} />
      ) : (
      <>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          icon={RadioTower}
          title={historical ? "Historical flows" : "Analyzed"}
          value={formatNumber(historical ? history?.total_records ?? 0 : data.total_analyzed, 0)}
          context={historical ? "Indexed CIC-IDS2017 records" : "Saved analyst investigations"}
          selected
        />
        <MetricCard
          icon={ShieldAlert}
          title="Malicious"
          value={formatNumber(historical ? history?.malicious ?? 0 : data.malicious, 0)}
          context={historical ? "Historical attack labels" : "Model-classified investigations"}
        />
        <MetricCard
          icon={historical ? ShieldCheck : AlertTriangle}
          title={historical ? "Benign" : "P1 critical"}
          value={formatNumber(historical ? history?.benign ?? 0 : critical, 0)}
          context={historical ? "Historical BENIGN labels" : "Immediate analyst review"}
        />
        <MetricCard
          icon={Database}
          title={historical ? "Traffic categories" : "Average risk"}
          value={historical ? formatNumber(Object.keys(history?.attack_distribution ?? {}).length, 0) : (data.operational_quality?.mean_risk_score ?? avgRisk).toFixed(0)}
          context={historical ? "Attack labels and BENIGN" : "Across stored investigations"}
        />
      </div>
      <div className="mt-5 grid gap-5 xl:grid-cols-3">
        <Panel
          title={historical ? "Capture Activity" : "Incident Activity"}
          eyebrow={historical ? "Historical capture days (UTC)" : "Recent investigations"}
          className="xl:col-span-2"
        >
          <ActivityChart
            data={
              historical ? history?.activity ?? [] : activity.length
                ? activity
                : [{ time: "No activity", incidents: 0 }]
            }
          />
        </Panel>
        <Panel title={historical ? "Historical Severity" : "Priority Queue"} eyebrow={historical ? "Label-based severity" : "Current investigation distribution"}>
          <PriorityChart data={historical ? history?.severity_distribution ?? {} : data.priority_distribution} />
        </Panel>
        <Panel
          title="Attack Distribution"
          eyebrow={historical ? "Known dataset labels" : "Model classification"}
          className="xl:col-span-2"
        >
          <AttackDistributionChart data={historical ? history?.attack_distribution ?? {} : data.attack_distribution} />
        </Panel>
        <Panel title="Operational Notes" eyebrow="Triage posture">
          <div className="space-y-4 text-sm">
            <div className="border-l-2 border-red-500 pl-3">
              <strong className="text-zinc-200">
                {historical ? "Historical evidence" : "P1 cases require validation"}
              </strong>
              <p className="mt-1 text-xs text-zinc-500">
                {historical ? "Dataset labels describe recorded benchmark traffic, not a current compromise." : "Correlate flow results with firewall, endpoint, and service telemetry."}
              </p>
            </div>
            <div className="border-l-2 border-gold pl-3">
              <strong className="text-zinc-200">Evidence is bounded</strong>
              <p className="mt-1 text-xs text-zinc-500">
                Predictions support triage; they do not prove intent or
                attribution.
              </p>
            </div>
          </div>
        </Panel>
      </div>
      <Panel
        title={historical ? "Latest Historical Flows" : "Recent Incidents"}
        eyebrow={historical ? "Indexed capture records" : "Investigation queue"}
        className="mt-5"
      >
        <IncidentTable
          key={historical ? "historical" : "investigations"}
          incidents={historical ? history?.recent_records ?? [] : data.recent_incidents}
          kind={historical ? "historical" : "investigation"}
          onSelect={(id) => navigate(`/incidents/${encodeURIComponent(id)}`)}
        />
      </Panel>
      {!historical && data.operational_quality && <Panel title="Data Quality" eyebrow="Observed investigation inputs" className="mt-5"><dl className="grid gap-4 sm:grid-cols-4">{[['Incomplete flows', data.operational_quality.incomplete_flows], ['Outside training ranges', data.operational_quality.out_of_range_flows], ['LLM fallbacks', data.operational_quality.llm_fallbacks], ['Mean latency (ms)', Math.round(data.operational_quality.mean_latency_ms)]].map(([label, value]) => <div key={label}><dt className="text-xs text-zinc-500">{label}</dt><dd className="mt-2 text-xl tabular-nums">{value}</dd></div>)}</dl></Panel>}
      </>
      )}
    </div>
  );
}
