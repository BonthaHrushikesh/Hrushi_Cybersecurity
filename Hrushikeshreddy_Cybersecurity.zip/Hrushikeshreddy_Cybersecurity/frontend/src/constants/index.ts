import type { Severity } from '../types'

export const ATTACK_TYPES = ['BENIGN', 'Brute Force', 'DoS', 'DDoS', 'PortScan', 'Bot', 'Web Attack', 'Infiltration', 'Heartbleed']
export const severityColor: Record<Severity, string> = {
  CRITICAL: '#EF4444', HIGH: '#F97316', MEDIUM: '#EAB308', LOW: '#22C55E',
}
