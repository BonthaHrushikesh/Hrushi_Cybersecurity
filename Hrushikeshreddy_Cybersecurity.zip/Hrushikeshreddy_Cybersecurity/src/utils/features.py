import re

import numpy as np
import pandas as pd

RAW_FEATURES = "Destination Port|Flow Duration|Total Fwd Packets|Total Length of Fwd Packets|Fwd Packet Length Max|Fwd Packet Length Min|Fwd Packet Length Mean|Fwd Packet Length Std|Bwd Packet Length Max|Bwd Packet Length Min|Bwd Packet Length Mean|Bwd Packet Length Std|Flow Bytes/s|Flow Packets/s|Flow IAT Mean|Flow IAT Std|Flow IAT Max|Flow IAT Min|Fwd IAT Total|Fwd IAT Mean|Fwd IAT Std|Fwd IAT Max|Fwd IAT Min|Bwd IAT Total|Bwd IAT Mean|Bwd IAT Std|Bwd IAT Max|Bwd IAT Min|Fwd Header Length|Bwd Header Length|Fwd Packets/s|Bwd Packets/s|Min Packet Length|Max Packet Length|Packet Length Mean|Packet Length Std|Packet Length Variance|FIN Flag Count|PSH Flag Count|ACK Flag Count|Average Packet Size|Subflow Fwd Bytes|Init_Win_bytes_forward|Init_Win_bytes_backward|act_data_pkt_fwd|min_seg_size_forward|Active Mean|Active Max|Active Min|Idle Mean|Idle Max|Idle Min".split("|")


def normalize_column(value: str) -> str:
    name = re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")
    aliases = {"src_ip": "source_ip", "src_port": "source_port", "dst_ip": "destination_ip", "dst_port": "destination_port",
               "total_bwd_packets": "total_backward_packets"}
    return aliases.get(name, name)


FEATURE_NAMES = [normalize_column(x) for x in RAW_FEATURES]
EXTRA_FEATURES = ["syn_flag_count", "rst_flag_count", "total_backward_packets", "total_length_of_bwd_packets"]
EXTRA_FEATURES += ["fwd_psh_flags", "bwd_psh_flags", "fwd_urg_flags", "bwd_urg_flags", "urg_flag_count", "cwe_flag_count", "ece_flag_count",
                   "down_up_ratio", "avg_fwd_segment_size", "avg_bwd_segment_size", "fwd_avg_bytes_bulk", "fwd_avg_packets_bulk",
                   "fwd_avg_bulk_rate", "bwd_avg_bytes_bulk", "bwd_avg_packets_bulk", "bwd_avg_bulk_rate", "subflow_fwd_packets",
                   "subflow_bwd_packets", "subflow_bwd_bytes", "active_std", "idle_std"]
METADATA = ["flow_id", "source_ip", "source_port", "destination_ip", "protocol", "timestamp", "source_timestamp"]
TARGETS = {"label", "attack_type", "original_label", "attack_category"}
DERIVED = ["duration_seconds", "forward_bytes_per_packet", "packet_rate_asymmetry"]
CANONICAL_LABELS = ["BENIGN", "Brute Force", "DoS", "DDoS", "PortScan", "Bot", "Web Attack", "Infiltration", "Heartbleed"]
SEVERITY_PRIORS = {"BENIGN": 0.0, "Brute Force": 0.65, "DoS": 0.75, "DDoS": 0.9, "PortScan": 0.4, "Bot": 0.8, "Web Attack": 0.7, "Infiltration": 0.9, "Heartbleed": 0.95}


def attack_category(label: str) -> str:
    value = str(label).lower().strip()
    if value in {"benign", "normal traffic", "normal"}:
        return "BENIGN"
    if "ddos" in value:
        return "DDoS"
    if "dos" in value:
        return "DoS"
    if "web" in value or "xss" in value or "sql" in value:
        return "Web Attack"
    if any(x in value for x in ["patator", "brute", "ftp", "ssh"]):
        return "Brute Force"
    if "port" in value and "scan" in value:
        return "PortScan"
    if "bot" in value:
        return "Bot"
    if "infil" in value:
        return "Infiltration"
    if "heart" in value:
        return "Heartbleed"
    raise ValueError(f"Unrecognized attack label: {label}")


def flow_signatures(frame: pd.DataFrame, columns: list[str]) -> pd.Series:
    """Treat equivalent numeric values and missing-value sentinels identically."""
    numeric = frame.reindex(columns=columns).apply(pd.to_numeric, errors="coerce").astype(float)
    numeric = numeric.replace([np.inf, -np.inf], np.nan).mask(numeric < 0)
    return pd.util.hash_pandas_object(numeric, index=False)


def feature_frame(records: list[dict], columns: list[str]) -> pd.DataFrame:
    frame = pd.DataFrame(records).reindex(columns=columns).apply(pd.to_numeric, errors="coerce")
    frame = frame.replace([np.inf, -np.inf], np.nan)
    # CICFlowMeter uses -1 for unavailable initial TCP windows.
    for col in columns:
        frame.loc[frame[col] < 0, col] = np.nan
    frame["duration_seconds"] = frame.get("flow_duration", pd.Series(np.nan, index=frame.index)) / 1_000_000
    frame["forward_bytes_per_packet"] = frame.get("total_length_of_fwd_packets", pd.Series(np.nan, index=frame.index)) / frame.get("total_fwd_packets", pd.Series(np.nan, index=frame.index)).clip(lower=1)
    forward = frame.get("fwd_packets_s", pd.Series(np.nan, index=frame.index))
    backward = frame.get("bwd_packets_s", pd.Series(np.nan, index=frame.index))
    frame["packet_rate_asymmetry"] = (forward - backward) / (forward + backward).clip(lower=1)
    return frame.replace([np.inf, -np.inf], np.nan)
