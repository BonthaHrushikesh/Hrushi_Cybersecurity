"""API contracts, application factory, and REST routes."""
