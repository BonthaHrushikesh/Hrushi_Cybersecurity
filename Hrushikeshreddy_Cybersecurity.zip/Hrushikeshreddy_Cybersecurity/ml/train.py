from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesClassifier, IsolationForest, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import classification_report, confusion_matrix, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import RobustScaler

from src.utils.features import DERIVED, feature_frame, flow_signatures


def train_models(processed: Path, artifacts: Path, trees: int = 100, fixed_test: pd.DataFrame | None = None) -> dict:
    data_path = processed / "incidents.csv"
    df = pd.read_csv(data_path)
    profile = json.loads((processed / "profile.json").read_text())
    columns = profile["numeric_features"]
    small = df["attack_category"].value_counts()
    unsupported = small[small < 5].to_dict()
    df = df.loc[~df["attack_category"].isin(unsupported)].reset_index(drop=True)
    if fixed_test is not None:
        reserved = set(flow_signatures(fixed_test, columns))
        training = df.loc[~flow_signatures(df, columns).isin(reserved)].copy()
        if training["attack_category"].value_counts().min() < 5:
            raise ValueError("Candidate needs at least five non-benchmark rows in each category")
        df = pd.concat([training, fixed_test], ignore_index=True)
        train_val = np.arange(len(training))
        test = np.arange(len(training), len(df))
    else:
        indices = np.arange(len(df))
        train_val, test = train_test_split(indices, test_size=0.2, stratify=df["attack_category"], random_state=42)
    X = feature_frame(df[columns].to_dict("records"), columns)
    y = df["attack_category"]
    train, validation = train_test_split(train_val, test_size=0.2, stratify=y.iloc[train_val], random_state=43)
    candidates = {
        "RandomForest": RandomForestClassifier(n_estimators=trees, class_weight="balanced", min_samples_leaf=2, max_depth=24, random_state=42, n_jobs=4),
        "ExtraTrees": ExtraTreesClassifier(n_estimators=trees, class_weight="balanced", min_samples_leaf=2, max_depth=24, random_state=42, n_jobs=4),
    }
    comparison, pipelines = {}, {}
    for name, estimator in candidates.items():
        pipeline = Pipeline([("imputer", SimpleImputer(strategy="median", keep_empty_features=True)), ("model", estimator)])
        pipeline.fit(X.iloc[train], y.iloc[train])
        predictions = pipeline.predict(X.iloc[validation])
        comparison[name] = {
            "validation_macro_f1": float(f1_score(y.iloc[validation], predictions, average="macro", zero_division=0)),
            "validation_report": classification_report(y.iloc[validation], predictions, output_dict=True, zero_division=0),
        }
        pipelines[name] = pipeline
        print(f"{name}: validation macro F1={comparison[name]['validation_macro_f1']:.4f}", flush=True)
    chosen = max(comparison, key=lambda x: comparison[x]["validation_macro_f1"])
    model = pipelines[chosen]
    model.fit(X.iloc[train_val], y.iloc[train_val])
    predictions = model.predict(X.iloc[test])
    classes = list(model.classes_)
    test_metrics = classification_report(y.iloc[test], predictions, output_dict=True, zero_division=0)

    intrusion = Pipeline([
        ("imputer", SimpleImputer(strategy="median", keep_empty_features=True)),
        ("model", RandomForestClassifier(n_estimators=trees, class_weight="balanced", min_samples_leaf=2,
                                         max_depth=24, random_state=44, n_jobs=4)),
    ])
    intrusion_target = (y != "BENIGN").astype(int)
    intrusion.fit(X.iloc[train_val], intrusion_target.iloc[train_val])
    intrusion_probabilities = intrusion.predict_proba(X.iloc[test])
    malicious_index = list(intrusion.named_steps["model"].classes_).index(1)
    malicious = intrusion_probabilities[:, malicious_index]
    intrusion_predictions = (malicious >= 0.5).astype(int)
    intrusion_metrics = classification_report(intrusion_target.iloc[test], intrusion_predictions,
                                              target_names=["BENIGN", "MALICIOUS"], output_dict=True, zero_division=0)
    benign_train = X.iloc[train_val].loc[y.iloc[train_val] == "BENIGN"]
    if len(benign_train) < 20:
        raise ValueError("At least 20 benign training rows are required for anomaly detection")
    anomaly = Pipeline([
        ("imputer", SimpleImputer(strategy="median", keep_empty_features=True)),
        ("scaler", RobustScaler()),
        ("model", IsolationForest(n_estimators=120, contamination=0.05, random_state=42, n_jobs=4)),
    ])
    anomaly.fit(benign_train)
    reference_scores = np.sort(-anomaly.score_samples(benign_train))
    anomaly_test = -anomaly.score_samples(X.iloc[test])
    dataset_hash = hashlib.sha256(data_path.read_bytes()).hexdigest()
    training_spec = {
        "attack_model": chosen,
        "intrusion_model": "RandomForest",
        "anomaly_model": "IsolationForest",
        "trees": trees,
        "features": columns + DERIVED,
        "schema_version": 2,
        "test_split_strategy": "fixed_active_benchmark_signatures_excluded_from_training" if fixed_test is not None else "stratified_random_holdout",
        "holdout_fingerprint": hashlib.sha256(pd.util.hash_pandas_object(
            X.iloc[test].assign(attack_category=y.iloc[test].to_numpy()), index=False).to_numpy().tobytes()).hexdigest(),
    }
    version_material = dataset_hash + json.dumps(training_spec, sort_keys=True)
    version = "cicids-" + hashlib.sha256(version_material.encode()).hexdigest()[:10]
    model_dir, evaluation_dir = artifacts / "models", artifacts / "evaluation"
    model_dir.mkdir(parents=True, exist_ok=True)
    evaluation_dir.mkdir(parents=True, exist_ok=True)
    bundle = {
        "classifier": model, "intrusion_classifier": intrusion,
        "anomaly": anomaly, "anomaly_reference_scores": reference_scores,
        "raw_features": columns, "model_features": columns + DERIVED, "version": version,
        "training_ranges": {col: [float(X.iloc[train_val][col].min()), float(X.iloc[train_val][col].max())] for col in columns},
    }
    joblib.dump(bundle, model_dir / "bundle.joblib")
    importance = sorted(zip(columns + DERIVED, model.named_steps["model"].feature_importances_), key=lambda x: x[1], reverse=True)
    metadata = {
        "name": chosen, "version": version, "training_date": datetime.now(timezone.utc).isoformat(),
        "dataset_version": dataset_hash, "source_dataset": profile["source_name"],
        "training_spec": training_spec,
        "features": columns + DERIVED, "target": "attack_category", "classes": classes,
        "artifact_path": str((model_dir / "bundle.joblib").resolve()), "seed": 42,
        "split_sizes": {"training": len(train), "validation": len(validation), "final_training": len(train_val), "test": len(test)},
        "selection_rule": "Highest validation macro F1; selected model refit on training+validation; final test never used for selection.",
        "test_split_strategy": "fixed_active_benchmark_signatures_excluded_from_training" if fixed_test is not None else "stratified_random_holdout",
        "excluded_rare_categories": unsupported, "model_comparison": comparison,
        "test_metrics": test_metrics, "confusion_matrix": confusion_matrix(y.iloc[test], predictions, labels=classes).tolist(),
        "intrusion_risk_model": "RandomForest binary classifier with balanced class weights",
        "intrusion_test_metrics": intrusion_metrics,
        "malicious_roc_auc": float(roc_auc_score(intrusion_target.iloc[test], malicious)),
        "anomaly_roc_auc": float(roc_auc_score(y.iloc[test] != "BENIGN", anomaly_test)),
        "global_importance": [{"feature": name, "importance": float(value)} for name, value in importance],
        "probability_interpretation": "Uncalibrated ensemble probabilities on a class-sampled dataset; not deployment risk probability.",
        "limitations": profile["limitations"] + ["Exact duplicate protection does not guarantee independence of near-duplicate sessions.", "Rare attack classes have small test support."],
    }
    (model_dir / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    (evaluation_dir / "classification.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    df.iloc[train_val].to_csv(processed / "historical.csv", index=False)
    df.iloc[test].to_csv(processed / "test.csv", index=False)
    patterns = df.iloc[train_val].groupby("attack_category")[columns].median().replace([np.inf, -np.inf], np.nan).fillna(0).to_dict("index")
    (evaluation_dir / "attack_patterns.json").write_text(json.dumps(patterns, indent=2), encoding="utf-8")
    print(json.dumps({"selected_model": chosen, "test_accuracy": test_metrics["accuracy"], "test_macro_f1": test_metrics["macro avg"]["f1-score"], "classes": classes}, indent=2), flush=True)
    return metadata
