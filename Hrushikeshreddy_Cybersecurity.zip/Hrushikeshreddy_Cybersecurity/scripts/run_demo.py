import json
from dataclasses import replace
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
from src.utils.config import settings
from src.api.application import create_app


if __name__ == "__main__":
    with TestClient(create_app(replace(settings, llm_provider="local"))) as client:
        sample = next(x for x in client.get("/api/v1/samples").json() if x["attack_type"] == "DDoS")
        response = client.post("/api/v1/investigate", json={"flow": {"features": sample["features"]}, "query": "Investigate this suspected denial of service flow", "use_llm": False, "judge": True})
        response.raise_for_status()
        result = response.json()
        feedback = client.post("/api/v1/feedback", json={"incident_id": result["incident_id"], "helpful": True, "comment": "Panel demo: evidence and triage reviewed."})
        feedback.raise_for_status()
        path = settings.artifacts / "evaluation/demo.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(json.dumps({"incident_id": result["incident_id"], "attack": result["prediction"]["predicted_attack_type"], "risk": result["risk"],
                          "retrieved": len(result["retrieval"]["results"]), "shap_method": result["explanation"]["method"], "feedback": feedback.json()}, indent=2))
