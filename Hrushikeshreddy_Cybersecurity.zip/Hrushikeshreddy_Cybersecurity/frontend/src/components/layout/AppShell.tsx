import { AnimatePresence, motion } from "framer-motion";
import {
  Activity,
  BarChart3,
  Bell,
  Bot,
  BrainCircuit,
  ChevronLeft,
  Command,
  Database,
  FlaskConical,
  Gauge,
  GitBranch,
  Menu,
  MessageSquareText,
  Microscope,
  Search,
  Settings,
  Shield,
  SlidersHorizontal,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useApiResource } from "../../hooks/useApiResource";
import { healthApi, dashboardApi } from "../../api";
import { demoHealth, demoMetrics } from "../../demo/data";
import { DemoBanner, StatusBadge } from "../ui";

const nav = [
  ["/dashboard", "Dashboard", Gauge],
  ["/investigate", "Investigate", FlaskConical],
  ["/incidents", "Incidents", Database],
  ["/ai-analyst", "AI Analyst", Bot],
  ["/rag-search", "RAG Search", Search],
  ["/traffic-analytics", "Traffic Analytics", BarChart3],
  ["/models", "Models", BrainCircuit],
  ["/agent-workflow", "Agent Workflow", GitBranch],
  ["/evaluation", "Evaluation", Microscope],
  ["/explainability", "Explainability", SlidersHorizontal],
  ["/feedback", "Feedback", MessageSquareText],
  ["/settings", "Settings", Settings],
] as const;
const titles: Record<string, string> = {
  dashboard: "Security Operations",
  investigate: "Incident Investigation",
  incidents: "Incident Explorer",
  "rag-search": "RAG Search",
  "ai-analyst": "AI Analyst",
  explainability: "Model Intelligence",
  "traffic-analytics": "Traffic Analytics",
  models: "Model Registry",
  "agent-workflow": "Agent Workflow",
  evaluation: "Evaluation Center",
  feedback: "Analyst Feedback",
  settings: "Settings",
};

function Sidebar({
  collapsed,
  setCollapsed,
  mobileOpen,
  setMobileOpen,
}: {
  collapsed: boolean;
  setCollapsed: (x: boolean) => void;
  mobileOpen: boolean;
  setMobileOpen: (x: boolean) => void;
}) {
  const health = useApiResource(["health"], healthApi.get, demoHealth);
  return (
    <aside
      className={`fixed inset-y-0 left-0 z-50 flex flex-col border-r border-gold/15 bg-[#090909] transition-[width,transform] duration-300 ${collapsed ? "w-[76px]" : "w-[248px]"} ${mobileOpen ? "translate-x-0" : "max-lg:-translate-x-full"}`}
    >
      <div className="flex h-16 items-center gap-3 border-b border-white/[.07] px-4">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-gold/30 bg-gold/[.08]">
          <Shield className="text-brightGold" />
        </div>
        {!collapsed && (
          <div className="leading-tight">
            <strong className="text-sm tracking-[.16em]">AI INCIDENT</strong>
            <p className="text-[10px] tracking-[.22em] text-gold">RESPONSE</p>
          </div>
        )}
        <button
          aria-label="Close navigation"
          className="ml-auto lg:hidden"
          onClick={() => setMobileOpen(false)}
        >
          <X size={18} />
        </button>
      </div>
      <nav
        aria-label="Primary navigation"
        className="no-scrollbar flex-1 space-y-1 overflow-y-auto p-3"
      >
        {nav.map(([to, label, Icon]) => (
          <NavLink
            key={to}
            to={to}
            onClick={() => setMobileOpen(false)}
            title={collapsed ? label : undefined}
            className={({ isActive }) =>
              `relative flex min-h-11 items-center gap-3 rounded-lg px-3 text-sm transition ${isActive ? "bg-gold/[.09] text-brightGold" : "text-zinc-500 hover:bg-white/[.035] hover:text-zinc-200"}`
            }
          >
            <Icon size={18} />
            {!collapsed && <span>{label}</span>}
            <span className="absolute inset-y-2 left-0 w-0.5 rounded bg-gold opacity-0 [.active_&]:opacity-100" />
          </NavLink>
        ))}
      </nav>
      <div className="border-t border-white/[.07] p-3">
        {!collapsed && (
          <div className="mb-3 rounded-lg border border-white/[.06] bg-white/[.02] p-3">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-zinc-600">
              System Status
            </p>
            <div className="mt-2 flex items-center justify-between text-xs">
              <span className="text-zinc-400">API</span>
              <StatusBadge
                status={
                  health.data?.status === "ok"
                    ? "online"
                    : health.isDemo
                      ? "demo"
                      : "offline"
                }
              />
            </div>
            <p className="mono mt-2 truncate text-[10px] text-zinc-600">
              {health.data?.model_version || "Unavailable"}
            </p>
          </div>
        )}
        <button
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          onClick={() => setCollapsed(!collapsed)}
          className="hidden h-10 w-full items-center justify-center rounded-lg text-zinc-500 hover:bg-white/[.04] hover:text-zinc-200 lg:flex"
        >
          <ChevronLeft
            size={18}
            className={`transition ${collapsed ? "rotate-180" : ""}`}
          />
        </button>
      </div>
    </aside>
  );
}

function Topbar({
  onMenu,
  onPalette,
}: {
  onMenu: () => void;
  onPalette: () => void;
}) {
  const location = useLocation();
  const current =
    titles[location.pathname.split("/")[1]] || "Security Operations";
  const [time, setTime] = useState(new Date());
  const [notifications, setNotifications] = useState(false);
  const navigate = useNavigate();
  const metrics = useApiResource(['metrics'], dashboardApi.metrics, demoMetrics);
  const priority = metrics.data?.priority_distribution.P1;
  const health = useApiResource(["health"], healthApi.get, demoHealth);
  useEffect(() => {
    const id = window.setInterval(() => setTime(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);
  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-white/[.07] bg-[#090909]/95 px-4 backdrop-blur md:px-6">
      <button
        className="icon-btn lg:hidden"
        onClick={onMenu}
        aria-label="Open navigation"
      >
        <Menu size={18} />
      </button>
      <h2 className="min-w-0 truncate text-sm font-semibold">{current}</h2>
      <button
        onClick={onPalette}
        className="ml-auto hidden h-9 w-full max-w-md items-center gap-2 rounded-lg border border-white/10 bg-[#111] px-3 text-left text-sm text-zinc-500 transition hover:border-gold/25 md:flex"
      >
        <Search size={15} />
        <span className="truncate">Search incidents, IPs, attacks...</span>
        <kbd className="ml-auto rounded border border-white/10 px-1.5 py-0.5 text-[10px]">
          ⌘K
        </kbd>
      </button>
      <div className="hidden items-center gap-2 text-xs text-zinc-500 xl:flex">
        <span
          className={`h-2 w-2 rounded-full ${health.data?.status === "ok" ? "bg-emerald-400" : "bg-amber-400"}`}
        />
        {health.data?.status === "ok" ? "API LIVE" : health.isDemo ? "DEMO" : "API OFFLINE"}
      </div>
      <div className="hidden items-center gap-2 text-xs text-zinc-500 lg:flex">
        <Activity size={14} className="text-orange-400" />
        {priority === undefined ? 'QUEUE UNAVAILABLE' : `${priority} P1 CASES`}
      </div>
      <button className="icon-btn" aria-label="Notifications" title="Priority notifications" aria-expanded={notifications} onClick={() => setNotifications(!notifications)}>
        <Bell size={17} />
      </button>
      <time className="mono hidden text-xs text-zinc-500 2xl:block">
        {time.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        })}
      </time>
      <div className="flex h-9 w-9 items-center justify-center rounded-full border border-gold/25 bg-gold/[.08] text-xs font-semibold text-gold">
        SA
      </div>
      {notifications && <section role="dialog" aria-label="Priority notifications" className="absolute right-4 top-16 w-[min(360px,calc(100vw-2rem))] rounded-lg border border-gold/20 bg-[#111] p-4 shadow-xl"><div className="mb-3 flex items-center justify-between"><h3 className="text-sm font-semibold">Priority Queue</h3><button className="icon-btn" aria-label="Close notifications" onClick={() => setNotifications(false)}><X size={15} /></button></div>{!metrics.data ? <p className="text-xs text-zinc-500">Priority data is unavailable.</p> : metrics.data.recent_incidents.filter(item => item.priority === 'P1').length ? <div className="max-h-72 space-y-2 overflow-y-auto">{metrics.data.recent_incidents.filter(item => item.priority === 'P1').map(item => <button key={item.incident_id} className="w-full rounded border border-white/10 p-3 text-left" onClick={() => { navigate(`/incidents/${encodeURIComponent(item.incident_id)}`); setNotifications(false); }}><span className="block text-xs text-zinc-200">{item.attack_type} · risk {item.risk_score.toFixed(1)}</span><span className="mt-1 block break-all font-mono text-[10px] text-zinc-500">{item.incident_id}</span></button>)}</div> : <p className="text-xs text-zinc-500">No P1 cases in the current investigation window.</p>}</section>}
    </header>
  );
}

function CommandPalette({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const choices = useMemo(
    () =>
      nav.filter(([, label]) =>
        label.toLowerCase().includes(query.toLowerCase()),
      ),
    [query],
  );
  useEffect(() => {
    if (!open) setQuery("");
  }, [open]);
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[90] flex items-start justify-center bg-black/70 px-4 pt-[12vh] backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onMouseDown={onClose}
        >
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="Command palette"
            initial={{ scale: 0.97, y: -10 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.98, opacity: 0 }}
            className="w-full max-w-xl overflow-hidden rounded-xl border border-gold/25 bg-[#111] shadow-2xl"
            onMouseDown={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 border-b border-white/10 px-4">
              <Command size={18} className="text-gold" />
              <input
                autoFocus
                className="h-14 flex-1 bg-transparent text-sm outline-none placeholder:text-zinc-600"
                placeholder="Type a command..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
              <button onClick={onClose}>
                <X size={17} />
              </button>
            </div>
            <div className="max-h-80 p-2">
              {choices.map(([to, label, Icon]) => (
                <button
                  key={to}
                  className="flex w-full items-center gap-3 rounded-lg px-3 py-3 text-left text-sm text-zinc-300 hover:bg-gold/[.07] hover:text-brightGold"
                  onClick={() => {
                    navigate(to);
                    onClose();
                  }}
                >
                  <Icon size={17} />
                  {label}
                </button>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function AppShell() {
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false),
    [mobileOpen, setMobileOpen] = useState(false),
    [palette, setPalette] = useState(false);
  const health = useApiResource(["health"], healthApi.get, demoHealth);
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPalette(true);
      }
      if (e.key === "Escape") setPalette(false);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);
  return (
    <div className="min-h-screen bg-void">
      <Sidebar {...{ collapsed, setCollapsed, mobileOpen, setMobileOpen }} />
      <div
        className={`transition-[padding] duration-300 ${collapsed ? "lg:pl-[76px]" : "lg:pl-[248px]"}`}
      >
        <Topbar
          onMenu={() => setMobileOpen(true)}
          onPalette={() => setPalette(true)}
        />
        <main className="min-h-[calc(100vh-64px)] p-4 md:p-6 xl:p-7">
          {health.isDemo && <DemoBanner />}
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
          >
            <Outlet />
          </motion.div>
        </main>
      </div>
      <CommandPalette open={palette} onClose={() => setPalette(false)} />
      {mobileOpen && (
        <button
          aria-label="Close navigation overlay"
          onClick={() => setMobileOpen(false)}
          className="fixed inset-0 z-40 bg-black/65 lg:hidden"
        />
      )}
    </div>
  );
}
