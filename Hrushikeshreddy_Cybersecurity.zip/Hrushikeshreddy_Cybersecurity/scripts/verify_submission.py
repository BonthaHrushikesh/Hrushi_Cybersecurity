"""Validate the ZIP and run its portable demo/tests in an isolated extraction."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
PROJECT = "Hrushikeshreddy_Cybersecurity"


def run(command, directory, environment):
    result = subprocess.run(command, cwd=directory, env=environment, capture_output=True, text=True, timeout=300)
    if result.returncode:
        raise RuntimeError(f"Fresh-package command failed: {command[1:]}\n{result.stdout[-3000:]}\n{result.stderr[-1500:]}")
    return result.stdout


def verify(path):
    with ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise ValueError("Archive integrity check failed")
        names = archive.namelist()
        forbidden = {".git", ".venv", "node_modules", "dist", "__pycache__"}
        for name in names:
            item = Path(name)
            if item.is_absolute() or ".." in item.parts or item.parts[0] != PROJECT or forbidden.intersection(item.parts):
                raise ValueError(f"Unexpected archive path: {name}")
            if item.name.startswith(".env") and item.name != ".env.example":
                raise ValueError("Private environment file in archive")
        manifest = json.loads(archive.read(PROJECT + "/SUBMISSION_MANIFEST.json"))
        for name, digest in manifest["files"].items():
            if hashlib.sha256(archive.read(PROJECT + "/" + name)).hexdigest() != digest:
                raise ValueError(f"File hash mismatch: {name}")
        presentation = archive.read(PROJECT + "/presentation/Project_Presentation.pdf")
        pages = len(re.findall(rb"/Type\s*/Page\b", presentation))
        if not presentation.startswith(b"%PDF-") or pages != 10:
            raise ValueError("Presentation must be the verified ten-slide PDF")
        with tempfile.TemporaryDirectory(prefix="capstone-submission-") as temporary:
            archive.extractall(temporary)
            directory = Path(temporary) / PROJECT
            environment = {key: value for key, value in os.environ.items()
                           if not any(term in key.upper() for term in ("API_KEY", "TOKEN", "PASSWORD", "SECRET"))}
            environment.update({"LLM_PROVIDER": "local", "EMBEDDING_PROVIDER": "lsa", "ARTIFACT_DIR": str(directory / "artifacts/demo"),
                                "PROCESSED_DIR": str(directory / "data/demo/processed"), "DEEPEVAL_TELEMETRY_OPT_OUT": "YES",
                                "CONFIDENT_TELEMETRY_OPT_OUT": "YES"})
            run([sys.executable, "scripts/seed_demo.py"], directory, environment)
            output = run([sys.executable, "-m", "pytest", "-q"], directory, environment)
            match = re.search(r"(\d+) passed", output)
            if match is None:
                raise ValueError("Fresh-package test summary is missing")
            metadata = json.loads((directory / "artifacts/demo/models/metadata.json").read_text())
            if len(metadata["classes"]) != 9:
                raise ValueError("Portable sample must train all nine categories")
    prefixes = ("src/", "app/", "ml/", "evaluation/", "scripts/", "tests/", "frontend/src/")
    source_hashes = {name: digest for name, digest in manifest["files"].items() if name.startswith(prefixes)}
    return {"status": "passed", "scope": "Fresh source and portable data; uses the current Python dependency environment, not a fresh dependency installation",
            "source_snapshot_hash": hashlib.sha256(json.dumps(source_hashes, sort_keys=True).encode()).hexdigest(),
            "fresh_backend_tests_passed": int(match.group(1)), "fresh_demo_classes": metadata["classes"],
            "fresh_demo_model_version": metadata["version"], "presentation_pages": pages,
            "archive_hashes_verified": True, "provider_mode": "local_only", "api_key_work": "deferred",
            "active_dataset_preserved": True}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, default=ROOT / "submission" / f"{PROJECT}.zip")
    parser.add_argument("--report", type=Path, default=ROOT / "docs/evidence/submission_verification.json")
    args = parser.parse_args()
    report = verify(args.archive)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
