import json
from datetime import datetime, timezone
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.utils.config import settings
from src.services.artifact_reports import write_report


def probe(config=settings):
    result = {"provider": config.llm_provider, "key_present": config.credentials_configured,
              "generation_model": config.generation_model, "judge_model": config.evaluation_model}
    if config.llm_provider == "nvidia":
        result["base_url"] = config.nvidia_base_url
    if not config.credentials_configured:
        return {**result, "status": "not_configured"}
    try:
        if config.llm_provider == "anthropic":
            from anthropic import Anthropic
            with Anthropic(timeout=config.llm_timeout_seconds, max_retries=0) as client:
                client.models.list(limit=1)
        elif config.llm_provider == "nvidia":
            import os
            from openai import OpenAI
            with OpenAI(api_key=os.getenv("NVIDIA_API_KEY"), base_url=config.nvidia_base_url,
                        timeout=config.llm_timeout_seconds, max_retries=0) as client:
                options = {"extra_body": {"chat_template_kwargs": {"enable_thinking": config.nvidia_enable_thinking}}} if "nemotron" in config.generation_model.lower() else {}
                client.chat.completions.create(model=config.generation_model,
                    messages=[{"role": "user", "content": "Reply with OK."}], max_tokens=32, stream=False, **options)
        else:
            from openai import OpenAI
            with OpenAI(timeout=config.llm_timeout_seconds, max_retries=0) as client:
                client.models.list()
        return {**result, "status": "authenticated",
                "limitation": "Authentication check only; NVIDIA uses a short generic completion with no incident data. Run verify_live_llm.py to verify structured generation and judging."}
    except Exception as error:
        # Provider exception messages and response bodies may contain sensitive data.
        return {**result, "status": "failed", "error_type": type(error).__name__,
                "http_status": getattr(error, "status_code", None)}


def save_probe(config=settings):
    report = {**probe(config), "created_at": datetime.now(timezone.utc).isoformat(), "credential_fingerprint": config.credential_fingerprint}
    path = config.artifacts / "evaluation/provider_connection.json"
    write_report(path, report)
    return report


if __name__ == "__main__":
    report = save_probe()
    print(json.dumps({key: value for key, value in report.items() if key != "credential_fingerprint"}, indent=2))
    sys.exit(0 if report["status"] == "authenticated" else 2)
