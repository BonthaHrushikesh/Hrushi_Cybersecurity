import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.utils.config import settings
from src.api.application import Services
from src.api.schemas import InvestigationRequest, RAGRequest


def verify(config=settings):
    if not config.credentials_configured:
        return {"status": "blocked", "reason": "Configure LLM_PROVIDER=openai, anthropic, or nvidia and its API key privately in .env."}
    services = Services(config)
    if services.orchestrator is None:
        return {"status": "blocked", "reason": services.load_error}
    services.orchestrator.persist = False
    core = {"destination_port", "flow_duration", "flow_packets_s", "flow_bytes_s"}
    complete = [item for item in services.retrieval.incidents if core <= item.features.keys()]
    if not complete:
        return {"status": "blocked", "reason": "No complete historical flow is available for live verification."}
    sample = next((item for item in complete if item.attack_type == "DDoS"), complete[0])
    request = InvestigationRequest(query="Investigate this flow using historical evidence and recommend defensive next steps.",
                                   flow={"features": sample.features, "metadata": sample.metadata}, use_llm=True, judge=True)
    result = services.orchestrator.investigate(request)
    query = RAGRequest(query="Find historical denial-of-service incidents and describe evidence gaps.", use_llm=True)
    answer = services.rag_answers.answer(query, services.retrieval.search(query))
    checks = {"investigation_provider_verified": result.analysis_provider == config.llm_provider,
              "judge_completed": bool(result.judge and result.judge.status == "completed" and result.judge.provider == config.llm_provider),
              "rag_provider_verified": answer.provider == config.llm_provider}
    return {"status": "completed" if all(checks.values()) else "degraded", "checks": checks,
            "created_at": datetime.now(timezone.utc).isoformat(), "model_version": result.prediction.model_version,
            "llm_provider": config.llm_provider,
            "generation_model": config.generation_model, "judge_model": config.evaluation_model,
            "investigation": result.model_dump(), "rag_answer": answer.model_dump()}


def main():
    parser = argparse.ArgumentParser(description="Make real provider calls only with a privately configured key; never count fallback as live success.")
    parser.add_argument("--deepeval", action="store_true", help="Also run category-level live quality metrics (additional paid provider calls)")
    args = parser.parse_args()
    report = verify()
    path = settings.artifacts / "evaluation/live_verification.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, indent=2))
    print(json.dumps({key: value for key, value in report.items() if key not in {"investigation", "rag_answer"}}, indent=2))
    if report["status"] != "completed":
        return 2
    if args.deepeval:
        from evaluation.deepeval_runner import run
        run(config=settings)
    return 0


if __name__ == "__main__":
    sys.exit(main())
