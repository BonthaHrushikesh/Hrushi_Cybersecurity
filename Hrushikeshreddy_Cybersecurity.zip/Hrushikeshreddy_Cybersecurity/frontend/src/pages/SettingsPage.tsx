import { Save } from "lucide-react";
import { useQuery } from '@tanstack/react-query';
import { healthApi } from '../api';
import { useState } from "react";
import { API_BASE_URL, DEMO_MODE } from "../api/client";
import { PageHeader, Panel } from "../components/ui";
import { getSettings, saveSettings, type UiSettings } from "../store/settings";

export function SettingsPage() {
  const status = useQuery({ queryKey: ['system-status'], queryFn: healthApi.status, refetchInterval: 15000 });
  const [settings, setSettings] = useState<UiSettings>(getSettings);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState(false);
  const update = <K extends keyof UiSettings>(key: K, value: UiSettings[K]) => {
    setSettings({ ...settings, [key]: value });
    setSaved(false);
  };
  const save = () => {
    const success = saveSettings(settings);
    setSaved(success);
    setSaveError(!success);
  };
  return (
    <div>
      <PageHeader
        eyebrow="Workspace"
        title="Settings"
        description="Configure local analyst preferences. API and model configuration remain controlled by deployment environment."
      />
      <div className="grid gap-5 xl:grid-cols-2">
        <Panel title="Retrieval Defaults" eyebrow="Analyst preferences">
          <div className="space-y-5">
            <label>
              <span className="label">
                Default result count: {settings.resultCount}
              </span>
              <input
                className="w-full accent-[#D4AF37]"
                type="range"
                min="3"
                max="30"
                value={settings.resultCount}
                onChange={(e) => update("resultCount", Number(e.target.value))}
              />
            </label>
            <label>
              <span className="label">
                Semantic weight: {settings.hybridAlpha.toFixed(2)}
              </span>
              <input
                className="w-full accent-[#D4AF37]"
                type="range"
                min="0"
                max="1"
                step=".05"
                value={settings.hybridAlpha}
                onChange={(e) => update("hybridAlpha", Number(e.target.value))}
              />
            </label>
            <label className="flex items-center gap-3 text-sm text-zinc-300">
              <input
                className="h-4 w-4 accent-[#D4AF37]"
                type="checkbox"
                checked={settings.autoRefresh}
                onChange={(e) => update("autoRefresh", e.target.checked)}
              />
              Auto-refresh operational data
            </label>
            <button className="btn-primary" onClick={save}>
              <Save size={15} />
              {saved ? "Saved" : "Save preferences"}
            </button>
            {saveError && <p role="alert" className="text-xs text-red-300">Preferences could not be saved in this browser.</p>}
          </div>
        </Panel>
        <Panel title="Service Readiness" eyebrow="Live configuration" className="xl:col-span-2">
          {status.isPending ? <p className="text-sm text-zinc-500">Checking services...</p> : !status.data ? <p className="text-sm text-red-300">Service status is unavailable.</p> : <><dl className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{[['Analysis services', status.data.ready ? 'Ready' : 'Setup required'], ['Embedding provider', status.data.embedding_provider || 'Unavailable'], ['Response provider', status.data.llm_provider], ['LLM credentials', status.data.llm_credentials_configured ? 'Configured' : 'Not configured'], ['LLM model', status.data.llm_model], ['Judge model', status.data.judge_model], ['Indexed records', status.data.indexed_incidents], ['Provider connection', status.data.provider_connectivity.replaceAll('_', ' ')]].map(([label, value]) => <div key={label}><dt className="text-xs text-zinc-500">{label}</dt><dd className="mt-1 break-words text-sm text-zinc-200">{value}</dd></div>)}</dl><div className="mt-5 flex flex-wrap gap-5 text-xs text-zinc-500">{Object.entries(status.data.circuits).map(([name, circuit]) => <span key={name}>{name}: {circuit?.state || 'unavailable'}{circuit?.state === 'open' ? ` · retry in ${circuit.retry_after_seconds}s` : ''}</span>)}</div>{status.data.setup_issue && <p className="mt-4 text-sm text-amber-300">{status.data.setup_issue}</p>}</>}
        </Panel>
        <Panel title="Deployment" eyebrow="Read only" className="xl:col-start-2 xl:row-start-1">
          <dl className="space-y-4 text-sm">
            <div>
              <dt className="text-xs text-zinc-600">API base URL</dt>
              <dd className="mt-1 break-all font-mono text-zinc-300">
                {API_BASE_URL || "Same origin"}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-zinc-600">Demo fallback</dt>
              <dd className="mt-1 text-zinc-300">
                {DEMO_MODE ? "Enabled" : "Disabled"}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-zinc-600">Sensitive configuration</dt>
              <dd className="mt-1 text-zinc-300">
                Managed by backend environment variables; secrets are never
                displayed here.
              </dd>
            </div>
          </dl>
        </Panel>
        <Panel
          title="Operational Safeguards"
          eyebrow="Policy"
          className="xl:col-span-2"
        >
          <div className="grid gap-4 md:grid-cols-3">
            <p className="rounded-lg border border-white/[.06] p-4 text-xs leading-5 text-zinc-500">
              <strong className="mb-1 block text-zinc-200">
                Input validation
              </strong>
              Network metadata, ports, timestamps, query intent, and traffic
              values are validated by the API.
            </p>
            <p className="rounded-lg border border-white/[.06] p-4 text-xs leading-5 text-zinc-500">
              <strong className="mb-1 block text-zinc-200">
                Human approval
              </strong>
              Recommendations are advisory and require an authorized analyst
              before containment.
            </p>
            <p className="rounded-lg border border-white/[.06] p-4 text-xs leading-5 text-zinc-500">
              <strong className="mb-1 block text-zinc-200">
                Feedback governance
              </strong>
              Corrections enter a review queue before they can influence
              candidate models.
            </p>
          </div>
        </Panel>
      </div>
    </div>
  );
}
