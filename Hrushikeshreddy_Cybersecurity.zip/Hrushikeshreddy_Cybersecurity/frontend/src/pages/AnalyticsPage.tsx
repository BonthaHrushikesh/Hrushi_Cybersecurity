import {
  Activity,
  Database,
  MessageSquareText,
  ShieldCheck,
} from "lucide-react";
import { dashboardApi } from "../api";
import { AttackDistributionChart, PriorityChart } from "../components/charts";
import { MetricCard, PageHeader, Panel, LoadingSkeleton, ErrorState } from "../components/ui";
import { demoMetrics } from "../demo/data";
import { useApiResource } from "../hooks/useApiResource";
import { formatNumber, titleCase } from "../utils/format";

export function AnalyticsPage() {
  const query = useApiResource(
    ["analytics-metrics"],
    dashboardApi.metrics,
    demoMetrics,
  );
  const data = query.data || demoMetrics;
  const profile = data.dataset_profile;
  if (!query.data) return query.isLoading ? <LoadingSkeleton rows={8} /> : <ErrorState message="Live analytics are unavailable." onRetry={() => query.refetch()} />;
  return (
    <div>
      <PageHeader
        eyebrow="Operational analytics"
        title="Security Analytics"
        description="Distribution, throughput, dataset coverage, and evaluation signals for the incident-analysis service."
      />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          icon={Activity}
          title="Investigations"
          value={formatNumber(data.total_analyzed, 0)}
          context="Stored analysis runs"
          selected
        />
        <MetricCard
          icon={Database}
          title="Indexed corpus"
          value={formatNumber(data.indexed_incidents, 0)}
          context="Historical incidents searchable"
        />
        <MetricCard
          icon={ShieldCheck}
          title="Malicious share"
          value={`${data.total_analyzed ? ((data.malicious / data.total_analyzed) * 100).toFixed(1) : 0}%`}
          context="Of completed investigations"
        />
        <MetricCard
          icon={MessageSquareText}
          title="Feedback"
          value={formatNumber(data.feedback_count, 0)}
          context="Analyst review records"
        />
      </div>
      <div className="mt-5 grid gap-5 xl:grid-cols-2">
        <Panel title="Attack Distribution" eyebrow="Classification output">
          <AttackDistributionChart data={data.attack_distribution} />
        </Panel>
        <Panel title="Priority Distribution" eyebrow="Risk queue">
          <PriorityChart data={data.priority_distribution} />
        </Panel>
        <Panel title="Dataset Profile" eyebrow="CIC-IDS2017 processing">
          <div className="grid gap-3 sm:grid-cols-2">
            {Object.entries(profile)
              .slice(0, 10)
              .map(([key, value]) => (
                <div
                  key={key}
                  className="rounded-lg border border-white/[.06] p-3"
                >
                  <p className="text-[10px] uppercase tracking-wider text-zinc-600">
                    {titleCase(key)}
                  </p>
                  <strong className="mt-1 block break-all text-sm">
                    {typeof value === "number"
                      ? formatNumber(value)
                      : Array.isArray(value) ? `${value.length} entries` : value && typeof value === 'object' ? `${Object.keys(value).length} categories` : String(value)}
                  </strong>
                </div>
              ))}
          </div>
        </Panel>
        <Panel title="Evaluation Registry" eyebrow="Quality checks">
          {Object.keys(data.evaluation).length ? (
            <div className="space-y-3">
              {Object.entries(data.evaluation).map(([name, value]) => (
                <div
                  key={name}
                  className="rounded-lg border border-white/[.06] p-3"
                >
                  <strong className="text-sm">{titleCase(name)}</strong>
                  <p className="mt-1 text-xs text-zinc-500">{value && typeof value === 'object' && 'status' in value ? String(value.status) : 'Measured report available'}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-zinc-500">
              No evaluation artifacts were returned by the API.
            </p>
          )}
        </Panel>
      </div>
    </div>
  );
}
