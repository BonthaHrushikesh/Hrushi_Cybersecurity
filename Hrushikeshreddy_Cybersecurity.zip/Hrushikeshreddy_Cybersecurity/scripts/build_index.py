import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import faiss
import joblib
import numpy as np
import pandas as pd

from src.utils.config import settings
from src.utils.features import METADATA
from src.rag.document_builder import historical_risk, incident_document
from src.api.schemas import Metadata
from src.services.embeddings import EmbeddingService


def build_index(config=settings) -> dict:
    source = config.processed / "historical.csv"
    if not source.exists():
        raise FileNotFoundError("Train models first to create a history corpus disjoint from the test set")
    df = pd.read_csv(source)
    profile = json.loads((config.processed / "profile.json").read_text())
    model = json.loads((config.artifacts / "models/metadata.json").read_text())
    documents = []
    for _, row in df.iterrows():
        features = {name: float(row[name]) for name in profile["numeric_features"] if pd.notna(row[name])}
        raw_metadata = {name: row[name] for name in METADATA if name in row and pd.notna(row[name])}
        if "flow_id" in raw_metadata:
            raw_metadata["flow_id"] = str(raw_metadata["flow_id"])
        for port in ["source_port", "destination_port"]:
            if port in raw_metadata:
                raw_metadata[port] = int(raw_metadata[port])
        raw_metadata["destination_port"] = int(features["destination_port"])
        metadata = Metadata.model_validate(raw_metadata).model_dump(mode="json")
        score, severity = historical_risk(row["attack_category"])
        documents.append({"incident_id": row["incident_id"], "attack_type": row["attack_category"], "original_label": row["original_label"],
                          "metadata": metadata, "features": features, "document": incident_document(features, metadata, row["attack_category"], row["original_label"]),
                          "severity": severity, "risk_score": score, "risk_source": "historical_label_prior"})
    provider = EmbeddingService(config.embedding_provider, config.embedding_model)
    vectors = provider.fit([x["document"] for x in documents])
    index = faiss.IndexFlatIP(vectors.shape[1])
    index.add(np.ascontiguousarray(vectors))
    directory = config.artifacts / "index"
    directory.mkdir(parents=True, exist_ok=True)
    faiss.write_index(index, str(directory / "vectors.faiss"))
    joblib.dump(provider, directory / "embeddings.joblib")
    (directory / "documents.json").write_text(json.dumps(documents), encoding="utf-8")
    info = {"documents": len(documents), "dimensions": vectors.shape[1], "provider": config.embedding_provider,
            "model_version": model["version"], "corpus": "training+validation history only; final test excluded"}
    (directory / "metadata.json").write_text(json.dumps(info, indent=2), encoding="utf-8")
    print(json.dumps(info, indent=2))
    return info


if __name__ == "__main__":
    build_index()
