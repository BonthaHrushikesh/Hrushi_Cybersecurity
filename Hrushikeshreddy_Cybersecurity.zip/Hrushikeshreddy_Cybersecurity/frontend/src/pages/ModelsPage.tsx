import {
  Binary,
  BrainCircuit,
  CheckCircle2,
  Fingerprint,
  Network,
  ScanSearch,
} from "lucide-react";
import { healthApi } from "../api";
import { MetricCard, PageHeader, Panel, StatusBadge, LoadingSkeleton, ErrorState } from "../components/ui";
import { demoModel } from "../demo/data";
import { useApiResource } from "../hooks/useApiResource";
import { asNumber, asRecord, asString, asStringArray } from "../utils/records";
import {
  formatDate,
  formatNumber,
  formatPercent,
  titleCase,
} from "../utils/format";

export function ModelsPage() {
  const query = useApiResource(["model-registry"], healthApi.model, demoModel);
  if (!query.data) return query.isLoading ? <LoadingSkeleton rows={8} /> : <ErrorState message="Model registry is unavailable." onRetry={() => query.refetch()} />;
  const metadata = query.data.metadata;
  const test = asRecord(metadata.test_metrics);
  const macro = asRecord(test["macro avg"]);
  const classes = asStringArray(metadata.classes);
  const features = asStringArray(metadata.features);
  const comparison = asRecord(metadata.model_comparison);
  const splits = asRecord(metadata.split_sizes);
  const accuracy = asNumber(test.accuracy),
    macroF1 = asNumber(macro["f1-score"]);
  return (
    <div>
      <PageHeader
        eyebrow="ML operations"
        title="Model Registry"
        description="Inspect deployed detection assets, measured holdout performance, feature contracts, and model lineage."
      />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          icon={BrainCircuit}
          title="Active classifier"
          value={asString(metadata.name, "RandomForest")}
          context={asString(metadata.version)}
          selected
        />
        <MetricCard
          icon={CheckCircle2}
          title="Test accuracy"
          value={accuracy ? formatPercent(accuracy) : "—"}
          context="Untouched held-out split"
        />
        <MetricCard
          icon={Binary}
          title="Macro F1"
          value={macroF1 ? formatPercent(macroF1) : "—"}
          context="Class-balanced quality"
        />
        <MetricCard
          icon={Fingerprint}
          title="Feature contract"
          value={String(
            features.length || metadata.global_importance?.length || 0,
          )}
          context={`${classes.length} attack categories`}
        />
      </div>
      <div className="mt-5 grid gap-5 xl:grid-cols-[1.15fr_.85fr]">
        <Panel title="Deployed Assets" eyebrow="Runtime registry">
          <div className="space-y-3">
            <Asset
              icon={BrainCircuit}
              name="Attack Classifier"
              method={asString(metadata.name, "Random Forest")}
              detail="Supervised multiclass traffic classification"
              status="active"
            />
            <Asset
              icon={Binary}
              name="Intrusion Risk Classifier"
              method={asString(
                metadata.intrusion_risk_model,
                "Random Forest binary classifier",
              )}
              detail="Dedicated malicious-versus-benign probability"
              status="active"
            />
            <Asset
              icon={ScanSearch}
              name="Anomaly Detector"
              method="Isolation Forest"
              detail="Benign-reference anomaly percentile"
              status="ready"
            />
            <Asset
              icon={Network}
              name="Hybrid Retriever"
              method="LSA vectors + BM25"
              detail="Semantic and keyword historical search"
              status="ready"
            />
            <Asset
              icon={Fingerprint}
              name="Local Explainer"
              method="TreeSHAP"
              detail="Per-flow feature contributions"
              status="ready"
            />
          </div>
        </Panel>
        <Panel title="Lineage" eyebrow="Reproducibility">
          <dl className="space-y-4 text-sm">
            <Row label="Model version" value={asString(metadata.version)} />
            <Row
              label="Training date"
              value={formatDate(
                typeof metadata.training_date === "string"
                  ? metadata.training_date
                  : null,
              )}
            />
            <Row
              label="Source dataset"
              value={asString(metadata.source_dataset, "CIC-IDS2017")}
            />
            <Row
              label="Dataset version"
              value={asString(metadata.dataset_version).slice(0, 18)}
            />
            <Row
              label="Random seed"
              value={String(asNumber(metadata.seed, 42))}
            />
          </dl>
        </Panel>
        <Panel
          title="Per-Class Holdout Performance"
          eyebrow="Classification report"
          className="xl:col-span-2"
        >
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Class</th>
                  <th>Precision</th>
                  <th>Recall</th>
                  <th>F1 score</th>
                  <th>Support</th>
                </tr>
              </thead>
              <tbody>
                {classes.map((label) => {
                  const row = asRecord(test[label]);
                  return (
                    <tr key={label}>
                      <td className="font-medium text-zinc-100">{label}</td>
                      <td>{formatPercent(asNumber(row.precision))}</td>
                      <td>{formatPercent(asNumber(row.recall))}</td>
                      <td className="font-semibold text-gold">
                        {formatPercent(asNumber(row["f1-score"]))}
                      </td>
                      <td>{formatNumber(asNumber(row.support), 0)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Panel>
        <Panel title="Candidate Comparison" eyebrow="Validation selection">
          <div className="space-y-4">
            {Object.entries(comparison).map(([name, value]) => {
              const score = asNumber(asRecord(value).validation_macro_f1);
              return (
                <div key={name}>
                  <div className="mb-2 flex justify-between text-sm">
                    <span>{name}</span>
                    <strong className="font-mono text-gold">
                      {formatPercent(score)}
                    </strong>
                  </div>
                  <div className="h-2 overflow-hidden rounded bg-white/[.07]">
                    <div
                      className="h-full bg-gold"
                      style={{ width: `${score * 100}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
          <p className="mt-5 text-xs leading-5 text-zinc-600">
            {asString(
              metadata.selection_rule,
              "Highest validation macro F1; final evaluation uses an untouched holdout.",
            )}
          </p>
        </Panel>
        <Panel title="Training Split" eyebrow="Data governance">
          <div className="grid grid-cols-2 gap-3">
            {Object.entries(splits).map(([key, value]) => (
              <div
                key={key}
                className="rounded-lg border border-white/[.06] p-3"
              >
                <p className="text-[10px] uppercase tracking-wider text-zinc-600">
                  {titleCase(key)}
                </p>
                <strong className="mt-1 block text-xl">
                  {formatNumber(asNumber(value), 0)}
                </strong>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}
function Asset({
  icon: Icon,
  name,
  method,
  detail,
  status,
}: {
  icon: typeof BrainCircuit;
  name: string;
  method: string;
  detail: string;
  status: string;
}) {
  return (
    <div className="flex items-center gap-4 rounded-lg border border-white/[.07] bg-black/20 p-4">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-gold/20 bg-gold/[.05]">
        <Icon size={18} className="text-gold" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <strong className="text-sm">{name}</strong>
          <StatusBadge status={status} />
        </div>
        <p className="mt-1 text-xs text-zinc-500">
          {method} · {detail}
        </p>
      </div>
    </div>
  );
}
function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-white/[.06] pb-3">
      <dt className="text-zinc-500">{label}</dt>
      <dd className="max-w-[65%] break-all text-right font-mono text-xs text-zinc-200">
        {value}
      </dd>
    </div>
  );
}
