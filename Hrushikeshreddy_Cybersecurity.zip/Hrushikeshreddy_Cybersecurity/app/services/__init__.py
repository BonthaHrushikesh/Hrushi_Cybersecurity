"""Compatibility namespace for trusted artifacts built before the src migration."""
