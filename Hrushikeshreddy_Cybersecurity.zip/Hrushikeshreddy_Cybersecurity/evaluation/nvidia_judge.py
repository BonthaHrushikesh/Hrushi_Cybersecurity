import asyncio

from deepeval.models import DeepEvalBaseLLM

from src.services.llm_provider import nvidia_completion


class NvidiaJudgeModel(DeepEvalBaseLLM):
    """Use NVIDIA for DeepEval without inventing token-price estimates."""

    def __init__(self, config):
        self.config = config
        super().__init__(model=config.evaluation_model)

    def load_model(self):
        return self.config

    def generate(self, prompt, schema=None):
        return nvidia_completion(self.config, "Evaluate the supplied response against its evidence and the requested rubric.",
                                 prompt, schema, judge=True)

    async def a_generate(self, prompt, schema=None):
        return await asyncio.to_thread(self.generate, prompt, schema)

    def get_model_name(self):
        return self.config.evaluation_model

    def supports_structured_outputs(self):
        return True
