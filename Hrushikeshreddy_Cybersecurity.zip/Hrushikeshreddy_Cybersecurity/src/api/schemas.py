from datetime import datetime, timezone
from ipaddress import ip_address
import math
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from src.utils.features import CANONICAL_LABELS, EXTRA_FEATURES, FEATURE_NAMES, normalize_column
from src.utils.guardrails import validate_query


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Metadata(StrictModel):
    flow_id: str | None = Field(default=None, max_length=512)
    source_ip: str | None = None
    destination_ip: str | None = None
    source_port: int | None = Field(default=None, ge=0, le=65535, strict=True)
    destination_port: int | None = Field(default=None, ge=0, le=65535, strict=True)
    protocol: Literal["TCP", "UDP", "ICMP"] | None = None
    timestamp: datetime | None = None
    source_timestamp: str | None = Field(default=None, max_length=64)

    @field_validator("source_ip", "destination_ip")
    @classmethod
    def validate_ip(cls, value: str | None) -> str | None:
        if value is None:
            return None
        try:
            return str(ip_address(value))
        except ValueError:
            raise ValueError("IP address must be valid IPv4 or IPv6") from None

    @field_validator("timestamp")
    @classmethod
    def timezone_required(cls, value: datetime | None) -> datetime | None:
        if value is not None and value.tzinfo is None:
            raise ValueError("Timestamp must include a timezone")
        return value.astimezone(timezone.utc) if value else None


class FlowInput(StrictModel):
    features: dict[str, float] = Field(min_length=3, max_length=100)
    metadata: Metadata = Field(default_factory=Metadata)

    @field_validator("features", mode="before")
    @classmethod
    def validate_features(cls, values: Any) -> dict[str, float]:
        if not isinstance(values, dict):
            raise ValueError("features must be an object")
        result = {}
        for key, value in values.items():
            name = normalize_column(key)
            if name not in FEATURE_NAMES + EXTRA_FEATURES:
                raise ValueError("Unsupported traffic feature")
            if name in result:
                raise ValueError(f"Duplicate feature alias: {name}")
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError(f"{name} must be a number")
            try:
                numeric = float(value)
            except (OverflowError, ValueError):
                raise ValueError(f"{name} must be finite and within 1e15") from None
            if not math.isfinite(numeric) or abs(numeric) > 1e15:
                raise ValueError(f"{name} must be finite and within 1e15")
            if numeric < 0 and not (name in {"init_win_bytes_forward", "init_win_bytes_backward"} and numeric == -1):
                raise ValueError(f"{name} cannot be negative")
            if name == "destination_port" and (numeric > 65535 or not numeric.is_integer()):
                raise ValueError("Destination Port must be an integer from 0 to 65535")
            result[name] = numeric
        return result

    @model_validator(mode="after")
    def align_port(self):
        port = self.features.get("destination_port")
        if port is None and self.metadata.destination_port is not None:
            self.features["destination_port"] = float(self.metadata.destination_port)
        elif port is not None:
            if self.metadata.destination_port is not None and port != self.metadata.destination_port:
                raise ValueError("Metadata and feature destination ports disagree")
            self.metadata.destination_port = int(port)
        required = {"destination_port", "flow_duration", "flow_packets_s", "flow_bytes_s"}
        missing = required - self.features.keys()
        if missing:
            raise ValueError(f"Required traffic features missing: {', '.join(sorted(missing))}")
        return self


class SearchFilters(Metadata):
    attack_type: str | None = None
    severity: Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"] | None = None
    min_risk_score: float | None = Field(default=None, ge=0, le=100, allow_inf_nan=False)
    timestamp_min: datetime | None = None
    timestamp_max: datetime | None = None

    @field_validator("attack_type")
    @classmethod
    def valid_attack(cls, value):
        if value is not None and value not in CANONICAL_LABELS:
            raise ValueError("Unknown attack category")
        return value

    @field_validator("timestamp_min", "timestamp_max")
    @classmethod
    def aware_date(cls, value):
        return Metadata.timezone_required(value)

    @model_validator(mode="after")
    def valid_range(self):
        if self.timestamp_min and self.timestamp_max and self.timestamp_min > self.timestamp_max:
            raise ValueError("timestamp_min must be before timestamp_max")
        return self


class SearchRequest(StrictModel):
    query: str = Field(min_length=3, max_length=1000)
    top_k: int = Field(default=5, ge=1, le=30)
    alpha: float | None = Field(default=None, ge=0, le=1, allow_inf_nan=False)
    filters: SearchFilters = Field(default_factory=SearchFilters)
    mode: Literal["hybrid", "keyword", "semantic"] = "hybrid"
    fusion: Literal["weighted", "rrf"] = "weighted"
    expand_query: bool = False
    diversify: bool = False

    @field_validator("query")
    @classmethod
    def secure_query(cls, value):
        return validate_query(value)


class InvestigationRequest(SearchRequest):
    fusion: Literal["weighted", "rrf"] = "rrf"
    expand_query: bool = True
    diversify: bool = True
    query: str = "Investigate this network flow"
    flow: FlowInput
    use_llm: bool = True
    judge: bool = False


class Prediction(StrictModel):
    predicted_attack_type: str
    classification_confidence: float
    malicious_probability: float
    probabilities: dict[str, float]
    model_version: str
    missing_features: list[str]
    out_of_range_features: list[str]


class AnomalyResult(StrictModel):
    anomaly_score: float
    normalized_anomaly_risk: float
    is_anomalous: bool
    interpretation: str


class FeatureContribution(StrictModel):
    feature: str
    observed_value: float | None
    shap_value: float
    direction: str


class Explanation(StrictModel):
    method: str
    predicted_class: str
    base_value: float
    predicted_probability: float
    reconstructed_probability: float
    contributions: list[FeatureContribution]
    explanation: str


class RiskResult(StrictModel):
    risk_score: float
    severity: Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]
    priority: Literal["P4", "P3", "P2", "P1"]
    components: dict[str, float]
    weights: dict[str, float]
    explanation: str


class HistoricalIncident(StrictModel):
    incident_id: str
    attack_type: str
    original_label: str
    metadata: dict[str, Any]
    features: dict[str, float]
    document: str
    severity: str
    risk_score: float
    risk_source: str


class SearchHit(HistoricalIncident):
    similarity_score: float
    semantic_score: float
    keyword_score: float
    normalized_keyword_score: float
    feature_similarity: float | None = None


class SearchResult(StrictModel):
    results: list[SearchHit]
    alpha: float
    embedding_provider: str
    latency_ms: float
    limitations: list[str]
    strategy: str = "hybrid_weighted"
    expanded_terms: list[str] = Field(default_factory=list)
    candidate_count: int = 0


class RAGAnswer(StrictModel):
    answer: str = Field(min_length=10, max_length=8000,
                        description="Answer with exact supplied incident IDs inline in individual square brackets, for example [CIC-123]. Every cited_incident_ids entry must appear in this field using that syntax.")
    cited_incident_ids: list[str] = Field(max_length=30,
                                        description="Only exact supplied IDs that are cited inline as [ID] in the answer field; use at least one when historical records are available.")
    evidence_gaps: list[str] = Field(min_length=1, max_length=20)
    recommended_next_steps: list[str] = Field(min_length=1, max_length=12)


class RAGRequest(SearchRequest):
    fusion: Literal["weighted", "rrf"] = "rrf"
    expand_query: bool = True
    diversify: bool = True
    use_llm: bool = True


class RAGResult(StrictModel):
    analysis: RAGAnswer
    retrieval: SearchResult
    provider: str
    context_incident_ids: list[str]


class Action(StrictModel):
    action: str
    evidence: str


class Analysis(StrictModel):
    executive_summary: str
    observed_evidence: list[str]
    model_inference: str
    historical_incident_ids: list[str]
    immediate_investigation: list[Action]
    containment_considerations: list[Action]
    further_evidence: list[Action]
    longer_term_mitigation: list[Action]
    evidence_limitations: list[str]


class JudgeScore(StrictModel):
    score: int = Field(ge=1, le=5)
    reason: str


class JudgeDimensions(StrictModel):
    groundedness: JudgeScore
    relevance: JudgeScore
    correctness: JudgeScore
    completeness: JudgeScore
    recommendation_usefulness: JudgeScore
    safety: JudgeScore
    hallucination_risk: JudgeScore


class JudgeOutput(StrictModel):
    dimensions: JudgeDimensions


class JudgeResult(StrictModel):
    status: str
    provider: str
    dimensions: dict[str, JudgeScore]
    limitation: str | None = None


class WorkflowStep(StrictModel):
    agent: str
    status: str
    latency_ms: float
    tools: list[str]
    detail: str | None = None


class InvestigationResult(StrictModel):
    incident_id: str
    created_at: str
    prediction: Prediction
    anomaly: AnomalyResult
    risk: RiskResult
    explanation: Explanation
    retrieval: SearchResult
    analysis: Analysis
    analysis_provider: str
    judge: JudgeResult | None
    workflow: list[WorkflowStep]
    latency_ms: float


class FeedbackRequest(StrictModel):
    incident_id: str | None = Field(default=None, min_length=1, max_length=100, description="Saved investigation to rate; use interaction_type and context for AI Analyst or RAG feedback.")
    interaction_type: Literal["ai_analyst", "rag_search"] | None = Field(default=None, description="Set for AI Analyst or RAG Search interaction feedback.")
    context: str | None = Field(default=None, min_length=3, max_length=1000, description="The question or search phrase associated with the feedback.")
    helpful: bool
    corrected_attack_type: str | None = None
    corrected_severity: Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"] | None = None
    comment: str = Field(default="", max_length=2000)

    @model_validator(mode="after")
    def valid_feedback_target(self):
        if self.incident_id:
            if self.interaction_type is not None or self.context is not None:
                raise ValueError("Investigation feedback cannot include interaction context")
        elif self.interaction_type is None or self.context is None:
            raise ValueError("Provide an investigation ID or an interaction type with context")
        elif self.corrected_attack_type is not None or self.corrected_severity is not None:
            raise ValueError("Corrections can only be attached to investigation feedback")
        return self

    @field_validator("corrected_attack_type")
    @classmethod
    def valid_label(cls, value):
        return SearchFilters.valid_attack(value)


class FeedbackResult(StrictModel):
    feedback_id: int
    incident_id: str | None = None
    interaction_type: Literal["ai_analyst", "rag_search"] | None = None
    status: str


class HealthResult(StrictModel):
    status: str
    models_ready: bool
    index_ready: bool
    model_version: str | None


class ModelInfo(StrictModel):
    ready: bool
    metadata: dict[str, Any]


class HistoricalFlowSummary(StrictModel):
    incident_id: str
    timestamp: str | None
    attack_type: str
    severity: Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]
    risk_score: float
    risk_source: str


class HistoricalActivity(StrictModel):
    time: str
    incidents: int


class HistoricalMetrics(StrictModel):
    total_records: int
    benign: int
    malicious: int
    attack_distribution: dict[str, int]
    severity_distribution: dict[str, int]
    activity: list[HistoricalActivity]
    timestamp_missing: int
    recent_records: list[HistoricalFlowSummary]


class MetricsResult(StrictModel):
    total_analyzed: int
    benign: int
    malicious: int
    attack_distribution: dict[str, int]
    priority_distribution: dict[str, int]
    recent_incidents: list[dict[str, Any]]
    feedback_count: int
    indexed_incidents: int
    dataset_profile: dict[str, Any]
    evaluation: dict[str, Any]
    operational_quality: dict[str, Any] = Field(default_factory=dict)
    historical_summary: HistoricalMetrics | None = None


class CSVFlowRequest(StrictModel):
    csv_text: str = Field(min_length=5, max_length=50000)
