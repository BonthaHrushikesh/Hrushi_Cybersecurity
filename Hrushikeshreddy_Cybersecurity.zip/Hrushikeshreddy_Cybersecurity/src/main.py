"""Canonical Uvicorn entry point: uvicorn src.main:app."""

from src.api.application import Services, app, create_app

__all__ = ["Services", "app", "create_app"]
