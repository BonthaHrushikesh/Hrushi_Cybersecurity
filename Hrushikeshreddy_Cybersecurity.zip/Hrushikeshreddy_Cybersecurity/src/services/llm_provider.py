import json
from typing import TypeVar

from pydantic import BaseModel

from src.utils.config import Settings

Output = TypeVar("Output", bound=BaseModel)


def generate_structured(config: Settings, instructions: str, payload: dict,
                        schema: type[Output], *, judge: bool = False) -> Output:
    model = config.evaluation_model if judge else config.generation_model
    content = json.dumps(payload, allow_nan=False)
    if config.llm_provider == "openai":
        from openai import OpenAI

        with OpenAI(timeout=config.llm_timeout_seconds, max_retries=0) as client:
            response = client.responses.parse(model=model, instructions=instructions, input=content,
                                              text_format=schema, store=False)
        parsed = response.output_parsed
    elif config.llm_provider == "anthropic":
        from anthropic import Anthropic

        with Anthropic(timeout=config.llm_timeout_seconds, max_retries=0) as client:
            response = client.messages.parse(model=model, system=instructions, max_tokens=4096,
                                             messages=[{"role": "user", "content": content}], output_format=schema)
        if response.stop_reason != "end_turn":
            raise ValueError("Claude did not complete the structured response")
        parsed = response.parsed_output
    else:
        raise ValueError("Structured generation requires a remote LLM provider")
    if parsed is None:
        raise ValueError("Provider returned no structured output")
    return schema.model_validate(parsed)
