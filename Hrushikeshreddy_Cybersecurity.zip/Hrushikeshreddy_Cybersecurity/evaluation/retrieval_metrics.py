import json
from datetime import datetime, timezone
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd

from src.utils.config import settings
from src.rag.document_builder import ALIASES, flow_document
from src.api.schemas import FlowInput, SearchRequest
from src.services.models import ModelService
from src.services.retrieval import RetrievalService


def ranking_metrics(relevance: list[bool], relevant_total: int, k: int) -> dict:
    hits = sum(relevance[:k])
    first = next((i + 1 for i, relevant in enumerate(relevance[:k]) if relevant), None)
    return {"precision_at_k": hits / k, "recall_at_k": hits / relevant_total if relevant_total else 0.0,
            "hit_rate_at_k": float(hits > 0), "mrr": 1 / first if first else 0.0}


def aggregate_metrics(rows: list[dict]) -> dict:
    metric_names = ["precision_at_k", "recall_at_k", "hit_rate_at_k", "mrr"]
    return {name: float(np.mean([row[name] for row in rows])) for name in metric_names}


def evaluate_retrieval(limit_per_class: int = 5, k: int = 5) -> dict:
    retrieval = RetrievalService(settings.artifacts, settings.hybrid_alpha)
    models = ModelService(settings.artifacts)
    held_out = pd.read_csv(settings.processed / "test.csv")
    profile = json.loads((settings.processed / "profile.json").read_text())
    totals: dict[str, int] = {}
    for incident in retrieval.incidents:
        totals[incident.attack_type] = totals.get(incident.attack_type, 0) + 1

    queries, baseline_rows, investigation_rows = [], [], []
    for _, row in held_out.groupby("attack_category", group_keys=False).head(limit_per_class).iterrows():
        category = row["attack_category"]
        features = {name: float(row[name]) for name in profile["numeric_features"] if pd.notna(row[name])}
        flow_text = flow_document(features)

        baseline_hits = retrieval.search(SearchRequest(query=flow_text, top_k=k)).results
        baseline = ranking_metrics([hit.attack_type == category for hit in baseline_hits], totals[category], k)
        baseline_rows.append({"category": category, **baseline})

        prediction = models.classify(FlowInput(features=features))
        predicted = prediction.predicted_attack_type
        hypothesis = f"Model hypothesis: {predicted}. {ALIASES.get(predicted, predicted)}."
        augmented_hits = retrieval.search(SearchRequest(query=f"{hypothesis} {flow_text}", top_k=k)).results
        integrated = ranking_metrics([hit.attack_type == category for hit in augmented_hits], totals[category], k)
        investigation_rows.append({"category": category, **integrated})

        queries.append({
            "held_out_incident_id": row["incident_id"],
            "expected_category": category,
            "predicted_category": predicted,
            "baseline_retrieved_ids": [hit.incident_id for hit in baseline_hits],
            "retrieved_ids": [hit.incident_id for hit in augmented_hits],
            "baseline_metrics": baseline,
            **integrated,
        })

    categories = sorted({row["category"] for row in investigation_rows})
    per_class = {
        category: aggregate_metrics([row for row in investigation_rows if row["category"] == category])
        for category in categories
    }
    report = {
        "status": "completed",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "model_version": models.bundle["version"],
        "query_count": len(queries),
        "k": k,
        "strategy": "Classifier prediction is appended as a soft text hint; it is not a strict metadata filter.",
        "metrics": aggregate_metrics(investigation_rows),
        "baseline_metrics": aggregate_metrics(baseline_rows),
        "per_class": per_class,
        "relevance_definition": "Same attack category as held-out flow; ground-truth labels are never included in queries.",
        "limitations": [
            "Category relevance is a coarse proxy for investigation relevance.",
            "Classifier-assisted retrieval can reinforce classification errors, so baseline metrics and alternative-category hits remain visible.",
            "Recall denominator is all corpus incidents in the category, so Recall@K is small by construction.",
        ],
        "queries": queries,
    }
    directory = settings.artifacts / "evaluation"
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "retrieval.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({"query_count": len(queries), "metrics": report["metrics"],
                      "baseline_metrics": report["baseline_metrics"], "per_class": per_class}, indent=2))
    return report


if __name__ == "__main__":
    evaluate_retrieval()
