"""Configuration, feature contracts, and validation guardrails."""
