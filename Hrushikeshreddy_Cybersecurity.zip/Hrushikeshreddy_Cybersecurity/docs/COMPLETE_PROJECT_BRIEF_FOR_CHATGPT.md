# Complete Project Brief For ChatGPT

Participant: Hrushikeshreddy. Snapshot: 11 October 2026.
Project: AI-Powered Cybersecurity Incident Response Assistant.
GitHub profile: https://github.com/BonthaHrushikesh.
Recommended repository: Hrushikeshreddy_Cybersecurity; project URL/upload pending.

## Instructions For Explaining This Project

Explain implemented behavior separately from demonstrated live-provider evidence.
Do not invent Claude responses, judge scores, business time savings, pretrained
embedding results, production certification, or host/time-disjoint evaluation.
The user explicitly wants React only despite guidelines prescribing Streamlit.
The latest Claude credential check failed HTTP 401. Local fallbacks work.
Use the linked current documentation for exact schemas and measured results.

## Business Problem And Solution

SOC analysts investigate flow alerts, find historical precedents, classify
attacks, explain network patterns, and decide which alerts to prioritize.
The assistant creates an evidence-backed record containing separate prediction,
anomaly, policy risk, retrieved evidence, explanation, defensive recommendations,
workflow timings, provider provenance, and feedback. It is decision support,
not a live packet sensor or automatic remediation system.

## Source And Preparation

Primary: eight TrafficLabelling CSVs from CIC-IDS2017. Numeric-only
MachineLearningCVE is a cross-check, not duplicate training input.
Parsed 3,119,345 rows; removed 288,602 unlabeled; labeled population 2,830,743.
Streaming cp1252 decoding, aliases, labels, valid metadata, negative/nonfinite
missing values, duplicate-header equivalence checks, random-priority sampling
(seed 42, cap 2,000 per original label), retained-sample exact dedup/conflicts.
Prepared 20,273 rows with 77 raw + three derived inputs; nine categories:
BENIGN, Bot, Brute Force, DDoS, DoS, Heartbleed, Infiltration, PortScan, Web Attack.
Original labels/subtypes and genuine Flow ID/IP/port/protocol/time are retained.
UTC is user-declared for naive times, not independently source-verified.
No AM/PM corrections or fabricated hosts/measurements.

Derived values: duration_seconds; forward_bytes_per_packet; packet_rate_asymmetry.
Host identifiers, time, IDs, labels, and protocol metadata are excluded from
numeric predictions; destination port is retained as an observed service feature.
Full preparation details: dataset_details.md. Real portable sample: 467 rows,
all nine categories, data/sample_data/cicids2017_labelled_sample.csv.

## Models And Measured Results

Random Forest and Extra Trees compete on validation macro F1. Selected Random
Forest (100 trees, balanced weights); train 12,974, validation 3,244, refit
16,218, untouched test 4,055. Model: cicids-aa6f46dbeb.
Accuracy 0.9921085, macro F1 0.9743258. Separate binary Random Forest:
accuracy 0.9930949, ROC AUC 0.9961082. Confidence is uncalibrated.
Isolation Forest fits benign-only traffic with imputation/RobustScaler;
score is negative score_samples, normalized to an empirical benign-reference
percentile; anomalous starts at 0.95. Anomaly ROC AUC 0.7627583.
Heartbleed test support two; Infiltration seven. High metrics do not imply
rare-attack or external-network reliability. See model_card.md.

## RAG And Hybrid Search

One flow becomes one compact structured narrative document: observed
service/rates/timing/packet characteristics and known historical labels.
Flow-level chunking preserves event integrity rather than arbitrary token splits.
Only final training/validation flows enter history: 16,218, of which
1,592 benign and 14,626 attack-labeled. Test flows never enter the corpus.

Default embeddings: TF-IDF + fitted 96D LSA, normalized. This is a latent-semantic
offline baseline, not a pretrained language model. Optional MiniLM is implemented
but not the active measured provider. FAISS IndexFlatIP scores cosine; BM25
independently scores keywords. Weighted fusion:
alpha * clipped_cosine + (1-alpha) * normalized_positive_BM25, alpha default 0.65.
Advanced path: attack-vocabulary query expansion, reciprocal-rank fusion,
observed-flow feature similarity reranking, MMR diverse evidence, bounded context.
Filters are AND-composed before eligible ranking and never match null metadata.
Keyword and semantic-only modes remain available; embedding failure can use
an explicit lexical fallback. Results expose component scores and stable IDs.

Investigation queries may receive a predicted-category soft vocabulary hint,
not an enforced category filter. Report assisted/unassisted evaluation separately:
42 test descriptions K5; unassisted precision 0.6285714, assisted keyword
0.9428571, assisted hybrid/advanced 0.9523810. Assisted recall 0.0409892.
Category agreement is a coarse proxy, not adjudicated usefulness or faithfulness.

## Agents, Risk, And Explainability

Seven specialist shared-state workflow roles: detection, anomaly, retrieval,
risk, explainability, response, optional quality judge. Dependency/output
contracts govern execution. Trace includes tools, status, timing, failure reason.
They are not seven autonomous chatbots; the LLM cannot change numeric evidence.

Risk = round(100 * weighted signals, 2): binary malicious probability .40,
anomaly percentile .15, nonbenign classification confidence .05, category prior
.25, traffic indicators .15. Weights must be nonnegative and sum to one.
Traffic indicators combine bounded packet/byte activity and optional SYN/RST.
Intervals: [0,30) LOW/P4, [30,60) MEDIUM/P3, [60,80) HIGH/P2,
[80,100] CRITICAL/P1. Risk is a triage policy, not calibrated probability.
Historical risk is a separate historical_label_prior, never a new-flow score.

Exact TreeSHAP after saved imputation returns baseline, contributions, observed
values, and additive reconstruction of predicted class probability. Correlated
features complicate attribution; SHAP is not causality. Global impurity
importance and category medians are separately labeled, not global SHAP.

## LLM, Guardrails, And Fallbacks

Providers: local deterministic playbook, Claude Messages structured output,
OpenAI Responses structured output. Analysis has executive summary, observed
evidence, inference, historical IDs, investigation actions, containment
considerations, further evidence, mitigation, and limitations. RAG answers
cite only supplied IDs and disclose evidence gaps.

Strict Pydantic rejects extras, invalid features/IPs/ports/protocols, naive
timestamps, alias collisions, mismatched port, nonfinite/boolean numeric inputs,
unrecognized negatives, overly large inputs. Queries/context are untrusted data.
Intent/credential/prompt-override screening is a first-line guard, not complete
semantic security. Schemas/citation membership/CVE/score checks constrain
generation but cannot prove every free-text claim. Hosts are excluded from the
LLM evidence context; logs omit bodies/keys/prompts.

Timeouts, no uncontrolled SDK retry loop, circuit breakers, missing-key checks,
bounded evidence, and output validation lead to explicit local fallback.
Judge failures produce unavailable status without invented scores. Backend
.env keys never belong in VITE variables. Current configured Claude returns
401 AuthenticationError. No live quality evidence should be claimed.

## Evaluation And Improvement

DeepEval produces nine category cases from real pipeline outputs. Offline custom
metrics validate sections and citation membership only; nine checks pass.
Offline reports are separate and cannot overwrite live DeepEval reports.
Hosted metrics implemented: answer relevancy, faithfulness, contextual precision,
contextual recall, hallucination. Separate judge emits seven 1-5 dimensions
with reasons (higher hallucination-risk rating means safer). Live generation,
judge, and hosted quality are still unverified. Measurement and threshold success
are distinct. Reports require active-model/provider provenance, finite values,
and current private credential fingerprint for connectivity (never returned).

SQLite persists full investigations and feedback. Analyst corrections are
pending until reviewed. Only approved corrected labels enter export. Shared
numeric signatures prevent duplicates/conflicts; candidate training excludes
matching fixed-holdout rows, evaluates the same benchmark, writes separate
artifacts, and requires manual promotion. No automatic online learning.

## API, Frontend, And Operations

FastAPI/Uvicorn typed endpoints: health, ready, system/status, flows/parse,
model/info, classify, anomaly, risk, search, rag/answer, investigate, explain,
recommend, feedback GET/POST, incidents list/detail/report, metrics,
explain/global, samples. Full contracts and actual local examples: api.md,
API_Examples.md, examples/openapi.json, examples/api_examples.json.

React/TypeScript/Vite/Tailwind 4/TanStack Query/Recharts workspace:
Dashboard, Investigate, Incidents/detail, AI Analyst, RAG Search, Traffic
Analytics, Models, Agent Workflow, Evaluation, Explainability, Feedback, Settings.
Dashboard separates historical counts from saved analyses. Forms preserve all
sample/imported measurements; absent fields remain missing. Responses show
provider limitations, trace, SHAP, policy signals, citations, reports, feedback.
React-only is intentional; organizer acceptance of the Streamlit deviation pending.

Python 3.12 and Node 22 recommended. seed_demo writes isolated demo directories
and refuses implicit overwrite. start_local starts/restarts recorded owned
localhost processes on free ports and checks /ready. APIs lack enterprise auth;
keep them on localhost. Docker/Compose/CI exist but are optional and not claimed
runtime-verified. README has fresh setup, keys, full-data commands, sample queries.

## Verification, Deliverables, And Remaining Work

173 backend tests, 20 React tests, lint/build, and browser checks passed in the
submission-preparation run. Offline DeepEval nine structural checks passed.
Named PDFs: architecture/Architecture_Diagram.pdf, design/Design_Document.pdf,
docs/API_Documentation.pdf, docs/Dataset_Details.pdf, docs/Evaluation_Report.pdf,
presentation/Project_Presentation.pdf. Ten slides total 600 seconds, with a
two-minute local demo. Canonical source is src/api/, src/agents/, src/rag/, src/services/, src/utils/,
with src/main.py as the entry point. app/ contains only compatibility modules
for the previous Uvicorn command and pre-migration joblib embedding artifacts.
ML, evaluation, operations, React, and tests remain in their dedicated folders.

Clean local ZIP excludes .env, raw multi-gigabyte datasets, private probes,
databases, logs, .venv, node_modules, build caches. No repository was published.
GitHub profile is not a project repository. Upload/access/URL/team extras remain
manual. Do not use the home-directory Git repo for project commits.

Remaining: valid Claude authentication, authorized paid/evidence live evaluation,
React acceptance, repository upload/access, larger rare-class validation,
host/time-disjoint evaluation, operational calibration, production controls.
Explain the prototype's implemented strengths without concealing these limits.
