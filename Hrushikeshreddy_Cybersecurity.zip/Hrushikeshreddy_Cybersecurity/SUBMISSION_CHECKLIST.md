# Capstone Submission Checklist

Participant: **Hrushikeshreddy**.
GitHub profile: https://github.com/BonthaHrushikesh.
Recommended separate project repository: **Hrushikeshreddy_Cybersecurity**.
Project repository URL and access verification are pending.

## Included Deliverables

- [x] Complete API, agents, RAG, ML, evaluation, scripts, React, and tests
- [x] README with overview, objectives, stack, setup, keys, local commands, five queries
- [x] architecture/Architecture_Diagram.pdf
- [x] design/Design_Document.pdf
- [x] docs/API_Documentation.pdf, all 22 business/health API operations
- [x] docs/Dataset_Details.pdf
- [x] docs/Evaluation_Report.pdf
- [x] presentation/Project_Presentation.pdf and Project_Presentation.pptx: ten required content slides in 10:00, plus title and thank-you bookends (10:30 total)
- [x] Presentation follows required sections 10–19: problem, business need, solution, architecture, data flow, stack, agent workflow, demo, evaluation, and challenges/learning
- [x] AI Analyst and RAG Search feedback is saved with its question/search phrase for analyst review; full generated responses are not stored with interaction feedback
- [x] Real nine-category 467-row portable sample, including metadata
- [x] Actual local API examples and complete OpenAPI JSON
- [x] Current model/retrieval/offline and hosted-quality evidence included in the ZIP
- [x] Participant name/profile recorded; no project URL invented

## Verification On 11 October 2026

- [x] Backend: 173 tests passed (one dependency deprecation warning)
- [x] React: 20 tests passed
- [x] React lint: zero warnings
- [x] React production build: passed
- [x] Browser: desktop/mobile checks, 18 screenshots, no browser errors
- [x] End-to-end real DDoS sample, keyword/hybrid retrieval, local RAG, SHAP, reports
- [x] Fresh portable-demo preparation and nine-category API investigation passed
- [x] Extracted submission ZIP: isolated sample training and all 173 backend tests passed
- [x] Offline DeepEval: nine structural checks passed, no hosted scores claimed
- [x] Model/index readiness confirmed; historical attack records are nonzero
- [x] Current real history has metadata and all nine categories
- [x] API-key presence distinguished from provider authentication
- [x] Active private .env and full-dataset artifacts preserved

## Verification On 12 October 2026

- [x] Latest fixes: stale feedback exports, candidate model protection, form recovery,
  destination-port validation, complete incident pagination, and incident-specific feedback
- [x] Backend: 203 tests passed (one dependency deprecation warning)
- [x] React: 27 tests passed
- [x] React lint and production build: passed
- [x] Local frontend/backend restarted and ready; pagination contract verified
- [x] API examples, schema, presentation counts, and PDF documents refreshed
- [x] Editable twelve-slide PowerPoint: opening title, required sections 10–19, closing thank-you slide
- [x] NVIDIA authentication, live recommendations, all seven judge dimensions, and cited RAG verified
- [x] Hosted NVIDIA DeepEval run: nine cases, 36/45 metric scores; full failure detail included
- [x] Final ZIP fresh-extraction verification: nine-category portable demo trained, all 203 backend tests passed, and the PDF page tree and ten-slide PPTX were checked; result recorded in docs/evidence/submission_verification.json
- [x] Refreshed final presentation and submission ZIP: 12 PowerPoint slides and 12 PDF pages; package integrity and both bookend slides checked, with required content sections still in order

## Important Gaps

- [x] Hosted provider connected through NVIDIA; the earlier Claude HTTP 401 is historical
- [x] Real NVIDIA generation and seven-dimension judge smoke evidence
- [x] NVIDIA DeepEval measured: 36/45 scores completed across nine cases; partial, not an overall quality pass
- [ ] Complete unavailable DeepEval metrics and remediate the five threshold failures
- [ ] Organizer acceptance of React-only: guidelines explicitly prescribe Streamlit
- [ ] Create/upload the separate GitHub project repository
- [ ] Verify organizer access and confirm the actual project repository URL
- [ ] Provide any additional institution/team identifiers requested by organizers
- [ ] Open every PDF from the uploaded repository to verify transfer

Docker/cloud/Kubernetes/CI are optional. Container runtime/hosted CI were not
verified, and this checklist makes no enterprise deployment certification claim.
Sampled random holdouts, rare-class support, calibration, and source-time ambiguity
remain documented limitations.

## Safe Upload

Use submission/Hrushikeshreddy_Cybersecurity.zip. It contains an allowlisted source
tree, named deliverables, public benchmark sample, and measured evidence, excluding
.env, private probes, databases, logs, caches, raw datasets, .venv, node_modules,
and dist. The packager scans text files against configured private credentials
and records SHA-256 file hashes. This is a checked local archive, not proof about
any existing Git history or a substitute for GitHub secret scanning.

This workspace belongs to a Git repository rooted at the participant's home
directory. Do not commit/push that parent repository. Create a dedicated project
repository and upload the ZIP contents. No upload or publication was performed.

Canonical source follows src/api/, src/agents/, src/rag/, src/services/, src/utils/,
and src/main.py. app/ contains only small legacy Uvicorn/artifact compatibility
modules, not duplicated implementations. Tests and script imports use src/.
Optional browser dependencies are declared in requirements-dev.txt.
Use scripts/start_local.py --restart --offline for a reproducible local demonstration;
the private .env, trained artifacts, and full dataset are not changed.

See docs/GUIDELINES_COMPLIANCE.md and docs/PROJECT_STRUCTURE.md. Run
python scripts/verify_submission.py to verify the archive, train the portable
sample in an isolated extraction, and execute its backend tests. The verifier
uses the current dependency environment; it does not claim a fresh pip installation.
Actual fresh-extraction results are included in docs/evidence/submission_verification.json.
