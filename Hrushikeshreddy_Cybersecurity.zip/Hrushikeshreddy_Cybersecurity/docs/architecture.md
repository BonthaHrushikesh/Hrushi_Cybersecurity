# System Architecture

The current panel-ready version is [Architecture_Diagram.pdf](../architecture/Architecture_Diagram.pdf), with editable source [Architecture_Diagram.html](../architecture/Architecture_Diagram.html). It describes the active metadata-rich nine-category run.

## 1. High-Level Architecture

```mermaid
flowchart TB
    subgraph Analyst[Analyst Workspace]
        UI[React SOC Workspace]
        CLI[Preparation / Training / Evaluation CLI]
    end
    subgraph Microservice[FastAPI Microservice]
        API[Typed REST Endpoints]
        VALIDATE[Pydantic Validation and Query Guardrails]
        ORCH[Stateful Investigation Orchestrator]
        DETECT[Detection Agent]
        RETRIEVE[Retrieval Agent]
        ANOMALY[Anomaly Agent]
        RISK[Risk Assessment Agent]
        EXPLAIN[Explainability Agent]
        RESPONSE[Response Recommendation Agent]
        JUDGE[Optional Quality Judge Agent]
    end
    subgraph Services[Evidence and Inference Services]
        CLASSIFIER[Random Forest / Extra Trees Pipeline]
        ISO[Benign-Trained Isolation Forest]
        SHAP[Exact TreeSHAP]
        HYBRID[FAISS + BM25 Hybrid Ranking]
        POLICY[Configurable Risk Policy]
        GENERATOR[Local Evidence Playbook / Claude Messages / OpenAI Responses]
    end
    subgraph Persistence[Local Persistence]
        MODELS[(Versioned Model Artifacts)]
        VECTORS[(FAISS Dense Vectors)]
        HISTORY[(Incident Documents and Metadata JSON)]
        DB[(SQLite Investigations and Feedback)]
        REPORTS[(Classification / Retrieval / DeepEval Reports)]
    end
    UI --> API --> VALIDATE --> ORCH
    ORCH --> DETECT --> CLASSIFIER --> MODELS
    ORCH --> ANOMALY --> ISO --> MODELS
    ORCH --> RETRIEVE --> HYBRID
    HYBRID --> VECTORS
    HYBRID --> HISTORY
    ORCH --> RISK --> POLICY
    ORCH --> EXPLAIN --> SHAP --> MODELS
    ORCH --> RESPONSE --> GENERATOR
    ORCH --> JUDGE --> GENERATOR
    API --> DB
    CLI --> MODELS
    CLI --> HISTORY
    CLI --> VECTORS
    CLI --> REPORTS
    DB --> REVIEW[Human Feedback Review]
    REVIEW --> CANDIDATE[Separate Candidate Model]
    CANDIDATE --> REPORTS
    REPORTS --> APPROVAL[Manual Model Promotion]
```

The local design uses FAISS as the vector store, JSON for immutable historical metadata, joblib for trusted local model/preprocessing objects, and SQLite for mutable investigation/feedback records. It is a single executable microservice with modular services, rather than several network services requiring distributed infrastructure.

## 2. Investigation Sequence

```mermaid
sequenceDiagram
    actor Analyst
    participant UI as React Workspace
    participant API as FastAPI
    participant WF as Orchestrator
    participant ML as Model Services
    participant RAG as Hybrid Retriever
    participant XAI as TreeSHAP
    participant Response as Response Provider
    participant Judge as Optional LLM Judge
    participant DB as SQLite
    Analyst->>UI: Submit complete flow or CSV row
    UI->>API: POST /api/v1/investigate
    API->>API: Validate fields, filters, and query
    API->>WF: Create investigation state
    WF->>ML: Classify attack and estimate binary intrusion risk
    ML-->>WF: Probabilities, model version, input limitations
    WF->>ML: Estimate benign-baseline anomaly percentile
    ML-->>WF: Raw anomaly score and percentile
    WF->>RAG: Search observed flow with soft model hypothesis
    RAG-->>WF: Ranked incident IDs, metadata, and scores
    WF->>WF: Calculate weighted risk and priority
    WF->>XAI: Explain predicted class probability
    XAI-->>WF: Baseline and exact feature contributions
    WF->>Response: Redacted evidence and query as data
    Response-->>WF: Structured analysis and defensive actions
    opt Judge requested and configured
        WF->>Judge: Source evidence and generated analysis
        Judge-->>WF: Seven scores and reasons
    end
    WF->>DB: Save validated request and complete result
    WF-->>API: Unified investigation with workflow timings
    API-->>UI: Typed JSON result
    UI-->>Analyst: Risk, evidence, SHAP, recommendations
    Analyst->>UI: Submit feedback or corrected label
    UI->>API: POST /api/v1/feedback
    API->>DB: Persist correction pending review
```

## 3. RAG Pipeline

```mermaid
flowchart LR
    QUERY[Query + Observed Flow] --> GUARD[Validate Length and Defensive Intent]
    GUARD --> FILTER[Explicit Metadata Filters]
    FILTER --> EMBED[Configured Query Embedding]
    FILTER --> TOKENS[Keyword Tokenization]
    EMBED --> FAISS[FAISS Cosine Search]
    TOKENS --> BM25[BM25 Scoring]
    FAISS --> FUSION[Eligible Candidate Score Fusion]
    BM25 --> FUSION
    FUSION --> RANK[Rank by Hybrid Score]
    RANK --> TOPK[Top-K Historical Evidence]
    TOPK --> CONTEXT[Redacted Structured Evidence]
    CONTEXT --> RESPONSE[Local / LLM Response]
    RESPONSE --> CHECK[Schema and Citation Validation]
    CHECK --> ANSWER[Grounded Analyst Response]
```

No historical label is added to the query for a newly investigated flow. Labels appear in historical documents because they are known historical annotations. No held-out test flow appears in the retrieval corpus. An empty or zero-score result yields an explicit insufficient-evidence limitation.

## 4. Multi-Agent State Workflow

```mermaid
stateDiagram-v2
    [*] --> ValidatedRequest
    ValidatedRequest --> Detection
    Detection --> Anomaly
    Anomaly --> Retrieval
    Retrieval --> RiskAssessment
    RiskAssessment --> Explainability
    Explainability --> ResponseRecommendation
    ResponseRecommendation --> QualityJudge
    QualityJudge --> PersistedInvestigation
    PersistedInvestigation --> [*]
```

Each agent declares required state keys, output keys, and permitted tools. The orchestrator checks dependencies and output contracts before advancing. The workflow stops on failed inference or retrieval rather than returning a partially invented investigation. LLM failure is recoverable through a local evidence playbook. The judge returns an explicit not-configured/unavailable status when it cannot run.

These are specialized tool-using workflow agents; the system does not claim autonomous reasoning or remediation by every node. Its decisions come from measured model outputs, retrieved evidence, configured policy, and the configured narrative provider.

## 5. ML Training Pipeline

```mermaid
flowchart TD
    RAW[Supplied CSV / Parquet] --> SCAN[Full CSV Scan and Class Profile]
    SCAN --> CLEAN[Normalize / Validate / Replace Nonfinite and Sentinel Values]
    CLEAN --> SAMPLE[Seeded Per-Class Priority Sample]
    SAMPLE --> DEDUP[Remove Duplicate and Conflicting Feature Signatures]
    DEDUP --> SPLIT[Stratified Train / Validation / Test Split]
    SPLIT --> TRAIN[Fit Training-Only Median Imputation]
    TRAIN --> RF[Balanced Random Forest]
    TRAIN --> ET[Balanced Extra Trees]
    RF --> SELECT[Select by Validation Macro F1]
    ET --> SELECT
    SELECT --> REFIT[Refit on Training + Validation]
    REFIT --> TEST[Untouched Test Evaluation]
    SPLIT --> BENIGN[Benign Training Subset]
    BENIGN --> ISO[Imputation + Robust Scaling + Isolation Forest]
    ISO --> BASELINE[Sorted Benign Anomaly Reference Scores]
    REFIT --> SAVE[Versioned Joblib Bundle and Metadata]
    BASELINE --> SAVE
    TEST --> REPORT[Classification / ROC AUC / Confusion Matrix]
    REFIT --> HISTORY[Training History Corpus Only]
    HISTORY --> INDEX[Incident Documents and Vector Index]
```

## Complete Request Lifecycle

1. FastAPI receives a typed request and assigns a request ID; validation returns useful 422 errors without echoing sensitive/nonfinite input.
2. Required traffic fields, optional metadata, and filters are checked. Feature aliases normalize to canonical names; target fields are forbidden.
3. Detection constructs the saved feature shape, adds deterministic derived features, imputes missing features with training medians, and predicts category probabilities.
4. Anomaly detection measures unusualness relative to the benign training reference, independently of classifier probabilities.
5. Retrieval describes observed traffic, embeds and tokenizes the query, applies explicit filters, and combines measured vector/BM25 scores.
6. Risk assessment applies configured weights and deterministic severity thresholds; similarity never overrides model findings.
7. TreeSHAP explains the selected classifier's predicted class with additive contributions.
8. Response synthesis receives redacted source evidence. The provider produces a schema-validated analysis; citation validation rejects nonexistent history references.
9. If requested, the configured LLM judge compares analysis with the same evidence; absence of configuration is explicit.
10. SQLite saves the full investigation. The API returns the unified result with agent timings, and feedback remains pending for later review.
