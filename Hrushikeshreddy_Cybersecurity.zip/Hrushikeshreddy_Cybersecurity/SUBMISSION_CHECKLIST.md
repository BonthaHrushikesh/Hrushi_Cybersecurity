# Capstone Submission Checklist

Participant: **Hrushikeshreddy**.
GitHub profile: https://github.com/BonthaHrushikesh.
Recommended separate project repository: **Hrushikeshreddy_Cybersecurity**.
Project repository URL and access verification are pending.

## Included Deliverables

- [x] Complete API, agents, RAG, ML, evaluation, scripts, React, and tests
- [x] README with overview, objectives, stack, setup, keys, local commands, five queries
- [x] architecture/Architecture_Diagram.pdf
- [x] design/Design_Document.pdf
- [x] docs/API_Documentation.pdf, all 21 business/health API operations
- [x] docs/Dataset_Details.pdf
- [x] docs/Evaluation_Report.pdf
- [x] presentation/Project_Presentation.pdf, ten minutes
- [x] Real nine-category 467-row portable sample, including metadata
- [x] Actual local API examples and complete OpenAPI JSON
- [x] Current model/retrieval/offline-quality evidence included in the ZIP
- [x] Participant name/profile recorded; no project URL invented

## Verification On 11 October 2026

- [x] Backend: 173 tests passed (one dependency deprecation warning)
- [x] React: 20 tests passed
- [x] React lint: zero warnings
- [x] React production build: passed
- [x] Browser: desktop/mobile checks, 18 screenshots, no browser errors
- [x] End-to-end real DDoS sample, keyword/hybrid retrieval, local RAG, SHAP, reports
- [x] Fresh portable-demo preparation and nine-category API investigation passed
- [x] Extracted submission ZIP: isolated sample training and all 173 backend tests passed
- [x] Offline DeepEval: nine structural checks passed, no hosted scores claimed
- [x] Model/index readiness confirmed; historical attack records are nonzero
- [x] Current real history has metadata and all nine categories
- [x] API-key presence distinguished from provider authentication
- [x] Active private .env and full-dataset artifacts preserved

## Important Gaps

- [ ] Claude authentication/live provider work deferred by participant; latest check failed HTTP 401
- [ ] Real hosted generation and seven-dimension judge evidence
- [ ] Hosted DeepEval quality scores; offline structure is not prose quality
- [ ] Organizer acceptance of React-only: guidelines explicitly prescribe Streamlit
- [ ] Create/upload the separate GitHub project repository
- [ ] Verify organizer access and confirm the actual project repository URL
- [ ] Provide any additional institution/team identifiers requested by organizers
- [ ] Open every PDF from the uploaded repository to verify transfer

Docker/cloud/Kubernetes/CI are optional. Container runtime/hosted CI were not
verified, and this checklist makes no enterprise deployment certification claim.
Sampled random holdouts, rare-class support, calibration, and source-time ambiguity
remain documented limitations.

## Safe Upload

Use submission/Hrushikeshreddy_Cybersecurity.zip. It contains an allowlisted source
tree, named deliverables, public benchmark sample, and measured evidence, excluding
.env, private probes, databases, logs, caches, raw datasets, .venv, node_modules,
and dist. The packager scans text files against configured private credentials
and records SHA-256 file hashes. This is a checked local archive, not proof about
any existing Git history or a substitute for GitHub secret scanning.

This workspace belongs to a Git repository rooted at the participant's home
directory. Do not commit/push that parent repository. Create a dedicated project
repository and upload the ZIP contents. No upload or publication was performed.

Canonical source follows src/api/, src/agents/, src/rag/, src/services/, src/utils/,
and src/main.py. app/ contains only small legacy Uvicorn/artifact compatibility
modules, not duplicated implementations. Tests and script imports use src/.
Optional browser dependencies are declared in requirements-dev.txt.
Use scripts/start_local.py --restart --offline for the key-deferred demonstration;
the private .env, trained artifacts, and full dataset are not changed.

See docs/GUIDELINES_COMPLIANCE.md and docs/PROJECT_STRUCTURE.md. Run
python scripts/verify_submission.py to verify the archive, train the portable
sample in an isolated extraction, and execute its backend tests. The verifier
uses the current dependency environment; it does not claim a fresh pip installation.
Actual fresh-extraction results are included in docs/evidence/submission_verification.json.
