from dataclasses import replace
import json

import pytest

from src.utils.config import settings
from src.services.artifact_reports import connection_report, model_report, read_report, write_report


def test_report_provenance_and_nonfinite_rejection(tmp_path):
    path = tmp_path / "report.json"
    assert read_report(path)["status"] == "unavailable"
    path.write_text('{"score": NaN}')
    assert read_report(path)["status"] == "unavailable"
    write_report(path, {"model_version": "old", "score": .99})
    assert model_report(path, "new")["status"] == "stale"
    assert "score" not in model_report(path, "new")
    assert model_report(path, "old")["score"] == .99
    before = path.read_text()
    with pytest.raises(ValueError):
        write_report(path, {"score": float("inf")})
    assert path.read_text() == before
    assert not list(tmp_path.glob("*.tmp"))


def test_changed_credentials_invalidate_connection_evidence(tmp_path, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-first-key")
    config = replace(settings, artifacts=tmp_path, llm_provider="anthropic")
    path = tmp_path / "evaluation/provider_connection.json"
    write_report(path, {"provider": "anthropic", "generation_model": config.generation_model,
                        "judge_model": config.evaluation_model, "credential_fingerprint": config.credential_fingerprint,
                        "status": "failed", "http_status": 401})
    report = connection_report(config)
    assert report["http_status"] == 401
    assert "fingerprint" not in json.dumps(report)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-second-key")
    assert connection_report(config)["status"] == "not_probed"
    assert "http_status" not in connection_report(config)


def test_offline_quality_preserves_live_artifact(tmp_path, monkeypatch):
    from evaluation.deepeval_runner import run

    for name in ["models", "index"]:
        (tmp_path / name).symlink_to(settings.artifacts / name, target_is_directory=True)
    path = tmp_path / "evaluation/deepeval.json"
    write_report(path, {"live_marker": "preserve"})
    run(offline=True, config=replace(settings, artifacts=tmp_path, llm_provider="local"))
    assert read_report(path) == {"live_marker": "preserve"}
    report = read_report(tmp_path / "evaluation/offline_quality.json")
    assert report["case_count"] >= 7
    assert report["llm_metrics_status"] == "not_run_offline"
    assert not report["live_generation_verified"]
