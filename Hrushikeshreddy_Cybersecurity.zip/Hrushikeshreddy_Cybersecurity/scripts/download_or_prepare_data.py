import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.utils.config import settings
from ml.preprocess import prepare_dataset

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Prepare the supplied CIC-IDS2017 CSV/Parquet without modifying it.")
    parser.add_argument("--input", type=Path, default=settings.dataset_path)
    parser.add_argument("--per-class", type=int, default=2000)
    parser.add_argument("--timestamp-timezone", help="Source timezone for naive timestamps; never inferred")
    parser.add_argument("--defer-timestamps", action="store_true", help="Preserve raw source times until their timezone is confirmed")
    parser.add_argument("--timestamp-format", help="Explicit strptime format for source timestamps")
    parser.add_argument("--day-first", action="store_true")
    parser.add_argument("--encoding", default="utf-8-sig")
    args = parser.parse_args()
    prepare_dataset(args.input, settings.processed, args.per_class, timestamp_timezone=args.timestamp_timezone,
                    timestamp_format=args.timestamp_format, day_first=args.day_first, encoding=args.encoding,
                    defer_timestamps=args.defer_timestamps)
