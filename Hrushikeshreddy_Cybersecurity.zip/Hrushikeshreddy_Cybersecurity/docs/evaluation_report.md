# Evaluation Report

Participant: Hrushikeshreddy. Snapshot: 12 October 2026.
Active model: **cicids-aa6f46dbeb**, metadata-rich CIC-IDS2017 sampled run.
Portable demo metrics differ from the full sampled run.

## ML Evaluation

20,273 prepared records, 77 raw + 3 derived features, nine categories.
Random Forest selected by validation macro F1 (0.9851 versus Extra Trees 0.9675),
then refit on 16,218 rows. Final holdout: 4,055, excluded from model selection/index.

| Held-out metric | Result |
|---|---:|
| Attack accuracy | 0.9921085 |
| Attack macro F1 | 0.9743258 |
| Binary intrusion accuracy | 0.9930949 |
| Binary intrusion ROC AUC | 0.9961082 |
| Anomaly ROC AUC | 0.7627583 |

Heartbleed support two, F1 1.0; Infiltration support seven, recall 0.7143,
F1 0.8333. Tiny supports and random sampled splits limit generalization.
Complete classification reports contain supports, confusion matrix, seed,
splits, feature order, model comparison, and provenance.

## Retrieval Evaluation

Corpus: 16,218 training/validation flows (1,592 benign, 14,626 attack-labeled).
Forty-two held-out queries, K=5. Same-category membership is a coarse relevance proxy.

| Strategy | Precision@5 |
|---|---:|
| Unassisted weighted LSA + BM25 | 0.6285714 |
| Model-assisted keyword | 0.9428571 |
| Model-assisted weighted hybrid | 0.9523810 |
| Model-assisted advanced RAG | 0.9523810 |

Assisted hit rate/MRR: 0.9523810; baseline hit rate: 0.6904762, MRR: 0.6130952.
Assisted recall: 0.0409892 against all same-category corpus documents.
Assisted query vocabulary can reinforce classifier errors; report both baselines.
Retrieval agreement does not measure factual correctness of generated prose.

## DeepEval And Judge

Nine real held-out pipeline cases cover all active categories. Offline custom
DeepEval checks validate response sections and citation membership, not prose
faithfulness. Eight of nine passed; Infiltration had an incomplete response.
Offline checks are stored separately and never stand in for hosted quality.

**Hosted DeepEval was measured with NVIDIA on 12 October 2026.** The five
metrics produced 36 completed scores out of 45. Answer relevancy completed for
7/9 cases (mean 0.603); faithfulness for 2/9 (0.292); contextual precision for
9/9 (0.889); contextual recall for 9/9 (1.000); hallucination for 9/9 (0.093,
lower is better). Means use completed scores only. Five completed scores missed
their metric thresholds; they were not counted as passes. Eight metric calls
returned `ValueError`, and one timed out (`APITimeoutError`). Failed thresholds
were faithfulness for BENIGN (0.250) and Heartbleed (0.333), answer relevancy
for Infiltration (0.000), contextual precision for Infiltration (0.000), and
hallucination for Infiltration (0.833). Two case generations used the local
fallback, so only seven of nine generated answers came from NVIDIA. The
NVIDIA judge completed all nine cases. This is a partial measurement, not an
overall quality pass; the category-level scores and failure types are in
`docs/evidence/deepeval.json`, with a visual summary in
`docs/evidence/deepeval_quality.svg`.

The seven-dimension NVIDIA judge and cited RAG smoke checks also completed.
Evidence is in `docs/evidence/live_verification.json`. These results do not
establish production accuracy or an independent quality assessment. Score means
come from the same model family used for judging and are not independent review.

## Regression And Verification

Release checks: 203 backend tests and 27 React tests passed on 12 October 2026;
lint and the production build passed. Desktop/mobile browser checks previously
passed on 11 October with zero browser errors. The archive verifier extracts the
ZIP into a temporary directory, trains all nine categories from its portable
sample, and runs its backend suite. It uses the current Python dependency
environment, not a claimed fresh dependency installation. The verified source
snapshot and extracted-package result are in docs/evidence/submission_verification.json.

The latest regression coverage checks revoked feedback exports, protection of
active model paths, preservation of failed-investigation inputs and provider
choices, required destination ports, pagination/search/sorting beyond 200 saved
records, and feedback state when switching incidents.

pytest covers schemas/guardrails, ML/SHAP, risk, real hybrid retrieval, metadata,
workflow contracts, NVIDIA JSON-schema generation/judging, provider fallbacks, feedback candidate isolation, import,
historical dashboards, private credential redaction, report provenance, and
offline/live artifact separation. React unit tests, lint, production build,
and desktop/mobile browser checks supplement API coverage.
Final verification counts are in SUBMISSION_CHECKLIST.md.

Reproduce using README commands. Docker/hosted CI are optional and were not
verified as runtime deployments. Authentication, realistic calibration,
time/host-disjoint validation, and larger rare-class testing remain future work.
