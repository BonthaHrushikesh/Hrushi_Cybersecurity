import { beforeEach, describe, expect, it } from 'vitest'
import { getSettings, saveSettings } from './settings'

describe('Analyst preferences', () => {
  beforeEach(() => localStorage.clear())
  it('validates corrupted and out-of-range stored settings', () => {
    localStorage.setItem('soc-settings', JSON.stringify({ resultCount: 999, hybridAlpha: 'secret', autoRefresh: 'yes' }))
    expect(getSettings()).toEqual({ resultCount: 8, hybridAlpha: .65, autoRefresh: true })
    localStorage.setItem('soc-settings', 'null')
    expect(getSettings().resultCount).toBe(8)
  })
  it('persists valid preferences', () => {
    expect(saveSettings({ resultCount: 12, hybridAlpha: .8, autoRefresh: false })).toBe(true)
    expect(getSettings()).toEqual({ resultCount: 12, hybridAlpha: .8, autoRefresh: false })
  })
})
