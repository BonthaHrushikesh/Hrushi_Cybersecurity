from contextlib import asynccontextmanager
import json
import logging
from time import perf_counter
from uuid import uuid4

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse, Response
from src.utils.config import Settings, settings
from src.utils.guardrails import RequestSizeLimitMiddleware
from src.services.repository import Repository
from src.api.schemas import (AnomalyResult, Explanation, FeedbackRequest, FeedbackResult, FlowInput, HealthResult,
                         HistoricalIncident, InvestigationRequest, InvestigationResult, MetricsResult, ModelInfo,
                         Prediction, RiskResult, SearchRequest, SearchResult)
from src.api.schemas import RAGRequest, RAGResult, CSVFlowRequest
from src.services.rag_answers import RAGAnswerService
from src.services.flow_import import parse_flow_csv
from src.services.reporting import markdown_report
from pydantic import ValidationError
from src.services.models import ModelService
from src.services.recommendations import RecommendationService
from src.services.retrieval import RetrievalService
from src.services.risk import RiskEngine
from src.services.artifact_reports import connection_report, model_report, read_report
from src.agents.orchestrator import Orchestrator
from src.agents.quality_judge import JudgeService

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)


class Services:
    def __init__(self, config: Settings):
        self.config = config
        self.repository = Repository(config.artifacts / "incidents.sqlite")
        self.models = self.retrieval = self.orchestrator = None
        self.risk = RiskEngine(config.risk_weights)
        self.rag_answers = RAGAnswerService(config)
        self.load_error = None
        try:
            self.models = ModelService(config.artifacts)
            self.retrieval = RetrievalService(config.artifacts, config.hybrid_alpha)
            version = self.models.bundle["version"]
            if self.models.metadata["version"] != version or self.retrieval.metadata.get("model_version") != version:
                raise ValueError("Model and retrieval artifacts belong to different versions")
            self.orchestrator = Orchestrator(self.models, self.retrieval, self.risk, RecommendationService(config), JudgeService(config), self.repository)
        except FileNotFoundError:
            self.load_error = "Prepare data, train models, and build the index before using analysis endpoints."
        except Exception as error:
            logger.error(json.dumps({"event": "artifact_load_failed", "error_type": type(error).__name__}))
            self.load_error = "Model or retrieval artifacts could not be loaded. Rebuild compatible artifacts before analysis."


def create_app(config: Settings = settings) -> FastAPI:
    @asynccontextmanager
    async def lifespan(api):
        api.state.services = Services(config)
        yield

    api = FastAPI(title="AI-Powered Cybersecurity Incident Response Assistant", version="1.0.0", lifespan=lifespan,
                  description="Evidence-based network-flow classification, hybrid retrieval, explainability, and analyst triage.")
    api.add_middleware(
        CORSMiddleware,
        allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$",
        allow_credentials=False,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization"],
    )
    api.add_middleware(RequestSizeLimitMiddleware, max_bytes=config.max_request_bytes)

    def services(request: Request) -> Services:
        svc = request.app.state.services
        if not svc.orchestrator:
            raise HTTPException(503, detail=svc.load_error)
        return svc

    @api.middleware("http")
    async def request_logging(request: Request, call_next):
        request_id = uuid4().hex
        started = perf_counter()
        try:
            response = await call_next(request)
        except Exception as error:
            logger.error(json.dumps({"event": "request_failed", "request_id": request_id, "error_type": type(error).__name__}))
            response = JSONResponse(status_code=500, content={"detail": "The operation failed. Retry or inspect the service logs."})
        response.headers["X-Request-ID"] = request_id
        logger.info(json.dumps({"event": "request", "request_id": request_id, "method": request.method, "path": request.url.path,
                                "status": response.status_code, "latency_ms": round((perf_counter() - started) * 1000, 3)}))
        return response

    @api.exception_handler(RequestValidationError)
    async def validation_error(request: Request, error: RequestValidationError):
        # Pydantic input payloads may contain Infinity or sensitive fields; expose only useful locations/messages.
        return JSONResponse(status_code=422, content={"detail": [{"loc": list(x["loc"]), "msg": x["msg"], "type": x["type"]} for x in error.errors()]})

    @api.exception_handler(Exception)
    async def unexpected_error(request: Request, error: Exception):
        logger.error(json.dumps({"event": "unexpected_error", "error_type": type(error).__name__}))
        return JSONResponse(status_code=500, content={"detail": "The operation failed. Retry or inspect the service logs."})

    @api.get("/", include_in_schema=False)
    def root():
        return RedirectResponse("/docs")

    @api.get("/health", response_model=HealthResult)
    def health(request: Request):
        svc = request.app.state.services
        return HealthResult(status="ok" if svc.orchestrator else "setup_required", models_ready=svc.models is not None,
                            index_ready=svc.retrieval is not None, model_version=svc.models.bundle["version"] if svc.models else None)

    @api.get("/api/v1/system/status")
    def system_status(request: Request):
        svc = request.app.state.services
        recommendations = next((agent.recommendations for agent in svc.orchestrator.agents if hasattr(agent, "recommendations")), None) if svc.orchestrator else None
        judge = next((agent.judge for agent in svc.orchestrator.agents if hasattr(agent, "judge")), None) if svc.orchestrator else None
        connection = connection_report(config)
        return {"ready": svc.orchestrator is not None, "setup_issue": svc.load_error,
                "model_version": svc.models.bundle["version"] if svc.models else None,
                "embedding_provider": svc.retrieval.embeddings.provider if svc.retrieval else None,
                "indexed_incidents": len(svc.retrieval.incidents) if svc.retrieval else 0,
                "llm_provider": config.llm_provider, "llm_credentials_configured": config.credentials_configured,
                "llm_model": config.generation_model, "judge_model": config.evaluation_model,
                "provider_connectivity": connection.get("status", "not_probed"), "provider_connection": connection,
                "circuits": {"rag": svc.rag_answers.circuit.snapshot(),
                             "recommendations": recommendations.circuit.snapshot() if recommendations else None,
                             "judge": judge.circuit.snapshot() if judge else None},
                "limits": {"max_request_bytes": config.max_request_bytes, "llm_timeout_seconds": config.llm_timeout_seconds}}

    @api.post("/api/v1/flows/parse", response_model=FlowInput)
    def parse_flow(query: CSVFlowRequest):
        try:
            return parse_flow_csv(query.csv_text)
        except ValidationError:
            raise HTTPException(422, "CSV contains invalid or incomplete traffic features or metadata") from None
        except ValueError as error:
            raise HTTPException(422, str(error)) from None

    @api.get("/ready", response_model=HealthResult)
    def readiness(request: Request, response: Response):
        result = health(request)
        response.status_code = 200 if result.status == "ok" else 503
        return result

    @api.get("/api/v1/model/info", response_model=ModelInfo)
    def model_info(svc: Services = Depends(services)):
        return ModelInfo(ready=True, metadata=svc.models.metadata)

    @api.post("/api/v1/classify", response_model=Prediction)
    def classify(flow: FlowInput, svc: Services = Depends(services)):
        return svc.models.classify(flow)

    @api.post("/api/v1/anomaly", response_model=AnomalyResult)
    def anomaly(flow: FlowInput, svc: Services = Depends(services)):
        return svc.models.anomaly(flow)

    @api.post("/api/v1/risk", response_model=RiskResult)
    def risk(flow: FlowInput, svc: Services = Depends(services)):
        return svc.risk.score(flow, svc.models.classify(flow), svc.models.anomaly(flow))

    @api.post("/api/v1/search", response_model=SearchResult)
    def search(query: SearchRequest, svc: Services = Depends(services)):
        return svc.retrieval.search(query)

    @api.post("/api/v1/rag/answer", response_model=RAGResult)
    def rag_answer(query: RAGRequest, svc: Services = Depends(services)):
        return svc.rag_answers.answer(query, svc.retrieval.search(query))

    @api.post("/api/v1/investigate", response_model=InvestigationResult)
    def investigate(query: InvestigationRequest, svc: Services = Depends(services)):
        return svc.orchestrator.investigate(query)

    @api.post("/api/v1/explain", response_model=Explanation)
    def explain(flow: FlowInput, svc: Services = Depends(services)):
        return svc.models.explain(flow)

    @api.post("/api/v1/recommend", response_model=InvestigationResult)
    def recommend(query: InvestigationRequest, svc: Services = Depends(services)):
        return svc.orchestrator.investigate(query)

    @api.post("/api/v1/feedback", response_model=FeedbackResult, status_code=201)
    def feedback(query: FeedbackRequest, svc: Services = Depends(services)):
        try:
            feedback_id = svc.repository.feedback(query)
        except KeyError:
            raise HTTPException(404, "Investigation not found") from None
        return FeedbackResult(feedback_id=feedback_id, incident_id=query.incident_id, status="pending_review")

    @api.get("/api/v1/feedback")
    def list_feedback(svc: Services = Depends(services)):
        return svc.repository.list_feedback()

    @api.get("/api/v1/incidents")
    def list_incidents(limit: int = 200, svc: Services = Depends(services)):
        return svc.repository.list_investigations(max(1, min(limit, 1000)))

    @api.get("/api/v1/incidents/{incident_id}", response_model=HistoricalIncident | InvestigationResult)
    def incident(incident_id: str, svc: Services = Depends(services)):
        result = svc.repository.get(incident_id) or svc.retrieval.by_id.get(incident_id)
        if result is None:
            raise HTTPException(404, "Incident not found")
        return result

    @api.get("/api/v1/incidents/{incident_id}/report")
    def report(incident_id: str, svc: Services = Depends(services)):
        result = svc.repository.get(incident_id)
        if result is None:
            raise HTTPException(404, "Investigation not found")
        return Response(markdown_report(result), media_type="text/markdown",
                        headers={"Content-Disposition": f'attachment; filename="{result["incident_id"]}.md"'})

    @api.get("/api/v1/metrics", response_model=MetricsResult)
    def metrics(svc: Services = Depends(services)):
        profile = read_report(config.processed / "profile.json")
        evaluation = {}
        for name in ["classification", "retrieval", "advanced_retrieval", "deepeval", "offline_quality", "prd_readiness", "provider_connection"]:
            path = config.artifacts / "evaluation" / f"{name}.json"
            if path.exists():
                evaluation[name] = connection_report(config) if name == "provider_connection" else model_report(path, svc.models.bundle["version"])
        return MetricsResult(**svc.repository.metrics(), indexed_incidents=len(svc.retrieval.incidents),
                             historical_summary=svc.retrieval.summary(), dataset_profile=profile, evaluation=evaluation)

    @api.get("/api/v1/explain/global")
    def global_explain(svc: Services = Depends(services)):
        patterns = read_report(config.artifacts / "evaluation/attack_patterns.json")
        limitations = []
        if patterns.get("status") == "unavailable":
            limitations.append("Historical attack-pattern profiles are unavailable; model importance remains available.")
            patterns = {}
        return {"global_importance": svc.models.metadata["global_importance"], "importance_method": "ensemble_mean_impurity_decrease",
                "attack_patterns": patterns, "limitations": limitations,
                "note": "Global importance is not SHAP; local explanations use exact TreeSHAP."}

    @api.get("/api/v1/samples")
    def samples(svc: Services = Depends(services)):
        rows = {}
        required = {"destination_port", "flow_duration", "flow_packets_s", "flow_bytes_s"}
        for item in svc.retrieval.incidents:
            if item.attack_type not in rows and required <= item.features.keys():
                rows[item.attack_type] = item.model_dump()
        return list(rows.values())

    return api


app = create_app()
