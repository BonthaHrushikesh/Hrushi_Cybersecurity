# Measured Endpoint Examples

These examples were captured from the actual local API using an isolated temporary database and local-only providers. Requests use four observed fields from a real DDoS sample, so missing-feature warnings are expected. Responses below are explicitly abridged, not complete schemas. Complete unabridged measured examples are in docs/examples/api_examples.json; request/response types, optional fields, and validation constraints are in docs/examples/openapi.json and /docs. No live judge scores were generated.

## GET /health

Request format: No body; path/query parameters as shown.

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/HealthResult"}}}

Sample request: GET /health

No request body.

Sample response (abridged):

```json
{
  "status": "ok",
  "models_ready": true,
  "index_ready": true,
  "model_version": "cicids-aa6f46dbeb"
}
```

## GET /ready

Request format: No body; path/query parameters as shown.

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/HealthResult"}}}

Sample request: GET /ready

No request body.

Sample response (abridged):

```json
{
  "status": "ok",
  "models_ready": true,
  "index_ready": true,
  "model_version": "cicids-aa6f46dbeb"
}
```

## GET /api/v1/system/status

Request format: No body; path/query parameters as shown.

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {}}}

Sample request: GET /api/v1/system/status

No request body.

Sample response (abridged):

```json
{
  "ready": true,
  "setup_issue": null,
  "model_version": "cicids-aa6f46dbeb",
  "embedding_provider": "lsa",
  "indexed_incidents": 16218,
  "llm_provider": "local",
  "llm_credentials_configured": false,
  "llm_model": "local_evidence_playbook",
  "judge_model": "none",
  "provider_connectivity": "not_required",
  "provider_connection": {
    "status": "not_required",
    "limitation": "Local providers are selected; no hosted authentication is required."
  },
  "circuits": {
    "rag": {
      "state": "closed",
      "consecutive_failures": 0,
      "retry_after_seconds": 0
    },
    "recommendations": {
      "state": "closed",
      "consecutive_failures": 0,
      "retry_after_seconds": 0
    },
    "judge": {
      "state": "closed",
      "consecutive_failures": 0,
      "retry_after_seconds": 0
    }
  },
  "_omitted_fields": 1
}
```

## GET /api/v1/model/info

Request format: No body; path/query parameters as shown.

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/ModelInfo"}}}

Sample request: GET /api/v1/model/info

No request body.

Sample response (abridged):

```json
{
  "ready": true,
  "metadata": {
    "name": "RandomForest",
    "version": "cicids-aa6f46dbeb",
    "training_date": "2026-10-11T07:50:13.301410+00:00",
    "dataset_version": "2b587a4b2089f80ea181251154bde09a99d707921ce493496ccf3a5b84c53367",
    "source_dataset": "TrafficLabelling ",
    "training_spec": {
      "attack_model": "RandomForest",
      "intrusion_model": "RandomForest",
      "anomaly_model": "IsolationForest",
      "trees": 100,
      "features": "[abridged; see full JSON example]",
      "schema_version": 2,
      "test_split_strategy": "stratified_random_holdout",
      "holdout_fingerprint": "ff872c55e739bf88c24c881b755ecf6e6f47abde1ab6b0923c8142deb46621f8"
    },
    "features": [
      "destination_port",
      "flow_duration",
      "[78 more items; see full JSON example]"
    ],
    "target": "attack_category",
    "classes": [
      "BENIGN",
      "Bot",
      "[7 more items; see full JSON example]"
    ],
    "artifact_path": "/Users/hrushikeshreddy/final capstone/artifacts/traffic_labelling/models/bundle.joblib",
    "seed": 42,
    "split_sizes": {
      "training": 12974,
      "validation": 3244,
      "final_training": 16218,
      "test": 4055
    },
    "_omitted_fields": 13
  }
}
```

## GET /api/v1/samples

Request format: No body; path/query parameters as shown.

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {}}}

Sample request: GET /api/v1/samples

No request body.

Sample response (abridged):

```json
[
  {
    "incident_id": "CIC-16453923491218481350",
    "attack_type": "DoS",
    "original_label": "DoS Hulk",
    "metadata": {
      "flow_id": "172.16.0.1-192.168.10.50-40064-80-6",
      "source_ip": "172.16.0.1",
      "destination_ip": "192.168.10.50",
      "source_port": 40064,
      "destination_port": 80,
      "protocol": "TCP",
      "timestamp": "2017-07-05T10:58:00Z",
      "source_timestamp": "5/7/2017 10:58"
    },
    "features": {
      "destination_port": 80.0,
      "flow_duration": 98833736.0,
      "total_fwd_packets": 7.0,
      "total_length_of_fwd_packets": 338.0,
      "fwd_packet_length_max": 338.0,
      "fwd_packet_length_min": 0.0,
      "fwd_packet_length_mean": 48.28571429,
      "fwd_packet_length_std": 127.7519919,
      "bwd_packet_length_max": 4344.0,
      "bwd_packet_length_min": 0.0,
      "bwd_packet_length_mean": 1932.5,
      "bwd_packet_length_std": 1754.831473,
      "_omitted_fields": 65
    },
    "document": "Network flow to destination port 80. Protocol TCP. Observed flow duration in microseconds: 9.883e+07. Observed packet rate packets per second: 0.1315. Observed byte throughput bytes per second: 120.7. Observed forward pa [abridged]",
    "severity": "HIGH",
    "risk_score": 75.0,
    "risk_source": "historical_label_prior"
  },
  {
    "incident_id": "CIC-13638945159822102235",
    "attack_type": "DDoS",
    "original_label": "DDoS",
    "metadata": {
      "flow_id": "172.16.0.1-192.168.10.50-51326-80-6",
      "source_ip": "172.16.0.1",
      "destination_ip": "192.168.10.50",
      "source_port": 51326,
      "destination_port": 80,
      "protocol": "TCP",
      "timestamp": "2017-07-07T03:57:00Z",
      "source_timestamp": "7/7/2017 3:57"
    },
    "features": {
      "destination_port": 80.0,
      "flow_duration": 298783.0,
      "total_fwd_packets": 3.0,
      "total_length_of_fwd_packets": 26.0,
      "fwd_packet_length_max": 20.0,
      "fwd_packet_length_min": 0.0,
      "fwd_packet_length_mean": 8.666666667,
      "fwd_packet_length_std": 10.26320288,
      "bwd_packet_length_max": 5840.0,
      "bwd_packet_length_min": 0.0,
      "bwd_packet_length_mean": 1933.5,
      "bwd_packet_length_std": 2189.772933,
      "_omitted_fields": 65
    },
    "document": "Network flow to destination port 80. Protocol TCP. Observed flow duration in microseconds: 2.988e+05. Observed packet rate packets per second: 30.12. Observed byte throughput bytes per second: 3.891e+04. Observed forward [abridged]",
    "severity": "CRITICAL",
    "risk_score": 90.0,
    "risk_source": "historical_label_prior"
  },
  "[7 more items; see full JSON example]"
]
```

## POST /api/v1/flows/parse

Request format: {"$ref": "#/components/schemas/CSVFlowRequest"}

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/FlowInput"}}}

Sample request: POST /api/v1/flows/parse

```json
{
  "csv_text": "Destination Port,Flow Duration,Flow Packets/s,Flow Bytes/s\n80.0,298783.0,30.12219571,38914.52994\n"
}
```

Sample response (abridged):

```json
{
  "features": {
    "destination_port": 80.0,
    "flow_duration": 298783.0,
    "flow_packets_s": 30.12219571,
    "flow_bytes_s": 38914.52994
  },
  "metadata": {
    "flow_id": null,
    "source_ip": null,
    "destination_ip": null,
    "source_port": null,
    "destination_port": 80,
    "protocol": null,
    "timestamp": null,
    "source_timestamp": null
  }
}
```

## POST /api/v1/classify

Request format: {"$ref": "#/components/schemas/FlowInput"}

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/Prediction"}}}

Sample request: POST /api/v1/classify

```json
{
  "features": {
    "destination_port": 80.0,
    "flow_duration": 298783.0,
    "flow_packets_s": 30.12219571,
    "flow_bytes_s": 38914.52994
  }
}
```

Sample response (abridged):

```json
{
  "predicted_attack_type": "BENIGN",
  "classification_confidence": 0.3821763388606656,
  "malicious_probability": 0.6803679830315411,
  "probabilities": {
    "BENIGN": 0.3821763388606656,
    "Bot": 0.01,
    "Brute Force": 0.11239834600532544,
    "DDoS": 0.25,
    "DoS": 0.18378782343755465,
    "Heartbleed": 0.0,
    "Infiltration": 0.0,
    "PortScan": 0.04163749169645428,
    "Web Attack": 0.02
  },
  "model_version": "cicids-aa6f46dbeb",
  "missing_features": [
    "total_fwd_packets",
    "total_length_of_fwd_packets",
    "[71 more items; see full JSON example]"
  ],
  "out_of_range_features": []
}
```

## POST /api/v1/anomaly

Request format: {"$ref": "#/components/schemas/FlowInput"}

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/AnomalyResult"}}}

Sample request: POST /api/v1/anomaly

```json
{
  "features": {
    "destination_port": 80.0,
    "flow_duration": 298783.0,
    "flow_packets_s": 30.12219571,
    "flow_bytes_s": 38914.52994
  }
}
```

Sample response (abridged):

```json
{
  "anomaly_score": 0.32218707973958577,
  "normalized_anomaly_risk": 0.19095477386934673,
  "is_anomalous": false,
  "interpretation": "Percentile relative to benign training flows; unusual traffic is not proof of an attack."
}
```

## POST /api/v1/risk

Request format: {"$ref": "#/components/schemas/FlowInput"}

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/RiskResult"}}}

Sample request: POST /api/v1/risk

```json
{
  "features": {
    "destination_port": 80.0,
    "flow_duration": 298783.0,
    "flow_packets_s": 30.12219571,
    "flow_bytes_s": 38914.52994
  }
}
```

Sample response (abridged):

```json
{
  "risk_score": 34.9,
  "severity": "MEDIUM",
  "priority": "P3",
  "components": {
    "malicious_probability": 0.6803679830315411,
    "anomaly_percentile": 0.19095477386934673,
    "malicious_confidence": 0.0,
    "attack_prior": 0.0,
    "traffic_indicators": 0.3214365037472449
  },
  "weights": {
    "malicious_probability": 0.4,
    "anomaly_percentile": 0.15,
    "malicious_confidence": 0.05,
    "attack_prior": 0.25,
    "traffic_indicators": 0.15
  },
  "explanation": "P3: model predicts BENIGN with 38.2% confidence; malicious confidence 68.0%; anomaly percentile 19.1%. Score is a configurable triage policy, not a calibrated probability. Historical label similarity does not establish a [abridged]"
}
```

## POST /api/v1/explain

Request format: {"$ref": "#/components/schemas/FlowInput"}

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/Explanation"}}}

Sample request: POST /api/v1/explain

```json
{
  "features": {
    "destination_port": 80.0,
    "flow_duration": 298783.0,
    "flow_packets_s": 30.12219571,
    "flow_bytes_s": 38914.52994
  }
}
```

Sample response (abridged):

```json
{
  "method": "TreeSHAP",
  "predicted_class": "BENIGN",
  "base_value": 0.11165469231452034,
  "predicted_probability": 0.38217633886066565,
  "reconstructed_probability": 0.38217633886066654,
  "contributions": [
    {
      "feature": "init_win_bytes_forward",
      "observed_value": null,
      "shap_value": 0.030582040578586656,
      "direction": "supports"
    },
    {
      "feature": "destination_port",
      "observed_value": 80.0,
      "shap_value": 0.026219564871836364,
      "direction": "supports"
    },
    "[78 more items; see full JSON example]"
  ],
  "explanation": "SHAP values explain the predicted class probability relative to the model baseline. Correlated features share attribution; contributions are not causal proof."
}
```

## POST /api/v1/search

Request format: {"$ref": "#/components/schemas/SearchRequest"}

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/SearchResult"}}}

Sample request: POST /api/v1/search

```json
{
  "query": "Historical SSH brute force traffic",
  "top_k": 5,
  "mode": "hybrid",
  "fusion": "rrf",
  "filters": {
    "attack_type": "Brute Force"
  }
}
```

Sample response (abridged):

```json
{
  "results": [
    {
      "incident_id": "CIC-15896995609171833047",
      "attack_type": "Brute Force",
      "original_label": "SSH-Patator",
      "metadata": "[abridged; see full JSON example]",
      "features": "[abridged; see full JSON example]",
      "document": "Network flow to destination port 22. Protocol TCP. Observed flow duration in microseconds: 104. Observed packet rate packets per second: 1.923e+04. Observed byte throughput bytes per second: 0. Observed forward packet co [abridged]",
      "severity": "HIGH",
      "risk_score": 65.0,
      "risk_source": "historical_label_prior",
      "similarity_score": 0.8034485784485784,
      "semantic_score": 0.604211151599884,
      "keyword_score": 7.334308427175653,
      "_omitted_fields": 2
    },
    {
      "incident_id": "CIC-106237111341150213",
      "attack_type": "Brute Force",
      "original_label": "SSH-Patator",
      "metadata": "[abridged; see full JSON example]",
      "features": "[abridged; see full JSON example]",
      "document": "Network flow to destination port 22. Protocol TCP. Observed flow duration in microseconds: 107. Observed packet rate packets per second: 1.869e+04. Observed byte throughput bytes per second: 0. Observed forward packet co [abridged]",
      "severity": "HIGH",
      "risk_score": 65.0,
      "risk_source": "historical_label_prior",
      "similarity_score": 0.8025,
      "semantic_score": 0.6116292476654053,
      "keyword_score": 7.334308427175653,
      "_omitted_fields": 2
    },
    "[3 more items; see full JSON example]"
  ],
  "alpha": 0.65,
  "embedding_provider": "lsa",
  "latency_ms": 60.087,
  "limitations": [
    "Similarity scores are ranking scores, not attack probabilities.",
    "Historical severity uses the documented label prior, not an investigation score."
  ],
  "strategy": "hybrid_rrf",
  "expanded_terms": [],
  "candidate_count": 2225
}
```

## POST /api/v1/rag/answer

Request format: {"$ref": "#/components/schemas/RAGRequest"}

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/RAGResult"}}}

Sample request: POST /api/v1/rag/answer

```json
{
  "query": "Historical SSH brute force traffic",
  "top_k": 5,
  "mode": "hybrid",
  "fusion": "rrf",
  "filters": {
    "attack_type": "Brute Force"
  },
  "use_llm": false
}
```

Sample response (abridged):

```json
{
  "analysis": {
    "answer": "Historical evidence matches:\n[CIC-13458235730792757916] Historical category: Brute Force; destination port: 22.0; packet rate: 4.340667246 packets/s.\n[CIC-17934726577791822535] Historical category: Brute Force; destinati [abridged]",
    "cited_incident_ids": [
      "CIC-13458235730792757916",
      "CIC-17934726577791822535",
      "[3 more items; see full JSON example]"
    ],
    "evidence_gaps": [
      "A local evidence extract cannot provide full LLM reasoning about the question.",
      "Flow-only history cannot establish intent, host compromise, or attribution.",
      "[3 more items; see full JSON example]"
    ],
    "recommended_next_steps": [
      "Correlate matching flow indicators with current IDS, firewall, authentication, and service logs.",
      "Confirm affected assets, event time, and impact before selecting containment actions."
    ]
  },
  "retrieval": {
    "results": [
      "[abridged; see full JSON example]",
      "[abridged; see full JSON example]",
      "[3 more items; see full JSON example]"
    ],
    "alpha": 0.65,
    "embedding_provider": "lsa",
    "latency_ms": 71.236,
    "limitations": [
      "Similarity scores are ranking scores, not attack probabilities.",
      "Historical severity uses the documented label prior, not an investigation score."
    ],
    "strategy": "hybrid_rrf_diverse",
    "expanded_terms": [
      "authentication",
      "password",
      "[7 more items; see full JSON example]"
    ],
    "candidate_count": 2225
  },
  "provider": "local_evidence_extract",
  "context_incident_ids": [
    "CIC-13458235730792757916",
    "CIC-17934726577791822535",
    "[3 more items; see full JSON example]"
  ]
}
```

## POST /api/v1/investigate

Request format: {"$ref": "#/components/schemas/InvestigationRequest"}

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/InvestigationResult"}}}

Sample request: POST /api/v1/investigate

```json
{
  "flow": {
    "features": {
      "destination_port": 80.0,
      "flow_duration": 298783.0,
      "flow_packets_s": 30.12219571,
      "flow_bytes_s": 38914.52994
    }
  },
  "query": "Investigate observed service traffic",
  "use_llm": false,
  "judge": false
}
```

Sample response (abridged):

```json
{
  "incident_id": "INV-266072ac60ec4ff7",
  "created_at": "2026-10-12T07:52:29.283764+00:00",
  "prediction": {
    "predicted_attack_type": "BENIGN",
    "classification_confidence": 0.38217633886066565,
    "malicious_probability": 0.6803679830315411,
    "probabilities": {
      "BENIGN": 0.38217633886066565,
      "Bot": 0.01,
      "Brute Force": 0.11239834600532544,
      "DDoS": 0.25,
      "DoS": 0.18378782343755465,
      "Heartbleed": 0.0,
      "Infiltration": 0.0,
      "PortScan": 0.04163749169645428,
      "Web Attack": 0.02
    },
    "model_version": "cicids-aa6f46dbeb",
    "missing_features": [
      "total_fwd_packets",
      "total_length_of_fwd_packets",
      "[71 more items; see full JSON example]"
    ],
    "out_of_range_features": []
  },
  "anomaly": {
    "anomaly_score": 0.32218707973958577,
    "normalized_anomaly_risk": 0.19095477386934673,
    "is_anomalous": false,
    "interpretation": "Percentile relative to benign training flows; unusual traffic is not proof of an attack."
  },
  "risk": {
    "risk_score": 34.9,
    "severity": "MEDIUM",
    "priority": "P3",
    "components": {
      "malicious_probability": 0.6803679830315411,
      "anomaly_percentile": 0.19095477386934673,
      "malicious_confidence": 0.0,
      "attack_prior": 0.0,
      "traffic_indicators": 0.3214365037472449
    },
    "weights": {
      "malicious_probability": 0.4,
      "anomaly_percentile": 0.15,
      "malicious_confidence": 0.05,
      "attack_prior": 0.25,
      "traffic_indicators": 0.15
    },
    "explanation": "P3: model predicts BENIGN with 38.2% confidence; malicious confidence 68.0%; anomaly percentile 19.1%. Score is a configurable triage policy, not a calibrated probability. Historical label similarity does not establish a [abridged]"
  },
  "explanation": {
    "method": "TreeSHAP",
    "predicted_class": "BENIGN",
    "base_value": 0.11165469231452034,
    "predicted_probability": 0.38217633886066565,
    "reconstructed_probability": 0.38217633886066654,
    "contributions": [
      "[abridged; see full JSON example]",
      "[abridged; see full JSON example]",
      "[78 more items; see full JSON example]"
    ],
    "explanation": "SHAP values explain the predicted class probability relative to the model baseline. Correlated features share attribution; contributions are not causal proof."
  },
  "retrieval": {
    "results": [
      "[abridged; see full JSON example]",
      "[abridged; see full JSON example]",
      "[3 more items; see full JSON example]"
    ],
    "alpha": 0.65,
    "embedding_provider": "lsa",
    "latency_ms": 233.408,
    "limitations": [
      "Similarity scores are ranking scores, not attack probabilities.",
      "Historical severity uses the documented label prior, not an investigation score.",
      "[1 more items; see full JSON example]"
    ],
    "strategy": "hybrid_rrf_flow_reranked_diverse",
    "expanded_terms": [],
    "candidate_count": 16218
  },
  "analysis": {
    "executive_summary": "The supervised model predicts BENIGN with 38.2% confidence. This is a model inference requiring analyst validation. Triage score is 34.90/100, MEDIUM severity, P3 priority.",
    "observed_evidence": [
      "Destination port: 80.",
      "Packet rate: 30.12 packets/s; byte rate: 3.891e+04 bytes/s.",
      "[1 more items; see full JSON example]"
    ],
    "model_inference": "The supervised model predicts BENIGN with 38.2% confidence. This is a model inference requiring analyst validation.",
    "historical_incident_ids": [
      "CIC-3269739774179571824",
      "CIC-7919786870730727174",
      "[3 more items; see full JSON example]"
    ],
    "immediate_investigation": [
      "[abridged; see full JSON example]",
      "[abridged; see full JSON example]"
    ],
    "containment_considerations": [
      "[abridged; see full JSON example]"
    ],
    "further_evidence": [
      "[abridged; see full JSON example]"
    ],
    "longer_term_mitigation": [
      "[abridged; see full JSON example]"
    ],
    "evidence_limitations": [
      "Flow records alone cannot establish host compromise, intent, or attribution.",
      "Model probabilities reflect a class-sampled training distribution and are not calibrated deployment probabilities.",
      "[6 more items; see full JSON example]"
    ]
  },
  "analysis_provider": "local_evidence_playbook",
  "judge": null,
  "workflow": [
    {
      "agent": "Detection Agent",
      "status": "completed",
      "latency_ms": 114.058,
      "tools": "[abridged; see full JSON example]",
      "detail": null
    },
    {
      "agent": "Anomaly Agent",
      "status": "completed",
      "latency_ms": 18.682,
      "tools": "[abridged; see full JSON example]",
      "detail": null
    },
    "[5 more items; see full JSON example]"
  ],
  "latency_ms": 390.875
}
```

## POST /api/v1/recommend

Request format: {"$ref": "#/components/schemas/InvestigationRequest"}

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/InvestigationResult"}}}

Sample request: POST /api/v1/recommend

```json
{
  "flow": {
    "features": {
      "destination_port": 80.0,
      "flow_duration": 298783.0,
      "flow_packets_s": 30.12219571,
      "flow_bytes_s": 38914.52994
    }
  },
  "query": "Investigate observed service traffic",
  "use_llm": false,
  "judge": false
}
```

Sample response (abridged):

```json
{
  "incident_id": "INV-e159fc9b92334abe",
  "created_at": "2026-10-12T07:52:29.601706+00:00",
  "prediction": {
    "predicted_attack_type": "BENIGN",
    "classification_confidence": 0.38217633886066565,
    "malicious_probability": 0.6803679830315411,
    "probabilities": {
      "BENIGN": 0.38217633886066565,
      "Bot": 0.01,
      "Brute Force": 0.11239834600532544,
      "DDoS": 0.25,
      "DoS": 0.18378782343755465,
      "Heartbleed": 0.0,
      "Infiltration": 0.0,
      "PortScan": 0.04163749169645428,
      "Web Attack": 0.02
    },
    "model_version": "cicids-aa6f46dbeb",
    "missing_features": [
      "total_fwd_packets",
      "total_length_of_fwd_packets",
      "[71 more items; see full JSON example]"
    ],
    "out_of_range_features": []
  },
  "anomaly": {
    "anomaly_score": 0.32218707973958577,
    "normalized_anomaly_risk": 0.19095477386934673,
    "is_anomalous": false,
    "interpretation": "Percentile relative to benign training flows; unusual traffic is not proof of an attack."
  },
  "risk": {
    "risk_score": 34.9,
    "severity": "MEDIUM",
    "priority": "P3",
    "components": {
      "malicious_probability": 0.6803679830315411,
      "anomaly_percentile": 0.19095477386934673,
      "malicious_confidence": 0.0,
      "attack_prior": 0.0,
      "traffic_indicators": 0.3214365037472449
    },
    "weights": {
      "malicious_probability": 0.4,
      "anomaly_percentile": 0.15,
      "malicious_confidence": 0.05,
      "attack_prior": 0.25,
      "traffic_indicators": 0.15
    },
    "explanation": "P3: model predicts BENIGN with 38.2% confidence; malicious confidence 68.0%; anomaly percentile 19.1%. Score is a configurable triage policy, not a calibrated probability. Historical label similarity does not establish a [abridged]"
  },
  "explanation": {
    "method": "TreeSHAP",
    "predicted_class": "BENIGN",
    "base_value": 0.11165469231452034,
    "predicted_probability": 0.38217633886066565,
    "reconstructed_probability": 0.38217633886066654,
    "contributions": [
      "[abridged; see full JSON example]",
      "[abridged; see full JSON example]",
      "[78 more items; see full JSON example]"
    ],
    "explanation": "SHAP values explain the predicted class probability relative to the model baseline. Correlated features share attribution; contributions are not causal proof."
  },
  "retrieval": {
    "results": [
      "[abridged; see full JSON example]",
      "[abridged; see full JSON example]",
      "[3 more items; see full JSON example]"
    ],
    "alpha": 0.65,
    "embedding_provider": "lsa",
    "latency_ms": 227.105,
    "limitations": [
      "Similarity scores are ranking scores, not attack probabilities.",
      "Historical severity uses the documented label prior, not an investigation score.",
      "[1 more items; see full JSON example]"
    ],
    "strategy": "hybrid_rrf_flow_reranked_diverse",
    "expanded_terms": [],
    "candidate_count": 16218
  },
  "analysis": {
    "executive_summary": "The supervised model predicts BENIGN with 38.2% confidence. This is a model inference requiring analyst validation. Triage score is 34.90/100, MEDIUM severity, P3 priority.",
    "observed_evidence": [
      "Destination port: 80.",
      "Packet rate: 30.12 packets/s; byte rate: 3.891e+04 bytes/s.",
      "[1 more items; see full JSON example]"
    ],
    "model_inference": "The supervised model predicts BENIGN with 38.2% confidence. This is a model inference requiring analyst validation.",
    "historical_incident_ids": [
      "CIC-3269739774179571824",
      "CIC-7919786870730727174",
      "[3 more items; see full JSON example]"
    ],
    "immediate_investigation": [
      "[abridged; see full JSON example]",
      "[abridged; see full JSON example]"
    ],
    "containment_considerations": [
      "[abridged; see full JSON example]"
    ],
    "further_evidence": [
      "[abridged; see full JSON example]"
    ],
    "longer_term_mitigation": [
      "[abridged; see full JSON example]"
    ],
    "evidence_limitations": [
      "Flow records alone cannot establish host compromise, intent, or attribution.",
      "Model probabilities reflect a class-sampled training distribution and are not calibrated deployment probabilities.",
      "[6 more items; see full JSON example]"
    ]
  },
  "analysis_provider": "local_evidence_playbook",
  "judge": null,
  "workflow": [
    {
      "agent": "Detection Agent",
      "status": "completed",
      "latency_ms": 41.318,
      "tools": "[abridged; see full JSON example]",
      "detail": null
    },
    {
      "agent": "Anomaly Agent",
      "status": "completed",
      "latency_ms": 18.19,
      "tools": "[abridged; see full JSON example]",
      "detail": null
    },
    "[5 more items; see full JSON example]"
  ],
  "latency_ms": 311.16
}
```

## POST /api/v1/feedback

Request format: {"$ref": "#/components/schemas/FeedbackRequest"}

Response format: HTTP 201, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/FeedbackResult"}}}

Sample request: POST /api/v1/feedback

```json
{
  "incident_id": "INV-266072ac60ec4ff7",
  "helpful": true,
  "comment": "Local documentation example; pending review."
}
```

Sample response (abridged):

```json
{
  "feedback_id": 1,
  "incident_id": "INV-266072ac60ec4ff7",
  "interaction_type": null,
  "status": "pending_review"
}
```

## POST /api/v1/feedback

Request format: {"$ref": "#/components/schemas/FeedbackRequest"}

Response format: HTTP 201, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/FeedbackResult"}}}

Sample request: POST /api/v1/feedback

```json
{
  "interaction_type": "ai_analyst",
  "context": "Explain SSH brute-force evidence",
  "helpful": false,
  "comment": "Needs clearer citation context."
}
```

Sample response (abridged):

```json
{
  "feedback_id": 1,
  "incident_id": null,
  "interaction_type": "ai_analyst",
  "status": "pending_review"
}
```

## POST /api/v1/feedback

Request format: {"$ref": "#/components/schemas/FeedbackRequest"}

Response format: HTTP 201, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/FeedbackResult"}}}

Sample request: POST /api/v1/feedback

```json
{
  "interaction_type": "rag_search",
  "context": "Historical SSH brute-force activity",
  "helpful": true,
  "comment": "Relevant historical matches."
}
```

Sample response (abridged):

```json
{
  "feedback_id": 2,
  "incident_id": null,
  "interaction_type": "rag_search",
  "status": "pending_review"
}
```

## GET /api/v1/feedback

Request format: No body; path/query parameters as shown.

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {}}}

Sample request: GET /api/v1/feedback

No request body.

Sample response (abridged):

```json
[
  {
    "id": 2,
    "context_type": "rag_search",
    "incident_id": null,
    "context": "Historical SSH brute-force activity",
    "created_at": "2026-10-12T07:52:29.616797+00:00",
    "helpful": 1,
    "corrected_attack_type": null,
    "corrected_severity": null,
    "comment": "Relevant historical matches.",
    "review_status": "pending"
  },
  {
    "id": 1,
    "context_type": "ai_analyst",
    "incident_id": null,
    "context": "Explain SSH brute-force evidence",
    "created_at": "2026-10-12T07:52:29.613435+00:00",
    "helpful": 0,
    "corrected_attack_type": null,
    "corrected_severity": null,
    "comment": "Needs clearer citation context.",
    "review_status": "pending"
  },
  "[1 more items; see full JSON example]"
]
```

## GET /api/v1/incidents

Request format: No body; path/query parameters as shown.

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {}}}

Sample request: GET /api/v1/incidents?limit=8&offset=0&sort=risk&query=INV-

No request body.

Sample response (abridged):

```json
{
  "items": [
    {
      "incident_id": "INV-e159fc9b92334abe",
      "created_at": "2026-10-12T07:52:29.601706+00:00",
      "attack_type": "BENIGN",
      "priority": "P3",
      "risk_score": 34.9
    },
    {
      "incident_id": "INV-266072ac60ec4ff7",
      "created_at": "2026-10-12T07:52:29.283764+00:00",
      "attack_type": "BENIGN",
      "priority": "P3",
      "risk_score": 34.9
    }
  ],
  "total": 2
}
```

## GET /api/v1/incidents/{incident_id}

Request format: No body; path/query parameters as shown.

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"anyOf": [{"$ref": "#/components/schemas/HistoricalIncident"}, {"$ref": "#/components/schemas/InvestigationResult"}], "title": "Response Incident Api V1 Incidents  Incident Id  Get"}}}

Sample request: GET /api/v1/incidents/INV-266072ac60ec4ff7

No request body.

Sample response (abridged):

```json
{
  "incident_id": "INV-266072ac60ec4ff7",
  "created_at": "2026-10-12T07:52:29.283764+00:00",
  "prediction": {
    "predicted_attack_type": "BENIGN",
    "classification_confidence": 0.38217633886066565,
    "malicious_probability": 0.6803679830315411,
    "probabilities": {
      "BENIGN": 0.38217633886066565,
      "Bot": 0.01,
      "Brute Force": 0.11239834600532544,
      "DDoS": 0.25,
      "DoS": 0.18378782343755465,
      "Heartbleed": 0.0,
      "Infiltration": 0.0,
      "PortScan": 0.04163749169645428,
      "Web Attack": 0.02
    },
    "model_version": "cicids-aa6f46dbeb",
    "missing_features": [
      "total_fwd_packets",
      "total_length_of_fwd_packets",
      "[71 more items; see full JSON example]"
    ],
    "out_of_range_features": []
  },
  "anomaly": {
    "anomaly_score": 0.32218707973958577,
    "normalized_anomaly_risk": 0.19095477386934673,
    "is_anomalous": false,
    "interpretation": "Percentile relative to benign training flows; unusual traffic is not proof of an attack."
  },
  "risk": {
    "risk_score": 34.9,
    "severity": "MEDIUM",
    "priority": "P3",
    "components": {
      "malicious_probability": 0.6803679830315411,
      "anomaly_percentile": 0.19095477386934673,
      "malicious_confidence": 0.0,
      "attack_prior": 0.0,
      "traffic_indicators": 0.3214365037472449
    },
    "weights": {
      "malicious_probability": 0.4,
      "anomaly_percentile": 0.15,
      "malicious_confidence": 0.05,
      "attack_prior": 0.25,
      "traffic_indicators": 0.15
    },
    "explanation": "P3: model predicts BENIGN with 38.2% confidence; malicious confidence 68.0%; anomaly percentile 19.1%. Score is a configurable triage policy, not a calibrated probability. Historical label similarity does not establish a [abridged]"
  },
  "explanation": {
    "method": "TreeSHAP",
    "predicted_class": "BENIGN",
    "base_value": 0.11165469231452034,
    "predicted_probability": 0.38217633886066565,
    "reconstructed_probability": 0.38217633886066654,
    "contributions": [
      "[abridged; see full JSON example]",
      "[abridged; see full JSON example]",
      "[78 more items; see full JSON example]"
    ],
    "explanation": "SHAP values explain the predicted class probability relative to the model baseline. Correlated features share attribution; contributions are not causal proof."
  },
  "retrieval": {
    "results": [
      "[abridged; see full JSON example]",
      "[abridged; see full JSON example]",
      "[3 more items; see full JSON example]"
    ],
    "alpha": 0.65,
    "embedding_provider": "lsa",
    "latency_ms": 233.408,
    "limitations": [
      "Similarity scores are ranking scores, not attack probabilities.",
      "Historical severity uses the documented label prior, not an investigation score.",
      "[1 more items; see full JSON example]"
    ],
    "strategy": "hybrid_rrf_flow_reranked_diverse",
    "expanded_terms": [],
    "candidate_count": 16218
  },
  "analysis": {
    "executive_summary": "The supervised model predicts BENIGN with 38.2% confidence. This is a model inference requiring analyst validation. Triage score is 34.90/100, MEDIUM severity, P3 priority.",
    "observed_evidence": [
      "Destination port: 80.",
      "Packet rate: 30.12 packets/s; byte rate: 3.891e+04 bytes/s.",
      "[1 more items; see full JSON example]"
    ],
    "model_inference": "The supervised model predicts BENIGN with 38.2% confidence. This is a model inference requiring analyst validation.",
    "historical_incident_ids": [
      "CIC-3269739774179571824",
      "CIC-7919786870730727174",
      "[3 more items; see full JSON example]"
    ],
    "immediate_investigation": [
      "[abridged; see full JSON example]",
      "[abridged; see full JSON example]"
    ],
    "containment_considerations": [
      "[abridged; see full JSON example]"
    ],
    "further_evidence": [
      "[abridged; see full JSON example]"
    ],
    "longer_term_mitigation": [
      "[abridged; see full JSON example]"
    ],
    "evidence_limitations": [
      "Flow records alone cannot establish host compromise, intent, or attribution.",
      "Model probabilities reflect a class-sampled training distribution and are not calibrated deployment probabilities.",
      "[6 more items; see full JSON example]"
    ]
  },
  "analysis_provider": "local_evidence_playbook",
  "judge": null,
  "workflow": [
    {
      "agent": "Detection Agent",
      "status": "completed",
      "latency_ms": 114.058,
      "tools": "[abridged; see full JSON example]",
      "detail": null
    },
    {
      "agent": "Anomaly Agent",
      "status": "completed",
      "latency_ms": 18.682,
      "tools": "[abridged; see full JSON example]",
      "detail": null
    },
    "[5 more items; see full JSON example]"
  ],
  "latency_ms": 390.875
}
```

## GET /api/v1/incidents/{incident_id}/report

Request format: No body; path/query parameters as shown.

Response format: HTTP 200, text/markdown; charset=utf-8. Schema: {"application/json": {"schema": {}}}

Sample request: GET /api/v1/incidents/INV-266072ac60ec4ff7/report

No request body.

Sample response (abridged):

```json
"# Investigation INV-266072ac60ec4ff7\n\nCreated: 2026-10-12T07:52:29.283764+00:00\nModel version: cicids-aa6f46dbeb\nAnalysis provider: local_evidence_playbook\n\n## Triage\n\nPredicted category: BENIGN\nClassification confidence [abridged]"
```

## GET /api/v1/metrics

Request format: No body; path/query parameters as shown.

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {"$ref": "#/components/schemas/MetricsResult"}}}

Sample request: GET /api/v1/metrics

No request body.

Sample response (abridged):

```json
{
  "total_analyzed": 2,
  "benign": 2,
  "malicious": 0,
  "attack_distribution": {
    "BENIGN": 2
  },
  "priority_distribution": {
    "P3": 2
  },
  "recent_incidents": [
    {
      "incident_id": "INV-e159fc9b92334abe",
      "created_at": "2026-10-12T07:52:29.601706+00:00",
      "attack_type": "BENIGN",
      "priority": "P3",
      "risk_score": 34.9
    },
    {
      "incident_id": "INV-266072ac60ec4ff7",
      "created_at": "2026-10-12T07:52:29.283764+00:00",
      "attack_type": "BENIGN",
      "priority": "P3",
      "risk_score": 34.9
    }
  ],
  "feedback_count": 3,
  "indexed_incidents": 16218,
  "dataset_profile": {
    "source_name": "TrafficLabelling ",
    "source_bytes": 1203105382,
    "source_files": [
      "Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv",
      "Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv",
      "[6 more items; see full JSON example]"
    ],
    "timestamp_timezone_declared": "UTC",
    "timestamp_timezone_provenance": "user_declared",
    "source_encoding": "cp1252",
    "timestamps_deferred": false,
    "deferred_timestamp_rows": 0,
    "duplicate_column_rows_checked_and_removed": {
      "fwd_header_length_1": 3119345
    },
    "timestamp_format": null,
    "day_first": true,
    "rows_scanned": 3119345,
    "_omitted_fields": 20
  },
  "evaluation": {
    "classification": {
      "name": "RandomForest",
      "version": "cicids-aa6f46dbeb",
      "training_date": "2026-10-11T07:50:13.301410+00:00",
      "dataset_version": "2b587a4b2089f80ea181251154bde09a99d707921ce493496ccf3a5b84c53367",
      "source_dataset": "TrafficLabelling ",
      "training_spec": "[abridged; see full JSON example]",
      "features": "[abridged; see full JSON example]",
      "target": "attack_category",
      "classes": "[abridged; see full JSON example]",
      "artifact_path": "/Users/hrushikeshreddy/final capstone/artifacts/traffic_labelling/models/bundle.joblib",
      "seed": 42,
      "split_sizes": "[abridged; see full JSON example]",
      "_omitted_fields": 13
    },
    "retrieval": {
      "status": "completed",
      "created_at": "2026-10-11T08:48:49.041885+00:00",
      "model_version": "cicids-aa6f46dbeb",
      "query_count": 42,
      "k": 5,
      "strategy": "Classifier prediction is appended as a soft text hint; it is not a strict metadata filter.",
      "metrics": "[abridged; see full JSON example]",
      "baseline_metrics": "[abridged; see full JSON example]",
      "per_class": "[abridged; see full JSON example]",
      "relevance_definition": "Same attack category as held-out flow; ground-truth labels are never included in queries.",
      "limitations": "[abridged; see full JSON example]",
      "queries": "[abridged; see full JSON example]"
    },
    "advanced_retrieval": {
      "status": "completed",
      "queries_per_strategy": 42,
      "k": 5,
      "created_at": "2026-10-11T08:49:11.292142+00:00",
      "model_version": "cicids-aa6f46dbeb",
      "metrics": "[abridged; see full JSON example]",
      "limitations": "[abridged; see full JSON example]",
      "queries": "[abridged; see full JSON example]"
    },
    "deepeval": {
      "framework": "DeepEval",
      "case_count": 9,
      "offline_structural_checks": "[abridged; see full JSON example]",
      "llm_metrics_status": "partial",
      "llm_metrics": "[abridged; see full JSON example]",
      "created_at": "2026-10-12T03:43:54.398044+00:00",
      "model_version": "cicids-aa6f46dbeb",
      "llm_provider": "nvidia",
      "generation_model": "nvidia/nemotron-3.5-lightning-30b-a3b",
      "judge_model": "nvidia/nemotron-3.5-lightning-30b-a3b",
      "analysis_providers": "[abridged; see full JSON example]",
      "judge_results": "[abridged; see full JSON example]",
      "_omitted_fields": 3
    },
    "offline_quality": {
      "framework": "DeepEval",
      "case_count": 9,
      "offline_structural_checks": "[abridged; see full JSON example]",
      "llm_metrics_status": "not_run_offline",
      "llm_metrics": "[abridged; see full JSON example]",
      "created_at": "2026-10-11T15:05:17.719798+00:00",
      "model_version": "cicids-aa6f46dbeb",
      "llm_provider": "anthropic",
      "generation_model": "claude-sonnet-4-6",
      "judge_model": "claude-sonnet-4-6",
      "analysis_providers": "[abridged; see full JSON example]",
      "judge_results": "[abridged; see full JSON example]",
      "_omitted_fields": 3
    },
    "prd_readiness": {
      "status": "incomplete",
      "checks": "[abridged; see full JSON example]",
      "created_at": "2026-10-12T04:15:32.432867+00:00",
      "model_version": "cicids-aa6f46dbeb",
      "source_dataset": "TrafficLabelling ",
      "metadata_record_counts": "[abridged; see full JSON example]",
      "complete_metadata_records": 16218,
      "missing_attack_categories": "[abridged; see full JSON example]",
      "key_configured": true,
      "quality_metrics_status": "partial",
      "blockers": "[abridged; see full JSON example]",
      "scope": "Reports whether DeepEval scores exist and whether full category coverage is complete; measurement does not mean scores passed quality thresholds."
    },
    "provider_connection": {
      "status": "not_required",
      "limitation": "Local providers are selected; no hosted authentication is required."
    }
  },
  "operational_quality": {
    "mean_risk_score": 34.9,
    "mean_latency_ms": 351.01750000000004,
    "incomplete_flows": 2,
    "out_of_range_flows": 0,
    "llm_fallbacks": 0
  },
  "historical_summary": {
    "total_records": 16218,
    "benign": 1592,
    "malicious": 14626,
    "attack_distribution": {
      "BENIGN": 1592,
      "Bot": 1562,
      "Brute Force": 2225,
      "DDoS": 1600,
      "DoS": 5905,
      "Heartbleed": 9,
      "Infiltration": 29,
      "PortScan": 1582,
      "Web Attack": 1714
    },
    "severity_distribution": {
      "HIGH": 9844,
      "CRITICAL": 3200,
      "MEDIUM": 1582,
      "LOW": 1592
    },
    "activity": [
      "[abridged; see full JSON example]",
      "[abridged; see full JSON example]",
      "[3 more items; see full JSON example]"
    ],
    "timestamp_missing": 0,
    "recent_records": [
      "[abridged; see full JSON example]",
      "[abridged; see full JSON example]",
      "[18 more items; see full JSON example]"
    ]
  }
}
```

## GET /api/v1/explain/global

Request format: No body; path/query parameters as shown.

Response format: HTTP 200, application/json. Schema: {"application/json": {"schema": {}}}

Sample request: GET /api/v1/explain/global

No request body.

Sample response (abridged):

```json
{
  "global_importance": [
    {
      "feature": "destination_port",
      "importance": 0.07886575228810692
    },
    {
      "feature": "init_win_bytes_backward",
      "importance": 0.055293320837551445
    },
    "[78 more items; see full JSON example]"
  ],
  "importance_method": "ensemble_mean_impurity_decrease",
  "attack_patterns": {
    "BENIGN": {
      "destination_port": 80.0,
      "flow_duration": 30834.5,
      "total_fwd_packets": 2.0,
      "total_length_of_fwd_packets": 66.0,
      "fwd_packet_length_max": 40.0,
      "fwd_packet_length_min": 6.0,
      "fwd_packet_length_mean": 37.0,
      "fwd_packet_length_std": 0.0,
      "bwd_packet_length_max": 90.0,
      "bwd_packet_length_min": 6.0,
      "bwd_packet_length_mean": 81.0,
      "bwd_packet_length_std": 0.0,
      "_omitted_fields": 65
    },
    "Bot": {
      "destination_port": 8080.0,
      "flow_duration": 71054.5,
      "total_fwd_packets": 3.0,
      "total_length_of_fwd_packets": 6.0,
      "fwd_packet_length_max": 6.0,
      "fwd_packet_length_min": 0.0,
      "fwd_packet_length_mean": 6.0,
      "fwd_packet_length_std": 0.0,
      "bwd_packet_length_max": 6.0,
      "bwd_packet_length_min": 6.0,
      "bwd_packet_length_mean": 6.0,
      "bwd_packet_length_std": 0.0,
      "_omitted_fields": 65
    },
    "Brute Force": {
      "destination_port": 21.0,
      "flow_duration": 9138501.0,
      "total_fwd_packets": 9.0,
      "total_length_of_fwd_packets": 107.0,
      "fwd_packet_length_max": 24.0,
      "fwd_packet_length_min": 0.0,
      "fwd_packet_length_mean": 11.88888889,
      "fwd_packet_length_std": 9.899494937,
      "bwd_packet_length_max": 34.0,
      "bwd_packet_length_min": 0.0,
      "bwd_packet_length_mean": 12.53333333,
      "bwd_packet_length_std": 14.54975045,
      "_omitted_fields": 65
    },
    "DDoS": {
      "destination_port": 80.0,
      "flow_duration": 1837729.5,
      "total_fwd_packets": 4.0,
      "total_length_of_fwd_packets": 26.0,
      "fwd_packet_length_max": 20.0,
      "fwd_packet_length_min": 0.0,
      "fwd_packet_length_mean": 7.0,
      "fwd_packet_length_std": 5.656854249,
      "bwd_packet_length_max": 5840.0,
      "bwd_packet_length_min": 0.0,
      "bwd_packet_length_mean": 1934.5,
      "bwd_packet_length_std": 2207.341206,
      "_omitted_fields": 65
    },
    "DoS": {
      "destination_port": 80.0,
      "flow_duration": 63097043.0,
      "total_fwd_packets": 6.0,
      "total_length_of_fwd_packets": 324.0,
      "fwd_packet_length_max": 231.0,
      "fwd_packet_length_min": 0.0,
      "fwd_packet_length_mean": 45.75,
      "fwd_packet_length_std": 99.6117463,
      "bwd_packet_length_max": 0.0,
      "bwd_packet_length_min": 0.0,
      "bwd_packet_length_mean": 0.0,
      "bwd_packet_length_std": 0.0,
      "_omitted_fields": 65
    },
    "Heartbleed": {
      "destination_port": 444.0,
      "flow_duration": 119261118.0,
      "total_fwd_packets": 2794.0,
      "total_length_of_fwd_packets": 13712.0,
      "fwd_packet_length_max": 5792.0,
      "fwd_packet_length_min": 0.0,
      "fwd_packet_length_mean": 4.902395424,
      "fwd_packet_length_std": 110.2779074,
      "bwd_packet_length_max": 13032.0,
      "bwd_packet_length_min": 0.0,
      "bwd_packet_length_mean": 3773.303973,
      "bwd_packet_length_std": 2372.06653,
      "_omitted_fields": 65
    },
    "Infiltration": {
      "destination_port": 444.0,
      "flow_duration": 99912925.0,
      "total_fwd_packets": 34.0,
      "total_length_of_fwd_packets": 12042.0,
      "fwd_packet_length_max": 1271.0,
      "fwd_packet_length_min": 6.0,
      "fwd_packet_length_mean": 337.7333333,
      "fwd_packet_length_std": 269.6103044,
      "bwd_packet_length_max": 6.0,
      "bwd_packet_length_min": 6.0,
      "bwd_packet_length_mean": 6.0,
      "bwd_packet_length_std": 0.0,
      "_omitted_fields": 65
    },
    "PortScan": {
      "destination_port": 3801.0,
      "flow_duration": 48.0,
      "total_fwd_packets": 1.0,
      "total_length_of_fwd_packets": 2.0,
      "fwd_packet_length_max": 2.0,
      "fwd_packet_length_min": 2.0,
      "fwd_packet_length_mean": 2.0,
      "fwd_packet_length_std": 0.0,
      "bwd_packet_length_max": 6.0,
      "bwd_packet_length_min": 6.0,
      "bwd_packet_length_mean": 6.0,
      "bwd_packet_length_std": 0.0,
      "_omitted_fields": 65
    },
    "Web Attack": {
      "destination_port": 80.0,
      "flow_duration": 5498213.5,
      "total_fwd_packets": 3.0,
      "total_length_of_fwd_packets": 0.0,
      "fwd_packet_length_max": 0.0,
      "fwd_packet_length_min": 0.0,
      "fwd_packet_length_mean": 0.0,
      "fwd_packet_length_std": 0.0,
      "bwd_packet_length_max": 0.0,
      "bwd_packet_length_min": 0.0,
      "bwd_packet_length_mean": 0.0,
      "bwd_packet_length_std": 0.0,
      "_omitted_fields": 65
    }
  },
  "limitations": [],
  "note": "Global importance is not SHAP; local explanations use exact TreeSHAP."
}
```
