import asyncio
from contextlib import nullcontext
from dataclasses import replace
import json
from types import SimpleNamespace

import pytest

from scripts.check_llm_connection import save_probe
from src.agents.quality_judge import DIMENSIONS, JudgeService
from src.api.schemas import Analysis, JudgeOutput, RAGAnswer, RAGRequest
from src.services.artifact_reports import connection_report
from src.services.llm_provider import generate_structured
from src.services.rag_answers import RAGAnswerService, validate_answer
from src.services.recommendations import RecommendationService
from src.utils.config import settings
from src.utils.guardrails import validate_analysis_content, validate_query


@pytest.fixture
def nvidia_config(monkeypatch):
    monkeypatch.setenv("NVIDIA_API_KEY", "nvapi-test-only-credential-not-real")
    return replace(settings, llm_provider="nvidia", nvidia_base_url="https://integrate.api.nvidia.com/v1",
                   nvidia_model="nvidia/generation-fixture", nvidia_judge_model="nvidia/judge-fixture",
                   llm_failure_threshold=1)


def mock_nvidia(monkeypatch, create):
    import openai
    constructors = []
    def client(**kwargs):
        constructors.append(kwargs)
        return nullcontext(SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    monkeypatch.setattr(openai, "OpenAI", client)
    return constructors


def completion(value, finish="stop", refusal=None):
    return SimpleNamespace(choices=[SimpleNamespace(finish_reason=finish,
                           message=SimpleNamespace(content=value, refusal=refusal))])


def evidence(investigation):
    return {"prediction": investigation["prediction"], "risk": investigation["risk"],
            "observed_features": {"destination_port": 80, "flow_duration": 1000, "flow_packets_s": 10, "flow_bytes_s": 500},
            "metadata_availability": {},
            "historical_incidents": [{"incident_id": item["incident_id"]} for item in investigation["retrieval"]["results"]]}


def test_nvidia_credentials_and_model_selection_are_independent(nvidia_config, monkeypatch):
    assert nvidia_config.generation_model == "nvidia/generation-fixture"
    assert nvidia_config.evaluation_model == "nvidia/judge-fixture"
    assert nvidia_config.api_key_env == "NVIDIA_API_KEY"
    assert nvidia_config.credentials_configured
    fingerprint = nvidia_config.credential_fingerprint
    monkeypatch.setenv("NVIDIA_API_KEY", "nvapi-a-different-test-credential")
    assert nvidia_config.credential_fingerprint != fingerprint
    assert not replace(nvidia_config, llm_provider="local").credentials_configured


def test_nvidia_uses_chat_completions_with_json_schema(nvidia_config, monkeypatch, investigation):
    calls = []
    def create(**kwargs):
        calls.append(kwargs)
        return completion(json.dumps(investigation["analysis"]))
    constructors = mock_nvidia(monkeypatch, create)
    result, provider = RecommendationService(nvidia_config).generate(evidence(investigation), "Investigate this flow")
    assert provider == "nvidia" and result == Analysis.model_validate(investigation["analysis"])
    assert constructors == [{"api_key": "nvapi-test-only-credential-not-real", "base_url": nvidia_config.nvidia_base_url,
                             "timeout": nvidia_config.llm_timeout_seconds, "max_retries": 0}]
    assert calls[0]["model"] == nvidia_config.generation_model
    assert calls[0]["response_format"]["type"] == "json_schema"
    assert calls[0]["response_format"]["json_schema"]["schema"] == Analysis.model_json_schema()
    assert calls[0]["stream"] is False
    assert "untrusted DATA" in calls[0]["messages"][0]["content"]


@pytest.mark.parametrize("failure", ["length", "empty", "refusal", "malformed", "invented_citation", "timeout"])
def test_nvidia_invalid_outputs_keep_validated_local_recommendations(nvidia_config, monkeypatch, investigation, failure):
    def create(**kwargs):
        if failure == "timeout":
            raise TimeoutError("private-provider-detail")
        output = dict(investigation["analysis"])
        if failure == "invented_citation":
            output["historical_incident_ids"] = ["CIC-not-provided"]
        return completion(None if failure == "empty" else "invalid JSON" if failure == "malformed" else json.dumps(output),
                          finish="length" if failure == "length" else "stop",
                          refusal="refused" if failure == "refusal" else None)
    mock_nvidia(monkeypatch, create)
    result, provider = RecommendationService(nvidia_config).generate(evidence(investigation), "Investigate this flow")
    assert provider == "local_fallback"
    assert result.immediate_investigation
    assert "CIC-not-provided" not in result.historical_incident_ids
    assert "private-provider-detail" not in result.model_dump_json()


def test_nvidia_judge_uses_its_configured_model(nvidia_config, monkeypatch, investigation):
    calls = []
    output = {"dimensions": {name: {"score": 4, "reason": "Mocked evidence assessment"} for name in DIMENSIONS}}
    def create(**kwargs):
        calls.append(kwargs)
        return completion(json.dumps(output))
    mock_nvidia(monkeypatch, create)
    result = JudgeService(nvidia_config).evaluate(Analysis.model_validate(investigation["analysis"]), {"marker": "source-evidence"})
    assert result.status == "completed" and result.provider == "nvidia"
    assert set(result.dimensions) == DIMENSIONS
    assert calls[0]["model"] == nvidia_config.evaluation_model
    assert "source-evidence" in calls[0]["messages"][1]["content"]


def test_nemotron_thinking_setting_is_sent_to_the_provider(nvidia_config, monkeypatch):
    calls = []
    output = {"answer": "Historical fixture only, requiring review.", "cited_incident_ids": [],
              "evidence_gaps": ["Missing current context"], "recommended_next_steps": ["Review logs"]}
    def create(**kwargs):
        calls.append(kwargs)
        return completion(json.dumps(output))
    mock_nvidia(monkeypatch, create)
    for enabled in (False, True):
        config = replace(nvidia_config, nvidia_model="nvidia/nemotron-3.5-lightning-30b-a3b", nvidia_enable_thinking=enabled)
        generate_structured(config, "Analyze fixture", {}, RAGAnswer)
        assert calls[-1]["extra_body"] == {"chat_template_kwargs": {"enable_thinking": enabled}}


def test_nvidia_rag_preserves_inline_citation_checks(nvidia_config, monkeypatch, client):
    request = RAGRequest(query="Historical DDoS traffic", top_k=2)
    retrieval = client.app.state.services.retrieval.search(request)
    incident_id = retrieval.results[0].incident_id
    answer = {"answer": f"Historical evidence [{incident_id}] requires analyst review.", "cited_incident_ids": [incident_id],
              "evidence_gaps": ["Current compromise is not established."], "recommended_next_steps": ["Correlate service logs."]}
    mock_nvidia(monkeypatch, lambda **kwargs: completion(json.dumps(answer)))
    result = RAGAnswerService(nvidia_config).answer(request, retrieval)
    assert result.provider == "nvidia" and result.analysis.cited_incident_ids == [incident_id]


def test_nvidia_authentication_probe_does_not_send_incident_data(nvidia_config, monkeypatch, tmp_path):
    calls = []
    def create(**kwargs):
        calls.append(kwargs)
        # Authentication is verified by successful HTTP handling even if a tiny
        # token allowance stops the model before it completes its reasoning.
        return completion("", finish="length")
    mock_nvidia(monkeypatch, create)
    config = replace(nvidia_config, artifacts=tmp_path)
    report = save_probe(config)
    assert report["status"] == "authenticated" and report["base_url"] == config.nvidia_base_url
    assert calls[0]["messages"] == [{"role": "user", "content": "Reply with OK."}]
    assert calls[0]["max_tokens"] == 32
    assert connection_report(config)["status"] == "authenticated"
    changed = replace(config, nvidia_base_url="https://different-nim.example/v1")
    assert connection_report(changed)["status"] == "not_probed"
    assert "nvapi-test-only-credential-not-real" not in json.dumps(report)


def test_nvidia_deepeval_adapter_uses_configured_judge(nvidia_config, monkeypatch):
    from evaluation.nvidia_judge import NvidiaJudgeModel
    calls = []
    output = {"dimensions": {name: {"score": 4, "reason": "Mocked quality assessment"} for name in DIMENSIONS}}
    def create(**kwargs):
        calls.append(kwargs)
        return completion(json.dumps(output))
    mock_nvidia(monkeypatch, create)
    model = NvidiaJudgeModel(nvidia_config)
    assert isinstance(model.generate("Evaluate fixture", schema=JudgeOutput), JudgeOutput)
    assert isinstance(asyncio.run(model.a_generate("Evaluate fixture", schema=JudgeOutput)), JudgeOutput)
    assert len(calls) == 2 and all(call["model"] == nvidia_config.evaluation_model for call in calls)


def test_nvidia_credentials_are_rejected_in_queries_and_output(investigation):
    secret = "nvapi-test-only-credential-not-real"
    with pytest.raises(ValueError, match="credentials"):
        validate_query(f"Investigate {secret}")
    analysis = Analysis.model_validate(investigation["analysis"])
    analysis.executive_summary = secret
    with pytest.raises(ValueError, match="credentials"):
        validate_analysis_content(analysis)
    answer = RAGAnswer(answer=f"Leaked fixture credential: {secret}", cited_incident_ids=[],
                       evidence_gaps=["Missing context"], recommended_next_steps=["Review logs"])
    with pytest.raises(ValueError, match="unsafe"):
        validate_answer(answer, [])


def test_real_sdk_sends_nvidia_key_only_to_nvidia_endpoint(nvidia_config, monkeypatch):
    import httpx
    import openai
    real_client = openai.OpenAI
    calls = []
    def respond(request):
        calls.append(request)
        return httpx.Response(200, json={"id": "fixture", "object": "chat.completion", "created": 0,
            "model": nvidia_config.generation_model, "choices": [{"index": 0, "finish_reason": "stop",
            "message": {"role": "assistant", "content": json.dumps({"answer": "Fixture historical evidence only.",
            "cited_incident_ids": [], "evidence_gaps": ["No current context"], "recommended_next_steps": ["Review logs"]})}}]})
    monkeypatch.setattr(openai, "OpenAI", lambda **kwargs: real_client(
        http_client=httpx.Client(transport=httpx.MockTransport(respond)), **kwargs))
    result = generate_structured(nvidia_config, "Defensive evidence analysis", {"fixture": True}, RAGAnswer)
    assert isinstance(result, RAGAnswer)
    assert str(calls[0].url) == "https://integrate.api.nvidia.com/v1/chat/completions"
    assert calls[0].headers["authorization"] == "Bearer nvapi-test-only-credential-not-real"
