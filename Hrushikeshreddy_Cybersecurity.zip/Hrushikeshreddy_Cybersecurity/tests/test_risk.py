import pytest

from src.api.schemas import AnomalyResult, FlowInput, Prediction
from src.services.risk import RiskEngine, severity_for


@pytest.mark.parametrize("score,severity,priority", [(0,"LOW","P4"),(29.99,"LOW","P4"),(30,"MEDIUM","P3"),(60,"HIGH","P2"),(80,"CRITICAL","P1"),(100,"CRITICAL","P1")])
def test_severity_boundaries(score, severity, priority):
    assert severity_for(score) == (severity, priority)


def test_risk_matches_configured_components(investigation):
    risk = investigation["risk"]
    calculated = 100 * sum(value * risk["weights"][name] for name, value in risk["components"].items())
    assert risk["risk_score"] == pytest.approx(round(calculated, 2))


def test_benign_confidence_does_not_inflate_malicious_confidence():
    flow = FlowInput(features={"destination_port": 443, "flow_duration": 100, "flow_packets_s": 2, "flow_bytes_s": 100})
    prediction = Prediction(predicted_attack_type="BENIGN", classification_confidence=1, malicious_probability=0, probabilities={"BENIGN":1}, model_version="test", missing_features=[], out_of_range_features=[])
    anomaly = AnomalyResult(anomaly_score=0.3, normalized_anomaly_risk=0.1, is_anomalous=False, interpretation="test")
    result = RiskEngine((0.5, 0.15, 0.1, 0.15, 0.1)).score(flow, prediction, anomaly)
    assert result.components["malicious_confidence"] == 0
    assert result.severity == "LOW"
