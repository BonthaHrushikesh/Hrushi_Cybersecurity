import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { InvestigationForm } from './InvestigationForm'
import { demoHistorical } from '../../demo/data'

describe('Investigation flow integrity', () => {
  afterEach(cleanup)
  it('preserves features outside visible fields and leaves absent measurements missing', async () => {
    const onSubmit = vi.fn()
    const features = { destination_port: 80, flow_duration: 1000, flow_packets_s: 10, flow_bytes_s: 500, fwd_iat_mean: 77 }
    render(<InvestigationForm samples={[{ ...demoHistorical, attack_type: 'DDoS', features }]} pending={false} onSubmit={onSubmit} />)
    fireEvent.click(screen.getByRole('button', { name: 'Run investigation' }))
    await waitFor(() => expect(onSubmit).toHaveBeenCalledOnce())
    expect(onSubmit.mock.calls[0][0].flow.features).toEqual(features)
    expect(onSubmit.mock.calls[0][0].judge).toBe(false)
  })

  it('preserves explicit LLM and judge choices when loading another flow', async () => {
    const onSubmit = vi.fn()
    render(<InvestigationForm initialJudge samples={[demoHistorical, { ...demoHistorical, incident_id: 'fixture-alternative' }]} pending={false} onSubmit={onSubmit} />)
    expect(screen.getByLabelText('Run LLM judge')).toBeChecked()
    fireEvent.click(screen.getByLabelText('Use configured LLM'))
    fireEvent.click(screen.getByLabelText('Run LLM judge'))
    fireEvent.change(screen.getByRole('combobox', { name: '' }), { target: { value: 'fixture-alternative' } })
    expect(screen.getByLabelText('Run LLM judge')).not.toBeChecked()
    expect(screen.getByLabelText('Use configured LLM')).not.toBeChecked()
    fireEvent.click(screen.getByRole('button', { name: 'Run investigation' }))
    await waitFor(() => expect(onSubmit).toHaveBeenCalledOnce())
    expect(onSubmit.mock.calls[0][0].judge).toBe(false)
    expect(onSubmit.mock.calls[0][0].use_llm).toBe(false)
  })

  it('submits an explicitly selected judge without requiring live calls in the test', async () => {
    const onSubmit = vi.fn()
    render(<InvestigationForm initialJudge samples={[demoHistorical]} pending={false} onSubmit={onSubmit} />)
    fireEvent.click(screen.getByRole('button', { name: 'Run investigation' }))
    await waitFor(() => expect(onSubmit).toHaveBeenCalledOnce())
    expect(onSubmit.mock.calls[0][0].judge).toBe(true)
  })
})
