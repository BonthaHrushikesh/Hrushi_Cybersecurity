import { cleanup, fireEvent, render, screen, within } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { demoMetrics } from '../demo/data'
import { useApiResource } from '../hooks/useApiResource'
import { EvaluationPage } from './EvaluationPage'

vi.mock('../hooks/useApiResource', () => ({ useApiResource: vi.fn() }))
afterEach(cleanup)

function renderEvaluation(evaluation: Record<string, unknown>) {
  const refetch = vi.fn()
  vi.mocked(useApiResource, { partial: true }).mockReturnValue({
    data: { ...demoMetrics, evaluation }, isLoading: false, isFetching: false, refetch,
  })
  render(<EvaluationPage />)
  return refetch
}

describe('evaluation evidence states', () => {
  it('does not render missing reports as measured zero scores or zero quality cases', () => {
    renderEvaluation({})
    expect(screen.getAllByText('Not measured').length).toBeGreaterThan(0)
    expect(screen.queryByText('0.0%')).not.toBeInTheDocument()
    expect(screen.queryByText('0')).not.toBeInTheDocument()
    expect(screen.getByText('Retrieval evaluation has not been run for the active dataset.')).toBeInTheDocument()
    expect(screen.getByText('No live LLM quality scores have been measured.')).toBeInTheDocument()
  })

  it('shows all offline cases and the real authentication blocker without declaring live success', () => {
    const categories = ['BENIGN', 'Bot', 'Brute Force', 'DDoS', 'DoS', 'Heartbleed', 'Infiltration', 'PortScan', 'Web Attack']
    const refetch = renderEvaluation({
      deepeval: {
        framework: 'DeepEval', case_count: 9, llm_metrics_status: 'not_run_offline', llm_metrics: [],
        offline_structural_checks: categories.map(category => ({ category, score: 1, reason: 'Synthetic structural test fixture.' })),
      },
      provider_connection: { provider: 'anthropic', status: 'failed', http_status: 401,
        generation_model: 'fixture-model', judge_model: 'fixture-judge', created_at: '2026-10-11T00:00:00Z' },
      prd_readiness: { status: 'incomplete', checks: { live_generation_evidence: false,
        live_judge_evidence: false, deepeval_quality_measured: false }, blockers: ['Synthetic authentication blocker.'] },
    })
    expect(screen.getByText('9')).toBeInTheDocument()
    expect(screen.getByText('OFFLINE ONLY')).toBeInTheDocument()
    expect(screen.getAllByText('BLOCKED')).toHaveLength(3)
    expect(screen.getByText(/Claude rejected the configured API credential \(HTTP 401\)/)).toBeInTheDocument()
    expect(screen.getByText('Infiltration')).toBeInTheDocument()
    expect(screen.queryByText('Threshold passed')).not.toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Refresh evaluation reports' }))
    expect(refetch).toHaveBeenCalledOnce()
  })

  it('preserves actual zero retrieval results and shows measured quality thresholds separately', () => {
    const names = ['Answer Relevancy', 'Faithfulness', 'Contextual Precision', 'Contextual Recall', 'Hallucination']
    renderEvaluation({
      retrieval: { status: 'completed', query_count: 42, k: 5, metrics: { precision_at_k: 0, mrr: 0 },
        baseline_metrics: { precision_at_k: 0.6 } },
      deepeval: { case_count: 1, llm_metrics_status: 'completed', llm_metrics: [{ category: 'DDoS',
        metrics: names.map((metric, index) => ({ metric, status: 'completed', score: index === 0 ? 0.2 : 0.8,
          passed: index !== 0, reason: 'Synthetic measurement fixture, not live provider evidence.' })) }],
        analysis_providers: { DDoS: 'anthropic' },
        judge_results: { DDoS: { status: 'completed', provider: 'anthropic',
          dimensions: { safety: { score: 4, reason: 'Synthetic judge fixture.' } } } },
      },
    })
    const precision = screen.getByText('RAG Precision@5').closest('article')!
    expect(within(precision).getByText('0.0%')).toBeInTheDocument()
    expect(screen.getByText('42 queries · K=5')).toBeInTheDocument()
    expect(screen.getByText('60.0%')).toBeInTheDocument()
    const quality = screen.getByRole('heading', { name: 'Live Quality Metrics' }).closest('section')!
    expect(within(quality).getByText('20.0%')).toBeInTheDocument()
    expect(within(quality).getByText('Threshold failed')).toBeInTheDocument()
    expect(within(quality).getAllByText('Threshold passed')).toHaveLength(4)
    fireEvent.click(screen.getByText('DDoS judge assessment'))
    expect(screen.getByText('Synthetic judge fixture.')).toBeVisible()
  })
})
