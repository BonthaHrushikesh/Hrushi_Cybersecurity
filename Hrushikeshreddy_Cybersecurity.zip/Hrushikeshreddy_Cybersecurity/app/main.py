"""Compatibility for the documented legacy uvicorn app.main:app command."""

from src.main import Services, app, create_app

__all__ = ["Services", "app", "create_app"]
