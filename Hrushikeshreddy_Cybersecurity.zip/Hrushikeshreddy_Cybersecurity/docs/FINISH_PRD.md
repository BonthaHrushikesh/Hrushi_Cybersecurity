# Remaining PRD Demonstrations

Genuine nine-category metadata-rich TrafficLabelling ingestion is complete.
Do not retrain or replace the active artifacts just to run the demonstration.
The remaining measured gaps concern live hosted generation and evaluation.

## Authenticate Privately

Set LLM_PROVIDER=anthropic and a valid ANTHROPIC_API_KEY in backend .env.
Keep it out of VITE variables, screenshots, chat, and GitHub. Restart and run:

```bash
python scripts/check_llm_connection.py
```

This only checks authentication; latest result was HTTP 401. Key presence alone
does not mean the provider works. Local playbooks continue, with honest degraded
or unavailable statuses and no invented judge scores.

## Collect Real Quality Evidence

Only after a valid key and explicit consent to send bounded incident evidence:

```bash
python scripts/verify_live_llm.py --deepeval
python scripts/check_prd_readiness.py
```

These make paid provider calls. Review per-category analysis provider, seven
judge dimensions, five built-in quality metrics, model/provider provenance,
and threshold pass flags. Measurement is not the same as passing. Offline
DeepEval checks structure/citations only and writes separate offline artifacts.

## Submission

The participant selected React only. Obtain organizer acceptance because the
guidelines prescribe Streamlit. The profile is github.com/BonthaHrushikesh;
a project repository URL and access verification are pending. Use the clean
submission ZIP and a separate project repository, not the home-directory Git repo.
