from collections import Counter
import json
from pathlib import Path
from ipaddress import ip_address
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from src.utils.features import EXTRA_FEATURES, FEATURE_NAMES, METADATA, attack_category, flow_signatures, normalize_column


def prepare_dataset(source: Path, output: Path, per_class: int = 2000, seed: int = 42,
                    timestamp_timezone: str | None = None, timestamp_format: str | None = None, day_first: bool = False,
                    encoding: str = "utf-8-sig", defer_timestamps: bool = False) -> dict:
    """Stream the full input and retain a uniform priority sample per original label."""
    if per_class < 20:
        raise ValueError("per_class must be at least 20")
    if timestamp_timezone:
        ZoneInfo(timestamp_timezone)
    if defer_timestamps and timestamp_timezone:
        raise ValueError("Choose a confirmed timestamp timezone or defer timestamps, not both")
    sources = sorted([*source.rglob("*.csv"), *source.rglob("*.parquet")]) if source.is_dir() else [source]
    if not sources or any(not path.is_file() for path in sources):
        raise ValueError("Provide a CSV/Parquet file or directory of extracted labeled flow files")
    output.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    counts, reservoirs = Counter(), {}
    invalid_ports = nonfinite = negatives = rows = 0
    unlabelled_rows = 0
    def chunks():
        for path in sources:
            file_rows = 0
            iterator = [pd.read_parquet(path)] if path.suffix.lower() == ".parquet" else pd.read_csv(path, chunksize=100_000, low_memory=False, encoding=encoding)
            for chunk in iterator:
                file_rows += len(chunk)
                yield chunk
            print(json.dumps({"event": "dataset_file_scanned", "file": path.name, "rows": file_rows}), flush=True)
    available = []
    metadata_invalid = Counter()
    duplicated_columns_removed = Counter()
    deferred_timestamp_rows = 0
    for chunk in chunks():
        chunk.columns = [normalize_column(x) for x in chunk.columns]
        if chunk.columns.duplicated().any():
            raise ValueError("Input contains duplicate normalized column names")
        if "fwd_header_length_1" in chunk and "fwd_header_length" in chunk:
            original = pd.to_numeric(chunk["fwd_header_length"], errors="coerce")
            duplicate = pd.to_numeric(chunk["fwd_header_length_1"], errors="coerce")
            if not (original.eq(duplicate) | (original.isna() & duplicate.isna())).all():
                raise ValueError("Repeated Fwd Header Length columns disagree; source data needs review")
            duplicated_columns_removed["fwd_header_length_1"] += len(chunk)
            chunk = chunk.drop(columns="fwd_header_length_1")
        label = next((x for x in ["attack_type", "label", "original_label"] if x in chunk), None)
        if label is None:
            raise ValueError("CSV must contain Attack Type or Label")
        present = [x for x in FEATURE_NAMES + EXTRA_FEATURES if x in chunk]
        available = [x for x in FEATURE_NAMES + EXTRA_FEATURES if x in set(available) | set(present)]
        missing_core = {"destination_port", "flow_duration", "flow_bytes_s", "flow_packets_s"} - set(present)
        if missing_core:
            raise ValueError(f"Missing required flow fields: {sorted(missing_core)}")
        rows += len(chunk)
        labels = chunk[label].astype("string").str.strip()
        labelled = labels.notna() & labels.ne("").fillna(False)
        unlabelled_rows += int((~labelled).sum())
        chunk = chunk.loc[labelled].copy()
        chunk["original_label"] = labels.loc[labelled].astype(str)
        counts.update(chunk["original_label"])
        for col in present:
            chunk[col] = pd.to_numeric(chunk[col], errors="coerce")
        values = chunk[present].to_numpy(dtype=float)
        nonfinite += int((~np.isfinite(values)).sum())
        negatives += int((values < 0).sum())
        chunk[present] = chunk[present].replace([np.inf, -np.inf], np.nan)
        chunk[present] = chunk[present].mask(chunk[present] < 0)
        port = chunk["destination_port"]
        valid = port.notna() & port.between(0, 65535) & (port % 1 == 0)
        invalid_ports += int((~valid).sum())
        chunk = chunk.loc[valid].copy()
        if "timestamp" in chunk and "source_timestamp" not in chunk:
            chunk["source_timestamp"] = chunk["timestamp"].astype("string")
        if "timestamp" in chunk and defer_timestamps:
            deferred_timestamp_rows += int(chunk["timestamp"].notna().sum())
            chunk["timestamp"] = pd.NaT
        if "timestamp" in chunk:
            timestamps = pd.to_datetime(chunk["timestamp"], errors="coerce", format=timestamp_format or "mixed", dayfirst=day_first)
            if isinstance(timestamps.dtype, pd.DatetimeTZDtype):
                timestamps = timestamps.dt.tz_convert("UTC")
            elif pd.api.types.is_datetime64_dtype(timestamps):
                if timestamps.notna().any() and not timestamp_timezone:
                    raise ValueError("Naive source timestamps require --timestamp-timezone; UTC must not be assumed")
                timestamps = timestamps.dt.tz_localize(timestamp_timezone or "UTC", ambiguous="NaT", nonexistent="NaT").dt.tz_convert("UTC")
            else:
                def aware(value):
                    if pd.isna(value):
                        return pd.NaT
                    parsed = pd.Timestamp(value)
                    if parsed.tzinfo is None:
                        if not timestamp_timezone:
                            raise ValueError("Naive source timestamps require --timestamp-timezone")
                        parsed = parsed.tz_localize(timestamp_timezone, ambiguous="NaT", nonexistent="NaT")
                    return parsed.tz_convert("UTC") if pd.notna(parsed) else pd.NaT
                timestamps = pd.to_datetime(timestamps.map(aware), utc=True)
            if not defer_timestamps:
                metadata_invalid["timestamp"] += int(timestamps.isna().sum())
            chunk["timestamp"] = timestamps
        for field in ["source_ip", "destination_ip"]:
            if field in chunk:
                def valid_ip(value):
                    try:
                        return str(ip_address(str(value).strip()))
                    except ValueError:
                        return None
                chunk[field] = chunk[field].map(valid_ip)
                metadata_invalid[field] += int(chunk[field].isna().sum())
        if "source_port" in chunk:
            ports = pd.to_numeric(chunk["source_port"], errors="coerce")
            valid = ports.between(0, 65535) & (ports % 1 == 0)
            metadata_invalid["source_port"] += int((~valid).sum())
            chunk["source_port"] = ports.where(valid)
        if "protocol" in chunk:
            protocols = chunk["protocol"].astype(str).str.upper().replace({"6": "TCP", "6.0": "TCP", "17": "UDP", "17.0": "UDP", "1": "ICMP", "1.0": "ICMP"})
            chunk["protocol"] = protocols.where(protocols.isin(["TCP", "UDP", "ICMP"]), None)
            metadata_invalid["protocol"] += int(chunk["protocol"].isna().sum())
        chunk["_sample_priority"] = rng.random(len(chunk))
        keep = present + [x for x in METADATA if x in chunk] + ["original_label", "_sample_priority"]
        for original, group in chunk[keep].groupby("original_label", sort=True):
            combined = pd.concat([reservoirs[original], group], ignore_index=True) if original in reservoirs else group
            reservoirs[original] = combined.nsmallest(per_class, "_sample_priority")
    if not reservoirs:
        raise ValueError("No usable rows found")
    sampled = pd.concat(list(reservoirs.values()), ignore_index=True).drop(columns="_sample_priority")
    sampled["attack_category"] = sampled["original_label"].map(attack_category)
    sampled["_signature"] = flow_signatures(sampled, available).astype(str)
    conflicting = sampled.groupby("_signature")["attack_category"].nunique()
    conflicting_ids = set(conflicting[conflicting > 1].index)
    conflicting_rows = int(sampled["_signature"].isin(conflicting_ids).sum())
    sampled = sampled.loc[~sampled["_signature"].isin(conflicting_ids)]
    before = len(sampled)
    sampled = sampled.drop_duplicates("_signature").sort_values("_signature").reset_index(drop=True)
    sampled["incident_id"] = "CIC-" + sampled["_signature"]
    sampled = sampled.drop(columns="_signature")
    sampled.to_csv(output / "incidents.csv", index=False)
    profile = {
        "source_name": source.name, "source_bytes": sum(path.stat().st_size for path in sources),
        "source_files": [path.name for path in sources], "timestamp_timezone_declared": timestamp_timezone,
        "timestamp_timezone_provenance": "user_declared" if timestamp_timezone else "embedded_offset_or_unverified",
        "source_encoding": encoding, "timestamps_deferred": defer_timestamps,
        "deferred_timestamp_rows": deferred_timestamp_rows,
        "duplicate_column_rows_checked_and_removed": dict(duplicated_columns_removed),
        "timestamp_format": timestamp_format, "day_first": day_first,
        "rows_scanned": rows, "original_label_counts": dict(counts),
        "numeric_features": available, "numeric_feature_count": len(available),
        "metadata_available": [x for x in METADATA if x in sampled],
        "metadata_missing": [x for x in METADATA if x not in sampled],
        "metadata_non_null_counts": {x: int(sampled[x].notna().sum()) for x in METADATA if x in sampled},
        "invalid_metadata_values_marked_missing": dict(metadata_invalid),
        "nonfinite_values_replaced": nonfinite, "negative_values_marked_missing": negatives,
        "invalid_port_rows_removed": invalid_ports, "sample_duplicates_removed": before - len(sampled),
        "unlabelled_rows_removed": unlabelled_rows,
        "sample_conflicting_rows_removed": conflicting_rows, "processed_rows": len(sampled),
        "category_counts": sampled["attack_category"].value_counts().to_dict(),
        "sample_per_original_class": per_class, "seed": seed,
        "sampling": "Uniform priority reservoir per original label; all rare-class rows retained up to cap.",
        "duplicate_scope": "Exact numeric flow signatures removed within retained sample before splitting; full-file duplicate count not computed.",
        "limitations": ["No temporal or host-disjoint evaluation is possible when identifiers/timestamps are missing.", "Balanced sample changes class priors; probabilities are uncalibrated model confidence, not deployment prevalence."],
    }
    if defer_timestamps and deferred_timestamp_rows:
        profile["limitations"].append("Source timestamps are preserved as source_timestamp, but UTC timestamps and time-range matching remain unavailable until the source timezone is confirmed. No timezone or AM/PM corrections were invented.")
    elif timestamp_timezone and "source_timestamp" in sampled:
        profile["limitations"].append("Timezone-free source timestamps use the explicitly declared source timezone, not a timezone verified from the CSV. Original strings are preserved; no clock-hour or AM/PM corrections were inferred.")
    (output / "profile.json").write_text(json.dumps(profile, indent=2), encoding="utf-8")
    sample_dir = output.parent / "sample_data"
    sample_dir.mkdir(parents=True, exist_ok=True)
    sample = sampled.groupby("attack_category", group_keys=False).head(60)
    sample.to_csv(sample_dir / "sample_incidents.csv", index=False)
    print(json.dumps({"rows_scanned": rows, "processed_rows": len(sampled), "category_counts": profile["category_counts"]}, indent=2))
    return profile
