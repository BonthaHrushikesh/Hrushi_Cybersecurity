import pandas as pd
import pytest

from src.services.flow_import import parse_flow_csv
from ml.preprocess import prepare_dataset
from scripts.compare_dataset_exports import compare


def flow_rows():
    return [{"Destination Port": 80, "Flow Duration": 1000 + index, "Flow Packets/s": 10 + index,
             "Flow Bytes/s": 100 + index, "Active Std": index, "Idle Std": index * 2,
             "Timestamp": "03/07/2017 08:30:00", "Label": "BENIGN"} for index in range(24)]


@pytest.mark.parametrize("deferred", [False, True])
def test_original_source_time_and_new_features_are_preserved(tmp_path, deferred):
    source = tmp_path / "flows.csv"
    pd.DataFrame(flow_rows()).to_csv(source, index=False)
    profile = prepare_dataset(source, tmp_path / "processed", defer_timestamps=deferred,
                              timestamp_timezone=None if deferred else "UTC", day_first=True)
    data = pd.read_csv(tmp_path / "processed/incidents.csv")
    assert {"active_std", "idle_std"} <= set(profile["numeric_features"])
    assert data.source_timestamp.eq("03/07/2017 08:30:00").all()
    assert data.timestamp.isna().all() if deferred else data.timestamp.str.startswith("2017-07-03 08:30:00+00:00").all()


@pytest.mark.parametrize("different", [False, True])
def test_known_repeated_header_is_verified_before_removal(tmp_path, different):
    data = pd.DataFrame(flow_rows()).drop(columns="Timestamp")
    data["Fwd Header Length"] = 10
    data.insert(len(data.columns), "Fwd Header Length", 11 if different else 10, allow_duplicates=True)
    source = tmp_path / "flows.csv"
    data.to_csv(source, index=False)
    if different:
        with pytest.raises(ValueError, match="columns disagree"):
            prepare_dataset(source, tmp_path / "processed")
    else:
        profile = prepare_dataset(source, tmp_path / "processed")
        assert profile["duplicate_column_rows_checked_and_removed"] == {"fwd_header_length_1": 24}


def test_unlabelled_flows_are_counted_and_never_given_a_fake_label(tmp_path):
    rows = flow_rows()
    rows.append({**rows[0], "Label": None})
    source = tmp_path / "flows.csv"
    pd.DataFrame(rows).drop(columns="Timestamp").to_csv(source, index=False)
    profile = prepare_dataset(source, tmp_path / "processed")
    assert profile["unlabelled_rows_removed"] == 1
    assert "nan" not in profile["original_label_counts"]
    assert set(pd.read_csv(tmp_path / "processed/incidents.csv").attack_category) == {"BENIGN"}


def test_csv_import_accepts_identical_cic_header_copy_and_new_std_features():
    csv = "Destination Port,Flow Duration,Flow Packets/s,Flow Bytes/s,Fwd Header Length,Fwd Header Length,Active Std,Idle Std,Label\n80,1000,10,100,20,20.0,3,4,BENIGN"
    flow = parse_flow_csv(csv)
    assert flow.features["active_std"] == 3 and flow.features["idle_std"] == 4
    assert flow.features["fwd_header_length"] == 20
    with pytest.raises(ValueError, match="columns disagree"):
        parse_flow_csv(csv.replace("20,20.0", "20,21.0"))


def test_export_reconciliation_ignores_metadata_not_missing_label_counts(tmp_path):
    primary, secondary = tmp_path / "traffic", tmp_path / "ml"
    primary.mkdir()
    secondary.mkdir()
    data = pd.DataFrame(flow_rows()).drop(columns="Timestamp")
    data.to_csv(secondary / "day.csv", index=False)
    data["Source IP"] = "192.0.2.1"
    extra = data.head(1).copy()
    extra["Label"] = None
    pd.concat([data, extra], ignore_index=True).to_csv(primary / "day.csv", index=False)
    report = compare(primary, secondary, tmp_path / "comparison.json")
    assert report["all_paired_exports_match"]
    assert report["files"][0]["primary_unlabelled_rows"] == 1
    assert report["files"][0]["primary_rows"] == 25
    assert report["files"][0]["secondary_rows"] == 24
