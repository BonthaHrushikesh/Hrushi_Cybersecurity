from dataclasses import replace
from datetime import datetime, timedelta, timezone
import json
import sys

import pandas as pd
import pytest

from scripts import export_feedback, retrain_candidate
from src.api.schemas import FeedbackRequest, InvestigationResult
from src.services.repository import Repository
from src.utils.config import settings


def test_rejecting_last_approved_correction_removes_previous_export(tmp_path, monkeypatch, investigation):
    config = replace(settings, artifacts=tmp_path / "artifacts", processed=tmp_path / "processed")
    repository = Repository(config.artifacts / "incidents.sqlite")
    result = InvestigationResult.model_validate(investigation)
    repository.save({"flow": {"features": {"destination_port": 80}}}, result)
    feedback_id = repository.feedback(FeedbackRequest(incident_id=result.incident_id, helpful=False, corrected_attack_type="DoS"))
    monkeypatch.setattr(export_feedback, "settings", config)
    monkeypatch.setattr(sys, "argv", ["export_feedback.py", "--approve", str(feedback_id)])
    export_feedback.main()
    output = config.processed / "reviewed_feedback.csv"
    assert pd.read_csv(output).iloc[0].attack_category == "DoS"

    monkeypatch.setattr(sys, "argv", ["export_feedback.py", "--reject", str(feedback_id)])
    export_feedback.main()
    assert repository.reviewed_rows() == []
    assert not output.exists()
    export_feedback.main()  # Empty exports can be regenerated without error.
    assert not output.exists()


@pytest.mark.parametrize("destination", ["active", "alias", "models_alias", "processed_alias"])
def test_candidate_rejects_active_output_before_reading_or_writing(tmp_path, monkeypatch, capsys, destination):
    config = replace(settings, artifacts=tmp_path / "active", processed=tmp_path / "processed")
    models = config.artifacts / "models"
    models.mkdir(parents=True)
    config.processed.mkdir()
    metadata = models / "metadata.json"
    metadata.write_text("active model must remain unchanged")
    output = tmp_path / "candidate"
    if destination == "active":
        output = config.artifacts
    elif destination == "alias":
        output.symlink_to(config.artifacts, target_is_directory=True)
    else:
        output.mkdir()
        (output / ("models" if destination == "models_alias" else "processed")).symlink_to(
            models if destination == "models_alias" else config.processed, target_is_directory=True)
    monkeypatch.setattr(retrain_candidate, "settings", config)
    monkeypatch.setattr(sys, "argv", ["retrain_candidate.py", "--feedback", str(tmp_path / "missing.csv"), "--output", str(output)])
    with pytest.raises(SystemExit) as error:
        retrain_candidate.main()
    assert error.value.code == 2
    assert "must not overlap active" in capsys.readouterr().err
    assert metadata.read_text() == "active model must remain unchanged"
    assert not (output / "processed/incidents.csv").exists()


def test_candidate_in_separate_directory_compares_with_original_active_model(tmp_path, monkeypatch):
    config = replace(settings, artifacts=tmp_path / "active", processed=tmp_path / "processed")
    config.processed.mkdir()
    (config.artifacts / "models").mkdir(parents=True)
    active = {"version": "active-version", "test_metrics": {"macro avg": {"f1-score": .9}}}
    metadata = config.artifacts / "models/metadata.json"
    metadata.write_text(json.dumps(active))
    baseline = pd.DataFrame([{"destination_port": 80, "flow_duration": 1000, "incident_id": "CIC-fixture", "attack_category": "BENIGN"}])
    baseline.to_csv(config.processed / "incidents.csv", index=False)
    baseline.to_csv(config.processed / "test.csv", index=False)
    (config.processed / "profile.json").write_text(json.dumps({"numeric_features": ["destination_port", "flow_duration"]}))
    reviewed = baseline.assign(incident_id="INV-reviewed", attack_category="DoS")
    reviewed.to_csv(config.processed / "reviewed_feedback.csv", index=False)
    candidate = {"version": "candidate-version", "test_metrics": {"macro avg": {"f1-score": .8}}}

    def train(processed, artifacts, fixed_test):
        assert artifacts == config.artifacts / "candidates/reviewed"
        assert pd.read_csv(processed / "incidents.csv").iloc[0].attack_category == "DoS"
        assert len(fixed_test) == 1
        return candidate

    monkeypatch.setattr(retrain_candidate, "settings", config)
    monkeypatch.setattr(retrain_candidate, "train_models", train)
    monkeypatch.setattr(sys, "argv", ["retrain_candidate.py"])
    retrain_candidate.main()
    comparison = json.loads((config.artifacts / "candidates/reviewed/comparison.json").read_text())
    assert comparison["active_model"] == "active-version"
    assert comparison["candidate_model"] == "candidate-version"
    assert comparison["active_macro_f1"] == .9
    assert comparison["candidate_macro_f1"] == .8
    assert json.loads(metadata.read_text()) == active


def test_empty_feedback_does_not_start_candidate_training(tmp_path, monkeypatch, capsys):
    config = replace(settings, artifacts=tmp_path / "active", processed=tmp_path / "processed")
    config.processed.mkdir()
    pd.DataFrame(columns=["incident_id", "attack_category"]).to_csv(config.processed / "reviewed_feedback.csv", index=False)
    monkeypatch.setattr(retrain_candidate, "settings", config)
    monkeypatch.setattr(sys, "argv", ["retrain_candidate.py"])
    with pytest.raises(SystemExit) as error:
        retrain_candidate.main()
    assert error.value.code == 2
    assert "No approved corrections" in capsys.readouterr().err
    assert not config.artifacts.exists()


def test_incident_api_can_page_and_search_beyond_first_200(client, tmp_path, monkeypatch):
    repository = Repository(tmp_path / "incidents.sqlite")
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    with repository.connection() as db:
        db.executemany("INSERT INTO investigations VALUES (?, ?, ?, ?, ?, ?, ?)", [
            (f"INV-{index:03}", (start + timedelta(seconds=index)).isoformat(), "{}", "{}",
             "DDoS" if index == 0 else "BENIGN", "P1" if index == 0 else "P4", 99 if index == 0 else 1)
            for index in range(205)
        ])
    monkeypatch.setattr(client.app.state.services, "repository", repository)
    first = client.get("/api/v1/incidents").json()
    assert first["total"] == 205 and len(first["items"]) == 200
    assert first["items"][0]["incident_id"] == "INV-204"
    last = client.get("/api/v1/incidents", params={"offset": 200, "limit": 8}).json()
    assert last["total"] == 205
    assert [item["incident_id"] for item in last["items"]] == [f"INV-{index:03}" for index in range(4, -1, -1)]
    for query in ("inv-000", "ddos", "P1"):
        result = client.get("/api/v1/incidents", params={"query": query}).json()
        assert result["total"] == 1 and result["items"][0]["incident_id"] == "INV-000"
    highest = client.get("/api/v1/incidents", params={"sort": "risk", "limit": 1}).json()
    assert highest["items"][0]["incident_id"] == "INV-000"
    assert client.get("/api/v1/incidents", params={"query": "%"}).json()["total"] == 0


@pytest.mark.parametrize("params", [{"offset": -1}, {"limit": 0}, {"limit": 1001}, {"sort": "DROP TABLE"}, {"query": "x" * 201}])
def test_incident_pagination_rejects_invalid_parameters(client, params):
    assert client.get("/api/v1/incidents", params=params).status_code == 422
