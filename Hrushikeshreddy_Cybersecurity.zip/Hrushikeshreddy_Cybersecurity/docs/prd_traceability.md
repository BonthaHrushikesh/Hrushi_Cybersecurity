# PRD Traceability

Status legend: **Implemented** means executable code exists and local behavior was exercised; **Configured** means executable integration exists but a downloaded provider model or API credentials are needed; **Unverified** identifies an environment-dependent check that could not be performed. No quality or deployment results are invented.

## Basic And Advanced Requirements

Current additions include rank-fused advanced retrieval and grounded RAG answers
(test_advanced_rag.py), complete sample/CSV preservation (InvestigationForm.test.tsx),
live readiness and circuit states, report export and operational counters
(test_operations.py), effective analyst preferences, and GitHub Actions release
checks. Browser verification covers new answer/search/readiness/report workflows
and an explicit unavailable-service state. See operations.md and advanced_rag.md.

| Requirement | Component | Source File | API/UI | Test | Status |
|---|---|---|---|---|---|
| Basic historical RAG | Grounded history retrieval and response | src/services/retrieval.py; src/services/recommendations.py | /investigate; investigation Evidence/Response | test_api.py; test_rag_eval.py | Implemented; local playbook / configured real LLM |
| Hybrid search | FAISS cosine + BM25 fusion | src/services/retrieval.py | /search; Historical Search | test_retrieval.py | Implemented |
| Classification agent | Supervised probabilities | src/agents/orchestrator.py; src/services/models.py | /classify; investigation | test_classifier.py; test_api.py | Implemented |
| Metadata filtering | Combined strict filters | src/api/schemas.py; src/services/retrieval.py | /search; Historical Search | test_retrieval.py; test_guardrails.py | Implemented; missing source metadata correctly gives empty matches |
| Investigation recommendations | Defensive category/evidence synthesis | src/services/recommendations.py | /recommend; Response tab | test_api.py; test_rag_eval.py | Implemented; optional LLM configured |
| Input guardrails | Typed fields and prompt-data boundaries | src/api/schemas.py; src/rag/prompts.py | All POST endpoints | test_guardrails.py | Implemented |
| Incident prioritization | Transparent weighted triage policy | src/services/risk.py | /risk; priority/score | test_risk.py | Implemented |
| Core REST APIs | FastAPI schemas and documentation | src/api/application.py | /docs; API reference | test_api.py | Implemented |
| DeepEval | Real cases; local structural and configured built-in metrics | evaluation/deepeval_runner.py | Stored evaluation reports | test_rag_eval.py | Local custom metric exercised; built-in LLM metrics need credentials |
| Attack and intrusion-risk prediction | Selected multiclass classifier + dedicated binary Random Forest | ml/train.py; src/services/models.py | /classify; /model/info | test_classifier.py | Implemented |
| LLM-as-Judge | Evidence-aware structured judge | src/agents/quality_judge.py | investigate judge result / Workflow tab | test_providers.py | Configured integration; live provider needs credentials |
| Multi-agent workflow | Required/provided state contracts | src/agents/orchestrator.py | /investigate; Workflow | test_api.py | Implemented |
| Anomaly prediction | Benign Isolation Forest and percentile reference | ml/train.py; src/services/models.py | /anomaly; anomaly metric | test_api.py; test_risk.py | Implemented |
| Explainable traffic analysis | TreeSHAP, importance, class medians | src/services/models.py; frontend/src/pages/ExplainabilityPage.tsx | /explain; Explainability | test_classifier.py; browser checks | Implemented; true additive SHAP |
| Feedback improvement loop | Pending review, approved export, signature-authoritative candidate merge | src/services/repository.py; scripts/export_feedback.py; scripts/retrain_candidate.py | /feedback; Feedback | test_api.py; test_feedback.py; test_candidate.py | Implemented; contradictory reviews rejected and promotion remains manual |
| Frontend | React/TypeScript SOC workspace with dedicated operational and model-intelligence routes | frontend/src/App.tsx | http://localhost:5173 | scripts/verify_ui.py; Vitest | Implemented; responsive desktop/mobile verification |

## All 40 Pasted Specification Sections

| Requirement | Component | Source File | API/UI | Test / Evidence | Status |
|---|---|---|---|---|---|
| 1. Business problem and analyst questions | Integrated investigation | README.md; frontend/src | SOC and Investigate | End-to-end demo | Implemented |
| 2. CIC CSV and Parquet, normalized/original labels | Data preparation | ml/preprocess.py; src/utils/features.py | Dataset profile | test_preprocess.py; profile.json | Implemented; supplied source lacks several original CIC fields/classes |
| 3. Layered architecture and lifecycle | Modular microservice | docs/architecture.md; src/api/application.py | API -> workflow -> services -> stores | Architecture/sequence diagrams | Implemented |
| 4. Recommended stack and configurable providers | FastAPI, React, sklearn, SHAP, FAISS | requirements.txt; frontend/package.json; src/utils/config.py; src/services/embeddings.py | Model/index/provider status | Imports and startup | Implemented; optional MiniLM download and live LLM require configuration |
| 5. Reproducible cleaning, splitting, leakage/imbalance handling | Streamed pipeline and balanced classifiers | ml/preprocess.py; ml/train.py | Training reports | test_preprocess.py; test_classifier.py | Implemented; sampled exact dedup scope documented |
| 6. Meaningful documents and separate metadata | Flow document builder | src/rag/document_builder.py | History result records | Retrieval tests and citations | Implemented |
| 7. Validated grounded RAG with citations/empty evidence | Retriever and response provider | src/services/retrieval.py; src/services/recommendations.py | /investigate | test_api.py; test_rag_eval.py | Implemented; optional LLM |
| 8. Semantic/BM25 fusion and configurable alpha | Measured score fusion | src/services/retrieval.py | /search | test_retrieval.py | Implemented |
| 9. Attack, protocol, host, port, time, severity, risk filters | Combined filter schema | src/api/schemas.py; src/services/retrieval.py | Historical Search | test_retrieval.py; test_guardrails.py | Implemented; absent metadata stays unknown |
| 10. Compare two classifiers and report class metrics | Random Forest vs Extra Trees | ml/train.py | /model/info | classification.json; test_classifier.py | Implemented |
| 11. Malicious probability/confidence distinct from category | Sum nonbenign probabilities | src/services/models.py | /classify | test_classifier.py | Implemented; uncalibrated confidence stated |
| 12. Isolation Forest raw/normalized anomaly score | Benign-reference novelty model | src/services/models.py; ml/train.py | /anomaly | API/integration tests | Implemented |
| 13. Deterministic configurable risk and threshold priorities | Weighted risk policy | src/services/risk.py | /risk | test_risk.py | Implemented |
| 14. Actual SHAP, local charts, global feature/category analysis | TreeSHAP / labeled global importance | src/services/models.py; frontend/src/pages/ExplainabilityPage.tsx | /explain; Explainability | Additivity tests; rendered chart checks | Implemented |
| 15. Explicit multi-agent state workflow | Agent input/output contracts | src/agents/orchestrator.py | Workflow tab | test_api.py | Implemented; tool-using workflow roles accurately described |
| 16. Defensive evidence-linked response groups | Playbooks and optional LLM synthesis | src/services/recommendations.py | Response tab | test_api.py; test_providers.py | Implemented |
| 17. Input/security guardrails and useful errors | Strict Pydantic and data prompts | src/api/schemas.py; src/api/application.py; src/rag/prompts.py | HTTP 422 / provider prompt | test_guardrails.py | Implemented |
| 18. LLM grounding and structured final analysis | Defensive system prompt; output schema/citations | src/rag/prompts.py; src/services/recommendations.py | Analysis + fixed model/risk sections | test_providers.py; test_rag_eval.py | Implemented; live generation configured |
| 19. Seven-dimension LLM judge with evidence | Structured provider judge | src/agents/quality_judge.py | Optional investigation judge | test_providers.py | Configured; no live scores without credentials |
| 20. DeepEval cases/quality metrics/readable results | Offline structural + built-in quality metrics | evaluation/deepeval_runner.py | deepeval.json / Metrics | test_rag_eval.py; offline runner | Implemented; built-in LLM judging requires credentials |
| 21. Non-LLM retrieval quality | Precision/Recall/Hit Rate/MRR | evaluation/retrieval_metrics.py | retrieval.json | test_rag_eval.py; 35 real held-out queries | Implemented |
| 22. Feedback, review, export, separate retrain/evaluate/promotion | SQLite and candidate CLI | src/services/repository.py; scripts/export_feedback.py; scripts/retrain_candidate.py | Feedback page | test_feedback.py; test_api.py | Implemented; no automatic deployment |
| 23. Professional routed React SOC workspace | Dashboard / Investigate / Incidents / AI Analyst / RAG Search / Traffic Analytics / Models / Agent Workflow / Evaluation / Explainability / Feedback / Settings | frontend/src/App.tsx | React workspace | scripts/verify_ui.py; Vitest | Implemented |
| 24. Required typed FastAPI endpoints and examples | API contracts | src/api/application.py; src/api/schemas.py; docs/api.md | /docs | test_api.py | Implemented |
| 25. Local persistence abstractions | FAISS/JSON/joblib/SQLite | src/services/retrieval.py; src/services/repository.py | History and saved investigations | API/retrieval/feedback tests | Implemented |
| 26. Professional modular repository | App/services/agents/rag/db + ML/eval/scripts/docs | Repository tree | N/A | Import and path checks | Implemented; routes consolidated to avoid unnecessary files |
| 27. Structured observability | Request and workflow event logs | src/api/application.py; src/agents/orchestrator.py | X-Request-ID; metrics | test_api.py; backend.log | Implemented |
| 28. Model version/metadata registry | SHA-based version and metadata report | ml/train.py; src/services/models.py | /model/info | Model report and API tests | Implemented |
| 29. Meaningful unit/integration/guardrail/ML tests | Pytest suite and browser integration | tests/; scripts/verify_ui.py | Entire app | Pytest results and browser report | Implemented |
| 30. Small executable demo with real sample records | 420-row sample and fresh training/index | data/sample_data/sample_incidents.csv; scripts/seed_demo.py | Demo API/dashboard | Isolated demo smoke check | Implemented |
| 31. Reproducible setup/train/index/start/eval commands | README and scripts | README.md; scripts/start_local.py | Local URLs | Command smoke checks | Implemented |
| 32. Complete project/design/model/API documentation | Version-controlled docs | README.md; docs/ | N/A | Document/file checks | Implemented |
| 33. Five architecture diagrams | Mermaid diagrams | docs/architecture.md | N/A | Diagram source review | Implemented |
| 34. Ten-minute panel content, timing, notes | Ten-slide narrative | docs/presentation.md | N/A | Timings total 600 seconds | Implemented |
| 35. Strong end-to-end demo story | Script + 2-minute panel flow | scripts/run_demo.py; docs/presentation.md | Investigation and feedback | demo.json / browser workflow | Implemented |
| 36. Measured results, no fake SHAP/scores, fallback/no secrets | Source boundaries and measured artifacts | app/; ml/; evaluation/ | Provider/status/version labels | Test suite and reports | Implemented |
| 37. Every requirement mapped | This document | docs/prd_traceability.md | N/A | Section 1-40 mapping | Implemented |
| 38. Runtime definition of done | Startup + classification/retrieval/SHAP/feedback/eval | scripts/ and tests/ | Local API/dashboard | Health/docs, pytest, browser | Local checks implemented; live LLM and Docker build need external prerequisites |
| 39. Incremental phases with checks | Foundation -> ML -> retrieval -> intelligence -> UI -> docs | All modules | App workflow | Preparation/training/imports/API/pytest/evaluation/browser checks | Implemented; measured phase evidence in reports |
| 40. Complete code, replaceable providers, real local fallback | Typed modular services | src/services/; src/agents/ | Full investigation | Unit/integration/provider checks | Implemented |

## Outstanding Environment Checks

Docker/cloud/hosted CI are optional and not claimed runtime-verified. The active genuine TrafficLabelling run includes all nine categories and metadata. Current Claude authentication returns HTTP 401, so live generation, judging, and hosted DeepEval quality remain unverified. Offline structural checks and mocked providers do not substitute for live quality. The default measured embedding provider is LSA; MiniLM is optional and unbenchmarked. The participant explicitly chose React only despite the submission guidelines prescribing Streamlit; organizer acceptance is pending. See PRD_AUDIT.md for the current verdict.
