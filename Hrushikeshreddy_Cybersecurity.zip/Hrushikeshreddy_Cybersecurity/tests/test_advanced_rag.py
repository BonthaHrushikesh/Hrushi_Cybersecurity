from contextlib import nullcontext
from dataclasses import replace
from types import SimpleNamespace

import numpy as np
import pytest

from src.utils.config import settings
from src.rag.ranking import expand_terms, flow_similarity, reciprocal_rank_fusion, select_diverse
from src.api.schemas import RAGAnswer, RAGRequest
from src.services.rag_answers import RAGAnswerService, pack_context


def test_rrf_ignores_score_scale_and_zero_evidence():
    semantic, keyword = np.array([.9, .8, 0]), np.array([1., 2., 0])
    assert reciprocal_rank_fusion(semantic, keyword, .6) == pytest.approx(reciprocal_rank_fusion(semantic, keyword * 1000, .6))
    assert reciprocal_rank_fusion(semantic, keyword, .6)[2] == 0


def test_expansion_and_feature_distance():
    assert 'injection' in expand_terms('Investigate SQLi activity')
    assert expand_terms('random unrecognized terms') == []
    flow = {'destination_port': 80, 'flow_packets_s': 1000, 'flow_bytes_s': 10000}
    assert flow_similarity(flow, flow) == pytest.approx(1)
    assert flow_similarity(flow, {'destination_port': 22, 'flow_packets_s': 1, 'flow_bytes_s': 1}) < .1


def test_diversity_prefers_distinct_evidence():
    vectors = {0: np.array([1., 0]), 1: np.array([1., 0]), 2: np.array([0., 1])}
    assert select_diverse([0, 1, 2], [.9, .89, .85], vectors, 2) == [0, 2]


@pytest.mark.parametrize('mode', ['hybrid', 'keyword', 'semantic'])
def test_advanced_modes_keep_filters(client, mode):
    response = client.post('/api/v1/search', json={'query': 'DDoS flood', 'mode': mode, 'fusion': 'rrf',
                                                'expand_query': True, 'diversify': True, 'filters': {'attack_type': 'DDoS'}})
    assert response.status_code == 200
    result = response.json()
    assert result['results']
    assert all(hit['attack_type'] == 'DDoS' for hit in result['results'])
    assert len({hit['incident_id'] for hit in result['results']}) == len(result['results'])


def test_keyword_does_not_call_embeddings_and_hybrid_falls_back(client, monkeypatch):
    def unavailable(*args):
        raise RuntimeError('Embedding unavailable')
    monkeypatch.setattr(client.app.state.services.retrieval.embeddings, 'encode', unavailable)
    assert client.post('/api/v1/search', json={'query': 'DDoS', 'mode': 'keyword'}).json()['results']
    result = client.post('/api/v1/search', json={'query': 'DDoS', 'fusion': 'rrf'}).json()
    assert result['results']
    assert result['strategy'] == 'keyword_fallback'
    assert client.post('/api/v1/search', json={'query': 'DDoS', 'mode': 'semantic'}).json()['strategy'] == 'semantic_unavailable'


def test_rag_api_local_and_no_history(client):
    response = client.post('/api/v1/rag/answer', json={'query': 'Investigate brute force SSH'})
    assert response.status_code == 200
    result = response.json()
    assert result['provider'] == 'local_evidence_extract'
    assert set(result['analysis']['cited_incident_ids']) <= set(result['context_incident_ids'])
    empty = client.post('/api/v1/rag/answer', json={'query': 'DDoS', 'filters': {'source_ip': '192.0.2.1'}}).json()
    assert empty['context_incident_ids'] == []
    assert 'No matching historical evidence' in empty['analysis']['answer']


def test_rag_context_budget_and_host_privacy(client):
    from src.api.schemas import SearchRequest
    retrieval = client.app.state.services.retrieval.search(SearchRequest(query='DDoS'))
    assert pack_context(retrieval, max_chars=10) == []
    context = pack_context(retrieval)
    assert context
    assert 'metadata' not in context[0]
    assert 'document' not in context[0]


@pytest.mark.parametrize('invented', [False, True])
def test_rag_llm_citations_and_fallback(client, monkeypatch, invented):
    import openai
    monkeypatch.setenv('OPENAI_API_KEY', 'test-only-key')
    request = RAGRequest(query='Investigate DDoS traffic')
    retrieval = client.app.state.services.retrieval.search(request)
    incident_id = 'CIC-fabricated' if invented else retrieval.results[0].incident_id
    output = RAGAnswer(answer=f'Historical DDoS flow [{incident_id}] requires further investigation.',
                       cited_incident_ids=[incident_id], evidence_gaps=['Flow-only evidence is limited.'],
                       recommended_next_steps=['Correlate service logs.'])
    captured = []

    def parse(**kwargs):
        captured.append(kwargs)
        return SimpleNamespace(output_parsed=output)

    monkeypatch.setattr(openai, 'OpenAI', lambda **kwargs: nullcontext(SimpleNamespace(responses=SimpleNamespace(parse=parse))))
    result = RAGAnswerService(replace(settings, llm_provider='openai')).answer(request, retrieval)
    assert result.provider == ('local_fallback' if invented else 'openai')
    assert captured[0]['store'] is False
    assert 'CIC-fabricated' not in result.analysis.model_dump_json()
