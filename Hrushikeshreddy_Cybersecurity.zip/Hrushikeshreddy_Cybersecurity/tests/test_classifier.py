import pandas as pd
import json
import pytest

from src.utils.config import settings
from src.utils.features import feature_frame, flow_signatures


def test_prediction_probabilities_and_shap_additivity(investigation):
    prediction = investigation["prediction"]
    assert sum(prediction["probabilities"].values()) == pytest.approx(1, abs=1e-6)
    assert 0 <= prediction["malicious_probability"] <= 1
    explanation = investigation["explanation"]
    assert explanation["method"] == "TreeSHAP"
    total = explanation["base_value"] + sum(x["shap_value"] for x in explanation["contributions"])
    assert total == pytest.approx(explanation["predicted_probability"], abs=1e-6)


def test_dedicated_intrusion_risk_model_is_registered(client):
    metadata = client.get("/api/v1/model/info").json()["metadata"]
    assert "binary classifier" in metadata["intrusion_risk_model"]
    assert metadata["intrusion_test_metrics"]["accuracy"] >= 0


def test_training_history_and_test_do_not_share_ids_or_feature_signatures():
    train = pd.read_csv(settings.processed / "historical.csv")
    test = pd.read_csv(settings.processed / "test.csv")
    assert set(train["incident_id"]).isdisjoint(test["incident_id"])
    features = json.loads((settings.processed / "profile.json").read_text())["numeric_features"]
    train_hash = set(flow_signatures(train, features))
    test_hash = set(flow_signatures(test, features))
    assert train_hash.isdisjoint(test_hash)


def test_derived_features_do_not_use_labels_or_identifiers():
    frame = feature_frame([{"flow_duration": 2_000_000, "total_fwd_packets": 4, "total_length_of_fwd_packets": 1000, "fwd_packets_s": 6, "bwd_packets_s": 2, "attack_type": "DoS"}],
                          ["flow_duration", "total_fwd_packets", "total_length_of_fwd_packets", "fwd_packets_s", "bwd_packets_s"])
    assert "attack_type" not in frame
    assert frame.iloc[0]["duration_seconds"] == 2
    assert frame.iloc[0]["forward_bytes_per_packet"] == 250
    assert frame.iloc[0]["packet_rate_asymmetry"] == 0.5
