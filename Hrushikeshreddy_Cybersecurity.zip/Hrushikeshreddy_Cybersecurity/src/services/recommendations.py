import json
import logging
import re

from src.utils.config import Settings
from src.utils.guardrails import validate_analysis_content, validate_query
from src.services.provider_resilience import ProviderCircuit, provider_failure_reason
from src.services.llm_provider import generate_structured
from src.rag.prompts import ANALYST_SYSTEM
from src.api.schemas import Action, Analysis

logger = logging.getLogger(__name__)

PLAYBOOKS = {
    "Brute Force": ("Correlate authentication failures and successful logins for the destination service.", "Review affected accounts, credential rotation, and MFA enforcement."),
    "DoS": ("Correlate traffic rates with service availability and resource saturation.", "Review service limits and validated traffic rate controls."),
    "DDoS": ("Compare traffic volume with baseline and correlate upstream network and service telemetry.", "Review upstream filtering and denial-of-service protection with the network team."),
    "PortScan": ("Inspect IDS and firewall logs for repeated probes across destination services.", "Review exposed services and restrict unnecessary access paths."),
    "Bot": ("Inspect endpoint telemetry, DNS activity, and repeated outbound connections.", "Review endpoint protection and egress restrictions after confirming compromise."),
    "Web Attack": ("Correlate web-server, WAF, and application logs with the observed service traffic.", "Review application input handling, access controls, and relevant patches."),
    "Infiltration": ("Correlate unusual egress, lateral connections, account logons, and endpoint alerts to establish scope.", "Review access boundaries and endpoint controls after validating the affected assets."),
    "Heartbleed": ("Validate TLS service versions and heartbeat alerts against preserved packet and service evidence.", "Review TLS patching and credential rotation with service owners after confirming exposure; flow data alone cannot establish vulnerable versions."),
    "BENIGN": ("Compare the flow with the expected workload and confirm the alert context.", "Tune alert thresholds only after verifying normal behavior."),
}


def evidence_payload(flow, prediction, anomaly, risk, retrieval, explanation) -> dict:
    # Hosts are unnecessary for summary generation and stay in the analyst-facing API only.
    return {"observed_features": flow.features,
            "metadata_availability": {k: v is not None for k, v in flow.metadata.model_dump().items()},
            "prediction": prediction.model_dump(), "anomaly": anomaly.model_dump(), "risk": risk.model_dump(),
            "explanation": explanation.model_dump(), "retrieval_limitations": retrieval.limitations,
            "historical_incidents": [{"incident_id": x.incident_id, "attack_type": x.attack_type, "document": x.document,
                                      "similarity_score": x.similarity_score} for x in retrieval.results]}


def local_analysis(evidence: dict) -> Analysis:
    prediction, risk = evidence["prediction"], evidence["risk"]
    category = prediction["predicted_attack_type"]
    f = evidence["observed_features"]
    observed = [f"Destination port: {int(f['destination_port'])}.",
                f"Packet rate: {f['flow_packets_s']:.4g} packets/s; byte rate: {f['flow_bytes_s']:.4g} bytes/s.",
                f"Flow duration: {f['flow_duration']:.4g} microseconds."]
    investigate, mitigation = PLAYBOOKS.get(category, ("Correlate network alerts with endpoint and service logs.", "Review validated network and endpoint controls."))
    inference = f"The supervised model predicts {category} with {prediction['classification_confidence']:.1%} confidence. This is a model inference requiring analyst validation."
    limitations = ["Flow records alone cannot establish host compromise, intent, or attribution.",
                   "Model probabilities reflect a class-sampled training distribution and are not calibrated deployment probabilities.",
                   "Anomaly percentile measures unusualness relative to benign training flows."]
    limitations.extend(evidence.get("retrieval_limitations", []))
    missing = [x for x, present in evidence["metadata_availability"].items() if not present]
    if missing:
        limitations.append("Missing metadata: " + ", ".join(missing) + ".")
    if prediction["missing_features"]:
        limitations.append(f"{len(prediction['missing_features'])} model features are unavailable and use training medians; confidence may be unreliable.")
    if prediction["out_of_range_features"]:
        limitations.append("Features outside training ranges: " + ", ".join(prediction["out_of_range_features"]) + ".")
    history = [x["incident_id"] for x in evidence["historical_incidents"]]
    if not history:
        limitations.append("Insufficient evidence: no matching historical incidents were retrieved.")
    basis = f"Model inference: {category}; triage policy: {risk['priority']} ({risk['severity']})."
    containment = ("After validating impact and scope, consider temporary traffic restrictions or host isolation through the approved incident process."
                   if category != "BENIGN" else "Maintain monitoring; validate evidence before considering any containment.")
    missing_context = [name for name in ("source_ip", "destination_ip", "protocol", "timestamp")
                       if not evidence["metadata_availability"].get(name)]
    context_action = ("Collect missing event context: " + ", ".join(missing_context) + "; correlate service and endpoint logs."
                      if missing_context else "Correlate the supplied event metadata with service, authentication, and endpoint logs to establish scope.")
    return Analysis(executive_summary=f"{inference} Triage score is {risk['risk_score']:.2f}/100, {risk['severity']} severity, {risk['priority']} priority.",
                    observed_evidence=observed, model_inference=inference, historical_incident_ids=history,
                    immediate_investigation=[Action(action=investigate, evidence=basis),
                                             Action(action="Inspect related IDS and firewall events and preserve the original flow evidence.", evidence=observed[1])],
                    containment_considerations=[Action(action=containment, evidence=basis)],
                    further_evidence=[Action(action=context_action, evidence="Flow measurements and event metadata alone cannot confirm host compromise or business impact.")],
                    longer_term_mitigation=[Action(action=mitigation, evidence=f"Suggested follow-up for the inferred {category} category; confirm applicability.")],
                    evidence_limitations=limitations)


def validate_grounding(analysis: Analysis, evidence: dict) -> None:
    validate_analysis_content(analysis)
    available = {x["incident_id"] for x in evidence["historical_incidents"]}
    if not set(analysis.historical_incident_ids) <= available:
        raise ValueError("Generated analysis cites unknown historical incident IDs")
    serialized = analysis.model_dump_json()
    mentioned = set(re.findall(r"CIC-[A-Za-z0-9_-]+", serialized))
    if not mentioned <= available:
        raise ValueError("Generated prose cites unknown historical incident IDs")
    source = json.dumps(evidence)
    if not set(re.findall(r"CVE-\d{4}-\d+", serialized)) <= set(re.findall(r"CVE-\d{4}-\d+", source)):
        raise ValueError("Generated analysis cites unsupported CVEs")
    if "risk" in evidence:
        scores = re.findall(r"\b(?:risk|triage)\s+score\s*(?:is|of|:)?\s*(\d+(?:\.\d+)?)", serialized, re.I)
        if any(abs(float(score) - evidence["risk"]["risk_score"]) > 0.51 for score in scores):
            raise ValueError("Generated narrative changes the calculated triage score")
    if re.search(r"run\s+(this\s+)?(exploit|payload)|disable\s+(all\s+)?(logging|security)|steal\s+credentials", serialized, re.I):
        raise ValueError("Generated actions are outside defensive assistance")


class RecommendationService:
    def __init__(self, config: Settings):
        self.config = config
        self.circuit = ProviderCircuit(config.llm_failure_threshold, config.llm_cooldown_seconds)

    def generate(self, evidence: dict, query: str, use_llm: bool = True) -> tuple[Analysis, str]:
        query = validate_query(query)
        fallback = local_analysis(evidence)
        if not use_llm or self.config.llm_provider == "local":
            return fallback, "local_evidence_playbook"
        if not self.config.credentials_configured:
            fallback.evidence_limitations.append("The configured provider API key is missing; a local evidence-based playbook was used.")
            return fallback, "local_fallback"
        def request_analysis():
            analysis = generate_structured(self.config, ANALYST_SYSTEM,
                                           {"query_data": query, "evidence_data": evidence}, Analysis)
            validate_grounding(analysis, evidence)
            return analysis

        try:
            return self.circuit.call(request_analysis), self.config.llm_provider
        except Exception as error:
            logger.warning(json.dumps({"event": "llm_fallback", "error_type": type(error).__name__}))
            fallback.evidence_limitations.append("The configured LLM was unavailable or its output failed validation; a local evidence-based playbook was used. " + provider_failure_reason(error))
            return fallback, "local_fallback"
