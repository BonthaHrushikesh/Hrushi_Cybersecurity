# Guardrails And Fallbacks

Requests use strict Pydantic schemas. Unknown fields, label leakage, invalid IPs,
ports, protocols, timezone-free timestamps, inconsistent ports, nonfinite values,
negative traffic measurements, and missing required traffic features are rejected
with HTTP 422. Validation responses omit input payloads.

Queries are normalized with Unicode NFKC. Control and invisible formatting
characters, common instruction overrides, offensive payload requests, and common
credential formats are rejected. These checks complement the instruction/data
boundary in the analyst and judge prompts; pattern matching cannot detect every
possible injection or secret format.

Request bodies are limited to 65,536 bytes by default, counting actual received
bytes even without Content-Length. Oversized bodies receive HTTP 413 before
parsing or model execution. Configure MAX_REQUEST_BYTES in the environment.

Generated recommendations must satisfy the Analysis schema and content bounds.
They must contain observed evidence, investigation actions, and limitations.
Unknown historical citations, unsupported CVEs, changed narrative triage scores,
unsafe action patterns, and common credential formats trigger fallback. These
structural checks do not prove every natural-language statement is correct;
the optional evidence-aware LLM judge supplies a separate quality assessment.

The recommendation and judge services each maintain an independent, process-local
circuit breaker. Provider calls use LLM_TIMEOUT_SECONDS (default 20 seconds) with
SDK retries disabled. This is a provider network timeout, not a hard total
investigation deadline. After LLM_FAILURE_THRESHOLD consecutive failures (default
3), calls skip the provider for LLM_COOLDOWN_SECONDS (default 60). One recovery
probe is allowed after the cooldown; success restores normal calls.

Timeouts, rate limits, authentication failures, refusals, malformed output, and
grounding failures produce analysis_provider=local_fallback with an explicit
limitation. The deterministic playbook retains calculated predictions and risk,
uses only retrieved historical IDs, and explains missing evidence. It does not
claim to be an LLM. Local mode or use_llm=false selects local_evidence_playbook.

An unconfigured judge returns not_configured. A failed judge returns unavailable
with empty dimensions, never fabricated quality scores. A missing model/index
returns HTTP 503; classifications and model scores are never invented to hide
missing artifacts. No response action is executed automatically.

Regression coverage is in tests/test_guardrails.py, tests/test_providers.py, and
tests/test_resilience.py. Provider tests use mocked responses and require no key.
