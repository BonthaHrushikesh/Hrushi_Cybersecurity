import numpy as np
import pandas as pd

from ml.preprocess import prepare_dataset


def test_preparation_handles_nonfinite_duplicates_and_preserves_labels(tmp_path):
    rows = [{"Destination Port": 80, "Flow Duration": i + 100, "Flow Packets/s": i + 1, "Flow Bytes/s": i * 10,
             "Attack Type": "Normal Traffic" if i < 30 else "DDoS"} for i in range(60)]
    rows += [rows[0].copy(), {**rows[1], "Destination Port": 99999}, {**rows[2], "Flow Bytes/s": np.inf}]
    source = tmp_path / "flows.csv"
    pd.DataFrame(rows).to_csv(source, index=False)
    profile = prepare_dataset(source, tmp_path / "processed", per_class=100)
    assert profile["rows_scanned"] == 63
    assert profile["invalid_port_rows_removed"] == 1
    assert profile["nonfinite_values_replaced"] == 1
    assert profile["sample_duplicates_removed"] == 1
    output = pd.read_csv(tmp_path / "processed/incidents.csv")
    assert set(output["original_label"]) == {"Normal Traffic", "DDoS"}
    assert set(output["attack_category"]) == {"BENIGN", "DDoS"}
    assert output["flow_bytes_s"].isna().sum() == 1
