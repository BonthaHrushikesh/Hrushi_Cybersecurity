import { useMutation, useQueryClient } from '@tanstack/react-query'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { investigationApi } from '../api'
import { AnalysisStageLoader } from '../components/investigation/AnalysisStageLoader'
import { InvestigationForm } from '../components/investigation/InvestigationForm'
import { PageHeader } from '../components/ui'
import { demoHistorical } from '../demo/data'
import { useApiResource } from '../hooks/useApiResource'
import type { InvestigationRequest } from '../types'

export function InvestigatePage() {
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const runJudge = params.get('judge') === 'true'
  const queryClient = useQueryClient()
  const samples = useApiResource(['samples'], investigationApi.samples, [demoHistorical])
  const mutation = useMutation({
    mutationFn: investigationApi.investigate,
    onSuccess: result => {
      sessionStorage.setItem(`investigation:${result.incident_id}`, JSON.stringify(result))
      for (const key of ['latest-workflow', 'metrics', 'incident-list']) {
        void queryClient.invalidateQueries({ queryKey: [key] })
      }
      navigate(`/incidents/${encodeURIComponent(result.incident_id)}`)
    },
  })
  const submit = (request: InvestigationRequest) => mutation.mutate(request)
  return <div>
    <PageHeader eyebrow="Multi-agent workflow" title="Investigate Network Flow" description="Validate a CIC-IDS2017-compatible flow, classify the attack pattern, retrieve similar incidents, and generate evidence-linked response guidance." />
    {mutation.isPending ? <AnalysisStageLoader /> : <InvestigationForm key={String(runJudge)} initialJudge={runJudge} samples={samples.data} pending={mutation.isPending} onSubmit={submit} />}
    {mutation.isError && <div className="mt-4 rounded-lg border border-red-400/25 bg-red-400/[.06] p-4 text-sm text-red-300">The live investigation failed. Check API readiness and verify every required feature is present.</div>}
  </div>
}
