from contextlib import contextmanager
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
from src.api.schemas import FeedbackRequest, InvestigationResult


class Repository:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS investigations (
                    incident_id TEXT PRIMARY KEY, created_at TEXT NOT NULL,
                    request_json TEXT NOT NULL, result_json TEXT NOT NULL,
                    attack_type TEXT NOT NULL, priority TEXT NOT NULL, risk_score REAL NOT NULL
                );
                CREATE TABLE IF NOT EXISTS feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    incident_id TEXT NOT NULL REFERENCES investigations(incident_id),
                    created_at TEXT NOT NULL, helpful INTEGER NOT NULL,
                    corrected_attack_type TEXT, corrected_severity TEXT, comment TEXT NOT NULL,
                    review_status TEXT NOT NULL DEFAULT 'pending'
                );
                CREATE TABLE IF NOT EXISTS interaction_feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    interaction_type TEXT NOT NULL CHECK (interaction_type IN ('ai_analyst', 'rag_search')),
                    context TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    helpful INTEGER NOT NULL,
                    comment TEXT NOT NULL DEFAULT '',
                    review_status TEXT NOT NULL DEFAULT 'pending'
                );
            """)

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA journal_mode=WAL")
        try:
            yield db
            db.commit()
        finally:
            db.close()

    def save(self, request: dict, result: InvestigationResult):
        with self.connection() as db:
            db.execute("INSERT INTO investigations VALUES (?, ?, ?, ?, ?, ?, ?)",
                       (result.incident_id, result.created_at, json.dumps(request), result.model_dump_json(),
                        result.prediction.predicted_attack_type, result.risk.priority, result.risk.risk_score))

    def get(self, incident_id: str) -> dict | None:
        with self.connection() as db:
            row = db.execute("SELECT result_json FROM investigations WHERE incident_id=?", (incident_id,)).fetchone()
        return json.loads(row["result_json"]) if row else None

    def list_investigations(self, limit: int = 200, offset: int = 0, query: str = "", sort: str = "time") -> dict:
        orders = {"time": "created_at DESC, incident_id DESC",
                  "risk": "risk_score DESC, created_at DESC, incident_id DESC"}
        if sort not in orders or limit < 1 or offset < 0:
            raise ValueError("Invalid investigation pagination or sort")
        where = "WHERE instr(lower(incident_id || ' ' || attack_type || ' ' || priority), lower(?)) > 0"
        search = query.strip()
        with self.connection() as db:
            total = db.execute(f"SELECT COUNT(*) FROM investigations {where}", (search,)).fetchone()[0]
            rows = db.execute(f"""SELECT incident_id, created_at, attack_type, priority, risk_score
                                  FROM investigations {where} ORDER BY {orders[sort]} LIMIT ? OFFSET ?""",
                              (search, limit, offset)).fetchall()
        return {"items": [dict(row) for row in rows], "total": total}

    def feedback(self, request: FeedbackRequest) -> int:
        created_at = datetime.now(timezone.utc).isoformat()
        if request.incident_id:
            if self.get(request.incident_id) is None:
                raise KeyError(request.incident_id)
            with self.connection() as db:
                cursor = db.execute("INSERT INTO feedback (incident_id, created_at, helpful, corrected_attack_type, corrected_severity, comment) VALUES (?, ?, ?, ?, ?, ?)",
                                    (request.incident_id, created_at, request.helpful,
                                     request.corrected_attack_type, request.corrected_severity, request.comment))
                return int(cursor.lastrowid)
        with self.connection() as db:
            cursor = db.execute("INSERT INTO interaction_feedback (interaction_type, context, created_at, helpful, comment) VALUES (?, ?, ?, ?, ?)",
                                (request.interaction_type, request.context, created_at, request.helpful, request.comment))
            return int(cursor.lastrowid)

    def list_feedback(self) -> list[dict]:
        with self.connection() as db:
            rows = db.execute("""SELECT * FROM (
                SELECT id, 'investigation' AS context_type, incident_id, incident_id AS context,
                       created_at, helpful, corrected_attack_type, corrected_severity, comment, review_status
                FROM feedback
                UNION ALL
                SELECT id, interaction_type AS context_type, NULL AS incident_id, context,
                       created_at, helpful, NULL AS corrected_attack_type, NULL AS corrected_severity,
                       comment, review_status
                FROM interaction_feedback
            ) ORDER BY created_at DESC, id DESC LIMIT 200""").fetchall()
        return [dict(row) for row in rows]

    def review_feedback(self, feedback_id: int, status: str):
        if status not in {"approved", "rejected"}:
            raise ValueError("Review status must be approved or rejected")
        with self.connection() as db:
            cursor = db.execute("UPDATE feedback SET review_status=? WHERE id=?", (status, feedback_id))
            if cursor.rowcount != 1:
                raise KeyError(feedback_id)

    def reviewed_rows(self) -> list[dict]:
        with self.connection() as db:
            rows = db.execute("""SELECT f.*, i.request_json, i.result_json FROM feedback f
                                 JOIN investigations i ON i.incident_id=f.incident_id
                                 WHERE f.review_status='approved' AND f.corrected_attack_type IS NOT NULL ORDER BY f.id""").fetchall()
        return [dict(x) for x in rows]

    def metrics(self) -> dict:
        with self.connection() as db:
            total = db.execute("SELECT COUNT(*) FROM investigations").fetchone()[0]
            attacks = dict(db.execute("SELECT attack_type, COUNT(*) FROM investigations GROUP BY attack_type").fetchall())
            priorities = dict(db.execute("SELECT priority, COUNT(*) FROM investigations GROUP BY priority").fetchall())
            recent = [dict(x) for x in db.execute("SELECT incident_id, created_at, attack_type, priority, risk_score FROM investigations ORDER BY created_at DESC LIMIT 20")]
            feedback = db.execute("SELECT (SELECT COUNT(*) FROM feedback) + (SELECT COUNT(*) FROM interaction_feedback)").fetchone()[0]
            quality = dict(db.execute("""SELECT
                COALESCE(AVG(risk_score), 0) AS mean_risk_score,
                COALESCE(AVG(json_extract(result_json, '$.latency_ms')), 0) AS mean_latency_ms,
                COALESCE(SUM(json_array_length(json_extract(result_json, '$.prediction.missing_features')) > 0), 0) AS incomplete_flows,
                COALESCE(SUM(json_array_length(json_extract(result_json, '$.prediction.out_of_range_features')) > 0), 0) AS out_of_range_flows,
                COALESCE(SUM(json_extract(result_json, '$.analysis_provider') = 'local_fallback'), 0) AS llm_fallbacks
                FROM investigations""").fetchone())
        return {"total_analyzed": total, "benign": attacks.get("BENIGN", 0), "malicious": total - attacks.get("BENIGN", 0),
                "attack_distribution": attacks, "priority_distribution": priorities, "recent_incidents": recent, "feedback_count": feedback,
                "operational_quality": quality}
