from dataclasses import replace
import json

from fastapi.testclient import TestClient

from src.utils.config import settings
from src.api.application import create_app
from src.api.schemas import HistoricalIncident, InvestigationResult
from src.services.retrieval import summarize_history


def history_record(incident_id, category, severity, score, timestamp):
    return HistoricalIncident(incident_id=incident_id, attack_type=category, original_label=category,
                              metadata={"timestamp": timestamp}, features={}, document="Synthetic unit fixture only.",
                              severity=severity, risk_score=score, risk_source="historical_label_prior")


def test_historical_summary_preserves_counts_and_unknown_capture_times():
    rows = [history_record("CIC-benign", "BENIGN", "LOW", 0, "2017-07-03T10:00:00Z"),
            history_record("CIC-ddos", "DDoS", "CRITICAL", 90, "2017-07-04T00:00:00+02:00"),
            history_record("CIC-bot", "Bot", "CRITICAL", 80, None),
            history_record("CIC-naive", "BENIGN", "LOW", 0, "2017-07-03T12:00:00")]
    result = summarize_history(rows)
    assert result.total_records == 4 and result.malicious == 2 and result.benign == 2
    assert result.attack_distribution == {"BENIGN": 2, "Bot": 1, "DDoS": 1}
    assert result.severity_distribution == {"LOW": 2, "CRITICAL": 2}
    assert result.timestamp_missing == 2
    assert result.activity[0].time == "2017-07-03" and result.activity[0].incidents == 2
    assert result.recent_records[0].incident_id == "CIC-ddos"
    assert all(record.timestamp is None for record in result.recent_records if record.incident_id in {"CIC-bot", "CIC-naive"})
    assert all(record.risk_source == "historical_label_prior" for record in result.recent_records)


def test_empty_history_does_not_invent_records():
    result = summarize_history([])
    assert result.total_records == result.benign == result.malicious == 0
    assert result.activity == result.recent_records == []


def test_dashboard_history_is_available_without_saved_investigations(tmp_path, investigation):
    for name in ["models", "index", "evaluation"]:
        (tmp_path / name).symlink_to(settings.artifacts / name, target_is_directory=True)
    config = replace(settings, artifacts=tmp_path, llm_provider="local")
    with TestClient(create_app(config)) as client:
        before = client.get("/api/v1/metrics").json()
        assert before["total_analyzed"] == before["malicious"] == before["benign"] == 0
        history = before["historical_summary"]
        assert history["total_records"] == before["indexed_incidents"] > 0
        assert history["malicious"] > 0
        assert history["malicious"] + history["benign"] == history["total_records"]
        assert sum(history["attack_distribution"].values()) == history["total_records"]
        assert sum(history["severity_distribution"].values()) == history["total_records"]
        assert sum(row["incidents"] for row in history["activity"]) + history["timestamp_missing"] == history["total_records"]
        assert len(history["recent_records"]) <= 20
        assert client.get("/api/v1/incidents/" + history["recent_records"][0]["incident_id"]).status_code == 200
        client.app.state.services.repository.save({}, InvestigationResult.model_validate(investigation))
        after = client.get("/api/v1/metrics").json()
        assert after["total_analyzed"] == 1 and after["malicious"] == 1
        assert after["historical_summary"] == history


def test_metrics_exposes_local_evaluation_reports_and_sanitized_provider_status(tmp_path, monkeypatch):
    from src.services.models import ModelService

    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-only-key")
    config = replace(settings, artifacts=tmp_path, llm_provider="anthropic")
    for name in ["models", "index"]:
        (tmp_path / name).symlink_to(settings.artifacts / name, target_is_directory=True)
    directory = tmp_path / "evaluation"
    directory.mkdir()
    version = ModelService(settings.artifacts).bundle["version"]
    reports = {"retrieval": {"model_version": version, "status": "completed", "query_count": 42, "metrics": {"precision_at_k": .9}},
               "deepeval": {"model_version": version, "case_count": 9, "llm_metrics_status": "not_run_offline"},
               "provider_connection": {"provider": "anthropic", "generation_model": config.generation_model,
                                       "judge_model": config.evaluation_model, "credential_fingerprint": config.credential_fingerprint,
                                       "status": "failed", "http_status": 401}}
    for name, report in reports.items():
        (directory / f"{name}.json").write_text(json.dumps(report))
    with TestClient(create_app(config)) as client:
        result = client.get("/api/v1/metrics")
        assert result.status_code == 200
        reports["provider_connection"].pop("credential_fingerprint")
        assert result.json()["evaluation"] == reports
