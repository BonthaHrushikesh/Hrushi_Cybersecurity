import pytest

def test_status_reports_configuration_without_secrets(client, monkeypatch):
    monkeypatch.setenv('OPENAI_API_KEY', 'private-test-secret')
    response = client.get('/api/v1/system/status')
    assert response.status_code == 200
    data = response.json()
    assert data['ready'] and data['llm_provider'] == 'local'
    assert not data['llm_credentials_configured']
    assert data['provider_connectivity'] == 'not_required'
    assert data['circuits']['rag']['state'] == 'closed'
    assert 'private-test-secret' not in response.text


def test_quoted_csv_import_preserves_features_and_ignores_label(client):
    text = '"Destination Port","Flow Duration","Flow Packets/s","Flow Bytes/s","Fwd IAT Mean","Label"\n80,1000,10,500,30,"Web Attack, historical label"\n'
    response = client.post('/api/v1/flows/parse', json={'csv_text': text})
    assert response.status_code == 200
    features = response.json()['features']
    assert features['fwd_iat_mean'] == 30
    assert 'label' not in features
    assert 'syn_flag_count' not in features


@pytest.mark.parametrize('text', [
    'Destination Port,Flow Duration,Flow Packets/s,Flow Bytes/s\n80,1,NaN,10',
    'Destination Port,Flow Duration,Flow Packets/s,Flow Bytes/s\n80,1,2',
    'Destination Port,Flow Duration,Flow Packets/s,Flow Bytes/s,flow_duration\n80,1,2,3,4',
    'Destination Port,Flow Duration\n80,1',
    'Destination Port,Flow Duration,Flow Packets/s,Flow Bytes/s\n80,1,"2,3',
])
def test_invalid_csv_import(client, text):
    assert client.post('/api/v1/flows/parse', json={'csv_text': text}).status_code == 422


def test_report_export_contains_measured_record_and_limits(client, investigation):
    response = client.get(f"/api/v1/incidents/{investigation['incident_id']}/report")
    assert response.status_code == 200
    assert 'attachment' in response.headers['content-disposition']
    assert investigation['incident_id'] in response.text
    assert investigation['prediction']['model_version'] in response.text
    assert 'Evidence Limitations' in response.text
    assert 'not_configured' in response.text
    assert client.get('/api/v1/incidents/missing/report').status_code == 404


def test_operational_quality_is_computed_from_records(client, investigation):
    metrics = client.get('/api/v1/metrics').json()
    quality = metrics['operational_quality']
    assert 0 <= quality['mean_risk_score'] <= 100
    assert quality['mean_latency_ms'] > 0
    assert quality['incomplete_flows'] <= metrics['total_analyzed']


def test_unexpected_errors_keep_request_id_and_hide_details(client, monkeypatch):
    def fail(*args):
        raise RuntimeError('private-test-secret')
    monkeypatch.setattr(client.app.state.services.retrieval, 'search', fail)
    response = client.post('/api/v1/search', json={'query': 'DDoS traffic'})
    assert response.status_code == 500
    assert response.headers['X-Request-ID']
    assert 'private-test-secret' not in response.text


def test_nan_risk_configuration_is_rejected():
    from dataclasses import replace
    from src.utils.config import settings
    with pytest.raises(ValueError, match='RISK_WEIGHTS'):
        replace(settings, risk_weights=(float('nan'), .15, .05, .25, .15))
