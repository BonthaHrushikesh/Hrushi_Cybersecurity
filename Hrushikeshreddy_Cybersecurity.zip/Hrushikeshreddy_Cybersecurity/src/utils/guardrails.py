import re
import unicodedata

from starlette.responses import JSONResponse


def validate_query(query: str) -> str:
    if any(unicodedata.category(char) in {"Cc", "Cf", "Cs"} for char in query):
        raise ValueError("Query cannot contain control or invisible formatting characters")
    query = unicodedata.normalize("NFKC", query).strip()
    if len(query) < 3 or len(query) > 1000:
        raise ValueError("Query must contain 3 to 1000 non-whitespace characters")
    if re.search(r"ignore\s+(all\s+)?(previous|prior|system)\s+instructions|reveal\s+(the\s+)?(system\s+prompt|api\s+key)|<\|?(system|assistant)|execute\s+(shell|code)|\b(build|write|generate)\b.{0,25}\b(ransomware|malware|exploit payload)\b", query, re.I):
        raise ValueError("Query must request defensive incident analysis")
    if re.search(r"\bsk-[A-Za-z0-9_-]{16,}|\bBearer\s+[A-Za-z0-9_.-]{16,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----", query, re.I):
        raise ValueError("Remove credentials or private keys from the query")
    return query


def validate_analysis_content(analysis) -> None:
    data = analysis.model_dump()
    for name in ("executive_summary", "model_inference"):
        if not data[name].strip() or len(data[name]) > 6000:
            raise ValueError("Generated summary is empty or too large")
    for name, value in data.items():
        if isinstance(value, list):
            if len(value) > 30:
                raise ValueError("Generated analysis contains too many entries")
            for item in value:
                texts = item.values() if isinstance(item, dict) else [item]
                if any(not text.strip() or len(text) > 4000 for text in texts):
                    raise ValueError("Generated analysis contains empty or oversized entries")
    if not analysis.observed_evidence or not analysis.immediate_investigation or not analysis.evidence_limitations:
        raise ValueError("Generated analysis omits evidence, investigation actions, or limitations")
    if re.search(r"\bsk-[A-Za-z0-9_-]{16,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----", analysis.model_dump_json()):
        raise ValueError("Generated analysis contains credentials")


class RequestSizeLimitMiddleware:
    """Bound actual body bytes, including requests without Content-Length."""

    def __init__(self, app, max_bytes: int):
        self.app, self.max_bytes = app, max_bytes

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["method"] not in {"POST", "PUT", "PATCH"}:
            await self.app(scope, receive, send)
            return
        messages, size = [], 0
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            size += len(message.get("body", b""))
            if size > self.max_bytes:
                await JSONResponse({"detail": "Request body exceeds the configured size limit"}, status_code=413)(scope, receive, send)
                return
            messages.append(message)
            if not message.get("more_body", False):
                break

        async def replay():
            return messages.pop(0) if messages else await receive()

        await self.app(scope, replay, send)
