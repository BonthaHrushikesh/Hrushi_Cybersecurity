import argparse
from collections import Counter
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd

from src.utils.features import EXTRA_FEATURES, FEATURE_NAMES, attack_category, flow_signatures, normalize_column


def export_signatures(path: Path, encoding: str):
    hashes, counts = [], Counter()
    raw_rows = unlabelled = 0
    for chunk in pd.read_csv(path, chunksize=100_000, low_memory=False, encoding=encoding):
        chunk.columns = [normalize_column(name) for name in chunk]
        columns = [name for name in FEATURE_NAMES + EXTRA_FEATURES if name in chunk]
        raw_rows += len(chunk)
        labels = chunk["label"].astype("string").str.strip()
        valid = labels.notna() & labels.ne("").fillna(False)
        unlabelled += int((~valid).sum())
        chunk = chunk.loc[valid]
        labels = labels.loc[valid].astype(str)
        if chunk.empty:
            continue
        counts.update(labels)
        families = labels.map({label: attack_category(label) for label in labels.unique()})
        identity = pd.DataFrame({"flow_signature": flow_signatures(chunk, columns), "attack_category": families})
        hashes.append(pd.util.hash_pandas_object(identity, index=False).to_numpy())
    return np.sort(np.concatenate(hashes)), dict(counts), columns, {"raw_rows": raw_rows, "unlabelled_rows": unlabelled}


def compare(primary: Path, secondary: Path, output: Path, encoding="utf-8-sig", secondary_encoding: str | None = None):
    first = {path.name: path for path in primary.rglob("*.csv")}
    second = {path.name: path for path in secondary.rglob("*.csv")}
    reports = []
    for name in sorted(first.keys() & second.keys()):
        left, left_labels, left_columns, left_stats = export_signatures(first[name], encoding)
        right, right_labels, right_columns, right_stats = export_signatures(second[name], secondary_encoding or encoding)
        exact = left_columns == right_columns and np.array_equal(left, right)
        left_unique, right_unique = np.unique(left), np.unique(right)
        common = len(np.intersect1d(left_unique, right_unique, assume_unique=True)) if left_columns == right_columns else 0
        reports.append({"file": name, "primary_rows": left_stats["raw_rows"], "secondary_rows": right_stats["raw_rows"],
                        "primary_labelled_rows": len(left), "secondary_labelled_rows": len(right),
                        "primary_unlabelled_rows": left_stats["unlabelled_rows"], "secondary_unlabelled_rows": right_stats["unlabelled_rows"],
                        "same_normalized_flow_multiset": exact,
                        "matching_unique_flow_signatures": common, "primary_unique_signatures": len(left_unique),
                        "secondary_unique_signatures": len(right_unique),
                        "primary_unique_signature_overlap": common / len(left_unique) if len(left_unique) else 0,
                        "primary_original_labels": left_labels, "secondary_original_labels": right_labels})
        print(json.dumps({"file": name, "rows": len(left), "same_normalized_flow_multiset": exact}), flush=True)
    report = {"status": "completed", "primary": str(primary), "secondary": str(secondary),
              "comparison": "Multiset of labeled normalized numeric flow signatures and canonical attack categories; row order is ignored and unlabeled rows are separately counted.",
              "all_paired_exports_match": bool(reports) and not (first.keys() ^ second.keys()) and all(row["same_normalized_flow_multiset"] for row in reports),
              "unpaired_files": sorted(first.keys() ^ second.keys()), "files": reports,
              "decision": "Primary metadata-retaining records are used for training/history; counterpart exports are cross-checked, not appended as duplicate training rows.",
              "limitations": ["64-bit feature hashes are a practical equality check, not a cryptographic data-integrity proof.",
                              "Canonical attack categories can group multiple original subtypes; original-label counts remain visible."]}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2))
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Cross-check CIC traffic and ML exports without duplicating their records.")
    parser.add_argument("--primary", type=Path, required=True)
    parser.add_argument("--secondary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--encoding", default="utf-8-sig")
    parser.add_argument("--secondary-encoding", help="Use when the counterpart export has different text encoding")
    args = parser.parse_args()
    result = compare(args.primary, args.secondary, args.output, args.encoding, args.secondary_encoding)
    print(json.dumps({"status": result["status"], "all_paired_exports_match": result["all_paired_exports_match"], "paired_files": len(result["files"])}))
