from contextlib import nullcontext
from dataclasses import replace
import json
from types import SimpleNamespace

import pytest

from src.utils.config import settings
from src.api.schemas import Analysis, JudgeDimensions, JudgeOutput, JudgeScore, RAGAnswer, RAGRequest
from src.services.llm_provider import generate_structured
from src.services.rag_answers import RAGAnswerService
from src.services.recommendations import RecommendationService
from src.agents.quality_judge import DIMENSIONS, JudgeService
from scripts.check_llm_connection import save_probe


@pytest.fixture
def claude_config(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-only-key")
    return replace(settings, llm_provider="anthropic", anthropic_model="claude-sonnet-4-6",
                   anthropic_judge_model="claude-haiku-4-5-20251001", llm_failure_threshold=1)


def mock_claude(monkeypatch, parse):
    import anthropic
    constructors = []

    def create(**kwargs):
        constructors.append(kwargs)
        return nullcontext(SimpleNamespace(messages=SimpleNamespace(parse=parse)))

    monkeypatch.setattr(anthropic, "Anthropic", create)
    return constructors


def evidence_for(investigation):
    return {"prediction": investigation["prediction"], "risk": investigation["risk"],
            "observed_features": {"destination_port": 80, "flow_duration": 100,
                                  "flow_packets_s": 2, "flow_bytes_s": 100},
            "metadata_availability": {},
            "historical_incidents": [{"incident_id": hit["incident_id"]} for hit in investigation["retrieval"]["results"]]}


def test_claude_configuration_uses_its_own_key(claude_config, monkeypatch):
    assert claude_config.generation_model == "claude-sonnet-4-6"
    assert claude_config.evaluation_model == "claude-haiku-4-5-20251001"
    assert claude_config.credentials_configured
    monkeypatch.delenv("ANTHROPIC_API_KEY")
    monkeypatch.setenv("OPENAI_API_KEY", "unrelated-test-key")
    assert not claude_config.credentials_configured
    assert not replace(claude_config, llm_provider="local").credentials_configured


def test_claude_analysis_structured_contract(monkeypatch, investigation, claude_config):
    output = Analysis.model_validate(investigation["analysis"])
    calls = []

    def parse(**kwargs):
        calls.append(kwargs)
        return SimpleNamespace(parsed_output=output, stop_reason="end_turn")

    constructors = mock_claude(monkeypatch, parse)
    analysis, provider = RecommendationService(claude_config).generate(evidence_for(investigation), "Investigate this flow")
    assert provider == "anthropic" and analysis == output
    assert constructors == [{"timeout": claude_config.llm_timeout_seconds, "max_retries": 0}]
    assert calls[0]["model"] == claude_config.generation_model
    assert calls[0]["output_format"] is Analysis
    assert calls[0]["max_tokens"] == 4096
    assert "untrusted DATA" in calls[0]["system"]
    payload = json.loads(calls[0]["messages"][0]["content"])
    assert payload["query_data"] == "Investigate this flow"
    assert "test-only-key" not in json.dumps(payload)


@pytest.mark.parametrize("failure", ["timeout", "refusal", "max_tokens", "missing", "invented_citation"])
def test_claude_invalid_output_and_errors_preserve_fallback(monkeypatch, investigation, claude_config, failure):
    output = Analysis.model_validate(investigation["analysis"])
    if failure == "invented_citation":
        output.historical_incident_ids = ["CIC-fabricated"]
    calls = []

    def parse(**kwargs):
        calls.append(kwargs)
        if failure == "timeout":
            raise TimeoutError("private-provider-detail")
        return SimpleNamespace(parsed_output=None if failure == "missing" else output,
                               stop_reason=failure if failure in {"refusal", "max_tokens"} else "end_turn")

    mock_claude(monkeypatch, parse)
    service = RecommendationService(claude_config)
    for _ in range(2):
        analysis, provider = service.generate(evidence_for(investigation), "Investigate this flow")
        assert provider == "local_fallback"
        assert analysis.immediate_investigation
        assert "private-provider-detail" not in analysis.model_dump_json()
        assert "CIC-fabricated" not in analysis.historical_incident_ids
    assert len(calls) == 1


def test_claude_judge_uses_separate_model(monkeypatch, investigation, claude_config):
    output = JudgeOutput(dimensions=JudgeDimensions(**{
        name: JudgeScore(score=4, reason="Mocked provider contract") for name in DIMENSIONS}))
    calls = []

    def parse(**kwargs):
        calls.append(kwargs)
        return SimpleNamespace(parsed_output=output, stop_reason="end_turn")

    mock_claude(monkeypatch, parse)
    result = JudgeService(claude_config).evaluate(Analysis.model_validate(investigation["analysis"]), {"marker": "source-evidence"})
    assert result.status == "completed" and result.provider == "anthropic"
    assert set(result.dimensions) == DIMENSIONS
    assert calls[0]["model"] == claude_config.evaluation_model
    assert calls[0]["output_format"] is JudgeOutput
    assert "source-evidence" in calls[0]["messages"][0]["content"]


def test_claude_judge_failure_is_not_a_score(monkeypatch, investigation, claude_config):
    def parse(**kwargs):
        raise RuntimeError("private-provider-detail")

    mock_claude(monkeypatch, parse)
    result = JudgeService(claude_config).evaluate(Analysis.model_validate(investigation["analysis"]), {})
    assert result.status == "unavailable" and result.provider == "anthropic"
    assert result.dimensions == {}
    assert "private-provider-detail" not in result.model_dump_json()


@pytest.mark.parametrize("invented", [False, True])
def test_claude_rag_validates_inline_citations(client, monkeypatch, claude_config, invented):
    request = RAGRequest(query="Investigate historical DDoS flows")
    retrieval = client.app.state.services.retrieval.search(request)
    incident_id = "CIC-fabricated" if invented else retrieval.results[0].incident_id
    output = RAGAnswer(answer=f"Historical flow [{incident_id}] needs validation.", cited_incident_ids=[incident_id],
                       evidence_gaps=["Flow-only evidence is limited."], recommended_next_steps=["Correlate service logs."])
    mock_claude(monkeypatch, lambda **kwargs: SimpleNamespace(parsed_output=output, stop_reason="end_turn"))
    result = RAGAnswerService(claude_config).answer(request, retrieval)
    assert result.provider == ("local_fallback" if invented else "anthropic")
    assert "CIC-fabricated" not in result.analysis.model_dump_json()


def test_claude_sdk_parses_actual_http_response(monkeypatch, claude_config):
    import anthropic
    import httpx2

    real_client = anthropic.Anthropic
    output = RAGAnswer(answer="Insufficient evidence.", cited_incident_ids=[],
                       evidence_gaps=["No history."], recommended_next_steps=["Collect logs."])
    requests = []

    def respond(request):
        requests.append(json.loads(request.content))
        return httpx2.Response(200, json={"id": "msg_fixture", "type": "message", "role": "assistant",
                                         "model": claude_config.generation_model,
                                         "content": [{"type": "text", "text": output.model_dump_json()}],
                                         "stop_reason": "end_turn", "stop_sequence": None,
                                         "usage": {"input_tokens": 10, "output_tokens": 10}})

    monkeypatch.setattr(anthropic, "Anthropic", lambda **kwargs: real_client(
        api_key="test-only-key", http_client=httpx2.Client(transport=httpx2.MockTransport(respond)), **kwargs))
    result = generate_structured(claude_config, "Defensive evidence only.", {"question_data": "Investigate"}, RAGAnswer)
    assert result == output
    assert requests[0]["output_config"]["format"]["type"] == "json_schema"


@pytest.mark.parametrize("fails", [False, True])
def test_authentication_probe_hides_provider_details(monkeypatch, claude_config, fails, tmp_path):
    import anthropic

    def list_models(**kwargs):
        if fails:
            raise RuntimeError("private-provider-detail")
        return SimpleNamespace(data=[])

    monkeypatch.setattr(anthropic, "Anthropic", lambda **kwargs: nullcontext(
        SimpleNamespace(models=SimpleNamespace(list=list_models))))
    result = save_probe(replace(claude_config, artifacts=tmp_path))
    assert result["status"] == ("failed" if fails else "authenticated")
    assert "private-provider-detail" not in json.dumps(result)
    assert "test-only-key" not in json.dumps(result)
    saved = (tmp_path / "evaluation/provider_connection.json").read_text()
    assert json.loads(saved) == result
    assert "private-provider-detail" not in saved and "test-only-key" not in saved
    assert result["created_at"]
