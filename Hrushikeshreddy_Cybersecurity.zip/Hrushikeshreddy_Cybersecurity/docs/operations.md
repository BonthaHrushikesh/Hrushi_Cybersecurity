# Operations And Panel Readiness

## Startup

For submission without a hosted key, run `.venv/bin/python scripts/start_local.py --restart --offline`.
This selects local providers for the process and leaves the private .env unchanged.
For future hosted use, omit --offline after configuring and validating credentials.
Canonical entry point: uvicorn src.main:app; app.main:app remains compatible. The script selects free
ports, prints URLs, and records owned process IDs in artifacts/runtime.json.
Startup allows 60 seconds for both services; override with --startup-timeout
when necessary (maximum 300 seconds). Failed startup cleans up its child processes.
Only recorded processes with matching project commands/directories are stopped.
Logs are in artifacts/backend.log and artifacts/frontend.log. Configure provider
keys only in the backend .env; never put them in frontend environment variables.

## Readiness And Quality

/health reports model/index availability. /api/v1/system/status reports provider
names, key presence, request limits, and circuit state without revealing keys.
Key presence does not prove provider connectivity; no paid probe runs automatically.
Missing/corrupt artifacts leave diagnostics accessible and return setup-required
HTTP 503 for analysis. Settings shows effective deployment status.

Complete sample/imported feature dictionaries are retained, including measurements
outside visible controls. Absent optional values stay missing. CSV import uses
the standard CSV parser and validates the first row; labels never enter model
features. The frontend accepts small flow files. Prepare large datasets offline.

Saved retrieval count and semantic weight affect Threat Search, AI Analyst, and
new investigation forms. Auto-refresh governs operational resource queries.
Invalid browser preferences revert to validated defaults.

Dashboard quality counters report incomplete flows, values outside training
ranges, LLM fallbacks, and mean risk/latency. These are descriptive signals, not
a statistical drift test. Workflow steps show degraded response execution and
unconfigured/unavailable judge status. Incident details download a Markdown
report with fixed predictions, risk, citations, explanations, and limitations.

The dashboard opens with indexed historical traffic: known dataset labels,
capture-day activity, label-prior severity, and real historical record links.
The Investigations tab separately displays saved analyses and policy priorities.
Importing a dataset does not create completed investigations. The metrics API
keeps existing operational counters intact and adds historical_summary, computed
from the loaded retrieval records; counts are not fabricated or mixed with the
full-source scan totals. Unknown or timezone-free capture times stay unknown.

Pages show explicit loading or unavailable states. Demo resource fallback data
is used only with VITE_DEMO_MODE=true after a failed request. Live API failures
must not silently replace metrics with sample figures.

## Verification And Recovery

Run pytest, frontend lint/tests/build, and scripts/verify_ui.py. Browser evidence
is saved to artifacts/figures/. GitHub Actions prepares the real-data demo in a
fresh environment and verifies both services after the repository is pushed;
adding a workflow does not claim a hosted run passed.

scripts/run_demo.py always uses the local response provider, and browser
verification unchecks both generation and judging controls before submission.
They make no remote LLM calls even when an API key is configured. Use the separate
verify_live_llm.py command only after approving transmission of incident evidence
and any paid calls. Explicit offline DeepEval runs report not_run_offline.

Evaluation reports belong to the active ARTIFACT_DIR, not the legacy model's
artifact folder. After preparing or switching datasets, run the local checks:

```sh
.venv/bin/python evaluation/retrieval_metrics.py
.venv/bin/python evaluation/advanced_retrieval.py
.venv/bin/python evaluation/deepeval_runner.py --offline
.venv/bin/python scripts/check_llm_connection.py
.venv/bin/python scripts/check_prd_readiness.py
```

The connection check uses the provider's models endpoint without incident data
or paid generation. It saves a sanitized status, error type, HTTP status, model names, check time,
and a private credential fingerprint used to invalidate stale checks. The
fingerprint is excluded from API responses and submission archives; bodies and
keys are excluded. Offline local connectivity is not_required, not a failed check.
The Evaluation page has a refresh control and follows the auto-refresh setting.
Missing scores show Not measured rather than 0%. Offline case checks do not
satisfy live generation, live judge, or DeepEval LLM quality requirements.
A 401 authentication result requires replacing the credential privately in
.env, restarting the backend, and rechecking authentication. Only after consent
to paid calls and evidence transmission should verify_live_llm.py --deepeval run.

Workflow statuses describe the saved request, not current configuration.
Response degraded means local recommendations were retained after a requested
LLM failed. Judge not_requested means judge=false; unavailable means a requested
judge failed and produced no quality scores. Optional workflow step detail fields
retain sanitized failure categories; incident details and exported reports also
show judge limitations. Older saved traces remain readable and are not rewritten.
The workflow page's Run workflow action opens a new investigation with judging
selected, but sends nothing until the analyst submits. Ordinary investigation
forms still default to judge=false. Loading another sample preserves the chosen
LLM/judge toggles; a successful new investigation invalidates cached workflow,
incident-list, and dashboard data. Refreshing an old trace does not rerun agents.

Back up processed data, model/index artifacts, and the database together. Stop
servers before a filesystem database backup or use SQLite's online backup API;
copying only the main database during writes can omit the WAL journal. Restore
compatible model/index artifacts together, then check model version and index
count. Candidate models remain separate until evaluated and reviewed.

## Panel Demonstration

1. Show Settings readiness and the configured provider.
2. Investigate a complete DDoS sample; inspect prediction, risk, and SHAP.
3. Compare keyword and advanced hybrid search with attack/port filters.
4. Ask AI Analyst a defensive question and inspect citations.
5. Show measured strategy comparison and actual judge/provider status.
6. Download a report and submit pending analyst feedback.

Use local mode for an offline demo. Configure a key for real LLM generation and
judging, then verify the returned provider. Local extraction and structural
metrics are not live LLM results. Public deployment still requires identity/access
controls, transport security, workload limits, and independent traffic validation.
