import json
from pathlib import Path
import threading

import joblib
import numpy as np

from src.utils.features import feature_frame
from src.api.schemas import AnomalyResult, Explanation, FeatureContribution, FlowInput, Prediction


class ModelService:
    def __init__(self, artifacts: Path):
        self.bundle = joblib.load(artifacts / "models/bundle.joblib")
        self.metadata = json.loads((artifacts / "models/metadata.json").read_text())
        self._explainer = None
        self._lock = threading.Lock()

    def frame(self, flow: FlowInput):
        return feature_frame([flow.features], self.bundle["raw_features"])

    def classify(self, flow: FlowInput) -> Prediction:
        model = self.bundle["classifier"]
        frame = self.frame(flow)
        probabilities = model.predict_proba(frame)[0]
        mapping = {str(label): float(value) for label, value in zip(model.classes_, probabilities)}
        label = max(mapping, key=mapping.get)
        intrusion = self.bundle.get("intrusion_classifier")
        if intrusion is None:
            malicious_probability = 1 - mapping.get("BENIGN", 0)
        else:
            intrusion_probabilities = intrusion.predict_proba(frame)[0]
            malicious_index = list(intrusion.named_steps["model"].classes_).index(1)
            malicious_probability = float(intrusion_probabilities[malicious_index])
        outliers = []
        for feature, value in flow.features.items():
            if feature in self.bundle["training_ranges"]:
                low, high = self.bundle["training_ranges"][feature]
                if value < low or value > high:
                    outliers.append(feature)
        return Prediction(
            predicted_attack_type=label, classification_confidence=mapping[label],
            malicious_probability=malicious_probability, probabilities=mapping,
            model_version=self.bundle["version"],
            missing_features=[x for x in self.bundle["raw_features"] if x not in flow.features or flow.features[x] < 0],
            out_of_range_features=outliers,
        )

    def anomaly(self, flow: FlowInput) -> AnomalyResult:
        score = float(-self.bundle["anomaly"].score_samples(self.frame(flow))[0])
        reference = self.bundle["anomaly_reference_scores"]
        percentile = float(np.searchsorted(reference, score, side="right") / len(reference))
        return AnomalyResult(anomaly_score=score, normalized_anomaly_risk=percentile, is_anomalous=percentile >= 0.95,
                             interpretation="Percentile relative to benign training flows; unusual traffic is not proof of an attack.")

    def explain(self, flow: FlowInput, prediction: Prediction | None = None) -> Explanation:
        import shap

        prediction = prediction or self.classify(flow)
        pipeline = self.bundle["classifier"]
        estimator = pipeline.named_steps["model"]
        observed_frame = self.frame(flow)
        transformed = pipeline.named_steps["imputer"].transform(observed_frame)
        with self._lock:
            if self._explainer is None:
                self._explainer = shap.TreeExplainer(estimator)
            values = np.asarray(self._explainer.shap_values(transformed))
            class_index = list(estimator.classes_).index(prediction.predicted_attack_type)
            contributions = values[0, :, class_index]
            base = float(np.asarray(self._explainer.expected_value)[class_index])
        observed = observed_frame.iloc[0].to_dict()
        items = [FeatureContribution(feature=name, observed_value=float(observed[name]) if np.isfinite(observed[name]) else None, shap_value=float(value),
                                     direction="supports" if value >= 0 else "opposes")
                 for name, value in zip(self.bundle["model_features"], contributions)]
        items.sort(key=lambda x: abs(x.shap_value), reverse=True)
        return Explanation(method="TreeSHAP", predicted_class=prediction.predicted_attack_type, base_value=base,
                           predicted_probability=prediction.classification_confidence,
                           reconstructed_probability=base + float(contributions.sum()), contributions=items,
                           explanation="SHAP values explain the predicted class probability relative to the model baseline. Correlated features share attribution; contributions are not causal proof.")
