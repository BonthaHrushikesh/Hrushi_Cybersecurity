# Evaluation Report

Participant: Hrushikeshreddy. Snapshot: 11 October 2026.
Active model: **cicids-aa6f46dbeb**, metadata-rich CIC-IDS2017 sampled run.
Portable demo metrics differ from the full sampled run.

## ML Evaluation

20,273 prepared records, 77 raw + 3 derived features, nine categories.
Random Forest selected by validation macro F1 (0.9851 versus Extra Trees 0.9675),
then refit on 16,218 rows. Final holdout: 4,055, excluded from model selection/index.

| Held-out metric | Result |
|---|---:|
| Attack accuracy | 0.9921085 |
| Attack macro F1 | 0.9743258 |
| Binary intrusion accuracy | 0.9930949 |
| Binary intrusion ROC AUC | 0.9961082 |
| Anomaly ROC AUC | 0.7627583 |

Heartbleed support two, F1 1.0; Infiltration support seven, recall 0.7143,
F1 0.8333. Tiny supports and random sampled splits limit generalization.
Complete classification reports contain supports, confusion matrix, seed,
splits, feature order, model comparison, and provenance.

## Retrieval Evaluation

Corpus: 16,218 training/validation flows (1,592 benign, 14,626 attack-labeled).
Forty-two held-out queries, K=5. Same-category membership is a coarse relevance proxy.

| Strategy | Precision@5 |
|---|---:|
| Unassisted weighted LSA + BM25 | 0.6285714 |
| Model-assisted keyword | 0.9428571 |
| Model-assisted weighted hybrid | 0.9523810 |
| Model-assisted advanced RAG | 0.9523810 |

Assisted hit rate/MRR: 0.9523810; baseline hit rate: 0.6904762, MRR: 0.6130952.
Assisted recall: 0.0409892 against all same-category corpus documents.
Assisted query vocabulary can reinforce classifier errors; report both baselines.
Retrieval agreement does not measure factual correctness of generated prose.

## DeepEval And Judge

Nine real pipeline cases cover the available categories. Offline custom DeepEval
checks validate section completeness and citation membership only. They do not
measure faithfulness, usefulness, or every factual statement. Offline output is
separate from live quality artifacts and cannot overwrite them.

Implemented hosted metrics: answer relevancy, faithfulness, contextual precision,
contextual recall, hallucination. The separate LLM judge has seven evidence-aware
1-5 dimensions. Successful measurement and passing thresholds are different.

**Latest Claude authentication: HTTP 401.** Live generation, live judge scores,
and hosted DeepEval quality scores remain unverified. No scores are fabricated.
A valid key and explicit consent to send bounded incident evidence are needed.

## Regression And Verification

Release checks: 173 backend tests and 20 React tests passed; lint/build and
desktop/mobile browser checks passed with zero browser errors. The actual ZIP
was extracted into a temporary directory, its real portable sample trained all
nine categories, and all 173 backend tests passed there too. This uses the current
Python dependency environment, not a claimed fresh dependency installation.
The source snapshot and result are in docs/evidence/submission_verification.json.

pytest covers schemas/guardrails, ML/SHAP, risk, real hybrid retrieval, metadata,
workflow contracts, provider fallbacks, feedback candidate isolation, import,
historical dashboards, private credential redaction, report provenance, and
offline/live artifact separation. React unit tests, lint, production build,
and desktop/mobile browser checks supplement API coverage.
Final verification counts are in SUBMISSION_CHECKLIST.md.

Reproduce using README commands. Docker/hosted CI are optional and were not
verified as runtime deployments. Authentication, realistic calibration,
time/host-disjoint validation, and larger rare-class testing remain future work.
