import { Check, LoaderCircle } from 'lucide-react'
import { useEffect, useState } from 'react'

const stages = ['Validating traffic features', 'Running attack classification', 'Scoring anomaly and risk', 'Retrieving historical incidents', 'Building grounded recommendations']

export function AnalysisStageLoader() {
  const [active, setActive] = useState(0)
  useEffect(() => { const id = window.setInterval(() => setActive(value => Math.min(value + 1, stages.length - 1)), 850); return () => window.clearInterval(id) }, [])
  return <div className="panel p-6" role="status" aria-live="polite">
    <div className="mb-5 flex items-center gap-3"><LoaderCircle className="animate-spin text-brightGold"/><div><h2 className="font-semibold">Investigation in progress</h2><p className="text-xs text-zinc-500">Coordinating detection, retrieval, risk, and response agents.</p></div></div>
    <div className="space-y-3">{stages.map((stage,index)=><div key={stage} className={`flex items-center gap-3 rounded-lg border px-4 py-3 text-sm ${index<=active?'border-gold/20 bg-gold/[.04] text-zinc-200':'border-white/[.05] text-zinc-600'}`}>{index<active?<Check size={16} className="text-emerald-400"/>:<LoaderCircle size={16} className={index===active?'animate-spin text-gold':'text-zinc-700'}/>}<span>{stage}</span></div>)}</div>
  </div>
}
