export type Severity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
export type Priority = 'P1' | 'P2' | 'P3' | 'P4'
export type Protocol = 'TCP' | 'UDP' | 'ICMP'

export interface NetworkMetadata {
  flow_id?: string | null
  source_ip?: string | null; destination_ip?: string | null
  source_port?: number | null; destination_port?: number | null
  protocol?: Protocol | null; timestamp?: string | null
  source_timestamp?: string | null
}

export interface NetworkFlow { features: Record<string, number>; metadata?: NetworkMetadata }
export interface ClassificationResult {
  predicted_attack_type: string; classification_confidence: number; malicious_probability: number
  probabilities: Record<string, number>; model_version: string; missing_features: string[]; out_of_range_features: string[]
}
export interface AnomalyResult { anomaly_score: number; normalized_anomaly_risk: number; is_anomalous: boolean; interpretation: string }
export interface RiskAssessment { risk_score: number; severity: Severity; priority: Priority; components: Record<string, number>; weights: Record<string, number>; explanation: string }
export interface SHAPFeature { feature: string; observed_value: number | null; shap_value: number; direction: string }
export interface Explanation { method: string; predicted_class: string; base_value: number; predicted_probability: number; reconstructed_probability: number; contributions: SHAPFeature[]; explanation: string }
export interface HistoricalIncident {
  incident_id: string; attack_type: string; original_label: string; metadata: NetworkMetadata; features: Record<string, number>
  document: string; severity: Severity; risk_score: number; risk_source: string
}
export interface SearchHit extends HistoricalIncident { similarity_score: number; semantic_score: number; keyword_score: number; normalized_keyword_score: number }
export interface SearchResult { results: SearchHit[]; alpha: number; embedding_provider: string; latency_ms: number; limitations: string[] }
export interface Recommendation { action: string; evidence: string }
export interface Analysis {
  executive_summary: string; observed_evidence: string[]; model_inference: string; historical_incident_ids: string[]
  immediate_investigation: Recommendation[]; containment_considerations: Recommendation[]
  further_evidence: Recommendation[]; longer_term_mitigation: Recommendation[]; evidence_limitations: string[]
}
export interface WorkflowStep { agent: string; status: string; latency_ms: number; tools: string[]; detail?: string | null }
export interface InvestigationResult {
  incident_id: string; created_at: string; prediction: ClassificationResult; anomaly: AnomalyResult; risk: RiskAssessment
  explanation: Explanation; retrieval: SearchResult; analysis: Analysis; analysis_provider: string
  judge: { status: string; provider: string; dimensions: Record<string, { score: number; reason: string }>; limitation?: string | null } | null
  workflow: WorkflowStep[]; latency_ms: number
}
export interface InvestigationRequest { query: string; flow: NetworkFlow; top_k?: number; alpha?: number; filters?: SearchFilters; use_llm?: boolean; judge?: boolean }
export interface SearchFilters extends NetworkMetadata { attack_type?: string | null; severity?: Severity | null; min_risk_score?: number | null; timestamp_min?: string | null; timestamp_max?: string | null }
export type RetrievalMode = 'hybrid' | 'keyword' | 'semantic'
export interface SearchRequest { query: string; top_k?: number; alpha?: number; filters?: SearchFilters; mode?: RetrievalMode; fusion?: 'weighted' | 'rrf'; expand_query?: boolean; diversify?: boolean }
export interface RAGResult { analysis: { answer: string; cited_incident_ids: string[]; evidence_gaps: string[]; recommended_next_steps: string[] }; retrieval: SearchResult; provider: string; context_incident_ids: string[] }
export type FeedbackInteractionType = 'ai_analyst' | 'rag_search'
export interface FeedbackRequest { incident_id?: string; interaction_type?: FeedbackInteractionType; context?: string; helpful: boolean; corrected_attack_type?: string | null; corrected_severity?: Severity | null; comment?: string }
export interface Feedback { id: number; context_type: 'investigation' | FeedbackInteractionType; incident_id?: string | null; context: string; created_at: string; helpful: number; corrected_attack_type?: string | null; corrected_severity?: Severity | null; comment: string; review_status: string }
export interface SystemHealth { status: string; models_ready: boolean; index_ready: boolean; model_version: string | null }
export interface ModelInfo { ready: boolean; metadata: ModelMetadata }
export interface ModelMetadata {
  name?: string; version?: string; training_date?: string; classes?: string[]; global_importance?: Array<{feature: string; importance: number}>
  test_metrics?: Record<string, unknown>; confusion_matrix?: number[][]; [key: string]: unknown
}
export interface IncidentSummary { incident_id: string; created_at: string; attack_type: string; priority: Priority; risk_score: number; request?: InvestigationRequest; result?: InvestigationResult }
export interface HistoricalFlowSummary { incident_id: string; timestamp: string | null; attack_type: string; severity: Severity; risk_score: number; risk_source: string }
export interface HistoricalMetrics {
  total_records: number; benign: number; malicious: number; attack_distribution: Record<string, number>; severity_distribution: Record<string, number>
  activity: Array<{ time: string; incidents: number }>; timestamp_missing: number; recent_records: HistoricalFlowSummary[]
}
export interface Metrics {
  historical_summary?: HistoricalMetrics | null
  operational_quality?: { mean_risk_score: number; mean_latency_ms: number; incomplete_flows: number; out_of_range_flows: number; llm_fallbacks: number }
  total_analyzed: number; benign: number; malicious: number; attack_distribution: Record<string, number>; priority_distribution: Record<string, number>
  recent_incidents: IncidentSummary[]; feedback_count: number; indexed_incidents: number; dataset_profile: Record<string, unknown>; evaluation: Record<string, unknown>
}
export interface GlobalExplanation { global_importance: Array<{feature: string; importance: number}>; importance_method: string; attack_patterns: Record<string, Record<string, number | null>>; limitations?: string[]; note: string }
export interface IncidentListResponse { items: IncidentSummary[]; total: number }
export interface IncidentListParams { limit?: number; offset?: number; query?: string; sort?: 'time' | 'risk' }
export interface SystemStatus { ready: boolean; setup_issue: string | null; embedding_provider: string | null; indexed_incidents: number; model_version: string | null; llm_provider: string; llm_credentials_configured: boolean; llm_model: string; judge_model: string; provider_connectivity: string; provider_connection?: Record<string, unknown>; circuits: Record<string, { state: string; consecutive_failures: number; retry_after_seconds: number } | null>; limits: { max_request_bytes: number; llm_timeout_seconds: number } }
