import { RotateCcw, Search, SlidersHorizontal } from 'lucide-react'
import { useMemo, useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { searchApi } from '../api'
import { ATTACK_TYPES } from '../constants'
import { EmptyState, PageHeader, Panel, SeverityBadge, AttackBadge } from '../components/ui'
import type { SearchFilters, RetrievalMode } from '../types'
import { formatPercent } from '../utils/format'
import { useSettings } from '../store/settings'

const severities = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] as const

function localDateTime(value?: string | null) {
  if (!value) return ''
  const date = new Date(value)
  return new Date(date.getTime() - date.getTimezoneOffset() * 60_000).toISOString().slice(0, 16)
}

function utcDateTime(value: string) {
  return value ? new Date(value).toISOString() : null
}

export function SearchPage() {
  const settings = useSettings()
  const [query, setQuery] = useState('high-volume TCP traffic targeting a web service')
  const [filters, setFilters] = useState<SearchFilters>({})
  const [filtersOpen, setFiltersOpen] = useState(false)
  const [mode, setMode] = useState<RetrievalMode>('hybrid')
  const [advanced, setAdvanced] = useState(true)
  const mutation = useMutation({ mutationFn: searchApi.search })
  const activeFilterCount = useMemo(
    () => Object.values(filters).filter(value => value !== null && value !== undefined && value !== '').length,
    [filters],
  )

  const setFilter = <K extends keyof SearchFilters>(key: K, value: SearchFilters[K]) => {
    setFilters(current => ({ ...current, [key]: value }))
  }
  const submit = () => mutation.mutate({ query, top_k: settings.resultCount, alpha: settings.hybridAlpha, filters, mode, fusion: advanced ? 'rrf' : 'weighted', expand_query: advanced, diversify: advanced })

  return <div>
    <PageHeader eyebrow="Hybrid retrieval" title="Threat Search" description="Search historical incidents using semantic similarity, keyword relevance, and structured metadata filters." />
    <Panel title="Search Historical Incidents" eyebrow="Semantic + BM25">
      <div className="flex flex-col gap-3 lg:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 text-zinc-600" size={17} />
          <input
            value={query}
            onChange={event => setQuery(event.target.value)}
            onKeyDown={event => { if (event.key === 'Enter') submit() }}
            className="field pl-10"
            placeholder="Describe suspicious activity, behavior, or indicators..."
          />
        </div>
        <button type="button" onClick={() => setFiltersOpen(open => !open)} className="btn-secondary" aria-expanded={filtersOpen}>
          <SlidersHorizontal size={15} />
          Filters{activeFilterCount > 0 ? ` (${activeFilterCount})` : ''}
        </button>
        <button onClick={submit} disabled={query.trim().length < 3 || mutation.isPending} className="btn-primary">
          <Search size={15} />{mutation.isPending ? 'Searching...' : 'Search'}
        </button>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-4">
        <label><span className="label">Retrieval mode</span><select className="field" value={mode} onChange={event => setMode(event.target.value as RetrievalMode)}><option value="hybrid">Hybrid</option><option value="keyword">Keyword / BM25</option><option value="semantic">Semantic</option></select></label>
        <label className="flex items-center gap-2 text-sm text-zinc-400"><input type="checkbox" checked={advanced} onChange={event => setAdvanced(event.target.checked)} className="accent-[#D4AF37]" />Advanced ranking</label>
      </div>
      {filtersOpen && <div className="mt-5 border-t border-white/[.07] pt-5">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          <label><span className="label">Attack type</span><select className="field" value={filters.attack_type || ''} onChange={event => setFilter('attack_type', event.target.value || null)}><option value="">Any attack</option>{ATTACK_TYPES.map(attack => <option key={attack}>{attack}</option>)}</select></label>
          <label><span className="label">Severity</span><select className="field" value={filters.severity || ''} onChange={event => setFilter('severity', (event.target.value || null) as SearchFilters['severity'])}><option value="">Any severity</option>{severities.map(severity => <option key={severity}>{severity}</option>)}</select></label>
          <label><span className="label">Protocol</span><select className="field" value={filters.protocol || ''} onChange={event => setFilter('protocol', (event.target.value || null) as SearchFilters['protocol'])}><option value="">Any protocol</option><option>TCP</option><option>UDP</option><option>ICMP</option></select></label>
          <label><span className="label">Source IP</span><input className="field font-mono" value={filters.source_ip || ''} onChange={event => setFilter('source_ip', event.target.value || null)} placeholder="192.0.2.10" /></label>
          <label><span className="label">Destination IP</span><input className="field font-mono" value={filters.destination_ip || ''} onChange={event => setFilter('destination_ip', event.target.value || null)} placeholder="198.51.100.20" /></label>
          <label><span className="label">Source port</span><input type="number" min="0" max="65535" className="field" value={filters.source_port ?? ''} onChange={event => setFilter('source_port', event.target.value ? Number(event.target.value) : null)} /></label>
          <label><span className="label">Destination port</span><input type="number" min="0" max="65535" className="field" value={filters.destination_port ?? ''} onChange={event => setFilter('destination_port', event.target.value ? Number(event.target.value) : null)} /></label>
          <label><span className="label">Minimum risk</span><input type="number" min="0" max="100" className="field" value={filters.min_risk_score ?? ''} onChange={event => setFilter('min_risk_score', event.target.value ? Number(event.target.value) : null)} /></label>
          <label><span className="label">Observed after</span><input type="datetime-local" className="field" value={localDateTime(filters.timestamp_min)} onChange={event => setFilter('timestamp_min', utcDateTime(event.target.value))} /></label>
          <label><span className="label">Observed before</span><input type="datetime-local" className="field" value={localDateTime(filters.timestamp_max)} onChange={event => setFilter('timestamp_max', utcDateTime(event.target.value))} /></label>
        </div>
        <div className="mt-4 flex justify-end">
          <button type="button" className="btn-secondary" disabled={activeFilterCount === 0} onClick={() => setFilters({})}><RotateCcw size={15} />Clear filters</button>
        </div>
      </div>}
    </Panel>

    {mutation.isError && <div className="mt-5 rounded-lg border border-red-400/20 bg-red-400/[.05] p-4 text-sm text-red-300">{mutation.error.message}</div>}
    {mutation.data && <Panel title="Search Results" eyebrow={`${mutation.data.results.length} matches · ${mutation.data.latency_ms.toFixed(0)} ms`} className="mt-5">
      {mutation.data.results.length === 0 ? <EmptyState /> : <div className="space-y-3">{mutation.data.results.map(hit => <Link to={`/incidents/${encodeURIComponent(hit.incident_id)}`} key={hit.incident_id} className="block rounded-lg border border-white/[.07] bg-black/20 p-4 transition hover:border-gold/30">
        <div className="flex flex-wrap items-center gap-2"><AttackBadge attack={hit.attack_type} /><SeverityBadge severity={hit.severity} /><span className="ml-auto font-mono text-sm text-gold">{formatPercent(hit.similarity_score)} match</span></div>
        <p className="mt-3 text-sm text-zinc-400">{hit.document}</p>
        <div className="mt-3 flex flex-wrap gap-4 text-xs text-zinc-600"><span>Semantic {formatPercent(hit.semantic_score)}</span><span>Keyword {hit.keyword_score.toFixed(2)}</span><span>Risk {hit.risk_score.toFixed(0)}</span></div>
      </Link>)}</div>}
    </Panel>}
    {!mutation.data && !mutation.isPending && <div className="mt-5"><EmptyState title="SEARCH READY" description="Enter behavior, indicators, or an attack pattern to retrieve evidence from the historical corpus." action={<SlidersHorizontal className="text-gold" />} /></div>}
  </div>
}
