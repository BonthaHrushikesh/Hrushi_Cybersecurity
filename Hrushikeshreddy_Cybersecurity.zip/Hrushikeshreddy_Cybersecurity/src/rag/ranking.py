import re

import numpy as np


EXPANSIONS = {
    "ddos": "distributed denial of service flooding",
    "dos": "denial of service resource exhaustion",
    "brute force": "authentication password guessing repeated login attempts",
    "password guessing": "brute force authentication",
    "port scan": "portscan reconnaissance service discovery",
    "port scanning": "portscan reconnaissance",
    "botnet": "bot command and control automated host activity",
    "c2": "bot command and control",
    "sqli": "web attack sql injection",
    "xss": "web attack cross site scripting",
    "ssh": "authentication destination port 22",
    "ftp": "authentication destination port 21",
}


def expand_terms(query: str) -> list[str]:
    terms = []
    for phrase, expansion in EXPANSIONS.items():
        if re.search(r"\b" + re.escape(phrase) + r"\b", query, re.I):
            terms.extend(expansion.split())
    return list(dict.fromkeys(terms))[:24]


def reciprocal_rank_fusion(semantic, keyword, alpha, depth=100):
    fused = np.zeros(len(semantic), dtype=float)
    for scores, weight in ((semantic, alpha), (keyword, 1 - alpha)):
        ranked = np.argsort(-scores, kind="stable")
        ranked = ranked[scores[ranked] > 1e-8][:depth]
        for rank, index in enumerate(ranked, 1):
            fused[index] += weight * 61 / (60 + rank)
    return fused


def flow_similarity(observed: dict, historical: dict) -> float:
    distances = []
    for name, value in observed.items():
        if name not in historical or name == "destination_port" or value < 0 or historical[name] < 0:
            continue
        distances.append(abs(np.log1p(value) - np.log1p(historical[name])))
    numeric = float(np.exp(-np.mean(distances))) if distances else 0.0
    if "destination_port" in observed and "destination_port" in historical:
        return 0.85 * numeric + 0.15 * float(observed["destination_port"] == historical["destination_port"])
    return numeric


def select_diverse(candidates, scores, vectors, top_k, diversity=0.15):
    selected = []
    remaining = list(candidates)
    while remaining and len(selected) < top_k:
        if not selected:
            best = remaining[0]
        else:
            def utility(index):
                redundancy = max(float(np.dot(vectors[index], vectors[other])) for other in selected)
                return (1 - diversity) * scores[index] - diversity * max(0, redundancy)
            best = max(remaining, key=utility)
        selected.append(best)
        remaining.remove(best)
    return selected
