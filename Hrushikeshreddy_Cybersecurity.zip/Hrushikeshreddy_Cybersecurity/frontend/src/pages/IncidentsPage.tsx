import { keepPreviousData } from '@tanstack/react-query'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { dashboardApi } from '../api'
import { IncidentTable } from '../components/tables/IncidentTable'
import { ErrorState, LoadingSkeleton, PageHeader, Panel } from '../components/ui'
import { demoMetrics } from '../demo/data'
import { useApiResource } from '../hooks/useApiResource'

const pageSize = 8

export function IncidentsPage() {
  const navigate = useNavigate()
  const [page, setPage] = useState(0)
  const [search, setSearch] = useState('')
  const [sort, setSort] = useState<'time' | 'risk'>('time')
  const demoRows = demoMetrics.recent_incidents
    .filter(item => `${item.incident_id} ${item.attack_type} ${item.priority}`.toLowerCase().includes(search.trim().toLowerCase()))
    .sort((a, b) => sort === 'risk' ? b.risk_score - a.risk_score : Date.parse(b.created_at) - Date.parse(a.created_at))
  const query = useApiResource(
    ['incident-list', String(page), search, sort],
    () => dashboardApi.incidentPage({ limit: pageSize, offset: page * pageSize, query: search, sort }),
    { items: demoRows.slice(page * pageSize, (page + 1) * pageSize), total: demoRows.length },
    { placeholderData: keepPreviousData },
  )

  return <div>
    <PageHeader eyebrow="Case management" title="Incident Explorer" description="Search, sort, and inspect completed investigations with risk-based prioritization." />
    {query.isLoading ? <LoadingSkeleton rows={7} /> : query.isError && !query.data ?
      <ErrorState message="Incident records are unavailable." onRetry={() => query.refetch()} /> :
      <Panel title="Investigations" eyebrow={`${query.data?.total ?? 0} records`}>
        {query.isFetching && <p role="status" className="mb-3 text-xs text-zinc-500">Loading investigations...</p>}
        <IncidentTable
          incidents={query.data?.items ?? []}
          pageSize={pageSize}
          onSelect={id => navigate(`/incidents/${encodeURIComponent(id)}`)}
          serverPagination={{
            page, total: query.data?.total ?? 0, query: search, sort, pending: query.isFetching,
            onPageChange: setPage,
            onQueryChange: value => { setSearch(value); setPage(0) },
            onSortChange: value => { setSort(value); setPage(0) },
          }}
        />
      </Panel>}
  </div>
}
